backend/api/urls.py

  from django.urls import include, path
  from rest_framework.routers import DefaultRouter

  from api.views import ApiViewSet


  app_name = 'api'

  v1_router = DefaultRouter()
  v1_router.register(app_name, ApiViewSet, basename=app_name)

  urlpatterns = [
      path('', include(v1_router.urls))
  ]

backend/api/views.py

  from rest_framework.decorators import action
  from rest_framework.viewsets import ViewSet

  from api import serializers
  from reducers.api import ApiReducer
  from valuation.logger import get_logger
  from users import models
  from users.permissions import IsAuthenticatedAndHasLimit

  class ApiViewSet(ViewSet):

      permission_classes = [IsAuthenticatedAndHasLimit]

      def __init__(self):
          super().__init__()
          self.api_reducer = ApiReducer()
          self.logger = get_logger('ApiViewSet')

      @action(methods=['POST'], detail=False)
      def price(self, request):
          self.logger.info(message='got request for price', request=request.data)
          serializer = serializers.PriceSerializer(data=request.data)
          serializer.is_valid(raise_exception=True)
          query = serializer.validated_data
          user = request.user

          log = models.Logs.objects.create(
              user=user,
              query=query,
              model='api',
              method='price',
          )

          response = self.api_reducer.price(query)
          self.logger.info(message='returned response about price', response=response)

          log.response = response
          log.save()

          return response

backend/valuation/urls.py

  from django.conf import settings
  from django.conf.urls.static import static
  from django.contrib import admin
  from django.urls import path, include

  from valuation.yasg import urlpatterns as doc_urls

  urlpatterns = [
      path('admin/', admin.site.urls),
      path('', include('api.urls')),
      path('', include('estate.urls')),
      path('', include('users.urls')),
  ]

  urlpatterns += doc_urls

  if settings.DEBUG:
      urlpatterns += static(
          settings.MEDIA_URL,
          document_root=settings.MEDIA_ROOT
      )

backend/valuation/yasg.py

  from django.urls import path
  from drf_yasg import openapi
  from drf_yasg.views import get_schema_view
  from rest_framework import permissions

  schema_view = get_schema_view(
      openapi.Info(
          title='...',
          default_version='...',
          description='...',
          terms_of_service='...',
          contact=openapi.Contact(email='...'),
          license=openapi.License(name='...'),
      ),
      public=True,
      permission_classes=(permissions.AllowAny,),
  )

  urlpatterns = [
      path('swagger<format>/', schema_view.without_ui(cache_timeout=0), name='schema-json'),
      path('swagger/', schema_view.with_ui('swagger', cache_timeout=0), name='schema-swagger-ui'),
      path('redoc/', schema_view.with_ui('redoc', cache_timeout=0), name='schema-redoc'),
  ]