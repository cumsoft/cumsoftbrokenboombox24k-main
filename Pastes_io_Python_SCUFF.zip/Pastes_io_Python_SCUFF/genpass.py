# python genpass.py


# generates single password randomly 


import random
import string
import os.path
#random numbers section
num1 = random.randrange(100,500)
number_section =  num1
#random letters section
string.letters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*()'
let1 = random.choice(string.letters)
let2 = random.choice(string.letters)
let3 = random.choice(string.letters)
let4 = random.choice(string.letters)
let5 = random.choice(string.letters)
let6 = random.choice(string.letters)
let7 = random.choice(string.letters)
let8 = random.choice(string.letters)
letters_section = let1 + let2 + let3 + let4 + let5 + let6 + let7 + let8
#letters and numbers combination
password = str(number_section) + letters_section
#input section
password_for = raw_input('This password is for: ')
your_pass =  'Your password for' + ' ' + password_for + ' ' + 'is:' + ' ' + password
print your_pass
#save section
save_path = '/home/ghostproxy/Desktop/wordlists'
name_of_file = raw_input("What is the name of the file: ")
completeName = os.path.join(save_path, name_of_file+".txt")         
file1 = open(completeName, "w")
toFile = your_pass
file1.write(toFile)
file1.close()