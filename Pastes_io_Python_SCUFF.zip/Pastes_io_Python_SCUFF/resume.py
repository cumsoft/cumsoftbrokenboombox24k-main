# Copyright (c) OpenMMLab. All rights reserved.
import os

# from chatbot import Chatbot, Session
# from chat_template import InternLMXComposer7B
from lmdeploy_vl.chatbot import Chatbot, Session
from lmdeploy_vl.chat_template import InternLMXComposer7B
import numpy as np


tritonserver_addr = '0.0.0.0:8001'

chatbot = Chatbot(tritonserver_addr)
decorator = InternLMXComposer7B()

messages = [
    {
        'role': 'user',
        'content': '10+9'
    },
    {'role': 'assistant', 'content': '29'}
]

history_prompt = decorator.messages2prompt(messages, sequence_start=True)
# emb = np.load('ayst.npy')
sess = Session(0)
sess.histories = history_prompt
# sess.history_image_embs = [emb]
chatbot.session = sess
chatbot.resume(0)
print(sess)

# Session(session_id=0, request_id='', histories='meta instruction\nYou are an AI assistant whose name is 浦语.\n- 浦语 is a conversational language model that is developed by Shanghai AI Laboratory (上海人工智能实验室). It is designed to be helpful, honest, and harmless.\n- 浦语 can understand and communicate fluently in the language chosen by the user such as English and 中文.\nconversation\n <|User|>: 10+9<TOKENS_UNUSED_0> <|Bot|>: 29<TOKENS_UNUSED_1>', sequence_length=array(95, dtype=uint32), prompt='', image_embs=[], image_offsets=array([], shape=(1, 0), dtype=int32), response='<TOKENS_UNUSED_1>', history_image_embs=[], status=<StatusCode.TRITON_STREAM_END: 0>)