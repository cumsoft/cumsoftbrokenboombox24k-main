def check_in_system(phone, prefix, index, ACCESS_KEY, SECRET_KEY):
    lead_check_url = f'https://api.leadsquared.com/v2/LeadManagement.svc/RetrieveLeadByPhoneNumber?accessKey={ACCESS_KEY}&secretKey={SECRET_KEY}'
    phone = prefix + phone
    print(f"{index}. Working on student: {phone}")
    response = requests.request("GET", lead_check_url + f'&phone={phone}')

    return response