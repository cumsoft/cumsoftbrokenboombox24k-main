class BoschKitchen(hass.Hass):

  appliances={}
  recall_announcement = 0
  message = ""

  def initialize(self):
    BoschKitchen.recall_announcement = 0
    BoschKitchen.appliances = {
      "oven door": self.get_entity("binary_sensor.bosch_hbl8753uc_68a40e35e446_bsh_common_status_doorstate"),
      "cooktop mode": self.get_entity("sensor.bosch_nitp669suc_68a40e49f847_bsh_common_status_operationstate"),
      "oven timer": self.get_entity("sensor.bosch_hbl8753uc_68a40e35e446_bsh_common_setting_alarmclock"),
      "cooktop timer": self.get_entity("number.bosch_nitp669suc_68a40e49f847_bsh_common_setting_alarmclock")
    }
    # self.log(BoschKitchen.appliances)
    # for s in BoschKitchen.appliances.values():
    #   self.log(s.entity_id + ": " + s.state)
    self.listen_state(self.timer_elapsed, BoschKitchen.appliances["oven timer"].entity_id, new="0")
    self.listen_state(self.timer_elapsed, BoschKitchen.appliances["cooktop timer"].entity_id, new="0")
    self.log("initialization complete, Bosch Kitchen.")
  
  def announce_timer_elapsed(self, **kwargs):
    self.log(kwargs)
    caller=kwargs["caller"]
    blnContinue = True
    if caller == "Bosch Cooktop":
      if self.get_state(BoschKitchen.appliances["cooktop mode"].entity_id) =="BSH.Common.EnumType.OperationState.Inactive":
        blnContinue = False
        self.log("cooktop powered off, cancel timer reminders")
        self.cancel_timer(self.timer_announcement_handle)
        BoschKitchen.recall_announcement = 0
    if blnContinue:
      msg = [f"{caller} timer elapsed"]
      if BoschKitchen.recall_announcement > 0:
        msg.extend([f" for {BoschKitchen.recall_announcement} minute"])
        if  BoschKitchen.recall_announcement > 1:
          msg.extend(["s"])
      self.log(msg)
      self.call_service("var/set", entity_id="var.tts_message", attributes={"message": "".join(msg)})
      self.call_service("script/overhead_announcement")
      self.log("announcement in progress")
      BoschKitchen.recall_announcement += 1

  def oven_door_opened(self, entity, attribute, old, new, kwargs):
    self.log("oven door opened, cancel timer reminders")
    self.cancel_listen_state(self.oven_door)
    self.cancel_timer(self.timer_announcement_handle)
    BoschKitchen.recall_announcement = 0

  def timer_elapsed (self, entity, attribute, old, new, kwargs):
    self.log(f"{entity} timer elapsed")
    if 70 > int(old) > 0:
      call_entity = self.get_entity(entity)
      self.log("timer value: " + call_entity.state)
      if entity==BoschKitchen.appliances["oven timer"].entity_id:
        caller="Bosch oven"
        self.oven_door = self.listen_state(self.oven_door_opened, BoschKitchen.appliances["oven door"].entity_id, new="open")
      elif entity==BoschKitchen.appliances["cooktop timer"].entity_id:
        caller="Bosch cooktop" 
      self.timer_announcement_handle = self.run_every(BoschKitchen.announce_timer_elapsed, "now", 60, caller=caller)