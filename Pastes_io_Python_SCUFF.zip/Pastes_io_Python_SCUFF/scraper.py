from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
from bs4 import BeautifulSoup
import os
import requests
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.chrome.service import Service
import re
import sqlite3
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.color import Color

agent = {"User-Agent": 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36'}
chromedriver = ("/Users/mehmetturkmen/Desktop/chromedriver/chromedriver")
op = webdriver.ChromeOptions()
browser = webdriver.Chrome(executable_path=chromedriver, options=op)
ayrac = "####################################################################################################"

def remove_html_tags(text):
    clean = re.compile('<.*?>')
    return re.sub(clean, '', text)

yenilist = []

search_list = ["https://www.zara.com/tr/tr/kadin-ceketler-l1114.html?v1=2290770",
                "https://www.zara.com/tr/tr/kadin-blazerlar-l1055.html?v1=2290737",
                "https://www.zara.com/tr/tr/kadin-dish-giyim-yelekler-l1204.html?v1=2290782",
                "https://www.zara.com/tr/tr/kadin-elbiseler-l1066.html?v1=2290847",
                "https://www.zara.com/tr/tr/kadin-est-giyim-l1322.html?v1=2291012",
                "https://www.zara.com/tr/tr/kadin-gemlekler-l1217.html?v1=2290933",
                "https://www.zara.com/tr/tr/kadin-tishertler-l1362.html?v1=2290973",
                "https://www.zara.com/tr/tr/kadin-erge-giyim-l1152.html?v1=2291084",
                "https://www.zara.com/tr/tr/kadin-pantolonlar-l1335.html?v1=2291147",
                "https://www.zara.com/tr/tr/kadin-kot-pantolonlar-l1119.html?v1=2291201",
                "https://www.zara.com/tr/tr/kadin-pantolonlar-shortlar-l1355.html?v1=2291272",
                "https://www.zara.com/tr/tr/kadin-etekler-l1299.html?v1=2291246",
                "https://www.zara.com/tr/tr/kadin-basicler-l1050.html?v1=2291284"]

for search_url in search_list:
    browser.get(search_url)
    time.sleep(5)
    browser.maximize_window()
    time.sleep(2)
    

    deger11 = False
    while not deger11:
        try:
            slider = browser.find_elements(By.CLASS_NAME, "view-option-selector-button__icon")
            slider=slider[-1]
            time.sleep(2)
            location = slider.location
            size = slider.size
            w, h = size['width'], size['height']
            time.sleep(3)
            ed = ActionChains(browser)
            ed.double_click(slider).perform()
            time.sleep(3)
            deger11 = True
        except:
            pass

    SCROLL_PAUSE_TIME = 3
    last_height = browser.execute_script("return document.documentElement.scrollHeight")
    while True:
        time.sleep(1)
        browser.execute_script("window.scrollTo(0,document.documentElement.scrollHeight);")
        time.sleep(SCROLL_PAUSE_TIME)

        deger = True
        count = 0
        while deger:
            if count < 12:
                column_class = "product-grid-product--ZOOM3-columns"
            else:
                column_class = "product-grid-product--ZOOM1-columns"

            hflink = browser.find_elements(By.CLASS_NAME, f"product-grid-product._product.{column_class}.product-grid-product--{count}th-column")
            if not hflink:
                break

            for item in hflink:
                urll = item.get_attribute('innerHTML')
                up_to_word = "https://www.zara.com"
                rx_to_first = r'^.*?{}'.format(re.escape(up_to_word))
                urll = re.sub(rx_to_first, '', urll, flags=re.DOTALL).strip()
                try:
                    x = urll.index(".html")
                    yenilist.append("https://www.zara.com" + urll[0:x] + ".html")
                except:
                    pass

            count += 1

        time.sleep(1)
        new_height = browser.execute_script("return document.documentElement.scrollHeight")
        time.sleep(1)
        if new_height == last_height:
            print("break")
            break

        time.sleep(1)
        last_height = new_height

os.chdir("/Users/mehmetturkmen/Desktop/db")
con = sqlite3.connect("zaraeticaretsearchyeni.db")
#con = sqlite3.connect("zaraeticaretceket.db")

cursor = con.cursor()


def tablo_olustur():
    cursor.execute("CREATE TABLE IF NOT EXISTS veriler(etiket TEXT,link TEXT,isim TEXT,fiyat INT,renk TEXT,kumas TEXT,aciklama TEXT,klasman TEXT,beden TEXT)")


def deger_ekle(etiket, link, isim, fiyat, renk, kumas, aciklama, klasman, beden):
    cursor.execute("INSERT INTO veriler VALUES ('{} ','{}','{}','{}','{}','{}','{}','{}','{}')".format(etiket, link, isim, fiyat, renk, kumas, aciklama, klasman, beden))
    con.commit()


tablo_olustur()

yenilist = list(set(yenilist))
print(len(yenilist))

for i in yenilist:
    browser.get(i)
    try:
        hflink = browser.find_elements(By.CLASS_NAME, "product-detail-color-selector__color")
        if hflink:
            for i in hflink:
                i.click()
                time.sleep(1)

                indirlist = []
                yenlist1 = []
                yenlist2 = []
                yenlist3 = []
                yenlist4 = []
                yenlist5 = []
                yenlist7 = []
                yenlist8 = []
                yenlist9 = []
                yenlist10 = []
                deger1 = False
                sayicounter = 20

                while not deger1:
                    try:
                        bilgi = browser.find_elements(By.CLASS_NAME, "structured-component-text-block-paragraph")
                        isim = browser.find_elements(By.CLASS_NAME, "product-detail-info__header")
                        renk = browser.find_elements(By.CLASS_NAME, "product-color-extended-name.product-detail-color-selector__selected-color-name")
                        otherrenk = browser.find_elements(By.CLASS_NAME, "product-detail-color-selector__color-area")
                        fiyat = browser.find_elements(By.CLASS_NAME, "product-detail-info__price")
                        ressim = browser.find_elements(By.CLASS_NAME, "media__wrapper.media__wrapper--fill.media__wrapper--force-height")
                        urun_aciklama = browser.find_elements(By.CLASS_NAME, "expandable-text__inner-content")
                        beden_bilgisi = browser.find_elements(By.CLASS_NAME, "product-size-info__main-label")
                        sayicounter -= 1

                        if bilgi and isim and renk and fiyat and ressim:
                            deger1 = True
                        elif sayicounter == 0:
                            deger1 = True
                        else:
                            pass
                    except:
                        continue

                for i in ressim:
                    ext = [i.get_attribute('innerHTML')]
                    for yext in ext:
                        try:
                            x = yext.index("1700w,")
                            y = yext.index("2048w")
                            indirlist.append(yext[x + 7:y].strip())
                        except:
                            pass

                for bdn in beden_bilgisi:
                    bdnn = bdn.get_attribute("innerHTML")
                    bdnhx = bdn.value_of_css_property("color")
                    hex_color = Color.from_string(bdnhx).hex
                    if hex_color == "#000000":
                        bdn_list = f"{bdnn}: mevcut"
                    else:
                        bdn_list = f"{bdnn}: mevcut_degil"
                    yenlist9.append(remove_html_tags(bdn_list))

                for isi in isim:
                    ext = [isi.get_attribute('innerHTML')]
                    for yext in ext:
                        yext = remove_html_tags(yext)
                        yenlist2.append(yext)

                for fi in fiyat:
                    fext = [fi.get_attribute('innerHTML')]
                    for yfext in fext:
                        yfext = remove_html_tags(yfext)
                        yenlist4.append(yfext)

                for aci in urun_aciklama:
                    acixt = [aci.get_attribute('innerHTML')]
                    for yacixt in acixt:
                        yacixt = remove_html_tags(yacixt)
                        yenlist8.append(yacixt)

                for irenk in renk:
                    rext = [irenk.get_attribute('innerHTML')]
                    for yrext in rext:
                        yrext = remove_html_tags(yrext)
                        yenlist3.append(yrext)

                for oirenk in otherrenk:
                    orext = [oirenk.get_attribute('innerHTML')]
                    for oyrext in orext:
                        oyrext = remove_html_tags(oyrext)
                        yenlist7.append(oyrext)

                for ip in bilgi:
                    text = [ip.get_attribute('innerHTML')]
                    for ytext in text:
                        ytext = remove_html_tags(ytext)
                        yenlist1.append(ytext)

                for uzunluk in indirlist:
                    if len(uzunluk) < 10:
                        indirlist.remove(uzunluk)

                for img in indirlist:
                    up_to_word = "https:"
                    rx_to_first = r'^.*?{}'.format(re.escape(up_to_word))
                    img = re.sub(rx_to_first, '', img, flags=re.DOTALL).strip()
                    img = "https:" + img
                    response = requests.get(img[0:106], stream=True, headers=agent)

                    if response.ok or not response.ok:
                        file_name = img[46:50]
                        file_name1 = file_name + "mt" + img[51:54]
                        file_name2 = file_name1 + "mt" + img[55:58]
                        name = file_name2
                        yenlist5.append(name)
                        break

                essizyenlist10 = list(yenlist9)

                for etiket in yenlist5:
                    for isim in yenlist2:
                        for fiyat in yenlist4:
                            for renk in yenlist3:
                                for kumas in yenlist1:
                                    beden = ", ".join(essizyenlist10)
                                    if kumas.count("%") > 0 and len(kumas) < 85:
                                        link = browser.current_url
                                        aciklama = yenlist8[1]
                                        kumasoran = kumas
                                        kumas = ''.join([i for i in kumas if not i.isdigit()])
                                        kumas = kumas.replace(" · ", "-")
                                        kumas = kumas.replace("%", "")
                                        kumas = kumas.replace(" ", "")

                                        if len(fiyat) < 1:
                                            fiyat = "indirimde"
                                        else:
                                            try:
                                                if isim.count("ELBİSE") == 1:
                                                    klasman = "ELBİSE"
                                                elif isim.count("ETEK") == 1:
                                                    klasman = "ETEK"
                                                elif isim.count("BLAZER")==1:
                                                    klasman="CEKET(BLAZER)"
                                                elif isim.count("BERMUDA")==1:
                                                    klasman="ŞORT"
                                                elif isim.count("AYAKKABI")==1:
                                                    klasman="AYAKKABI"
                                                elif isim.count("ÇANTA")==1:
                                                    klasman="ÇANTA"
                                                elif isim.count("KAZAK")==1:
                                                    klasman="KAZAK"
                                                elif isim.count("BODY")==1:
                                                    klasman="BODY-TISORT"
                                                elif isim.count("GÖMLEK")==1:
                                                    klasman="GÖMLEK-BLUZ"
                                                elif isim.count("SANDALET")==1:
                                                    klasman="AYAKKABI"
                                                elif isim.count("JEAN")==1:
                                                    klasman="JEAN"
                                                elif isim.count("T-SHIRT")==1:
                                                    klasman="BODY-TISORT"
                                                elif isim.count("TOP")==1 and isim.count("FİTİLLİ")==1:
                                                    klasman="BODY-TISORT"
                                                elif isim.count("BLUZ")==1:
                                                    klasman="GÖMLEK-BLUZ"
                                                elif isim.count("SWEATSHIRT")==1:
                                                    klasman="SWEATSHIRT"
                                                elif isim.count("TOP")==1 and isim.count("TRİKO")==1:
                                                    klasman="BODY-TISORT"
                                                elif isim.count("PANTOLON")==1:
                                                    klasman="PANTOLON"
                                                elif isim.count("KABAN")==1:
                                                    klasman="KABAN-MONT"
                                                elif isim.count("KİMONO")==1:
                                                    klasman="KİMONO"
                                                elif isim.count("TULUM")==1:
                                                    klasman="ELBİSE"
                                                elif isim.count("TOP")==1 and isim.count("DİKİŞSİZ")==1:
                                                    klasman="BODY-TISORT"
                                                elif isim.count("TOP")==1:
                                                    klasman="GÖMLEK-BLUZ"
                                                elif isim.count("ŞORT")==1:
                                                    klasman="ŞORT"
                                                elif isim.count("ŞORT")==1 and isim.count("ETEK")==1:
                                                    klasman="SORT-ETEK"
                                                elif isim.count("TRENCH")==1 and isim.count("COAT")==1:
                                                    klasman="TRENÇKOT"
                                                elif isim.count("YELEK")==1:
                                                    klasman="YELEK"
                                                elif isim.count("HIRKA")==1:
                                                    klasman="HIRKA"
                                                elif isim.count("KÜPE")==1:
                                                    klasman="KÜPE"
                                                elif isim.count("CEKET")==1:
                                                    klasman="CEKET"
                                                elif isim.count("DENIM")==1 and isim.count("CEKET")==1:
                                                    klasman="CEKET(DENİM)"
                                                elif isim.count("KOLYE")==1:
                                                    klasman="KOLYE"
                                                elif isim.count("ŞAPKA")==1:
                                                    klasman="ŞAPKA"
                                                elif isim.count("KAFTAN")==1:
                                                    klasman="KAFTAN"
                                                else:
                                                    klasman = ""
                                                
                                                deger_ekle(etiket, link, isim, fiyat, renk, kumas, aciklama, klasman, beden)
                                            except:
                                                pass

                                        break
                                break
                            break
                        break

        else:
            url1 = browser.current_url
            r = requests.get(url1, headers=agent)
            soup = BeautifulSoup(r.content, "lxml")
            images = soup.find_all("source")

            indirlist = []
            yenlist1 = []
            yenlist2 = []
            yenlist3 = []
            yenlist4 = []
            yenlist5 = []
            yenlist7 = []
            yenlist8 = []
            yenlist9 = []
            yenlist10 = []

            deger2 = False
            sayicounter1 = 20

            while not deger2:
                try:
                    bilgi = browser.find_elements(By.CLASS_NAME, "structured-component-text-block-paragraph")
                    isim = browser.find_elements(By.CLASS_NAME, "product-detail-info__header")
                    renk = browser.find_elements(By.CLASS_NAME, "product-color-extended-name.product-detail-info__color")
                    otherrenk = browser.find_elements(By.CLASS_NAME, "product-detail-color-selector__color-area")
                    fiyat = browser.find_elements(By.CLASS_NAME, "product-detail-info__price")
                    ressim = browser.find_elements(By.CLASS_NAME, "media__wrapper.media__wrapper--fill.media__wrapper--force-height")
                    urun_aciklama = browser.find_elements(By.CLASS_NAME, "expandable-text__inner-content")
                    beden_bilgisi = browser.find_elements(By.CLASS_NAME, "product-size-info__main-label")
                    sayicounter1 -= 1

                    if bilgi and isim and renk and fiyat and ressim:
                        deger2 = True
                    elif sayicounter1 == 0:
                        deger2 = True
                    else:
                        pass
                except:
                    continue

            indirlist = []
            for i in ressim:
                ext = [i.get_attribute('innerHTML')]
                for yext in ext:
                    try:
                        x = yext.index("1700w,")
                        y = yext.index("2048w")
                        indirlist.append(yext[x + 7:y].strip())
                    except:
                        pass

            for bdn in beden_bilgisi:
                bdnn = bdn.get_attribute("innerHTML")
                bdnhx = bdn.value_of_css_property("color")
                hex_color = Color.from_string(bdnhx).hex
                if hex_color == "#000000":
                    bdn_list = f"{bdnn}: mevcut"
                else:
                    bdn_list = f"{bdnn}: mevcut_degil"
                yenlist9.append(remove_html_tags(bdn_list))

            for isi in isim:
                ext = [isi.get_attribute('innerHTML')]
                for yext in ext:
                    yext = remove_html_tags(yext)
                    yenlist2.append(yext)

            for fi in fiyat:
                fext = [fi.get_attribute('innerHTML')]
                for yfext in fext:
                    yfext = remove_html_tags(yfext)
                    yenlist4.append(yfext)

            for aci in urun_aciklama:
                acixt = [aci.get_attribute('innerHTML')]
                for yacixt in acixt:
                    yacixt = remove_html_tags(yacixt)
                    yenlist8.append(yacixt)

            for irenk in renk:
                rext = [irenk.get_attribute('innerHTML')]
                for yrext in rext:
                    yrext = remove_html_tags(yrext)
                    yenlist3.append(yrext)

            for oirenk in otherrenk:
                orext = [oirenk.get_attribute('innerHTML')]
                for oyrext in orext:
                    oyrext = remove_html_tags(oyrext)
                    yenlist7.append(oyrext)

            for ip in bilgi:
                text = [ip.get_attribute('innerHTML')]
                for ytext in text:
                    ytext = remove_html_tags(ytext)
                    yenlist1.append(ytext)

            for uzunluk in indirlist:
                if len(uzunluk) < 10:
                    indirlist.remove(uzunluk)

            for img in indirlist:
                up_to_word = "https:"
                rx_to_first = r'^.*?{}'.format(re.escape(up_to_word))
                img = re.sub(rx_to_first, '', img, flags=re.DOTALL).strip()
                img = "https:" + img
                response = requests.get(img[0:106], stream=True, headers=agent)

                if response.ok or not response.ok:
                    file_name = img[46:50]
                    file_name1 = file_name + "mt" + img[51:54]
                    file_name2 = file_name1 + "mt" + img[55:58]
                    name = file_name2
                    yenlist5.append(name)
                    break

            essizyenlist10 = list(yenlist9)

            for etiket in yenlist5:
                for isim in yenlist2:
                    for fiyat in yenlist4:
                        for renk in yenlist3:
                            for kumas in yenlist1:
                                beden = ", ".join(essizyenlist10)
                                if kumas.count("%") > 0 and len(kumas) < 85:
                                    link = browser.current_url
                                    aciklama = yenlist8[1]
                                    kumasoran = kumas
                                    kumas = ''.join([i for i in kumas if not i.isdigit()])
                                    kumas = kumas.replace(" · ", "-")
                                    kumas = kumas.replace("%", "")
                                    kumas = kumas.replace(" ", "")

                                    if len(fiyat) < 1:
                                        fiyat = "indirimde"
                                    else:
                                        try:
                                            if isim.count("ELBİSE") == 1:
                                                klasman = "ELBİSE"
                                            elif isim.count("ETEK") == 1:
                                                klasman = "ETEK"
                                            elif isim.count("BLAZER")==1:
                                                klasman="CEKET(BLAZER)"
                                            elif isim.count("BERMUDA")==1:
                                                klasman="ŞORT"
                                            elif isim.count("AYAKKABI")==1:
                                                klasman="AYAKKABI"
                                            elif isim.count("ÇANTA")==1:
                                                klasman="ÇANTA"
                                            elif isim.count("KAZAK")==1:
                                                klasman="KAZAK"
                                            elif isim.count("BODY")==1:
                                                klasman="BODY-TISORT"
                                            elif isim.count("GÖMLEK")==1:
                                                klasman="GÖMLEK-BLUZ"
                                            elif isim.count("SANDALET")==1:
                                                klasman="AYAKKABI"
                                            elif isim.count("JEAN")==1:
                                                klasman="JEAN"
                                            elif isim.count("T-SHIRT")==1:
                                                klasman="BODY-TISORT"
                                            elif isim.count("TOP")==1 and isim.count("FİTİLLİ")==1:
                                                klasman="BODY-TISORT"
                                            elif isim.count("BLUZ")==1:
                                                klasman="GÖMLEK-BLUZ"
                                            elif isim.count("SWEATSHIRT")==1:
                                                klasman="SWEATSHIRT"
                                            elif isim.count("TOP")==1 and isim.count("TRİKO")==1:
                                                klasman="BODY-TISORT"
                                            elif isim.count("PANTOLON")==1:
                                                klasman="PANTOLON"
                                            elif isim.count("KABAN")==1:
                                                klasman="KABAN-MONT"
                                            elif isim.count("KİMONO")==1:
                                                klasman="KİMONO"
                                            elif isim.count("TULUM")==1:
                                                klasman="ELBİSE"
                                            elif isim.count("TOP")==1 and isim.count("DİKİŞSİZ")==1:
                                                klasman="BODY-TISORT"
                                            elif isim.count("TOP")==1:
                                                klasman="GÖMLEK-BLUZ"
                                            elif isim.count("ŞORT")==1:
                                                klasman="ŞORT"
                                            elif isim.count("ŞORT")==1 and isim.count("ETEK")==1:
                                                klasman="SORT-ETEK"
                                            elif isim.count("TRENCH")==1 and isim.count("COAT")==1:
                                                klasman="TRENÇKOT"
                                            elif isim.count("YELEK")==1:
                                                klasman="YELEK"
                                            elif isim.count("HIRKA")==1:
                                                klasman="HIRKA"
                                            elif isim.count("KÜPE")==1:
                                                klasman="KÜPE"
                                            elif isim.count("CEKET")==1:
                                                klasman="CEKET"
                                            elif isim.count("DENIM")==1 and isim.count("CEKET")==1:
                                                klasman="CEKET(DENİM)"
                                            elif isim.count("KOLYE")==1:
                                                klasman="KOLYE"
                                            elif isim.count("ŞAPKA")==1:
                                                klasman="ŞAPKA"
                                            elif isim.count("KAFTAN")==1:
                                                klasman="KAFTAN"
                                            else:
                                                klasman = ""

                                            deger_ekle(etiket, link, isim, fiyat, renk, kumas, aciklama, klasman, beden)
                                        except:
                                            pass

                                    break
                            break
                        break
                    break
    except:
        continue