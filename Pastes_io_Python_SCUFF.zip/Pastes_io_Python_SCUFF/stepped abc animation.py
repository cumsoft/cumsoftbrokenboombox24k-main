min = cmds.playbackOptions(q=1,ast=1)
max =  cmds.playbackOptions(q=1,aet=1)
rate = 5
t = min
[cmds.disconnectAttr('time1.outTime',abc+'.time') for abc in cmds.ls(type='AlembicNode')]
 
while t < max+rate:
    for abc in cmds.ls(type='AlembicNode'):
        cmds.setKeyframe(abc,at='time',t=t,v=t,ott='step')
    t+=rate