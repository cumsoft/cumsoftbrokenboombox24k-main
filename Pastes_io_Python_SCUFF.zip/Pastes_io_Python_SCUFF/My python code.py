//1

principle = float(input("Enter principle amount : "))
rate = float(input("Enter rate of interest : "))
time = float(input("Enter time period : "))

interest = (principle * rate * time)/100
print(f"Simple interest = {interest}") 

//2

principle = float(input("Enter principle amount : "))
rate = float(input("Enter rate of interest : "))
time = float(input("Enter time period : "))


new_principle = principle * ((1 + (rate/100))**time)
interest = new_principle - principle

print(f"Compound interest = {interest}") 

//3
A = float(input("Enter first no. : "))
B = float(input("Enter second no. : "))

temp = A
A = B
B = temp

print(f"A is now : {A}")
print(f"B is now : {B}")


//4

import math

r = float(input("Enter radius : "))


def area(r):
	return math.pi * (r**2)
	
result = area(r)

print(f"Area : {result}")


//5

n = int(input("Enter no. of terms - "))

sum = ((n*(n+1))/2)**2

print(f"Sum :{sum}")

//6

n = int(input("Enter size of list : "))

list = []	

for i in range(0,n):
	 add = float(input(f"Enter element {i+1} : "))
	 list.append(add)
	
print(f"Old list : {list}")

temp = list[0]
list[0] = list[n-1]
list[n-1] = temp

print(f"New list : {list}")
	 
  //7
n = int(input("Enter no. of students : "))

A = []
B = []
B_add = 0
for i in range(0,n):
	A_add = int(input("Enter no. of pen : "))
	A.append(A_add)
	

for i in range(0,n):
	for j in range(0,n):
		if(i == j):
			continue
		else:
			B_add += A[j]
			
	B.append(B_add)
	B_add = 0
				
				
print(B)				
				
//9
n = int(input("Enter the number : "))

for i in range(1,11):
	print(f"{n} x {i} = {n * i}")