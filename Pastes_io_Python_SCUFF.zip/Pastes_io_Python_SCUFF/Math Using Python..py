Dividing
def sum(a, b):
    return (a / b)

a = int(input('The Number You Are Dividing? '))
b = int(input('What Amount You Want To Divide The Number By? '))

print(f'{a} Divided By {b} Equals {sum(a, b)}')
_________________________________________________________________________
Adding
def sum(a, b):
    return (a + b)

a = int(input('Type First Number To Start Adding.'))
b = int(input('Type The Number You Want To Add To The Number You Just Typed. '))

print(f'Sum Of {a} And {b} Equals {sum(a, b)}')
__________________________________________________________________________
Subtracting

def sum(a, b):
    return (a - b)

a = int(input('Type The Number You Want To Subtract.'))
b = int(input('Type The Number You Want To Subtract To The Number You Just Typed. '))

print(f'{a} Minus {b} Equals {sum(a, b)}')
____________________________________________________________________________
Multiplying
def sum(a, b):
    return (a * b)

a = int(input('Type The Number You Want To Multiply To Start.'))
b = int(input('Type The Number You Want To Multiply The Number By. '))

print(f'{a} Multiplied By {b} Equals {sum(a, b)}')