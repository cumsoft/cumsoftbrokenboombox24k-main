# program to find max prim of a number
x = int(input("write your number : "))
i = x-1
while i > 0:
    if x % i == 0:
        print("max prim is : " + str(i)) 
        break
    else:
        i -= 1