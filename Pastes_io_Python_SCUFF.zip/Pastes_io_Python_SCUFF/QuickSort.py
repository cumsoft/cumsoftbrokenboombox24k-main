#pivot =first element
def quickSort(arr):
    def qsort(l,r):
        if l<r:
            #parition index find
            swap=l
            piv=arr[l]
            for j in range(l+1,r+1):
                if arr[j]<piv:
                    swap+=1
                    arr[swap],arr[j]=arr[j],arr[swap]
            #we swap with l
            arr[swap],arr[l]=arr[l],arr[swap]
            #quick sort
            qsort(l,swap-1)
            qsort(swap+1,r)
    qsort(0,len(arr)-1)
    return arr
#pivot =last element
def quickSort(arr):
    def qsort(l,r):
        if l<r:
            #find parition index
            piv=arr[r]
            swap=l-1
            for j in range(l,r):
                if arr[j]<=piv:
                    swap+=1
                    arr[j],arr[swap]=arr[swap],arr[j]
            #swap+1 is the partition index
            #we swap with r
            arr[swap+1],arr[r]=arr[r],arr[swap+1]
            qsort(l,swap)
            qsort(swap+2,r)
    qsort(0,len(arr)-1)
    return arr