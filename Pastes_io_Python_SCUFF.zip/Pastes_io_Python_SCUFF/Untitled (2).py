#!/usr/bin/env python3
# https://gist.githubusercontent.com/danielhoherd/6b87f6449c1091dce2ffc413754556bb/raw/ff1f738c64a53247f4278c5488158a043fc77689/gistfile0.txt
from multiprocessing.pool import ThreadPool
import subprocess
import shlex
import sys
import time
import cProfile
import pstats
import asyncio

# sample data obtained with
# curl -s https://s3.amazonaws.com/alexa-static/top-1m.csv.zip | unzip | head -n 100 top-1m.csv | awk -F ',' '{print $2}' > alexa-top-100.csv

def dig(data: set) -> None:
    """Perform a dig command for one host.  """
    hostname = data[0]
    server = data[1]
    cmd = f"dig +short {hostname} {server}"
    dig_data = subprocess.check_output(shlex.split(cmd))

async def dig_async(data: set) -> None:
    """ async perform a dig command for one host.  """
    hostname = data[0]
    server = data[1]
    cmd = f"dig +short {hostname} {server}"
    proc = await asyncio.create_subprocess_exec(
        *shlex.split(cmd), 
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        
    )   
    stdout_data, stderr_data = await proc.communicate()
    return

async def main():
    servers = [
        "1.1.1.1",  # Cloudflare
        "1.0.0.1",  # Cloudflare
        "8.8.8.8",  # Google
        "8.8.4.4",  # Google
        "208.67.222.222",  # OpenDNS
        "208.67.220.220",  # OpenDNS
        "9.9.9.9",  # Quad9
        "149.112.112.112",  # Quad9
        "64.6.65.6",  # Verisign
        "64.6.64.6",  # Verisign
    ]

    permutations = list()
    with open('alexa-top-100.csv') as hostnames:
        for hostname in hostnames:
            # strip trailing newline
            hostname = hostname.split('\n')[0]
            for server in servers:
                permutations.append((hostname, server))

    # serial
    """
    finished: 13.62s

    real	0m13.678s
    user	0m6.172s
    sys	0m5.543s
    """
    #start = time.perf_counter()
    #for pair in permutations:
    #    dig(pair)
    #elapsed = time.perf_counter() - start
    #print(f'finished: {elapsed:.2f}s')

    # profiling
    """
       299756 function calls in 23.172 seconds
       Ordered by: internal time
       ncalls  tottime  percall  cumtime  percall filename:lineno(function)
         1000   20.009    0.020   20.009    0.020 {method 'read' of '_io.BufferedReader' objects}
         1000    0.865    0.001    0.865    0.001 {built-in method posix.read}
         1000    0.461    0.000    0.461    0.000 {built-in method _posixsubprocess.fork_exec}
         1000    0.274    0.000    2.321    0.002 /usr/lib/python3.8/subprocess.py:1552(_execute_child)
         5000    0.146    0.000    0.201    0.000 /usr/lib/python3.8/shlex.py:133(read_token)
         1000    0.133    0.000    0.320    0.000 /usr/lib/python3.8/subprocess.py:1101(_close_pipe_fds)
         1000    0.089    0.000    0.090    0.000 /usr/lib/python3.8/shlex.py:21(__init__)
         1000    0.077    0.000    2.490    0.002 /usr/lib/python3.8/subprocess.py:736(__init__)
         1000    0.067    0.000    0.160    0.000 /usr/lib/python3.8/os.py:613(get_exec_path)
         1000    0.053    0.000    0.053    0.000 {built-in method io.open}
         1000    0.052    0.000    0.093    0.000 /usr/lib/python3.8/contextlib.py:429(callback)
         1000    0.049    0.000   22.747    0.023 /usr/lib/python3.8/subprocess.py:452(run)
         1000    0.044    0.000    0.054    0.000 /usr/lib/python3.8/contextlib.py:482(__exit__)
         1000    0.044    0.000    0.044    0.000 {built-in method posix.waitpid}
        33840    0.043    0.000    0.043    0.000 {method 'read' of '_io.StringIO' objects}
    """
    #start = time.perf_counter()
    #with cProfile.Profile() as profile:
    #    for pair in permutations:
    #        dig(pair)
    #stats = pstats.Stats(profile)
    #stats.sort_stats(pstats.SortKey.TIME)
    #stats.print_stats()
    #elapsed = time.perf_counter() - start
    #print(f'finished: {elapsed:.2f}s')


    # ThreadPool()
    """ 
    finished: 4.42s

    real	0m4.508s
    user	0m8.618s
    sys	0m7.853s
    """
    #start = time.perf_counter()
    #with ThreadPool(processes=16) as pool:
    #    pool.map(dig, permutations)
    #elapsed = time.perf_counter() - start
    #print(f'finished: {elapsed:.2f}s')


    # asyncio ()
    """ 
    finished: 7.40s

    real	0m7.519s
    user	0m8.850s
    sys	0m10.900s
    """
    tasks = list()
    for pair in permutations:
        tasks.append(asyncio.create_task(dig_async(pair)) )
    start = time.perf_counter()
    commands = await asyncio.gather(*tasks)
    elapsed = time.perf_counter() - start
    print(f'finished: {elapsed:.2f}s')

if __name__ == '__main__':
    asyncio.run(main())