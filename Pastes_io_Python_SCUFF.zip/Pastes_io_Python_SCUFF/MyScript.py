import json
import os
import subprocess
import shutil
import plotly.offline as pyo
import plotly.express as px
from collections import defaultdict
import tabulate

# Initialize aggregated data dictionary
total_revenue = defaultdict(lambda: {"purchase_revenue": 0, "total_ad_revenue": 0})


def remove_folder(folder_path):
    if os.path.exists(folder_path):
        shutil.rmtree(folder_path)
        print("The folder has been deleted successfully!")
    else:
        print("Can not delete the folder as it doesn't exists")

    os.mkdir(folder_path)


def revenue_report():
    request = {
        "dimensions": [
            {
                "name": "customUser:user_type"
            }
        ],
        "metrics": [
            {
                "name": "purchaseRevenue"
            },
            {
                "name": "totalAdRevenue"
            }
        ],
        "dateRanges": [
            {
                "startDate": "2daysAgo",
                "endDate": "2daysAgo"
            }
        ],
        "metricAggregations": [
            "TOTAL"
        ]
    }

    # Create the "country" dimension and "dimensionFilter" if country_values are provided
    # if country_code:
    #     request["dimensionFilter"] = {
    #         "filter": {
    #             "fieldName": "countryId",
    #             "inListFilter": {
    #                 "values": country_code
    #             }
    #         }
    #     }

    # Specify the file path where you want to save the JSON data
    request_folder = f"{documents_folder}/Request"
    file_path = os.path.join(request_folder, f"request_revenue_{property_id}.json")

    # Write the JSON data to the file
    with open(file_path, 'w') as file:
        json.dump(request, file, indent=3)  # Use indent to format the JSON with indentation

    # Specify the name of the JSON file you want to read
    bash_script_filename = "analytics.sh"  # Replace with the actual JSON file name
    # Define the path to your Bash script
    bash_script_path = os.path.join(workspace_folder, bash_script_filename)
    print(bash_script_path)

    api_version = "v1beta"
    api_end_point = "runReport"

    # Use subprocess to run the Bash script
    try:
        subprocess.run(
            ['C:\\Program Files\\Git\\bin\\bash.exe', bash_script_path, property_id, f"revenue_{property_id}",
             api_end_point, api_version],
            check=True)
        # funnel_chart(str(i), True)
    except subprocess.CalledProcessError as e:
        # Handle any errors that occurred while running the script
        print(f"Error running the script: {e}")


# Function to aggregate values by user_type
def aggregate_values(json_data, aggregated_data):
    # Check if "rows" key exists in the JSON data
    if "rows" in json_data:
        for row in json_data["rows"]:
            user_type = row["dimensionValues"][0]["value"]
            purchase_revenue = float(row["metricValues"][0]["value"])
            total_ad_revenue = float(row["metricValues"][1]["value"])
            print(f"{property_id}-Purchase revenue = {purchase_revenue}")
            print(f"{property_id}-Ad revenue = {total_ad_revenue}")
            if purchase_revenue >= 0:
                aggregated_data[user_type]["purchase_revenue"] += purchase_revenue
            aggregated_data[user_type]["total_ad_revenue"] += total_ad_revenue
    else:
        print("Error: 'rows' key not found in the JSON data.")


def revenue_chart():
    json_file_name = f"response_revenue_{property_id}.json"  # Replace with the actual JSON file name
    # Specify the name of the JSON file you want to read
    json_path = os.path.join(f"{documents_folder}/Response", json_file_name)

    # Check if the JSON file exists
    if os.path.exists(json_path):
        try:
            # The JSON file exists, so you can proceed to read it.
            with open(json_path, 'r') as json_file:
                data = json.load(json_file)

                json_data = defaultdict(lambda: {"purchase_revenue": 0, "total_ad_revenue": 0})

                aggregate_values(data, total_revenue)
                aggregate_values(data, json_data)

                # Create a list for user types, purchase revenue, and total ad revenue
                user_types = list(json_data.keys())
                purchase_revenues = [values["purchase_revenue"] for values in json_data.values()]
                total_ad_revenues = [values["total_ad_revenue"] for values in json_data.values()]

                # Create a Plotly pie chart for Purchase Revenue
                fig_purchase = px.pie(names=user_types, values=purchase_revenues,
                                      title='Aggregated Purchase Revenue Distribution by User Type',
                                      labels={'values': 'Purchase Revenue', 'names': 'User Type'})

                # Create a Plotly pie chart for Total Ad Revenue
                fig_ad = px.pie(names=user_types, values=total_ad_revenues,
                                title='Aggregated Total Ad Revenue Distribution by User Type',
                                labels={'values': 'Total Ad Revenue', 'names': 'User Type'})

                chart_path = os.path.join(f"{documents_folder}/Chart", f"purchase_revenue_chart_{property_id}.html")
                print(f"{documents_folder}/Chart")
                pyo.plot(fig_purchase, filename=chart_path, auto_open=False)
                print(f"Purchase Revenue chart saved as 'revenue_chart.html' in the working directory.")

                chart_path = os.path.join(f"{documents_folder}/Chart", f"ad_revenue_chart_{property_id}.html")
                print(f"{documents_folder}/Chart")
                pyo.plot(fig_ad, filename=chart_path, auto_open=False)
                print(f"Ad Revenue chart saved as 'ad_revenue_chart.html' in the working directory.")

        except Exception as e:
            print(f"An error occurred while processing the JSON file: {str(e)}")
    else:
        print(f"The JSON file '{json_file_name}' does not exist in the Documents folder.")


def total_revenue_chart():
    # Create a list for user types, purchase revenue, and total ad revenue
    user_types = list(total_revenue.keys())
    purchase_revenues = [values["purchase_revenue"] for values in total_revenue.values()]
    total_ad_revenues = [values["total_ad_revenue"] for values in total_revenue.values()]

    # Create a Plotly pie chart for Purchase Revenue
    fig_purchase = px.pie(names=user_types, values=purchase_revenues,
                          title='Aggregated Purchase Revenue Distribution by User Type',
                          labels={'values': 'Purchase Revenue', 'names': 'User Type'})

    # Create a Plotly pie chart for Total Ad Revenue
    fig_ad = px.pie(names=user_types, values=total_ad_revenues,
                    title='Aggregated Total Ad Revenue Distribution by User Type',
                    labels={'values': 'Total Ad Revenue', 'names': 'User Type'})

    chart_path = os.path.join(f"{documents_folder}/Chart", f"purchase_revenue_total.html")
    print(f"{documents_folder}/Chart")
    pyo.plot(fig_purchase, filename=chart_path, auto_open=False)
    print(f"Purchase Revenue chart saved as 'revenue_chart.html' in the working directory.")

    chart_path = os.path.join(f"{documents_folder}/Chart", f"ad_revenue_total.html")
    print(f"{documents_folder}/Chart")
    pyo.plot(fig_ad, filename=chart_path, auto_open=False)
    print(f"Ad Revenue chart saved as 'ad_revenue_chart.html' in the working directory.")


def total_revenue_table_to_txt():
    # Create a list for user types, purchase revenue, and total ad revenue
    user_types = list(total_revenue.keys())
    purchase_revenues = [values["purchase_revenue"] for values in total_revenue.values()]
    total_ad_revenues = [values["total_ad_revenue"] for values in total_revenue.values()]

    # Calculate the total revenue for each user type
    total_revenues = [purchase + ad for purchase, ad in zip(purchase_revenues, total_ad_revenues)]

    # Add a new row for "all_users" and aggregate the values
    all_users_row = ['all_users', sum(purchase_revenues), sum(total_ad_revenues), sum(total_revenues)]

    # Combine data into a list of tuples for tabulate
    table_data = list(zip(user_types, purchase_revenues, total_ad_revenues, total_revenues))
    
    # Append the "all_users" row to the table data
    table_data.append(all_users_row)

    # Define headers for the table
    headers = ['User Type', 'Purchase Revenue', 'Total Ad Revenue', 'Total Revenue']

    # Generate the tabulated table
    table_str = tabulate.tabulate(table_data, headers=headers, tablefmt='grid')

    # Get the directory of the script
    script_dir = os.path.dirname(os.path.abspath(__file__))

    # Specify the file path for the output text file in the script directory
    output_file_path = os.path.join(script_dir, "total_revenue_output.txt")

    # Write the tabulated table to the text file
    with open(output_file_path, 'w') as output_file:
        output_file.write(table_str)

    print(f"Total revenue table written to {output_file_path}")


documents_folder = os.path.expanduser(os.path.join("~", "Documents"))
remove_folder(f"{documents_folder}/Response")
remove_folder(f"{documents_folder}/Request")
remove_folder(f"{documents_folder}/Chart")
workspace_folder = os.path.dirname(os.path.abspath(__file__))

game = os.environ.get("PROPERTY_ID")

game_list = game.split(",")
for g in game_list:
    # Split the string by "-"
    property_id_list = g.split("-")

    # Check if there are at least two parts (before and after the hyphen)
    if len(property_id_list) >= 2:
        property_id = property_id_list[1]
        print(property_id)
    else:
        print("String does not contain a hyphen.")

    revenue_report()
    revenue_chart()

total_revenue_chart()
total_revenue_table_to_txt()