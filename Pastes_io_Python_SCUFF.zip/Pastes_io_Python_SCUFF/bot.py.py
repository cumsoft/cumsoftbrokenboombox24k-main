import logging
from aiogram import Bot, Dispatcher
from aiogram.webhook.aiohttp_server import SimpleRequestHandler, setup_application
from aiohttp import web
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker
from config_reader import config
from handlers import start
from handlers.adult import catalog
from middlewares.UserMiddleware import UserMiddleware


async def on_startup(bot: Bot):
    url = f'{config.webhook_url}/{config.bot_token.get_secret_value()}'
    await bot.set_webhook(url)


def start_database() -> async_sessionmaker:
    async_engine = create_async_engine(config.db_url, echo=True)
    _async_session_factory = async_sessionmaker(async_engine)

    return _async_session_factory


def run_web_app(app: web.Application, dp: Dispatcher, bot: Bot) -> None:
    webhook_requests_handler = SimpleRequestHandler(dispatcher=dp, bot=bot)
    webhook_requests_handler.register(app, f'/{config.bot_token.get_secret_value()}')
    setup_application(app, dp, bot=bot)

    web.run_app(app, host=config.web_server_host, port=config.web_server_port)


def main():
    async_session_factory = start_database()

    app = web.Application()
    bot = Bot(token=config.bot_token.get_secret_value())
    dp = Dispatcher(
        async_session_factory=async_session_factory
    )

    dp.startup.register(on_startup)
    dp.message.middleware(UserMiddleware())
    dp.include_routers(
        start.router,
        catalog.router
    )

    run_web_app(app, dp, bot)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    main()