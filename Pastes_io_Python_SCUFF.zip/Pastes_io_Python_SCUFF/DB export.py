"""
Commands for Admins.
"""

from evennia import CmdSet

from commands.command import Command
from typeclasses.constants import TC_EXIT, TC_ROOM


class AdminCmdSet(CmdSet):
    """Command set for admins."""

    key = "admin_cmdset"
    priority = 10

    def at_cmdset_creation(self):
        self.add(CmdDbExport())


def _fmt(value):
    if value is None:
        return "None"
    if isinstance(value, str):
        value = value.replace('"', '\\"')
        value = value.replace("\n", "||/")
        value = value.replace("|/", "||/")
        return f'"{value}"'
    return str(value)


class CmdDbExport(Command):
    """
    Snapshots the current world.

    Usage:
        dbexport

    Only usable by the superuser account. This command will generate a sequence
    of python commands capable of regenerating rooms and exits in a new database
    from the current one.
    """

    key = "dbexport"
    locks = "cmd:false()"  # Superuser only.

    def _copy_tags(self, obj_name, handler, property, py_output):
        for tag, category in handler.all(return_key_and_category=True):
            category = _fmt(category) if category else "None"
            py_output.append(f"{obj_name}.{property}.add({_fmt(tag)}, category={category})")

    def func(self):
        from typeclasses.objects import Object

        self.caller.msg("Listing objects")
        py_output = [
            "from evennia.utils.create import create_object",
            "from typeclasses.rooms import Room",
            "from typeclasses.exits import Exit",
        ]

        for obj in Object.objects.get_dbref_range(3, 1000):
            if not obj.is_typeclass(TC_ROOM) and not obj.is_typeclass(TC_EXIT):
                continue
            obj_type = obj.typeclass_path.split(".")[-1]
            obj_id_name = f"obj_{str(obj.id)}"
            if obj.location and obj.location.id > obj.id:
                self.caller.msg(
                    f"WARNING: LOCATION {obj}(#{obj.id}) > {obj.location}(#({obj.location.id}))"
                )
            if obj.destination and obj.destination.id > obj.id:
                self.caller.msg(
                    f"WARNING: DEST {obj}(#{obj.id}) > {obj.destination}(#({obj.destination.id}))"
                )
            location = f"obj_{obj.location.id}" if obj.location else "None"
            py_output.append(
                f"{obj_id_name} = create_object({obj_type}, key={_fmt(obj.key)}, location={location})"
            )
            if obj.destination:
                py_output.append(f"{obj_id_name}.destination = obj_{obj.destination.id}")
            if obj.tags:
                self._copy_tags(obj_id_name, obj.tags, "tags", py_output)
            if obj.aliases:
                self._copy_tags(obj_id_name, obj.aliases, "aliases", py_output)

            for attr in obj.attributes.all():
                if bool(attr.value):
                    category = f"{_fmt(attr.category)}" if attr.category else "None"
                    py_output.append(
                        f"{obj_id_name}.attributes.add({_fmt(attr.key)}, "
                        f"{_fmt(attr.value)}, category={category})"
                    )
        self.caller.msg("Done")
        self.caller.msg("_" * 78)
        self.caller.msg("\n".join(py_output))