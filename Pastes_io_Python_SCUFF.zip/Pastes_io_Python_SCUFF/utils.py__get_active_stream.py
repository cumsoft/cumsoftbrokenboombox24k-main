def get_active_stream(channel_id: str, driver: uc.Chrome | None = None) -> str | None:
    """Returns stream url if a channel with specified channel_id has active stream"""
    src = 'LiveCheck'

    streams_url ='https://www.youtube.com/@overwatchleague/streams'
    videos_url = 'https://www.youtube.com/@overwatchleague/videos'

    driver_failed = False

    for check_url in [streams_url, videos_url]:
        if driver:
            log_debug(src, 'Checking stream status using WebDriver...')
            driver.get(check_url)
            if 'consent.youtube.com' in driver.current_url:
                log_debug(src, 'YouTube asked for consent')
                try:
                    element = driver.find_element(By.XPATH, '//form[@action="https://consent.youtube.com/save"]')
                    element.click()
                except:
                    log_error(src, 'Failed to get stream status using driver!')
                    driver_failed = True
                    driver.get(NEW_TAB_URL)

        if not driver or driver_failed:
            log_debug(src, 'Checking stream status using \'requests\'...')
            response = make_get_request(check_url).text
        log_info(src, 'check content')
        try:
            # may throw NoSuchElementException
            el = driver.find_element(By.CSS_SELECTOR, 'a:has(div .ytd-thumbnail:is([overlay-style=LIVE]))')
            stream_url = el.get_attribute('href')
            log_info(src, f'got {stream_url}')
            return stream_url
        except NoSuchElementException:
            log_info(src, 'stream not live')
        except Exception as e:
            log_error(src, f'&rLive stream check failed: {str(e)}')
            make_debug_file('failed-getting-active-stream', traceback.format_exc())
            return
    return