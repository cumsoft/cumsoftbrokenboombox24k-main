import ccxt
import numpy as np

# Define your API credentials
api_key = 'your_api_key'
api_secret = 'your_api_secret'
exchange = ccxt.mexc({
    'apiKey': api_key,
    'secret': api_secret,
})

# Set the symbol and timeframe
symbol = 'BTC/USDT'
timeframe = '1m'

# Define the EMA period and volume spread divergence threshold
ema_period = 200
divergence_threshold = 0.5

# Define leverage and order parameters
leverage = 10
take_profit_percentage = 200
stop_loss_percentage = 75

def calculate_ema(data, period):
    return np.mean(data[-period:])

def identify_trend(data):
    # You can use any trend identification method here, such as comparing EMA with current price
    current_price = data[-1]
    ema = calculate_ema(data, ema_period)
    if current_price < ema:
        return 'downtrend'
    else:
        return 'uptrend'

def check_divergence(data):
    # Implement your volume spread divergence logic here
    return True  # Replace with your divergence condition

def execute_trade(symbol, side, quantity):
    exchange.fapiPrivate_post_leverage({
        'symbol': symbol,
        'leverage': leverage,
    })
    response = exchange.fapiPrivate_post_order({
        'symbol': symbol,
        'side': side,
        'type': 'MARKET',
        'quantity': quantity,
    })
    return response

def main():
    while True:
        try:
            # Fetch the latest candlestick data
            candles = exchange.fetch_ohlcv(symbol, timeframe)
            close_prices = [candle[4] for candle in candles]

            # Check if we have enough data to calculate EMA and divergence
            if len(close_prices) > ema_period:
                current_trend = identify_trend(close_prices)
                if current_trend == 'downtrend' and check_divergence(close_prices[-5:]):
                    # Execute short trade
                    execute_trade(symbol, 'SELL', 1)
                    print('Short trade executed.')

                elif current_trend == 'uptrend' and check_divergence(close_prices[-5:]):
                    # Execute long trade
                    execute_trade(symbol, 'BUY', 1)
                    print('Long trade executed.')

            # Wait for the next candlestick
            exchange.sleep(exchange.rateLimit / 1000)

        except Exception as e:
            print('An error occurred:', str(e))

if __name__ == '__main__':
    main()