#ML DEO!!!!!!!!!!!!!!!!!!!!!!!!!
#ML DEO!!!!!!!!!!!!!!!!!!!!!!!!!
#ML DEO!!!!!!!!!!!!!!!!!!!!!!!!!
# pip install pandas
# pip install sklearn
# pip install seaborn
# pip install numpy
# pip install matplotlib

#knn.py
from collections import Counter
from typing import Callable
import numpy as np
from abc import ABC, abstractmethod

from sklearn.metrics import r2_score, accuracy_score


def euclidian_distnace(x1: np.ndarray, x2: np.ndarray) -> np.float64:
   return np.sqrt(np.sum((x1-x2)**2))

class KNN(ABC):

    def __init__(self, k: int = 3, distance_metric: Callable[[np.ndarray, np.ndarray], np.float64] = euclidian_distnace) -> None:
        super().__init__()
        self.k = k
        self._metric = distance_metric

    def fit(self, X: np.ndarray, y: np.ndarray):
        self._X_train = X
        self._y_train = y

    def predict(self, X):
        predictions = [self._predict(x) for x in X]
        return predictions

    def _predict(self, x):
        # compute the distance
        distances = [self._metric(x, x_train) for x_train in self._X_train]
    
        # get the closest k
        k_indices = np.argsort(distances)[:self.k]
        k_nearest = [self._y_train[i] for i in k_indices]

        value = self._predict_from_k_nearest(k_nearest)
        return value
    
    @abstractmethod
    def _predict_from_k_nearest(self, k_nearest: np.ndarray):
        pass

    @abstractmethod
    def score(self, X, y, sample_weight = None):
        pass

class KNNRegressor(KNN):

    def _predict_from_k_nearest(self, k_nearest: np.ndarray):
        return np.mean(k_nearest)
    
    def score(self, X, y, sample_weight = None):
        y_pred = self.predict(X)
        return r2_score(y, y_pred, sample_weight=sample_weight)
    
class KNNClassifier(KNN):

    def _predict_from_k_nearest(self, k_nearest: np.ndarray):
        # majority voye
        label, _ = Counter(k_nearest).most_common(1)[0]
        return label
    
    def score(self, X, y, sample_weight = None):
        y_pred = self.predict(X)
        return accuracy_score(y, y_pred, sample_weight=sample_weight)
    

#perceptron.py
from typing import Callable
import numpy as np

def unit_step_func(x: np.ndarray) -> np.ndarray:
    return np.where(x > 0, 1, 0)

class Perceptron:
    def __init__(self, learning_rate: float = 0.01, n_iters:int = 1000, activation_func: Callable[[np.ndarray], np.ndarray] = unit_step_func):
        self.lr = learning_rate
        self.n_iters = n_iters
        self.activation_func = activation_func
        self.weights = None
        self.bias = None

    def fit(self, X: np.ndarray, y: np.ndarray):
        n_samples, n_features = X.shape
        # Inicijalne vrednosti parametara
        self.weights = np.zeros(n_features)
        self.bias = 0
        # Određivanje težinskih koeficijenata
        for _ in range(self.n_iters):
            for idx, x_i in enumerate(X):
                linear_output = np.dot(x_i, self.weights) + self.bias
                y_predicted = self.activation_func(linear_output)
                # Pravilo obuke modela -  SGD
                update = self.lr * (y[idx] - y_predicted)
                self.weights += update * x_i
                self.bias += update

    def predict(self, X: np.ndarray):
        linear_output = np.dot(X, self.weights) + self.bias
        y_predicted = self.activation_func(linear_output)
        return y_predicted

#test_perceptron.py
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn import datasets
import numpy as np
from perceptron import Perceptron

def accuracy(y_true, y_pred):
    accuracy = np.sum(y_true == y_pred) / len(y_true)
    return accuracy

X, y = datasets.make_blobs(
    n_samples=150, n_features=2, centers=2, cluster_std=1.05, random_state=2
)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=123
)

p = Perceptron(learning_rate=0.01, n_iters=1000)  
p.fit(X_train, y_train)
predictions = p.predict(X_test)

print("Perceptron classification accuracy", accuracy(y_test, predictions))

# vizuelizacija
fig = plt.figure()
ax = fig.add_subplot(1, 1, 1)

h = 0.01
x0_min, x0_max = X[:, 0].min() - 1, X[:, 0].max() + 1
x1_min, x1_max = X[:, 1].min() - 1, X[:, 1].max() + 1
xx0, xx1 = np.meshgrid(np.arange(x0_min, x0_max, h),
                     np.arange(x1_min, x1_max, h))
# here "model" is your model's prediction (classification) function
Z = p.predict(np.array([xx0.ravel(), xx1.ravel()]).T) 
# Put the result into a color plot
Z = Z.reshape(xx0.shape)
from matplotlib.colors import ListedColormap
cmap = ListedColormap(colors=['blue', 'lightgreen'])
plt.contourf(xx0, xx1, Z, cmap=cmap, alpha=0.15)

plt.scatter(X_train[:, 0], X_train[:, 1], marker="o", c=y_train, label='Trening podaci')

# w0x0 + w1x1 + bias = 0
# w1x1 = - w0x0 - bias 
# x1 = (- w0x0 - bias ) / w1

x1_1 = (-p.weights[0] * x0_min - p.bias) / p.weights[1]
x1_2 = (-p.weights[0] * x0_max - p.bias) / p.weights[1]

ax.plot([x0_min, x0_max], [x1_1, x1_2], label='Razdvajanje klasa', color='orange')

ax.set_xlim([x0_min, x0_max])
ax.set_ylim([x1_min, x1_max])
plt.xlabel('x0')
plt.ylabel('x1')
plt.legend()
plt.show()


#simple_linear_regression.py
import numpy as np

class SimpleLinearRegression:
    def __init__(self, w1: float = 0.0, w0: float = 0.0 ) -> None:
        self._w1 = w1
        self._w0 = w0

    def fit(self, X : np.ndarray, y: np.ndarray ) -> 'SimpleLinearRegression' :
        m_rows, n_features = X.shape
        assert n_features == 1, "Multivariate linear regression is not implemented!"
        self._w1 =  (m_rows * np.sum(np.dot(X.T, y)) - np.sum(X)*np.sum(y)) / (m_rows * np.sum(X**2) - (np.sum(X))**2)
        self._w0 = (np.sum(y) - np.sum(np.dot(self._w1, X))) / m_rows

        return self
    
    def pred(self, X : np.ndarray):
        return np.dot(self._w1, X) + self._w0

    def get_params(self) -> dict:
        return {'w1': self._w1, 'w0': self._w0}


###ML PODSETNIK!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
###ML PODSETNIK!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
###ML PODSETNIK!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
###ML PODSETNIK!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
############################ ML - PRVE VEZBE ##########################
import pandas as pd
# kreiranje DF od recnika
data = {
    'apples': [3, 2, 0, 1], 
    'oranges': [0, 3, 7, 2]
}
purchases = pd.DataFrame(data)
purchases

# ako zelimo da dodelimo nazive redovima, potrebno je da 
# argumentu index prosledimo listu sa nazivima  
purchases = pd.DataFrame(data, index=['June', 'Robert', 'Lilly', 'David'])
purchases

# uzimanje reda na osnovu njegovog naziva 
june = purchases.loc['June']
june

# preuzimanje podataka iz CSV-a
df = pd.read_csv('purchases.csv')
df

# prilikom ucitavanja csv-a, prva kolona je zapravo kolona sa nazivima indeksa,
# a ne klasicna kolona. Da bismo nazivima indeksa dodelili njene vrednost, 
# potrebno je da setujemo parametar index_col = 0
df = pd.read_csv('purchases.csv', index_col=0)
df

# ucitavanje podataka iz JSON-a
# kod ucitavanja JSON-a, ne moramo da vodimo racuna o nazivima indeksa, 
# prva kolona ce da se gleda kao kolona sa nazivima indeksa
df = pd.read_json('purchases.json')
df

# konvetovanje DF-a u CSV, JSON
df.to_csv('new_purchases.csv')
df.to_json('new_json.csv')

movies = pd.read_csv('IMDB-Movie-Data.csv', index_col='Title')
movies

# zaglavlje DF-a mozemo da vidimo preko funkcije head(). Bez prosledjenog 
# broja u pozivu funkcije, vraca prvih 5 redova, a ukoliko se prosledi broj n 
# vratice n redova 
movies.head()

# zacelje DF-a mozemo da vidimo preko funkcije tail(). Funkcionise isto kao 
# i funkcija tail()
movies.tail()

# funkcija info() obezbedjuje prikaz najbitnijih informacija o dataset-u
# (broj ne null vredosti po kolonama, tip kolone, broj kolona i redova)
movies.info()

# shape vraca broj redova i kolona
rows, columns = movies.shape
rows, columns

# append ce da doda na trenutni DF prosledjeni DF koji moramo da sacuvamo 
# u nekoj promenljivoj 
temp_df = movies.append(movies)
temp_df.shape

temp_df = temp_df.drop_duplicates()
temp_df.shape

# Funkcija drop_duplicates() ima argument keep koji moze da ima tri 
# potencijalne vrednosti: 
# 1. first - ovo je default vrednost koja se prosledjuje ukoliko se 
# keep argument ne prosledjuje pozivu funkcije i on znaci da se brisu 
# svi duplikati sem prvog pojavljivanja 
# 2. last - brisu se svi duplikati sem poslednjeg pojavljivanja 
# 3. false - brisu se svi duplikati (u DF-u ostaju samo jedinstvene vrednosti 
# koje nisu imale nijedan duplikat)
# inplace je argument cija je vrednost true/false i on postoji u okviru svih 
# DF-a. Ukoliko je njegova vrednost na true, onda se poziv trenutno pozvane 
# funkcije izvrsava direktno nad datasetom, a ne pravi se njegova kopija. 
temp_df = movies.append(movies)
temp_df.drop_duplicates(inplace=True, keep='last')
temp_df.shape

# pregled naziva kolona i njihova izmena 
movies.columns
movies.rename(columns= {'Runtime (Minutes)':'Runtime', 'Revenue (Millions)': 'Revenue_millions'}, inplace=True)
movies.columns

movies.columns = [col.lower() for col in movies]
movies.columns

# Postoje dve opcije za rad sa null vrednostima: 
# 1. ukloniti ih 
# 2. popuniti ih nekom vrednoscu (imputacija)

# za svaki podatak u tabeli vraca vrednost true/false u zavisnosti od toga da li je null
movies.isnull()

# kombinacija funkcija isnull i sum ce za svaku kolonu vratiti broj null vrednosti u toj koloni 
movies.isnull().sum()

# funkcija dropna brise svaki red gde se pojavljuje bar jedna null vrednost
movies.dropna()
movies

# axis = 1 znaci da se funkcija izvrsava nad kolonama, odnosno 
# u ovom slucaju, obrisace se 
movies.dropna(axis=1)

# imputacija je metoada koja se koristi za cuvanje vrednih podataka
# koji imaju null vrednosti. Postoje slucajevi kada ima previse redova sa 
# null vrednostima i njihovo uklanjanje u tom slucaju dovodi do gubljenja velikog 
# broja podataka 
# za imputaciju se obicno koristi medijana ili srednja vrednost
revenue = movies['revenue_millions']
revenue
revenue_mean = revenue.mean()
revenue_mean
# popunjavanje null vrednosti 
revenue.fillna(revenue_mean, inplace=True)
revenue

# Funkcija describe() nam daje kratak rezime distribucije 
# kontinualnih promenljivih (count, mean, std, min, kvartili, max)
movies.describe()

# Ova funkcija moze da bude primenjena i na kategorijske promenljive 
# Tada describe() vraca count, broj jedinstvenih, top(najvise zastupljena
# vrednost), freq(count), type 
movies.genre.describe()

# funkcija value_counts nam pokazuje frekvenciju svih podataka u koloni 
movies.genre.value_counts()

# korelaciona matrica 
movies.corr()

# dobijanje serije
genre = movies['genre']
type(genre)

# dobijanje DF-a
genre = movies[['genre']]
type(genre)

subset = movies[['genre', 'rating']]
subset

# izdvanjanje redova po nazivu indeksa 
prometheus = movies.loc['Prometheus']
prometheus

# izdvajanje redova po broju indeksa 
prometheus = movies.iloc[1]
prometheus

# izdvajanje dela DF-a
subset = movies.iloc[1:4]
subset

# ukljucuje Sing u rezultat, dok iloc ne ukljucuje Suicide Squad(4)
subset = movies.loc['Prometheus':'Sing'] 
subset

# selekcija po uslovu 

condition = (movies['director'] == 'Ridley Scott')
condition

movies[movies['director'] == 'Ridley Scott']
movies[movies['rating']>=8.6].head(3)
movies[(movies['director'] == 'Ridley Scott') | (movies['director'] == 'Christopher Nolan')].head(3)
movies[movies['director'].isin(['Christopher Nolan', 'Ridley Scott'])].head(3)
movies[(movies['year']>=2005) & (movies['year'] <= 2010) & (movies['rating']>8.0) & (movies['revenue_millions']< movies['revenue_millions'].quantile(0.25))]

def rating_func(x): 
    if x >= 8.0: 
        return "good"
    else: 
        return "bad"

movies['rating_category'] = movies['rating'].apply(rating_func)
movies

import matplotlib.pyplot as plt
movies.plot(kind='scatter', x = 'rating', y='revenue_millions', title ='Revenue cs Rating')
plt.show()
movies['rating'].plot(kind='box')
plt.show()
movies.boxplot(column='revenue_millions', by='rating_category')
plt.show()

###################################################################################
############################# ML - DRUGE VEZBE ##########################

"""
    Klasifikacioni modeli resavaju pripadnost odredjenoj klasi. Za ocenu 
    kvaliteta modela se koriste metrike: confusion matrix, accuracy, precision, 
    recall(sensitivity), specificity, f1, roc, auc

    Konfuziona matrica je tabela od dve dimenzija - actual i predicted.
    Sastoji se od True Positive (TP), True Negative (TN), 
    False Positive (FP), False Negative (FN) 
"""
import pandas as pd
import seaborn as sns
from sklearn.metrics import confusion_matrix

df = pd.read_csv('data.csv')
df.head()
sns.histplot(df[['model_LR']])
plt.show()

# postavljamo granicu 
thresh = 0.5 
df['predicted_RF'] = (df['model_RF']>thresh).astype(int)
df['predicted_LR'] = (df['model_LR']>thresh).astype(int)

# konfuzionoj matrici prosledjujemo actual i predicted 
cm = confusion_matrix(df['actual_label'], df['predicted_RF'])
cm

# accuracy (tacnost) = (TP + TN)/(TP + FP + FN + TN)
from sklearn.metrics import accuracy_score
accuracy = accuracy_score(df['actual_label'], df['predicted_RF'])
accuracy*100

# precision (preciznost)
from sklearn.metrics import precision_score
precision = precision_score(df['actual_label'], df['predicted_RF'])
precision*100

#recall(sensitivity)
from sklearn.metrics import recall_score
recall = recall_score(df['actual_label'], df['predicted_RF'])
recall*100

# specificity = tn/(tn+fp)
tn, fp, fn, tp = confusion_matrix(df['actual_label'], df['predicted_RF']).ravel()
specificity = tn/(tn+fp)
specificity*100

from sklearn.metrics import f1_score
f1 = f1_score(df['actual_label'], df['predicted_RF'])
f1*100

# roc_auc_score 
from sklearn.metrics import roc_auc_score, roc_curve
fpr, tpr, _ = roc_curve(df['actual_label'], df['model_RF'])
roc_auc_rf = roc_auc_score(df['actual_label'], df['model_RF'])
plt.figure()
plt.plot(fpr, tpr, color = "darkorange", label = "ROC curve RF (area = %0.2f)" % roc_auc_rf)
plt.plot(fpr_lr, tpr_lr, color = "green", label = "ROC curve LR (area = %0.2f)" % roc_auc_lr)
plt.plot([0, 1], [0, 1], color = "navy", lw = 2, linestyle = "--")
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.0])
plt.xlabel("False Positeve Rate")
plt.ylabel("True Positice Rate")
plt.legend(loc = 'lower right')
plt.title("ROC example")
plt.show()

# precision_recall_score 
from sklearn.metrics import precision_recall_curve, auc

precision, recall, thresholds = precision_recall_curve(df['actual_label'], df['model_RF'])
pr_auc = auc(recall, precision)

plt.plot(recall, precision, color = "darkorange", label = "area = %0.2f" % pr_auc)

plt.xlim([0.0, 1.0])
plt.ylim([0.5, 1.0])
plt.xlabel("Recall")
plt.ylabel("Precision")
plt.legend(loc = 'upper right')
plt.title("PRC")
plt.show()

# classification_report 
from sklearn.metrics import classification_report
print(classification_report(df['actual_label'], df['predicted_RF'] ))

################################ III DEO - ML ################################
# Enkoderi sluze da kategorijske promenljive kodiramo na neki nacin 
# ordinal - string labele se konvertuju u vrednosti od 1 do k 
# onehot - jedna kolona za svaku vrednost koja se poredi vs sve druge vrednosti 
# binary - svaka integer vrednost se konertuje u string (8-1000, 7 - 0111)

import pandas as pd
import numpy as np
import copy 
# ucitavamo fajl 
flights = pd.read_csv('https://raw.githubusercontent.com/ismayc/pnwflights14/master/data/flights.csv')
# gledamo osnovne informacije da bismo utvrdili tipove kolona 
# kolone tipa object su potencijalno kategorijske promenljive 
flights.info()

# selektujemo kolone gde je tip podataka object i kopiramo u novi DF
flights_cat = flights.select_dtypes(include=['object']).copy()
flights_cat

# prvo da vidimo null vrednosti po kolonama 
flights_cat.isnull().sum()
# isnull vraca DF sa vrednostima true/false, values ga pretvara u ND niz, a 
# primenom sum() funkcije nad nizom, dobijamo ukupan broj null vrednosti (248)
flights_cat.isnull().values.sum()

# vraca listu count-a za svaku kategoriju unutar ove klase 
list = flights_cat['tailnum'].value_counts()
list
flights_cat = flights_cat.fillna(list[0])
flights_cat.isnull().values.sum()


flights_cat['carrier'].value_counts()

# pretvaranje object klase u kategoriju 
flights_cat = flights.copy()
flights_cat['carrier'] = flights_cat['carrier'].astype('category')
flights_cat['origin'] = flights_cat['origin'].astype('category')

# rad sa kategorijama - codes su vrednosti od 1 do n kategorija
flights_cat['carrier'] = flights_cat['carrier'].cat.codes
flights_cat['carrier']

def us_func(code): 
    if code == 'US': 
        return 1 
    return 0
flights_cat['US_code'] = flights['carrier'].apply(us_func)
flights_cat['US_code']

# Label Encoding 
from sklearn.preprocessing import LabelEncoder
flights_lb = flights.copy()
encoder = LabelEncoder()
flights_lb['carrier_code'] = encoder.fit_transform(flights_lb['carrier'])
flights_lb.head()

# One *** encoding - I nacin 
flights_onehot = flights.copy()
flights_onehot = pd.get_dummies(flights_onehot, columns=['carrier'], prefix=['carrier'])
flights_onehot.head()
flights_onehot.shape

# One *** encoding - II nacin (Label Binarizer)
# iz nekog razloga su nazivi kolona 0..n-1
from sklearn.preprocessing import LabelBinarizer
one_hot = flights.copy()
encoder = LabelBinarizer()
lb_results = encoder.fit_transform(one_hot['carrier'])
lb_df_results = pd.DataFrame(lb_results)
lb_df_results.head()

result_df = pd.concat([one_hot, results_df], axis=1)
result_df

# binary encoding 
import category_encoders as ce 
flights_be = flights_cat.copy()
encoder = ce.BinaryEncoder(cols=['carrier'])
df_binary = encoder.fit_transform(flights_be)
df_binary.head()

#BackwardDifferenceEncoder 
flights_be = flights_cat.copy()
encoder = ce.BackwardDifferenceEncoder(cols=['carrier'])
df_bd = encoder.fit_transform(flights_be)
df_bd.head()

# primer 
dummy_df_age = pd.DataFrame({'age': ['0-20', '20-40', '40-60','60-80']})
def split_mean(x): 
    split_list = x.split('-')
    mean = (float(split_list[0]) + float(split_list[1]))/2
    return mean
dummy_df_age['mean'] = dummy_df_age['age'].apply(split_mean)
dummy_df_age.head()

# linearna regresija 
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn import metrics

dataset = pd.read_csv('Weather.csv')
dataset.head()
dataset.describe()

# prvo radimo reshape
X = dataset['MinTemp'].values.reshape(-1,1)
Y = dataset['MaxTemp'].values.reshape(-1,1)
X.shape

# podela skupa na trening i test
x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=0.2, random_state=0, shuffle=True)
# podaci su spremni za treniranje 
regressor = LinearRegression()
regressor.fit(x_train, y_train)
regressor.intercept_
regressor.coef_ # koef je oko 92% 

#
y_predicted = regressor.predict(x_test)
df = pd.DataFrame({'Actual':y_test.flatten(), 'Predicted': y_predicted.flatten()})
df.head()

# MAE - srednja apsolutna greska 
metrics.mean_absolute_error(y_test, y_predicted)
# MSE - srednja kvadratna greska 
metrics.mean_squared_error(y_test, y_predicted)
# RMSE - koren srednje kvadratna greska
np.sqrt(metrics.mean_squared_error(y_test, y_predicted))

# visestruka linearna regresija 
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn import metrics

# proveravamo kakav je skup podataka sa kojim radimo 
dataset = pd.read_csv('winequality.csv')
dataset.shape
dataset.describe()

# proveravamo da li i koje kolone imaju null vrednosti 
# funkcija any() ce da vrati true ili false u odnosu na to da li 
# kolona ima null vrednosti (prvo se primenjuje fja isnull)
dataset.isnull().any()

# brisanje null vrednosti - ova linija se nece izvrsiti, posto je 
# rezultat prethodne funkcije pregled svih kolona gde vidimo da nijedna 
# kolona ne sadrzi null vrednosti 
dataset = dataset.fillna(method='ffill')

# na osnovu skupa X cemo da predvidjamo vrednosti za Y 
X = dataset[['fixed acidity', 'volatile acidity', 'citric acid', 'residual sugar', 'chlorides', 'free sulfur dioxide', 'total sulfur dioxide', 'density', 'pH', 'sulphates','alcohol']].values
y = dataset[['quality']].values

# podela podataka na train i test
x_train, x_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)

# kreiranje regressora 
regressor =  LinearRegression()
regressor.fit(x_train, y_train)

y_predicted = regressor.predict(x_test)
df = pd.DataFrame({'Actual': y_test.flatten(), 'Predicted':y_predicted.flatten()})
df.head(10)
y_pred_label = [int(x) for x in  np.round(y_pred.flatten()) ]
metrics.accuracy_score(y_test, y_pred_label)

# logistic regression?
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_score
logistic_regressor = LogisticRegression()
logistic_regressor.fit(x_train, y_train)
y_predicted = logistic_regressor.predict(x_test)
df = pd.DataFrame({'Actual': y_test, 'Predicted': y_predicted})
##################### ML - IV termin ############################
# KNN - K nearest neighbours algorithm
"""
    1. Ucitati podatke 
    2. Inicijalizovati k najblizih suseda 
    3. Za svaki primer u podacima 
        - izracunati distancu izmedju primera za kog pitamo i trenutnog 
          primera 
        - dodati distancu i indeks u listu 
    4. sortirati listu 
    5. uzeti prvih k elemenata iz liste 
    6. uzeti njihove labele 
    7. ako je regresija, vratiti mean, a ako je klasifikacija, vratiti mode 
"""
import numpy as np 
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score

headernames = ['sepal-length', 'sepal-width', 'petal-length', 'petal-width', 'Class']
path = "https://archive.ics.uci.edu/ml/machine-learning-databases/iris/iris.data"
dataset = pd.read_csv(path)
dataset.head()
x = dataset.iloc[:, :-1].values
y = dataset.iloc[:, 4].values
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.4)


scaler = StandardScaler()
scaler.fit(x_train)
x_train = scaler.transform(x_train)
x_test = scaler.transform(x_test)
classifier = KNeighborsClassifier(n_neighbors=7)
classifier.fit(x_train, y_train)
y_predicted = classifier.predict(x_test)

cm = confusion_matrix(y_test, y_predicted)
cm
classification_report(y_test, y_predicted)

# ANN 
import pandas as pd 
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import confusion_matrix

names = ['sepal-length', 'sepal-width', 'petal-length', 'petal-width', 'Class']
irisdata = pd.read_csv('iris.data', names=names)
irisdata
X = irisdata.iloc[:, 0:4]
y = irisdata.select_dtypes(include=[object])
X.head()
y.head()

# broj jedinstvenih vrednosti u y seriji 
y.Class.unique()
le = preprocessing.LabelEncoder()
y = y.apply(le.fit_transform)

x_train, x_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
scaler = StandardScaler()
scaler.fit(x_train)
x_train = scaler.transform(x_train)
x_test = scaler.transform(x_test)

# kreiranje NN 
mlp = MLPClassifier(hidden_layer_sizes=(10, 10, 10), max_iter=1000)
mlp.fit(x_train, y_train.values.ravel())
predictions = mlp.predict(x_test)
predictions

print(confusion_matrix(y_test,predictions))
print(classification_report(y_test,predictions))

#ML ROKOVI!!!!!!!!!!!!!!!!!!!!!!
#ML ROKOVI!!!!!!!!!!!!!!!!!!!!!!
#ML ROKOVI!!!!!!!!!!!!!!!!!!!!!!
# Банка се суочава са проблем одласка клијената. Како би се зауставио губитак клијената банка жели
# да предвиди који ће клијенти напустити банку. Прикупљени су подаци о клијентима. Садрже
# информације као што су држава порекла, биланс рачуна, да ли поседује кредитну картицу итд. На
# основу датих података креирати моделе машинског учења којима се за једног клијента предвиђа
# да ли ће напустити банку или не.
# Потребно је извршити следеће:
# 1. Учитати сет податка
# 2. Проверити да ли неке вредности података недостају. Уколико недостају, уклонити податке
# о клијентима за које постоје грешке у подацима.
# 3. Категоријске варијабле кодирати методом One-***-Encoding.
# 4. Поделити податке на скуп за обуку и скуп за тестирање у односу 80:20
# 5. Креирати и обучити моделе логистичке регресије и К најближих суседа.
# 6. Извршити предикције на тестном скупу.
# 7. Одредити матрице конфузије за предикције оба модела.
# 8. Потом одредити тачност и прецизност оба модела.
# 9. Сачувати предикције модела са скупа за тестирање у csv формату. Излазни фајл треба да
# садржи податке у формату ID клијента, предикција моделом логистичке регресије,
# предикција моделом К најближих суседа.
# Бонус (2 поена): На основу предикције вероватноћа модела, нацртати на истом графику ROC
# криве модела. У легенди графика означити називе модела и вредности површина испод кривих.
import pandas as pd

# Data import
dataset = pd.read_csv('bank_churn_all_data.csv', index_col='customer_id')

# Null values droped
dataset.dropna(inplace=True)

# Encoding
dataset = pd.get_dummies(dataset, prefix=['gender'], columns=['gender'])
dataset = pd.get_dummies(dataset, prefix=['country'], columns=['country'])

# Data division
x = dataset
y = dataset['churn']

from sklearn.model_selection import train_test_split

x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2)

### Models
## Regression
# Training
from sklearn.linear_model import LogisticRegression

lr = LogisticRegression()
lr.fit(x_train, y_train)

# Prediction
y_pred_1 = lr.predict(x_test)

## KNN
# Training
from sklearn.neighbors import KNeighborsClassifier

k = 10
kn = KNeighborsClassifier(n_neighbors=k)
kn.fit(x_train, y_train)

# Prediction
y_pred_2 = kn.predict(x_test)

# Model evaluation
from sklearn import metrics

print("Model 1 :")
print(metrics.confusion_matrix(y_test, y_pred_1))
print(metrics.accuracy_score(y_test, y_pred_1))
print(metrics.precision_score(y_test, y_pred_1))

print("Model 2 :")
print(metrics.confusion_matrix(y_test, y_pred_2))
print(metrics.accuracy_score(y_test, y_pred_2))
print(metrics.precision_score(y_test, y_pred_2))

# Save results
ret = dict()
ret['model_1'] = dict()
ret['model_2'] = dict()
for i in range(len(y_pred_1)):
    ret['model_1'][dataset.index[i]] = y_pred_1[i]
    ret['model_2'][dataset.index[i]] = y_pred_1[i]
ret_df = pd.DataFrame(ret)
ret_df.to_csv('results.csv')

# Дат је сет податка о путницима на броду Титаник. Подаци о путницима садрже информације о
# карти, класи, полу, кабини итд. На основу тих податка потребно је креирати моделе машинског
# учења који ће придиковати да ли ће путник преживети бродолом.
# Потребно је извршити следеће кораке:
# • Учитати сет података titanic.csv.
# • Путницима који немају кабину доделити вредност no_cabin.
# • Одбацити колоне које означавају Id путника и његово име.
# • Попунити недостајуће податке о годинама просечним броје година. Одбацити преостале
# редове чији подаци нису исправни.
# • Ознаку кабине и карте енкодирати методом Label Encoding. Преостале категоријске
# варијабле енкодирати методом One-*** Encoding.
# • Издвојити излазну колону (Survived) из скупа.
# • Поделити податке на скупове за обуку и тестирање у односу 80:20. Користити случајну
# поделу података.
# • Креирати модел логистичке регресије.
# • Оценити модел метрикама тачност и прецизност на тестном скупу.
# • Учитати други сет податка titanic_for_prediction.csv
# o Извршити неопходне трансформације како би се могао применити креирани модел
# o Придиковати да ли ће путници преживети.
# o На основу остварених предикција креирати CSV фајл који садржи колоне Name и
# Survived

import pandas as pd
import numpy as np
titanik = pd.read_csv("titanic.csv")
titanik.head(20)
titanik['Cabin'] = titanik['Cabin'].fillna("no_cabin")
titanik['Age'] = titanik['Age'].fillna(round(titanik['Age'].mean(),1))
titanik.dropna(inplace=True)
from sklearn.preprocessing import LabelEncoder
l_encoder = LabelEncoder()
titanik['Cabin_Encode'] = l_encoder.fit_transform(titanik['Cabin'])
titanik['Ticket_Encode'] = l_encoder.fit_transform(titanik['Ticket'])

cabins = dict()
tickets = dict()

for i in range(len(titanik['Cabin'].value_counts())):
    value = titanik['Cabin'].value_counts().index[i]
    cabins[value] = titanik['Cabin_Encode'].value_counts().index[i]

for i in range(len(titanik['Ticket'].value_counts())):
    value = titanik['Ticket'].value_counts().index[i]
    tickets[value] = titanik['Ticket_Encode'].value_counts().index[i]

titanik = pd.get_dummies(titanik,columns=['***','Embarked'],prefix=['***','Embarked'])
y = titanik['Survived'].values
from sklearn.model_selection import train_test_split

#gledam vrednosti da vidim sta izbacujem
unique_percentages = (titanik.nunique() / len(titanik)) * 100
unique_percentages #vidim da passengerid, name, ticket imaju mnogo unikatnih vrednosti pa i njih drop

null_percentages = (titanik.isnull().sum() / len(titanik)) * 100
null_percentages #vidim da cabin ima ~77% na pa ga drop

x = titanik.drop(['PassengerId','Name','Survived','Cabin','Ticket'],axis=1)
X = x.values
X_train,X_test,y_train,y_test = train_test_split(X,y,test_size=0.2,random_state=0)
from sklearn.linear_model import LogisticRegression
lr = LogisticRegression()

lr.fit(X_train,y_train)

y_pred = lr.predict(X_test)
from sklearn.metrics import accuracy_score,precision_score

print("Tacnost modela je: " + str(accuracy_score(y_test,y_pred)))
print("Preciznost modela je: " + str(precision_score(y_test,y_pred)))
titanik_pred = pd.read_csv("titanic_for_prediction.csv")
titanik_pred['Cabin'] = titanik_pred['Cabin'].fillna("no_cabin") 

titanik_pred['Age'] = titanik_pred['Age'].fillna(round(titanik_pred['Age'].mean(),1))
titanik_pred['Cabin_Encode'] = titanik_pred['Cabin']
for i in range(len(titanik_pred)):
    titanik_pred['Cabin_Encode'][i] = cabins[titanik_pred['Cabin'][i]]
titanik_pred['Cabin_Encode'] = titanik_pred['Cabin_Encode'].astype('int')

titanik_pred['Ticket_Encode'] = titanik_pred['Ticket']
for i in range(len(titanik_pred)):
    titanik_pred['Ticket_Encode'][i] = tickets[titanik_pred['Ticket'][i]]
titanik_pred['Ticket_Encode'] = titanik_pred['Ticket_Encode'].astype('int')
titanik_pred = pd.get_dummies(titanik_pred,columns=['***','Embarked'],prefix=['***','Embarked'])
titanik_ready = titanik_pred.drop(['PassengerId','Name','Cabin','Ticket'],axis=1)
titanik_ready.head(11)

y_pred2 = lr.predict(titanik_ready.values)
new_data = pd.DataFrame({"Name":titanik_pred['Name'],"Survived":y_pred2})

new_data.to_csv("preziveli.csv")

# На основу историјских података продаји дијаманата креирати моделе машинског учења којима се
# може проценити цена дијаманата.
# Потребно је извршити следеће:
# 1. Учитати сет податка diamonds.csv.
# 2. Проверити да ли неке вредности података недостају. Уколико недостаје део података,
# попунити просечним вредностима за тај тип података.
# 3. Чистоћу дијаманта кодирати методом Label Encoding, а преостале категоријске варијабле
# кодирати методом One-***-Encoding.
# 4. Поделити податке на скуп за обуку и скуп за тестирање у односу 70:30
# 5. Креирати и обучити моделе вишеструке линеарне регресије и вештачке неуронске мреже.
# ANN модел садржи 2 скривена слоја са по 5 неурона.
# 6. Извршити предикције на тестном скупу.
# 7. Потом одредити метрике оба модела на тестном скупу:
# a. MAE
# b. RMSE
# 8. За модел са мањом грешком МАЕ нацртати дијаграм распршености. На 𝑥 оси налазе се
# стварне вредности, а на 𝑦 оси налазе се придиковане вредности. Исцртати праву 𝑦 = 𝑥 на
# истом графику.
import pandas as pd
from math import sqrt
import copy
from numpy import mean
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.neural_network import MLPRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error

data_raw = pd.read_csv("diamonds.csv")
#data_raw.head()

data_raw.isnull().sum()

data_filled = data_raw.fillna(mean(data_raw))
#data_filled.head()

data_filled.isnull().sum()

data_onehot = pd.get_dummies(data_filled, columns=['cut', 'color'], prefix=['cut', 'color'])
le = LabelEncoder()
le.fit(data_onehot['clarity'].values)
data = data_onehot.copy()
data['clarity'] = le.transform(data['clarity'])

#data.head() 

noY = data.drop(columns=['price'])
onlyY = data[['price']]
#noY.info()
#onlyY.info()

x = noY.values
y = onlyY.values
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.3, random_state=0)

lin_reg = LinearRegression()
lin_reg.fit(x_train, y_train)

y_pred_lin = lin_reg.predict(x_test)

ann = MLPRegressor(hidden_layer_sizes=(5, 5))

ann.fit(x_train, y_train.ravel())
y_pred_ann = ann.predict(x_test)

df = pd.DataFrame({'Actual':y_test.flatten(), 'Predicted (Linear Regression)':y_pred_lin.flatten(), 'Predicted (Neural Network)':y_pred_ann.flatten()})
print(df.head())

print("MAE (Linear Regression, Neural Network):")
print(mean_absolute_error(y_test, y_pred_lin))
print(mean_absolute_error(y_test, y_pred_ann))

print("RMSE (Linear Regression, Neural Network):")
print(sqrt(mean_squared_error(y_test, y_pred_lin)))
print(sqrt(mean_squared_error(y_test, y_pred_ann)))

# Dijagram rasprsenosti za ANN
import matplotlib.pyplot as plt

plt.scatter(y_test, y_pred_ann)
plt.xlabel("Actual")
plt.ylabel("Predicted")
plt.plot([0, 20000],[0, 20000], color='red')
plt.show()

#GRAPH THEORY SEACH!!!!!!!!!!!!!
#GRAPH THEORY SEACH!!!!!!!!!!!!!
#GRAPH THEORY SEACH!!!!!!!!!!!!!
#fifoqueue.py
class FIFOQueue():
#First in, first out
    def __init__(self) -> None:
        self.list = [] #pakujemo podatke u neki listu, na pocetku prazna

    def append(self, value):
        self.list.append(value) #dodali na kraj lista

    def pop(self):
        return self.list.pop(0) #vraca prvi element liste (naseg reda)
    #isto sto i ^^^^
    #first = self.list[0]
    #self.list = self.list[1:]
    #return first
    
    def __len__(self):
        return len(self.list)

#priorityqueue.py
from typing import Callable, List
from node import Node

class PriorityQueue:
    #Lista sortirana po vrednsoti f-je
    
    # def __init__(self, f = lambda x: x) -> None:
    #     self.list = []
    #     self.f = f
    #nisam siguran koju implementaciju konstruktora da koristim    
    #za f kaze da je callable f-ja koja prima node i vraca float
    #lambda je default vrednost koja se dodeljuje parametru f
    #uzima argument x i vraca vrednost x.path_cost
    def __init__(self, f: Callable[[Node], float] = lambda x: x.path_cost) -> "PriorityQueue":
        self.list: List[Node] = [] #lista tipa Node
        self.f = f
   
    def append(self, node: Node)->None:
        place = len(self.list)
        for i in range(len(self.list)):
            if self.f(node) < self.f(self.list[i]):
                place = i
                break
        self.list.insert(place, node)
    
    def pop(self)->Node:
        return self.list.pop(0)
    
    def __len__(self):
        return len(self.list)
    
#sortedqueue.py
from node import Node

class SortedQueue(object):

    def __init__(self) -> None:
        self.list = []
    
    def append(self, node: Node):
        #Dodaje se cvor u listu sortiranu po vrednosti path_cost
        place = len(self.list) #uzima vrednost za kraj liste

        for i in range(len(self.list)):#sortiramo prema .path_cost varijabli
            if node.path_cost < self.list[i].path_cost:
                place = i
                break
        self.list.insert(place, node)

    def pop(self): #vraca se prvi element iz liste
        return self.list.pop(0)
    
    def __len__(self):
        return len(self.list)    

#graph.py
class Graph(object):
    #pravimo graf kao recnik jer mozemo da predstavimo gradove (stanja)
    # a da vrednosti u recniku budu vrednosti, tj gradovi sa kojima
    # su oni povezani i cena puta izmedju njih
    # gradovi = { npr. lista nije kompletna pa zato nema smisla
    #       'Drobeta' : { 'Mehadia':75 },
    #       'Eforie' : { 'Hirsova':86 },
    #       'Fagaras' : { 'Sibiu':99 },
    #       'Hirsova' : { 'Urziceni':98 }
    # }
    # Pravimo graf u vidu recnika gde je prvi nivo nase stanje, a vrednosti gradovi sa kojim
    # su oni povezani!
    # Svaki graf moze biti usmeren ili neusmeren. Kod usmerenih ako postoji veza od a-b
    # nije garantovano da postoji veza od b-a. Kod neusmerenih grafova podrazumeva se da
    # je usmeren u obe strane (ako a-b, postoji b-a sa istom cenom puta)
    def __init__(self, dictionary : dict, directed: bool = True) -> None:
        self.dict = dictionary
        self.directed = directed
        if directed:
            self._make_directed()
        else:
            self._make_undirected()

    #ako imamo vezu od a-b, onda cemo za vezu od b-a da postavimo default vrednost
    #a ako to inace postoji deffaultna vrednost nece da promeni nista
    def _make_directed(self):
        keys = list(self.dict.keys())
        for a in keys:
            a_keys = self.dict[a].keys()
            for b in a_keys:
                self.dict.setdefault(b, {})

    def _make_undirected(self):
        keys = list(self.dict.keys())
        for a in keys:
            a_items = self.dict[a].items()
            for b, distance in a_items:
                self.connect(b, a, distance) #spajamo veze od b do a, sa rastojanjem distance

    #da se od nekog stanja a upise veza do stanja b sa nekom distancom
    def connect(self, a, b, distance):
        #obezbedjujemo se da stanje a (na prvom nivou) zapravo postoji
        self.dict.setdefault(a, {})
        #ukoliko a NIJE U RECNIKU //NA PRVOM NIVOU
        #setdefault ubacuje stanje a u recnik i daje mu default vrednost {} (PRAZAN RECNIK)
        #ukoliko kljuc a postoji, nemoj da radis nista
        self.dict[a][b] = distance #od a do b je vrednost distance

    def get(self, a)->dict: #prosledjujemo stanje, vraca nam recnik sa susednim stanjima
        self.dict.setdefault(a, {}) #obezbedjujemo se da stanje postoji
        return self.dict[a]
    
    def nodes(self)->list: #metoda koja vraca sve kljuceve, odnosno sve cvorove
        return self.dict.keys()

#node.py
from problem import Problem

## Cvor u stablu pretrazivanja
# Čvor 𝑛 – struktura podataka koja čuva stanje i još neke dodatne
# podatke
# • 𝑛 = 𝑠, 𝑑, 𝑝
# • 𝑠 – stanje
# • 𝑑 – dubina
# • 𝑝 – prethodnik, roditelj

class Node(object):
    def __init__(self, state, parent = None, path_cost = 0) -> None:
        self.state = state
        self.parent = parent
        self.path_cost = path_cost
        #dubinu odredjujemo na osnovu roditelja
        if parent == None: #ako nema roditelja onda je dubina 0
            self.depth = 0
        else: # u suprotnom je dubina za 1 veca od dubine roditelja
            self.depth = parent.depth + 1

    #sluzi nam da razvijemo naredni cvor, tj da definisemo naredne cvorove
    def expand(self, problem: Problem)->list:
        exp_nodes = [] #nodovi(cvorovi) koje smo istrazili, inicijalno prazno; explored nodes
        neighbour_states = problem.actions(self.state) #susedna stanja preuzimamo iz problema
        #actions nam vraca gde sve mozemo da odemo tj susedna stanja
        for state in neighbour_states:#              trenutno stanje  sledece stanje
            new_cost = problem.path_cost(self.path_cost, self.state, state)
            new_node = Node(state, self, new_cost) #pravim novi node koji ima neko stanje(lokacija)
            #kome sam ja(trenutno stanje) roditelj, i koji od inicijalnog cvora do mene ima taj cost
            exp_nodes.append(new_node) #novi node dodam u listu explored nodes
        return exp_nodes
    
    #rekonstrukcijom utvrdjujemo kako da iz krajnjeg cvora dodjemo do onog sa pocetka(initial)
    def solution(self):
        sol_states = [] #lista stanja koje je prvo prazna. vracamo stanja a ne kompletne cvorove
        node = self
        while node != None: #kad nema roditelja znaci da smo dosli do vrha
            sol_states.insert(0, node.state) #ubacujem u listu stanja
            #ili da append pa da okrenes jer ce on gornja stanja da stavlja na kraj
            #ili da insert i da kazes dodaj na prvo poziciju. Onda je redosled ok
            node = node.parent #iteriram ka "GORE" dok vise nemam roditelja
        return sol_states
    
#problem.py
from graph import Graph

# • 𝑆 – skup stanja
# • 𝑝𝑟𝑜𝑏𝑙𝑒𝑚 = 𝑠0, 𝑠𝑢𝑐𝑐, 𝑔𝑜𝑎𝑙
# • 𝑠𝑜 ∈ 𝑆 – početno stanje
# • 𝑠𝑢𝑐𝑐 – funkcija tranzicije
# • 𝑔𝑜𝑎𝑙 – skup terminalnih stanja

class Problem(object):
    def __init__(self, initial, goal, graph: Graph) -> None:
        self.initial = initial #s0
        self.goal = goal #skup terminalnih f-ja
        self.graph = graph #preko grafa smo opisali f-ju tranzicije

    # • 𝑠𝑢𝑐𝑐 – funkcija tranzicije
    def actions(self, state): #prosledjujemo stanje a onda iz grafa vidimo koji su susedni elementi
        return self.graph.get(state).keys() #iz tog recnika, uzimamo sve kljuceve
    
    def goal_test(self, state): #provera da li je stanje koje prosledjujemo zavrsno(terminalno) stanje
        #return self.goal == state #kad imamo 1 zavrsno stanje
        # da li je nas goal isti kao state koji prosledjujemo f-ji
        return any(x == state for x in self.goal)#kada imamo vise zavrsnih stanja
        #ovo je true ako je bilo koje stanje true

    #cena puta se racuna u odnosu na inicijalni cvor
    def path_cost(self, cost_so_far, a, b): #a,b = state, next_state
        return cost_so_far + self.graph.get(a)[b]
    
#search.py
from problem import Problem
from node import Node
from typing import List, Union, Callable
from fifoqueue import FIFOQueue
from sortedqueue import SortedQueue
from priorityqueue import PriorityQueue

def general_search_algorithm(problem: Problem, open_nodes):
    explored = [problem.initial] #explored nodes: proveravamo da li je cvor koji otkrivamo
    #vec otkriven. Koristimo stanja (ne cvorove), i stavljamo nase inicijalno(pocetno) stanje
    open_nodes.append(Node(problem.initial)) #u open nodes smestamo I KREIRAMO
    #inicijalni cvor u odnosu na inicijalno stanje
    while len(open_nodes) > 0: #dokle god imamo cvorova koje mozemo da posetimo, radimo petlju
        node = open_nodes.pop() #uzmi prvi i taj prvi obrisi iz liste
        if problem.goal_test(node.state): #proveri dal je stanje tvog cvora goal(ciljno stanje)
            return node.solution() #ako jeste vrati solution (odnosno listu stanja)
        for child in node.expand(problem): #vidi ko su mu "komsije" sa kojima ima vezu
            if child.state not in explored: #ako nije otkriven, otkrij ga i dodaj u listu cvorova
                open_nodes.append(child) #tipa Node
                explored.append(child.state)
    return None #u slucaju da resenje nije pronadjeno

def bfs(problem: Problem):
    return general_search_algorithm(problem, FIFOQueue())

def dfs(problem: Problem):
    return general_search_algorithm(problem, [])
    
def uniform_cost_search(problem: Problem):
    #Pretraga se uniformnim troskom. Resenje nije optimalno po ceni puta
    return general_search_algorithm(problem, SortedQueue())

#slican je kao general_search ali jos ima limit
def depth_limited_search(problem: Problem, limit: int):
    open_nodes = [] #LIFO (kao stack kod DFS)
    explored = [problem.initial]
    open_nodes.append(Node(problem.initial))

    while len(open_nodes) > 0:
        node = open_nodes.pop()
        if problem.goal_test(node.state):
            return node.solution()
        if node.depth < limit: #limit nije prekoracen mogu se dodati susedi
            for child in node.expand(problem):
                if child.state not in explored:
                    open_nodes.append(child)
                    explored.append(child.state)
    return None

def iterative_deepening_search(problem: Problem):
    for depth in range(len(problem.graph.nodes)):
        result = depth_limited_search(problem, depth)
        if result != None:
            return result
    return None

def best_first_graph_search(problem: Problem, f:Callable[[Node], float]):
    node = Node(problem.initial)
    
    open_nodes = PriorityQueue(f) #cvorovi koji trebaju da se posete
    open_nodes.append(node)
    open_states = [node.state] #stanja(na osnovu cvorova) koja trebaju da se posete
    closed_states = [] #stanja koja su posecena

    while len(open_nodes) > 0:
        node = open_nodes.pop()
        if problem.goal_test(node.state): #uzmemo prvi i ispitamo dal je zavrsno stanje
            return node.solution()
        open_states.remove(node.state) #"prebacim" iz otvorenog u zatvoreno stanje
        closed_states.append(node.state)

        #susedi trenutnog cvora
        for child in node.expand(problem):
            if child.state not in open_states and child.state not in closed_states:
                #potpuno novo stanje koje do sada nismo videli
                open_nodes.append(child) #tipa node
                open_states.append(child.state) #tipa state
            elif child.state in open_states: #vec je otkriveno ali mozda postoji bolji put
                for i in range(len(open_nodes)):
                    if open_nodes.list[i] == child.state:
                        #pronadjeno isto stanje
                        if f(child) < f(open_nodes.list[i]):
                            del open_nodes.list[i]
                            open_nodes.append(child)
    return None

    #f(x) = g(x) //Dijkstra algoritam
def uniform_cost_best_first_search(problem: Problem): #kad kaze uniform_cost misli na ovaj jer radi ispravno
    return best_first_graph_search(problem, f = lambda node: node.path_cost)

    #f(x) = g(x) + h(x)
def astar_search(problem:Problem, h: Callable[[Node], float]):
    return best_first_graph_search(problem, f = lambda node: node.path_cost + h(node))

#zadatak. Sve sem search.py je isto
# Implementirati algoritam pretrage koji čini kombinaciju algoritama uniform cost search i iterative
# deepening search. Ovaj algoritam treba iterativno da izvršava uniform cost search sa limitiranom cenom
# puta koja se u svakoj iteraciji povećava. Na početku je limit 0. U svakom koraku se izvršava uniform cost
# search. Ako se prilikom ove pretrage dođe do čvora čije je rastojanje od početnog čvora (path_cost) veće
# od limita, taj čvor se odbacuje i ne ulazi u pretragu. Ako se u tekućem koraku ne pronađe rešenje, limit
# se povećava. Nova vrednost limita se bira na sledeći način – među cenama puta svih odbačenih čvorova
# se odabira najmanja cena, najmanja vrednost koja je prekoračila limit.
#search.py (za zadatak)
from problem import Problem
from node import Node
from priorityqueue import PriorityQueue
from typing import Callable

def best_first_limited_search(problem: Problem, limit: float, f: Callable[[Node], float]):

    open_nodes = PriorityQueue(f)
    open_nodes.append(Node(problem.initial))
    open_states = [problem.initial]
    closed_states = []

    next_limit = float('inf') #ono sto vracamo ako ne pronadjemo resenja; inic maks vred. za float
    
    while len(open_nodes) > 0:
        node = open_nodes.pop()
        
        #provera cilja
        if problem.goal_test(node.state):
            return (node.solution, next_limit)
        
        open_states.remove(node.state)
        closed_states.append(node.state)

        #iteracija po susedima
        for child in node.expand(problem):
            if child.state not in open_states and child.state not in closed_states:
#potpuno novo stanje na koje do sada nismo videli. BITNO: ovde je razlika u odnosu na obican alg
#jer mi imamo limit. Svaki put kad naidjemo na novo stanje, proverimo dal je putanja veca od limita
                if f(child) <= limit:
                    open_nodes.append(child)
                    open_states.append(child.state)
                elif f(child) < next_limit: #dal je cena do child-a manja od narednog limita
                    next_limit = f(child) #ako jeste, to je novi limit
            elif child.state in open_states: #vec je otkriveno ali mozda postoji bolji put
                for i in range(len(open_nodes)):
                    if open_nodes.list[i] == child.state:
                        #pronadjeno isto stanje; da li child ima manju cenu puta od open_nodes.list[i]
                        if f(child) < f(open_nodes.list[i]):
                            del open_nodes.list[i]
                            open_nodes.append(child)
    return (None, next_limit)

def uniform_cost_limited_search(problem: Problem, limit: float):
    return best_first_limited_search(problem, limit, lambda node: node.path_cost)

def iterative_uniform_cost_search(problem: Problem):
    limit = 0 #limit u pocetnom stanju
    while True: #"beskonacna" petlja
        solution, next_limit = uniform_cost_limited_search(problem, limit)
        if solution != None: #ako je vratio nesto sto nije None, to je resenje
            return solution
        if next_limit == float('inf'): #ako je limit jednak najvecoj vred. onda nije naso resenje
            return None
        limit = next_limit #pomeram limit

#misionari i kanibali zadatak. sve sem problem.py je isto. search.py ne postoji.
# Tri misionara i tri kanibala moraju da se prevezu čamcem sa jedne obale reke na drugu. Ni u jednom
# trenutku ne sme biti više kanibala nego misionara na bilo kojoj strani reke. Čamac može da primi do dva
# putnika i ne može da se kreće sam od sebe.
# Definisati početno i završno stanje, kao i prelaze iz jednog stanja u drugo. Izmeniti potrebne metode u
# klasi Problem. Dozvoljeno je i menjanje klase Node. Implementirati rešenje sa najmanjim mogućim
# brojem koraka
from typing import Tuple

class Problem(object):
    def __init__(self) -> None:
        #pamtimo sta se nalazi na levoj strani obale
        #(misionari, kanibali, camac)
        self.initial(3, 3, 'L')
        self.goal(0, 0, 'R') #niko nije ostao levo i camac je na desnoj obali


    # • 𝑠𝑢𝑐𝑐 – funkcija tranzicije
    def actions(self, state: Tuple[int, int, str]):
        next_states = []
        #(misionari, kanibali)
        moves = [(1, 0), (2, 0), (1, 1), (0, 1), (0, 2)]
        for move in moves:
            m, k, b = state
            delta_m, delta_k = move
            if b == 'L': #ako je camac na levoj strani
                #mi prebacujemo na desnu pa se br m i k na levoj smanjuje 
                m = m - delta_m
                k = k - delta_k
                b = 'R'
            else:
                m = m + delta_m
                k = k + delta_k
                b = 'L'
            new_state = (m, k ,b)
            if self._is_valid_state(new_state):
                next_states.append(new_state)

        return next_states
    
    def _is_valid_state(self, state: Tuple[int, int, str]) -> bool:
        m, k, _ = state # _ kaze da nam ta varijabla nije bitna i da je ignorisemo
        return (m == 0) or (m == 3) or (m == k) #vraca true ako je ispunjeno, suprotno false


    def goal_test(self, state)-> bool:
        return state == self.goal
    
    def path_cost(self, cost_so_far, a, b):
        return cost_so_far + 1
    #ili da ovako jer se koristi u node=u ili da se obrise sa oba mesta