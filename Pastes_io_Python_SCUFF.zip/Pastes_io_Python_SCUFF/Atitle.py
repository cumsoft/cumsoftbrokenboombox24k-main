#-------------------------------------------------------------------------------
def compare_rows(row1, row2):
  scores = []
  keys = list(row1.keys())
  IGNORE = ["id", "db_name", "export_time"]
  for key in keys:
    if key in IGNORE:
      continue

    value1 = row1[key]
    value2 = row2[key]

    if value1 is None or value2 is None:
      scores.append(INVALID_SCORE)
      continue

    if type(value1) is int:
      num1 = value1
      num2 = value2
      val = abs(num1 - num2) / 2
      scores.append(val)
    elif type(value1) is str:
      if value1.startswith('["') and value2.startswith('["'):
        s1 = set( json.loads(value1) )
        s2 = set( json.loads(value2) )
        if len(s1) == 0 or len(s2) == 0:
          val = INVALID_SCORE
        else:
          inter = len(s1.intersection(s2))
          maxs  = len(max(s1, s2))
          val = 1. - (inter / maxs)
        scores.append(val)
      else:
        val = quick_ratio(value1, value2)
        scores.append(val)
    else:
      scores.append(value1 == value2)
  return scores