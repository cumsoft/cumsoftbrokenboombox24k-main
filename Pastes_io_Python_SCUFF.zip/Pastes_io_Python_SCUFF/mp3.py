from pyrogram import Client, filters
import yt_dlp
import shutil
import os


app = Client(
    "sample bot",
    api_id=23951485,
    api_hash="1b0ed878b1df1665f7f370453cd44125",
    bot_token="",
)


def download_hook(d: dict, msg):
    if d["status"] == "downloading":
        percent = f'{(100 * float(d["downloaded_bytes"])/float(d["total_bytes"])):.2f}%'
        title = d["info_dict"]["title"]
        try:
            msg.edit_text("Title: {0}\n\nDownloading: {1}".format(title, percent))
        except:
            pass
            


@app.on_message(filters.command("start"))
def start(app, message):
    app.send_message(
        message.chat.id,
        "Ready to groove? Drop your YouTube link, and I'll convert it to MP3 in a snap! 🎵😊",
    )


@app.on_message(filters.text)
def authorised_user(app, message):
    if message.chat.id in [5948556591, 557639247]:
        url = message.text
        if "youtu.be" in url or "youtube.com" in url or "www.youtube.com" in url:
            folder_name = f"{message.chat.id}"
            msg = message.reply_text("Downloading...")
            ydl_opts = {
                "progress_hooks": [lambda d: download_hook(d, msg)],
                "format": "bestaudio/best",
                "outtmpl": os.path.join(folder_name, "%(title)s.%(ext)s"),
                "quiet": True,
                "postprocessors": [
                    {
                        "key": "FFmpegExtractAudio",
                        "preferredcodec": "mp3",
                        "preferredquality": "192",
                    }
                ],
            }
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                ydl.download([url])
            msg.edit_text("Uploading...")
            for filename in os.listdir(folder_name):
                audio_file = os.path.join(folder_name, filename)
                message.reply_audio(audio=audio_file)
            shutil.rmtree(folder_name)
            msg.delete()
        else:
            app.send_message(message.chat.id, "Not a valid yt link")
    else:
        app.send_message(message.chat.id, "Not an Authorized User")


print("I am alive")

app.run()