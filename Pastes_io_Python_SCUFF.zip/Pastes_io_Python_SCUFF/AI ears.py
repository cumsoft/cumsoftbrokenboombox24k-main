import requests
from bs4 import BeautifulSoup
import nltk
from nltk.tokenize import sent_tokenize

# Download the required NLTK data
nltk.download('punkt')

# Function to scrape web content from a given URL
def scrape_website(url):
    response = requests.get(url)
    # Check if the request was successful
    if response.status_code == 200:
        soup = BeautifulSoup(response.text, 'html.parser')
        return soup.get_text()
    else:
        return "Error: Unable to fetch webpage content"

# Function to process text and extract sentences mentioning 'earache'
def find_remedies(text):
    # Split the text into sentences
    sentences = sent_tokenize(text)
    # Filter sentences that mention 'earache'
    remedies = [sentence for sentence in sentences if 'earache' in sentence.lower()]
    return remedies

# URL of the Mayo Clinic page containing information about earache remedies
# Replace with a valid URL from the Mayo Clinic
url = 'https://www.mayoclinic.org/earache-remedies'

# Scrape the content from the website
text = scrape_website(url)

# Find sentences that could mention potential remedies
remedies = find_remedies(text)

# Output the extracted sentences
print("Possible remedies for earache mentioned in the text:")
for remedy in remedies:
    print(remedy)