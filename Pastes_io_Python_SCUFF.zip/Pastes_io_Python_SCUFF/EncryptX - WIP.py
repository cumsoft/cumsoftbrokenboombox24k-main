import base64
import os
import logging
from cryptography.fernet import Fernet
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives import hashes as asym_hashes
from cryptography.exceptions import InvalidKey

# Setup basic logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Function to generate a key from a passphrase, with optional salt and iterations
def generate_key(passphrase: str, salt: bytes = None, iterations: int = 100000) -> (bytes, bytes):
    # Validate passphrase
    if not passphrase:
        raise ValueError("Passphrase cannot be empty.")
    
    # Generate salt if not provided
    salt = salt or os.urandom(16)
    try:
        # Key derivation function
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=iterations,
            backend=default_backend()
        )
        # Derive key and return along with salt
        key = base64.urlsafe_b64encode(kdf.derive(passphrase.encode()))
        return key, salt
    except Exception as e:
        logging.error("Error generating key: %s", e)
        raise

# Function to select encryption method based on user's choice
def select_encryption_method(method: str):
    if method.lower() == 'fernet':
        return Fernet
    elif method.lower() == 'rsa':
        return RSAEncryption
    else:
        raise ValueError(f"Unsupported encryption method: {method}")

# Class for RSA Encryption and Decryption utility
class RSAEncryption:
    # Method to generate an RSA private key
    @staticmethod
    def generate_private_key(passphrase: str, key_size: int = 2048) -> bytes:
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=key_size,
            backend=default_backend()
        )
        # Serialize private key in PEM format
        pem = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.BestAvailableEncryption(passphrase.encode())
        )
        return pem

    # Method to encrypt a message using RSA public key
    @staticmethod
    def encrypt(message: str, public_key) -> bytes:
        try:
            # Encrypt message using RSA public key
            encrypted_message = public_key.encrypt(
                message.encode(),
                padding.OAEP(
                    mgf=padding.MGF1(algorithm=asym_hashes.SHA256()),
                    algorithm=asym_hashes.SHA256(),
                    label=None
                )
            )
            return encrypted_message
        except Exception as e:
            logging.error("RSA encryption failed: %s", e)
            raise

    # Method to decrypt an encrypted message using RSA private key
    @staticmethod
    def decrypt(encrypted_message: bytes, private_key) -> str:
        try:
            # Decrypt encrypted message using RSA private key
            decrypted_message = private_key.decrypt(
                encrypted_message,
                padding.OAEP(
                    mgf=padding.MGF1(algorithm=asym_hashes.SHA256()),
                    algorithm=asym_hashes.SHA256(),
                    label=None
                )
            )
            return decrypted_message.decode()
        except Exception as e:
            logging.error("RSA decryption failed: %s", e)
            raise

if __name__ == "__main__":
    try:
        # Retrieve passphrase from environment variable or use default
        passphrase = os.getenv("PASSPHRASE", "defaultpassphrase")
        salt = None  # Let the function generate it or provide your own
        method = "fernet"  # Can be 'fernet' or 'rsa'
        encryption_method = select_encryption_method(method)

        if method == "fernet":
            # Generate key, encrypt and decrypt using Fernet
            key, salt = generate_key(passphrase, salt)
            f = encryption_method(key)
            message = "Secure Message"
            encrypted_message = f.encrypt(message.encode())
            decrypted_message = f.decrypt(encrypted_message).decode()
            logging.info(f"Encrypted message: {encrypted_message}")
            logging.info(f"Decrypted message: {decrypted_message}")
        elif method == "rsa":
            # RSA usage example would be more complex due to key generation and management
            pass
    except Exception as e:
        logging.error("An error occurred: %s", e)