# file: mirror.py
import logging
import os

from telethon.sync import TelegramClient
from telethon.sessions import StringSession
from telethon import events

from config import (API_ID, API_HASH, SESSION_STRING, 
                    SOURCE_CHANNEL, TARGET_CHANNEL)

# Настройка логирования
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Подключение к Telegram API
if os.path.exists('session.txt'):
    with open('session.txt', 'r') as f:
        session_str = f.read().strip()
    client = TelegramClient(StringSession(session_str), API_ID, API_HASH)
else:
    client = TelegramClient(StringSession(), API_ID, API_HASH)

# Обработчик новых сообщений
@client.on(events.NewMessage(chats=SOURCE_CHANNEL))
async def handler_new_message(event):
    try:
        await client.send_message(TARGET_CHANNEL, event.message)
        logger.debug(f"Message forwarded: {event.message}")
    except Exception as e:
        logger.error(f"Error forwarding message: {e}")

# Запуск клиента
if __name__ == '__main__':
    client.start()
    logger.info("Client started")
    if not os.path.exists('session.txt'):
        with open('session.txt', 'w') as f:
            f.write(client.session.save())
    client.run_until_disconnected