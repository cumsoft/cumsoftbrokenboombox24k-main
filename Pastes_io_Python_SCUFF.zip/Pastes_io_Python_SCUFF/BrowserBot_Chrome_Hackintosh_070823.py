from urllib.parse import urlparse
import asyncio
from selenium import webdriver
from bs4 import BeautifulSoup
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.chrome.options import Options as ChromeOpts
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import InvalidArgumentException, TimeoutException
from re import search
import pyautogui
import time
from selenium.common.exceptions import NoSuchElementException, WebDriverException
import Logger
import os
import math
from WinManager import *

os.system("taskkill /f /im webdriver.exe /T")
os.system("taskkill /f /im chrome.exe /T") 
HomeDir = r'C:\Users\Serbz\Desktop\9.py'
VarDir = HomeDir + r'\VariableVariables'
LogDir = HomeDir + r'\Logs'
StaticVarDir = HomeDir + r'\StaticVars'
SoundDir = HomeDir + r'\Sound'
ChromeDir = HomeDir + r'\Chrome'
ScriptDir = HomeDir + r'\SkrippitySkripz'
ImgDir = HomeDir + r'\ImageSearch'
homepage = r'https://google.com'
PATH = HomeDir + r"\Chrome\chromedriver.exe"
options = ChromeOpts()
prefs = {'exit_type': 'Normal'}
#options.add_experimental_option("excludeSwitches", ['enable-automation']);
options.add_experimental_option("prefs", {"profile.default_content_setting_values.notifications": 2})
options.add_experimental_option("prefs", {'profile': prefs})
options.add_extension(r"C:\Users\Serbz\Desktop\9.py\Chrome\User Data\Default\Extensions\cfhdojbkjhnklbpkdaibdccddilifddb\3.11_0.crx") #either adblock or tunnelbear
options.add_extension(r"C:\Users\Serbz\Desktop\9.py\Chrome\User Data\Default\Extensions\omdakjcmkglenbhjadbccaookpfjihpa\3.4.0_0.crx") #either adblock or tunnelbear
options.add_argument(r"user-data-dir=C:\Users\Serbz\Desktop\9.py\Chrome\User Data")
driver = webdriver.Chrome(options=options, executable_path=PATH)
wait = WebDriverWait(driver, 3)
driver.get(homepage)
presence = EC.presence_of_element_located
visible = EC.visibility_of_element_located
tabsOpen = len(driver.window_handles)
main_window = driver.current_window_handle
AutoScroll = False
ScrollVar = 0
NetflixUser = None
ProxyBox = False
SerbzDir = HomeDir + r'\SerbzDir'
driver.maximize_window()
##########################################################################
##########################################################################
def ScrollVarChange(val):
    ScrollVar=val
    return
##########################################################################
##########################################################################
#def click(var1, var2=0):
#    pyautogui.hotkey('ctrl', 'f')
#    pyautogui.write(var1)
#    if var2 > 0:
#        pyautogui.press('return', presses=var2)
#    pyautogui.hotkey('ctrl', 'return')
#    
#    return "Clicked on " + var1 + " using hotkeys."
##########################################################################
##########################################################################
def LocateElementDisc(var1, Xoff, Yoff):
    driver.find_element_by_class(str(var1))
    Logger.LogPrint("element coordinates x =" + str(var1.location['x']) + " y =" + str(var1.location['y']) + " width="
                    + str(var1.size['width']) + "height=" + str(var1.size['height']))
    return str("element coordinates x =" + str(var1.location['x']) + " y =" + str(var1.location['y']) + " width="
               + str(var1.size['width']) + "height=" + str(var1.size['height']))
##########################################################################
##########################################################################
def clickElement(var1: WebElement):
    x = var1.location['x'] + (var1.size['width'] / 2)
    y = var1.location['y'] + (var1.size['height'] / 2)
    print("Clicking at coordinates x =" + str(x) + " y =" + str(y) + " " + str(var1.size['width']) + " "
          + str(var1.size['height']))
    pyautogui.click(x=x, y=y + 120)
##########################################################################
##########################################################################
async def clickm():
    pyautogui.hotkey('ctrl', 'return')
    return "Clicked at current selection."
##########################################################################
##########################################################################
def xclick(var1, var2=-1):
    
    try:
        eleList = driver.find_elements_by_xpath(var1)
        if len(eleList) == 0:
            return "not found"
        eleList[var2].click()
    except NoSuchElementException:
        return "not found"
    return "Clicked on " + var1 + " using xpath."
##########################################################################
##########################################################################
def forward():
    driver.forward()
    
    return
##########################################################################
##########################################################################
def back():
    driver.back()
    return
    
async def pwindow():
    global prev_window
    driver.switch_to.window(prev_window)
    return

async def mainTabTitle():
    global prev_window
    prev_window = driver.current_window_handle
    driver.switch_to.window(main_window)
    return str(driver.title)

##########################################################################
##########################################################################
def close_tab():
    tabsCounter = 0
    for key in driver.window_handles:
        tabsCounter = tabsCounter + 1
        if driver.current_window_handle == key:
            break
    if driver.current_window_handle == main_window:
        Logger.LogPrint("unable to close this window")
        return
    driver.close()
    driver.switch_to.window(driver.window_handles[tabsCounter - 2])
    verifyTab()
    return
##########################################################################
##########################################################################
def previousKinda_tab():
    tabsCounter = 0
    for key in driver.window_handles:
        tabsCounter = tabsCounter + 1
        if driver.current_window_handle == key:
            break
    if driver.current_window_handle == main_window:
        Logger.LogPrint("unable to close this window")
        return
    # driver.close()
    driver.switch_to.window(driver.window_handles[tabsCounter - 2])
    verifyTab()    
    return
##########################################################################
##########################################################################
def new_tab():
    global main_window
    global prev_window
    verifyTab()
    prev_window = driver.current_window_handle
    tabsCounter = 0
    for key in driver.window_handles:
        tabsCounter = tabsCounter + 1
    driver.execute_script('''window.open("https://www.google.com", "_blank");''')
    new_window = [window for window in driver.window_handles if window != main_window][tabsCounter - 1]
    driver.switch_to.window(new_window)
    # await switch_tab(tabsCounter-1)
    verifyTab()
    return
##########################################################################
##########################################################################
def switch_tab(var1):
    global prev_window
    prev_window = driver.current_window_handle
    driver.switch_to.window(driver.window_handles[var1 - 1])
    verifyTab()
    return
##########################################################################
##########################################################################
def verifyTab(param="NaN"):
    global tabsOpen
    tabsOpen = len(driver.window_handles)
    return
##########################################################################
##########################################################################
def http(var1):
    global ProxyBox
    if 'spotify' in str(var1):
        driver.get("https://open.spotify.com")
        return r"Browsing to <https://open.spotify.com>"
    if var1[0:4] != "http":
        var1 = "https://" + var1
    if not ("." in var1):
        var1 = var1 + ".com"
    try:
        driver.get(var1)
        #if ProxyBox == False:
        #    WinManager.proxyCheck(ProxyBox)
        return "Browsing to <" + var1 + ">"
    except InvalidArgumentException:
        return "Invalid URL"
##########################################################################
##########################################################################
async def ASYNChttp(var1):
    global ProxyBox
    if var1[0:4] != "http":
        var1 = "https://" + var1
    if not ("." in var1):
        var1 = var1 + ".com"
    try:
        driver.get(var1)
        await asyncio.sleep(3)
        if ProxyBox == False:
            ProxyBox = await proxyCheck(ProxyBox)
        return var1
    except (InvalidArgumentException, NameError, WebDriverException) as e:
        return var1
##########################################################################
##########################################################################
async def view():
    driver.save_screenshot(HomeDir + r"\ImageSearch\screenshot.png")
    return
async def viewAS():
    driver.save_screenshot(HomeDir + r"\ImageSearch\screenShot2.png")
    return
##########################################################################
##########################################################################
async def fmovie(var1):
    stringBuild = "http://fmovies.to/movies?keyword="
    for subStr in str(var1).split():
        stringBuild = stringBuild + subStr + "+"
    stringBuild = stringBuild[:-1]
    http(stringBuild)

    wait.until(visible((By.ID, "menu")))
    moviePoster = driver.find_element_by_class_name("poster")
    moviePoster.click()
    time.sleep(1)
    VerifyTabs()
    
    return "Enjoy the Magic of the Movies!"
##########################################################################
##########################################################################

##########################################################################
##########################################################################
async def CHnetflix1(ctx, var1, season=1, episode=1): ######## user="serbz"):
#    global NetflixUser
    global CPos
    CPos = await scrollPos()
    stringBuild = "https://netflix.com/search?q="
    for subStr in str(var1).split():
        stringBuild = stringBuild + subStr + "+"

    stringBuild = stringBuild[:-1]
    await ASYNChttp(stringBuild)
    try:
        await asyncio.sleep(1)
        wait.until(visible((By.CLASS_NAME, "galleryContent")))
        driver.find_element_by_class_name("title-card").click()
    
        WebDriverWait(driver, 4).until(visible((By.CLASS_NAME, "episodeSelector-dropdown")))
    except TimeoutException:
        await asyncio.sleep(2)
        pass
    await scrollClickElement(driver.find_element_by_class_name(r"episodeSelector-dropdown"), x=1050)
    await asyncio.sleep(0.2)
    pyautogui.moveTo(1540,450,0.5)
    pyautogui.scroll(25)
    await asyncio.sleep(2)
    CPos = await scrollPos()
    print("CPos " + str(CPos))
    return



async def CHnetflix2(ctx, var1, season=1, episode=1, user="serbz"):
    try:
        WebDriverWait(driver, 4).until(visible((By.CLASS_NAME, "episodeSelector-dropdown")))
        await scrollClickElement(driver.find_element_by_class_name(r"episodeSelector-dropdown"), x=1050)
    except:
        pass

    await asyncio.sleep(1)
    try:
        WebDriverWait(driver, 2).until(visible((By.XPATH, "//div[@class='titleCardList-title']")))
        await scrollClickElement(driver.find_elements_by_xpath("//div[@class='titleCardList-title']")[episode - 1], x=700, y=170)
        await asyncio.sleep(1)
    except TimeoutException:
        pass
    xclick(r"//a[@data-uia='play-button']")
    return "done"
##########################################################################
##########################################################################
def bSearch(ctx, var1):
    stringBuild = "https://www.google.com/search?q="
    for subStr in str(var1).split():
        stringBuild = stringBuild + subStr + "+"
    stringBuild = stringBuild[:-1]
    http(stringBuild)
    return
##########################################################################
##########################################################################
def VerifyURL():
    text_file = open(StaticVarDir + r"\BlackList.txt")
    text_fileSplit = str(text_file.read()).split("\n")
    text_file.close()
    for line in text_fileSplit:
        if search(line, driver.current_url):
            driver.get(homepage)
            return False
    return True
##########################################################################
##########################################################################
def VerifyTabs():
    originalTab = driver.current_window_handle
    if len(driver.window_handles) > 1:
        for thisWindowHandle in driver.window_handles[1:]:
            driver.switch_to.window(thisWindowHandle)
            driver.close()
        driver.switch_to.window(originalTab)
    return
##########################################################################
##########################################################################
async def getURL(line, var2=None):
    global URL
    if var2!=None:
        URL = driver.current_url
        return driver.current_url
    if line in driver.current_url:
        return True
    if line == "NaN":
        return str(driver.current_url)
    return False
##########################################################################
##########################################################################
def playPause():
    pyautogui.press('playpause')
    return
##########################################################################
##########################################################################
def volume(var1):
    if not var1.isnumeric():
        return "Variable must be a number 0 - 100"

    thisInt = int(var1)
    if not (0 <= thisInt <= 100):
        return "Variable must be a number 0 - 100"

    pyautogui.press('volumedown', presses=50)

    pyautogui.press('volumeup', presses=int(thisInt / 2))

    return "Set volume to " + str(2 * int(thisInt / 2)) + " percent."
##########################################################################
##########################################################################
def refresh():
    driver.refresh()
    
    return
##########################################################################
##########################################################################
def ytsearch(var1):
    stringBuild = "https://www.youtube.com/results?search_query="
    for subStr in str(var1).split():
        stringBuild = stringBuild + subStr + "+"
    stringBuild = stringBuild[:-1]
    http(stringBuild)
    
    return
##########################################################################
##########################################################################
async def scrollClickElement(var1, x=0, y=140):
    driver.execute_script("arguments[0].scrollIntoView();", var1)
    pyautogui.click(x=x, y=y)
    return
    
##########################################################################
##########################################################################

async def getSize():
    size = driver.get_window_size()
    width1 = size.get("width")
    height1 = size.get("height")
    width1 = width1 - 20
    height1 = height1 - 15
    return width1, height1

async def getLoc():
    x, y = driver.get_window_position(driver.current_window_handle)
    return x, y

async def coordClick(x=0, y=125):
    
    if x > 0 or y > 0:
        if pyautogui.onScreen(x, y):
            pyautogui.moveTo(x, y, 1)
            pyautogui.click(x, y)
            return "Clicked at coordinates x-" + str(x) + ", y=" + str(y)
        else:
            return "Invalid coordinates. Please try again."
    else:
        pyautogui.click()
        return "Clicked at current coordinates."
##########################################################################
##########################################################################
async def scrollUp(amt=450):
    CPos = await scrollPos()
    ScrollVar = int(CPos) - amt
    driver.execute_script("window.scrollTo(0, " + str(ScrollVar) + ")")
    return
##########################################################################
##########################################################################
async def scrollDown(amt=450):
    CPos = await scrollPos()
    ScrollVar = int(CPos) + amt
    driver.execute_script("window.scrollTo(0, " + str(ScrollVar) + ")")
    return
    
async def xpathSearch(str):
    try:
        
        #find_element(By.XPATH, "//*[@value='
        #textS_Str = driver.find_element_by_xpath("//*[normalize-space(text()) = str]")
        #textS_Str = driver.find_element_by_xpath(r"//*[normalize-space(text()) = " + str + r"]")
        #textS_Str = driver.find_element_by_xpath(r"//*[. = " + str + r"]")
        #textS_Str = driver.find_element_by_xpath(r"//*[normalize-space() = " + str + r"]")
        #textS_Str = driver.findElement(By.xpath("//*[contains(text()," + str + "])")
        #textS_Str = driver.find_element_by_xpath("//div[contains(@class," + str + "]//text())")
        #textS_Str = driver.find_element_by_xpath('//p[contains(text(),"$strStr")]', strStr=str)
        textS_Str = driver.find_element(By.XPATH, str = "//*[@value=\'" + str + "\']" )
        #textS_Str = driver.find_element_by_xpath("//h3[contains(text(),'" + str + "'])")
        #textS_Str = driver.find_element_by_text("//h3[contains(text(),'" + str + "'])")
        #String count = driver.findElement(By.cssSelector("div.alert.alert-count p")).getText();
        #String count = driver.findElement(By.cssSelector("div.alert.alert-count p")).getText();
    except NoSuchElementException:
        return "Not Found"
    return str(textS_Str)
##########################################################################
##########################################################################
async def scrollBottom():
    scrolls = 4
    while True:
        scrolls -= 1
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight)")
        time.sleep(3)
        if scrolls < 0:
            break
    return
##########################################################################
##########################################################################
def scrollPos2():
    return str(driver.execute_script('return window.pageYOffset;'))
async def scrollPos():
    return str(driver.execute_script('return window.pageYOffset;'))

async def maximize():
    driver.maximize_window()
    return

async def url_change(stringy, strings):
    global URL, O_URL
    URL = await getURL(1, 1)
    URLcut = ((str(URL.replace("http://www.", "")).replace("https://www.", "")).split("."))[0]
    if strings == "string stuff":
        O_URL = URL
        return False
    else:
        if O_URL != URLcut:
            O_URL = stringy
            return True
    return False