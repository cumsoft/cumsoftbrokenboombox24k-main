import turtle
import random
import winsound

# variables
Playing = True
playerpic = "Player.gif"
alien1 = "Alien 1.gif"
alien2 = "Alien 2.gif"

# screen
wn = turtle.Screen()
wn.title("Space Invaders")
wn.bgcolor("black")
wn.setup(width=600, height=800)
wn.addshape(playerpic)
wn.addshape(alien1)
wn.addshape(alien2)
# Player
player = turtle.Turtle()
player.speed(1)
player.shape(playerpic)
player.color("red")
player.penup()
player.goto(0,-350)

while Playing:
    wn.update()