import random
gamestate = True
while gamestate == True:
 
  dungeon= [["empty", "downstairs", "empty", "medkit", "sword", "empty", "empty", "scraps", "empty", "magical bullet","e1"],
  ["upstairs", "empty", "scraps", "arrow", "e2", "empty", "empty", "longsword", "empty", "downstairs","medkit"],
  ["empty", "empty", "upstairs", "empty", "scraps", "empty", "empty", "downstairs", "dagger", "e3","empty"],
  ["medkit", "upstairs", "empty", "arrow", "empty", "empty", "empty", "e4", "sword", "downstairs","empty"],
  ["prize", "empty", "arrow", "boss", "empty", "empty", "upstairs", "empty", "empty", "magical gun","empty"]]
  
  injury = 0
  position = 0
  inventory = []
  floor = 0
  highscore = []
  x = 0
  
  def e1 (floor,position):
    global injury
    response = input("fight,run")
    chancef = random.randint(1,20)
    chancer = random.randint(1,20)
    weapon = input("what weapon would you like to use")
    if weapon == "bow" and "arrow" in inventory:
      chancef +=7
    elif weapon == "bow" and "arrow" not in inventory:
      print("you are out of arrows")
      weapon = input("what weapon would you like to use")
    if weapon != "bow":
      if weapon == "sword":
        chancef +=3
      elif weapon == "magical gun":
        chancef +=10
      elif weapon == "axe":
        chancef +=5
      elif weapon == "longsword":
        chancef +=6
      elif weapon =="dagger":
        chancef +=3
      elif weapon == "fastrelic":
        chancer +=4
      elif weapon == "flail":
        chancef +=9
      else:
        print("invalid")
    if chancef > 10 and response == "fight":
      if chancef > 10 and chancef < 15:
        injury += random.randint(1,3)
        print("you got injured")
        if input("do you want to heal y/n") == "y" and "medkit" in inventory:
          injury -=1
          inventory.remove("medkit")
          if injury < 0:
            injury = 0
      print("you have "+str(injury) + "injuries") 
      print("monster died")
      dungeon[floor][position] = "axe"
      newMove()
    elif chancef < 11   and response == "fight":
      dungeon[floor][position] = "dead"
    if chancer > 5 and response == "run":
      if chancer > 5 and chancer < 11:
        injury +=1
      dungeon[floor][position] = "gone"
    elif chancer < 6 and response == "run":
      dungeon[floor][position] = "dead"

  def e2 (floor,position):
    global injury
    response = input("fight,run")
    chancef = random.randint(1,25)
    chancer = random.randint(1,25)
    weapon = input("what weapon would you like to use")
    if weapon == "bow" and "arrow" in inventory:
      chancef +=7
    elif weapon == "bow" and "arrow" not in inventory:
      print("you are out of arrows")
      weapon = input("what weapon would you like to use")
    if weapon != "bow":
      if weapon == "sword":
        chancef +=3
      elif weapon == "magical gun":
        chancef +=10
      elif weapon == "axe":
        chancef +=5
      elif weapon == "longsword":
        chancef +=6
      elif weapon =="dagger":
        chancef +=3
      elif weapon == "fastrelic":
        chancer +=4
      elif weapon == "flail":
        chancef +=9
      else:
        print("invalid")
    if chancef > 13 and response == "fight":
      if chancef > 13 and chancef < 20:
        injury += random.randint(1,3)
        print("you got injured")
        if input("do you want to heal y/n") == "y" and "medkit" in inventory:
          injury -=1
          inventory.remove("medkit")
          if injury < 0:
            injury = 0
      print("you have "+str(injury) + "injuries") 
      print("monster died")
      dungeon[floor][position] = "bow"
      newMove()
    elif chancef < 14   and response == "fight":
      dungeon[floor][position] = "dead"
    if chancer > 10 and response == "run":
      if chancer > 10 and chancer < 18:
        injury +=1
      dungeon[floor][position] = "gone"
    elif chancer < 10 and response == "run":
      dungeon[floor][position] = "dead"

  def e3 (floor,position):
    global injury
    response = input("fight,run")
    chancef = random.randint(1,30)
    chancer = random.randint(1,30)
    weapon = input("what weapon would you like to use")
    if weapon == "bow" and "arrow" in inventory:
      chancef +=7
    elif weapon == "bow" and "arrow" not in inventory:
      print("you are out of arrows")
      weapon = input("what weapon would you like to use")
    if weapon != "bow":
      if weapon == "sword":
        chancef +=3
      elif weapon == "magical gun":
        chancef +=10
      elif weapon == "axe":
        chancef +=5
      elif weapon == "longsword":
        chancef +=6
      elif weapon =="dagger":
        chancef +=3
      elif weapon == "fastrelic":
        chancer +=4
      elif weapon == "flail":
        chancef +=9
      else:
        print("invalid")
    if chancef > 20 and response == "fight":
      if chancef > 20 and chancef < 25:
        injury += random.randint(1,3)
        print("you got injured")
        if input("do you want to heal y/n") == "y" and "medkit" in inventory:
          injury -=1
          inventory.remove("medkit")
          if injury < 0:
            injury = 0
      print("you have "+str(injury) + "injuries") 
      print("monster died")
      dungeon[floor][position] = "fastrelic"
      newMove()
    elif chancef < 20   and response == "fight":
      dungeon[floor][position] = "dead"
    if chancer > 15 and response == "run":
      if chancer > 15 and chancer < 20:
        injury +=1
      dungeon[floor][position] = "gone"
    elif chancer < 16 and response == "run":
      dungeon[floor][position] = "dead"

  def e4 (floor,position):
    global injury
    response = input("fight,run")
    chancef = random.randint(1,35)
    chancer = random.randint(1,35)
    if response == "fight":
      weapon = input("what weapon would you like to use")
      if weapon == "bow" and "arrow" in inventory:
        chancef +=7
      elif weapon == "bow" and "arrow" not in inventory:
        print("you are out of arrows")
        weapon = input("what weapon would you like to use")
      if weapon != "bow":
        if weapon == "sword":
          chancef +=3
        elif weapon == "magical gun":
          chancef +=10
        elif weapon == "axe":
          chancef +=5
        elif weapon == "longsword":
          chancef +=6
        elif weapon =="dagger":
          chancef +=3
        elif weapon == "fastrelic":
          chancer +=4
        elif weapon == "flail":
          chancef +=9
        else:
          print("invalid")
    if chancef > 20 and response == "fight":
      if chancef > 20 and chancef < 26:
        injury += random.randint(1,3)
        print("you got injured")
        if input("do you want to heal y/n") == "y" and "medkit" in inventory:
          injury -=1
          inventory.remove("medkit")
          if injury < 0:
            injury = 0
      print("you have "+str(injury) + "injuries") 
      print("monster died")
      dungeon[floor][position] = "flail"
      newMove()
    elif chancef < 21   and response == "fight":
      dungeon[floor][position] = "dead"
    if chancer > 15 and response == "run":
      if chancer > 15 and chancer < 21:
        injury +=1
      dungeon[floor][position] = "gone"
    elif chancer < 16 and response == "run":
      dungeon[floor][position] = "dead"
    
  def boss(floor,position):
    global injury
    response = input("fight,run")
    chancef = random.randint(1,50)
    chancer = random.randint(1,50)
    if response == "fight":
      weapon = input("what weapon would you like to use")
      if weapon == "bow" and "arrow" in inventory:
        chancef +=7
      elif weapon == "bow" and "arrow" not in inventory:
        print("you are out of arrows")
        weapon = input("what weapon would you like to use")
        inventory.remove(weapon)
      if weapon != "bow":
        if weapon == "sword":
          chancef +=3
        elif weapon == "magical gun":
          chancef +=10
        elif weapon == "axe":
          chancef +=5
        elif weapon == "longsword":
          chancef +=6
        elif weapon =="dagger":
          chancef +=3
        elif weapon == "fastrelic":
          chancer +=4
        elif weapon == "flail":
          chancef +=9
        else:
          print("invalid")
    if chancef > 25 and response == "fight":
      if chancef > 25 and chancef < 35:
        injury += random.randint(1,3)
        print("you got injured")
        if input("do you want to heal y/n") == "y" and "medkit" in inventory:
          injury -=1
          inventory.remove("medkit")
          if injury < 0:
            injury = 0
      print("you have "+str(injury) + "injuries") 
    elif chancef < 26   and response == "fight":
      dungeon[floor][position] = "dead"
    if chancer > 15 and response == "run":
      if chancer > 15 and chancer < 21:
        injury +=1
        position -=1
    elif chancer < 16 and response == "run":
      dungeon[floor][position] = "dead"
    print("the boss is almost dead")
    print(inventory)
    response = input("fight,run")
    chancef = random.randint(1,50)
    chancer = random.randint(1,50)
    if response == "fight":
     weapon = input("what weapon would you like to use")
    if weapon == "bow" and "arrow" in inventory:
      chancef +=7
    if weapon != "bow":
      if weapon == "sword":
        chancef +=3
      elif weapon == "magical gun":
        chancef +=10
      elif weapon == "axe":
        chancef +=5
      elif weapon == "longsword":
        chancef +=6
      elif weapon =="dagger":
        chancef +=3
      elif weapon == "fastrelic":
        chancer +=4
      elif weapon == "flail":
        chancef +=9
      else:
        print("invalid")
    if chancef > 25 and response == "fight":
      print("the boss is dead")
      if chancef > 25 and chancef < 35:
        injury += random.randint(1,3)
        print("you got injured")
        if input("do you want to heal y/n") == "y" and "medkit" in inventory:
          injury -=1
          inventory.remove("medkit")
          if injury < 0:
            injury = 0
      print("you have "+str(injury) + "injuries") 
      dungeon[floor][position] = "empty"
      newMove()
    elif chancef < 26   and response == "fight":
      dungeon[floor][position] = "dead"
    if chancer > 15 and response == "run":
      if chancer > 15 and chancer < 21:
        injury +=1
      dungeon[floor][position] = "gone"
    elif chancer < 16 and response == "run":
      dungeon[floor][position] = "dead"
    

  def newMove ():
    print(dungeon[floor][position])
    print("Floor " + str(floor) + ", Room "+ str(position) + ", Inventory:" + str(inventory))
   
  
  
  def moving ():
    global position
    global floor
    
    move = input("left, down, up, right, grab: ")
    
    if(move == "left"):
      if(position > 0):
        position -= 1
      else: print("invalid")
    elif(move == "right"):
      if(position < 10):
        position += 1
      else: print("invalid")
    elif(move == "up"):
      if(dungeon[floor][position] == "upstairs"):
        floor -= 1
      else: print("invalid")
    elif(move == "down"):
      if(dungeon[floor][position] =="downstairs"):
        floor += 1
      else: print("invalid")
    elif(move == "grab"):
      if(dungeon[floor][position] =="sword"):
        inventory.append("sword")
        dungeon[floor][position] = "empty"
      elif(dungeon[floor][position] =="longsword"):
        inventory.append("longsword")
        dungeon[floor][position] = "empty"
      elif(dungeon[floor][position] =="magical bullet"):
        inventory.append("magical bullet")
        dungeon[floor][position] = "empty"
      elif(dungeon[floor][position] =="magical gun"):
        inventory.append("magical gun")
        dungeon[floor][position] = "empty"
      elif(dungeon[floor][position] =="medkit"):
        inventory.append("medkit")
        dungeon[floor][position] = "empty"
      elif(dungeon[floor][position] =="scraps"):
        inventory.append("scraps")
        dungeon[floor][position] = "empty"
      elif(dungeon[floor][position] =="axe"):
        inventory.append("axe")
        dungeon[floor][position] = "empty"
      elif(dungeon[floor][position] =="bow"):
        inventory.append("bow")
      elif(dungeon[floor][position] =="arrow"):
        inventory.append("arrow")
        dungeon[floor][position] = "empty"
      elif(dungeon[floor][position] =="dagger"):
        inventory.append("dagger")
        dungeon[floor][position] = "empty"
      elif(dungeon[floor][position] =="fastrelic"):
        inventory.append("fastrelic")
        dungeon[floor][position] = "empty"
      elif(dungeon[floor][position] =="flail"):
        inventory.append("flail")
        dungeon[floor][position] = "empty"
      elif(dungeon[floor][position] =="prize"):
        inventory.append("prize")
        dungeon[floor][position] = "win"
      else: print("invalid")
    else: print("invalid")

  
  def checkMonster ():
    if(dungeon[floor][position] == "e1"):
      e1(floor,position)
    if(dungeon[floor][position] == "e2"):
      e2(floor,position)
    if(dungeon[floor][position] == "e3"):
      e3(floor,position)
      print("there appears to be a second enemy")

    if(dungeon[floor][position] == "e4"):
      e4(floor,position)
      print("there appears to be a second enemy,")

    if (dungeon[floor][position] == "boss"):
      boss(floor,position)

  while (gamestate):
    
    moving()
    newMove()
    checkMonster()
    
    if dungeon[floor][position] == "dead":
        print("You Died")
        if position < len(dungeon[floor]):
            score = len(dungeon[floor]) * 10 + position
        else:
            print("Invalid position")
        highscore.append(score)
        x = score
        
        for i in highscore:
            if i > score:
                score = x
        print("your highscore is " + str(score))
      
        playAgain = input("play again? y/n")
        if playAgain == "y":
            injury = 0
            position = 0
            inventory = []
            floor = 0
            dungeon= [["empty", "downstairs", "empty", "medkit", "sword", "empty", "empty", "scraps", "empty", "magical bullet","e1"],
            ["upstairs", "empty", "scraps", "arrow", "e2", "empty", "empty", "longsword", "empty", "downstairs","medkit"],
            ["empty", "empty", "upstairs", "empty", "scraps", "empty", "empty", "downstairs", "dagger", "e3","empty"],
            ["medkit", "upstairs", "empty", "arrow", "empty", "empty", "empty", "e4", "sword", "downstairs","empty"],
            ["prize", "empty", "arrow", "boss", "empty", "empty", "upstairs", "empty", "empty", "magical gun","empty"]]
        elif playAgain == "n":
            gamestate = False
            exit()
      
        if injury >=6:
          print("injuries were too severe, you died")
          score = dungeon[floor] * 10 + dungeon[position]
          highscore.append(score)
          x = score
          for i in highscore:
    
            if i > score:
              score = x
    
    
          print("your highscore is " + str(score))
    

        playAgain = input("play again? y/n")
        if playAgain == "y":
            injury = 0
            position = 0
            inventory = []
            floor = 0
            dungeon= [["empty", "downstairs", "empty", "medkit", "sword", "empty", "empty", "scraps", "empty", "magical bullet","e1"],
    ["upstairs", "empty", "scraps", "arrow", "e2", "empty", "empty", "longsword", "empty", "downstairs","medkit"],
    ["empty", "empty", "upstairs", "empty", "scraps", "empty", "empty", "downstairs", "dagger", "e3","empty"],
    ["medkit", "upstairs", "empty", "arrow", "empty", "empty", "empty", "e4", "sword", "downstairs","empty"],
    ["prize", "empty", "arrow", "boss", "empty", "empty", "upstairs", "empty", "empty", "magical gun","empty"]]
        elif playAgain == "n":
            gamestate = False
            exit()
      
        if(dungeon[floor][position] == "win"):
            print("your highscore is floor 5 and your highest room is 10")
            if position < len(dungeon[floor]):
                score = dungeon[floor][position] * 10 + position
            else:
                print("Invalid position")
            highscore.append(score)
            x = score
            
            for i in highscore:
                if i > score:
                    score = x
            print("your highscore is " + str(score))
        
            playAgain = input("play again? y/n")
            if playAgain == "y":
                injury = 0
                position = 0
                inventory = []
                floor = 0
                dungeon= [["empty", "downstairs", "empty", "medkit", "sword", "empty", "empty", "scraps", "empty", "magical bullet","e1"],
                ["upstairs", "empty", "scraps", "arrow", "e2", "empty", "empty", "longsword", "empty", "downstairs","medkit"],
                ["empty", "empty", "upstairs", "empty", "scraps", "empty", "empty", "downstairs", "dagger", "e3","empty"],
                ["medkit", "upstairs", "empty", "arrow", "empty", "empty", "empty", "e4", "sword", "downstairs","empty"],
                ["prize", "empty", "arrow", "boss", "empty", "empty", "upstairs", "empty", "empty", "magical gun","empty"]]
            elif playAgain == "n":
                gamestate = False
                exit()