import os
from pydub import AudioSegment
import PyPDF2
import pyttsx3

pdf_path = 'Brief answers.pdf'

output_file_name = os.path.splitext(pdf_path)[0] + "-output.wav"

try:
    pdf_reader = PyPDF2.PdfReader(open(pdf_path, 'rb'))
    speaker = pyttsx3.init()
    pages = len(pdf_reader.pages)
except FileNotFoundError:
    print(f'Error: The file {pdf_path} does not exist.')
    exit()
except PyPDF2.utils.PdfReadError:
    print(f'Error: The file {pdf_path} is not a valid PDF file.')
    exit()
except Exception as e:
    print(f'Error: An unexpected error occurred.')
    exit()

# Generate all audio files
for page_num in range(pages):
    try:
        text = pdf_reader.pages[page_num].extract_text()
        clean_text = text.strip().replace('\n', ' ')
        print(clean_text)

        if clean_text:
            audio_file_path = f'page_{page_num}.wav'
            speaker.save_to_file(clean_text, audio_file_path)
        else:
            print(f'Skipping page {page_num} as it has no text.')
            continue
    except Exception as e:
        print(f'Error on page {page_num}: An unexpected error occurred.')
        continue

try:
    speaker.runAndWait()
    speaker.stop()
except Exception as e:
    print(f'Error: An unexpected error occurred.')
    exit()

finally:
    print(f'Audio files generated for {pages} pages.')

# Concatenate audio segments into a single audio file
combined_audio = AudioSegment.silent(duration=0)
for page_num in range(pages):
    audio_file_path = f'page_{page_num}.wav'
    if os.path.exists(audio_file_path):
        audio_segment = AudioSegment.from_wav(audio_file_path)
        combined_audio = combined_audio.append(audio_segment, crossfade=0)
    else:
        print(f'Error: WAV file not found for page {page_num}.')
        continue

# Export the combined audio to a single file
nam_Transf_file = "YourNewAudiobook"
combined_audio.export(output_file_name, format="wav")
print("Combined audio file generated successfully.")

# Clean up temporary audio files
for page_num in range(pages):
    audio_file_path = f'page_{page_num}.wav'
    if os.path.exists(audio_file_path):
        os.remove(audio_file_path)