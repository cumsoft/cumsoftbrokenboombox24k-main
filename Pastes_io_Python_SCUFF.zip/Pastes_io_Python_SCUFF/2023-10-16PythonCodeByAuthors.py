#This python code was created and used by the authors of the work with the preliminary title "Taxation and the relationship between payments and time spent". This work including this code was created in 2023-10. The work is expected to be handed in to a journal in 2023Q4 and expected to be published in 2024. Today is 2023-10-16.
### 0. SET PIC
Dpi = 999#<-SetDPI(3500->2MB).
PicHeight = 0#0=Standard.InInch.CanBeMax28(betterMax20)At900Dpi.LengthWillBe1.5*H.
FileFmt = 'png'#png, svg, svgz, pdf, eps, ps, tif, tiff, raw, rgba, jpg, jpeg, pgf.#First6AreBest.

### 1. LABEL: TitleLine1, TitleLine2, x&y-axis
TtlL1 = ''
TtlL2 = ''
xLabl = "x, hours spent"
yLabl = "y, amount of payments"

### 2. INPUT X&Y
X = [270,252,265,287,177,311.5,264,105,131,159,155,22.5,435,241,170,136,147,270,52,1025,411,120,1501,52.5,441,270,232,180,173,624,131,483,834,296,138,255.5,100,346,602,151,187,206,119.5,230,132,76,117,317,664,370,168,492,216,50,122,300,247,90,139,632,326,216,218,226,193,140,248,400,218,256,184,203,34.5,277,140,251.88,191,216,312,81.5,234,238,268,128.5,96.5,186,179.5,168,174,153.5,98,220,362,168.5,181,327,139.5,889,95,55,183,169,174,390.5,276,139,56,270,140,240.5,128,183,134,300,155,200,282,302,377,119,140,201,270,343.365,119,79,68,283,52,408,207,378,260,171,334,243,218,41,163,159,90.5,224,52,424,104,416,225.5,85,343,64,192,233,80,210,210,143,129,203,110,108,180,199,122,63,336,221,224,207,229,234,159,200,210,144,170,195,327.5,116,114,175,163,181,120,920,384,174,248,158,242]
Y = [6,18,15,17,20,7,12,6,8,5,8,2,16,12,4,8,16,25,4,29,20,15,5.6,3,12,20,15,14,16,19,4,28,18,5,4,7,18,15,20,7,11,10,13,5,6,19,20,4,5,14,5,21,16,7,18,16,15,4,6,31,31,3,6,19,6,17,5,18,29,17,16,18,1,7,7,5,7,7,2,7,3,11,9,13,7,5,9,4,8,4,0,23,19,5,7,16,16,3,8,6,14,17,5,4,7,5,5,23,6,3,17,6,6,4,4,18,14,11,17,7,4,18,25,19,5,3,1,8,3,18,18,6,5,9,4,6,5,2,10,4,6,8,4,30,2,14,31,4,16,3,6,8,17,4,20,7,29,22,19,20,28,13,4,10,6,6,4,18,6,1,20,17,11,3,8,16,3,4,6,4.6,6,5,19,57,3,13,19,8,30]


### 3. SCRIPT RUNS:
#Imports
from datetime import datetime, timezone
timestr1 = datetime.strftime(datetime.now(timezone.utc), "%Y-%m-%dz%H%M%S");earlier = datetime.now(timezone.utc)
print("Start: {}".format(timestr1))
import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import pearsonr
from sklearn.metrics import mutual_info_score

#Calculate MutInf
X = [i * 1000 for i in X]#due to X-value:343.365;sklearn's mutual_info_score-function seems to dislike floats(=decimal number).#this line avoids getting warning "[...]\lib\site-packages\sklearn\metrics\cluster\_supervised.py:58: UserWarning: Clustering metrics expects discrete values but received continuous values for label, and continuous values for target"#
Y = [i * 1000 for i in Y]#The multiplication does not change results. It only removes a warning that would otherwise be printed with the results.
MutInf = mutual_info_score(X, Y)
MaxMutInf = mutual_info_score(X, X)
X = [i / 1000 for i in X];Y = [i / 1000 for i in Y]
#Calculate r&p
r, p = pearsonr(X, Y)
#Calculate+draw Slope.
Slope, intercept = np.polyfit(X, Y, 1)
LineFunc = np.poly1d((Slope, intercept))

#Print results:
print("\nN:",len(X))
print("Slope:",Slope)
print("r:",r)
print("rr:",r*r)
print("p for any correlation (2sided/2tailed):",p)
if str(p)[len(str(p))-4:len(str(p))-2]=="e-":
    AmtOfZeros = int(str(p)[len(str(p))-2:])
    NumWithoutDot = str(p)[:len(str(p))-4].replace('.','')
    NoSciNumStr = "0."+"0"*(AmtOfZeros-1)+NumWithoutDot
    print("Decimal form without exponents:",NoSciNumStr)
print("p for a positive correlation (1tailed): 2p")
print("MutalInfo:",MutInf) #=2.810649601375341
print("MaxMutInf:",MaxMutInf)
print("MutalInfo/MaxMutInf:",MutInf/MaxMutInf)


#Create ScatterPlotGraph and save as picture.
if PicHeight > 0:
    plt.figure(figsize=(1.5*PicHeight, PicHeight),dpi=Dpi)
else:
    plt.figure(dpi=Dpi)

if xLabl != '':
    plt.xlabel(xLabl) 
if yLabl != '':
    plt.ylabel(yLabl)
if TtlL1 != '':
    plt.suptitle(TtlL1, x=0.125, ha="left")#, va="center")#x defines how far to the left SupTtlL2 starts.
if TtlL2 != '':
    plt.title(TtlL2, loc="left")
plt.scatter(X, Y, marker="2", c="black", edgecolors='yellow', linewidths=0.1)
#edgecolorsOnlyWorksIf:marker="X"|Else:linewidthsChangesThicknessOfMarkers:0.1IsBest.
#s=90 can be added/removed to change marker length&height.

#SavePic
plt.plot(X, LineFunc(X), 'b')#or:'#999999'/'c'/'b'.
plt.savefig('{}{}{}ScatPlot{}Dpi.{}'.format(timestr1,TtlL1,TtlL2,Dpi,FileFmt), dpi=Dpi)

"""
print("- - - Results when rounding to integers: - - -")
X = [int(i) for i in X];Y = [int(i) for i in Y]

#Calculate and print Slope.
Slope, intercept = np.polyfit(X, Y, 1)
LineFunc = np.poly1d((Slope, intercept))
print("Slope:",Slope)
#Calculate and print MutInf
MutInf = mutual_info_score(X, Y)
MaxMutInf = mutual_info_score(X, X)
print("MutalInfo:",MutInf) #=2.810649601375341
print("MaxMutInf:",MaxMutInf)
print("MutalInfo/MaxMutInf:",MutInf/MaxMutInf)
"""
###### TIME CONTROL #################
timestr2 = datetime.strftime(datetime.now(timezone.utc), "%Y-%m-%dz%H%M%S")
print("\nEnd:   {}".format(timestr2))
now = datetime.now(timezone.utc)
diff = now - earlier
print("Script took {}s.".format(diff.seconds))