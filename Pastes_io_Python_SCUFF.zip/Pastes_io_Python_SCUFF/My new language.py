import time
import os
import random
from KILLSWITCH import flag

def language1(message, key):
    return ''.join([message[j] for i in sorted(zip(key, range(len(key)))) for j in range(i[1], len(message), len(key))])

def language2(message):
    now = str(time.time()).ljust(18, '0').encode('utf-8')
    random.seed(now)
    key = [random.randrange(256) for _ in message]
    return [m ^ k for m, k in zip(message + now, key + [0x42] * len(now))]

rand_nums = set()
while len(rand_nums) != 8: rand_nums.add(int.from_bytes(os.urandom(1), "big"))

for _ in range(42): flag = language1(flag, rand_nums)

with open("kill.switch", "wb") as f: f.write(bytes(language2(flag.encode('utf-8'))))

print("File 'kill.switch' created successfully. I trust hoomans")