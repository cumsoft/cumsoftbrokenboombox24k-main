from html.parser import HTMLParser
from collections import deque

fonts = ['regular', 'bold', 'italic', 'bold_italic']
colors = ['white', 'yellow']
color_map = {
    'attack': 'yellow',
}
gimmicks = ['solid']


class AdvancedTextParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.current_font = deque(fonts[0:1])
        self.current_color = deque(colors[0:1])
        self.current_gimmick = deque(gimmicks[0:1])
        self.letters = []

    def handle_starttag(self, tag, attrs):
        if tag in fonts:
            if tag == 'italic' and 'bold' in self.current_font:
                self.current_font.append('bold_italic')
            elif tag == 'bold' and 'italic' in self.current_font:
                self.current_font.append('bold_italic')
            else:
                self.current_font.append(tag)
        elif tag in colors:
            self.current_color.append(tag)
        elif tag in color_map:
            self.current_color.append(color_map[tag])
        elif tag in gimmicks:
            self.current_gimmick.append(tag)

    def handle_endtag(self, tag):
        if tag in fonts:
            self.current_font.pop()
        elif tag in colors:
            self.current_color.pop()
        elif tag in color_map:
            self.current_color.pop()
        elif tag in gimmicks:
            self.current_gimmick.pop()

    def handle_data(self, data):
        for letter in data:
            self.letters.append((letter, self.current_color[-1], self.current_font[-1], self.current_gimmick[-1]))


def parse_text(text):
    parser = AdvancedTextParser()
    lines = []
    for line in text.splitlines():
        parser.feed(line)
        lines.append(parser.letters)
        parser.letters = []
    print(lines)
    return lines