import openai
import telebot

openai.api_key = "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"
API_TOKEN = '6056202922:AAEH81tAoRU75M-It7Nzp3dgLRIfOZSQMNk'

bot = telebot.TeleBot(API_TOKEN)

@bot.message_handler(commands=['start', 'help'])
def send_welcome(message):
    bot.reply_to(message, "Hello! I'm a conversational bot powered by OpenAI. How can I help you?")

@bot.message_handler(func=lambda message: True)
def chat_with_user(message):
    response = openai.Completion.create(
        engine="text-davinci-002",
        prompt="User: " + message.text + "\nBot:",
        max_tokens=1024,
        n=1,
        stop=None,
        temperature=0.5,
    ).choices[0].text

    bot.reply_to(message, response)

bot.polling()