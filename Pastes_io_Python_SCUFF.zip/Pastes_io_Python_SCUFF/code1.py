import time

import RPi.GPIO as GPIO

print("Wating for sensor to settle")
time.sleep(3)

repeats = 0
tens = [15, 30, 45, 60, 75, 90]
handoverdistance = 50
switch = 0
PIN_TRIGGER = 7
PIN_ECHO = 11
PIN_LED = 38


while True:

    GPIO.setmode(GPIO.BOARD)

    GPIO.setup(PIN_LED, GPIO.OUT)
    GPIO.setup(PIN_TRIGGER, GPIO.OUT)
    GPIO.setup(PIN_ECHO, GPIO.IN)

    GPIO.output(PIN_TRIGGER, GPIO.LOW)
    
    
    if switch == 1:
        print("on")
        GPIO.output(PIN_LED, GPIO.HIGH)
        
    else:
        GPIO.output(PIN_LED, GPIO.LOW)

    repeats += 1
    
    if repeats in tens:
        time.sleep(1.2)
    
    elif repeats == 100:
        time.sleep(4)
        repeats = 0
        
    else:
        time.sleep(0.25)

    GPIO.output(PIN_TRIGGER, GPIO.HIGH)
    time.sleep(0.00001)
    GPIO.output(PIN_TRIGGER, GPIO.LOW)
    
    pulsestarttime = time.time()
    while GPIO.input(PIN_ECHO) == 0:
        pulsestarttime = time.time()
        
    pulseendtime = time.time()
    while GPIO.input(PIN_ECHO) == 1:
        pulseendtime = time.time()
        
    pulse_duration = pulseendtime - pulsestarttime
    distance = round(pulse_duration * 17150, 2)
    
    
    if distance <= handoverdistance:
        print("hand detected")
        GPIO.setup(PIN_LED, GPIO.OUT)
        
        if GPIO.output(PIN_LED, GPIO.HIGH) == True:
            GPIO.output(PIN_LED, GPIO.LOW)
            switch = 0

        
        elif GPIO.output(PIN_LED, GPIO.LOW) == True:
            GPIO.output(PIN_LED, GPIO.HIGH)
            switch = 1
        time.sleep(2)
        
        
    else:
        print(" ")