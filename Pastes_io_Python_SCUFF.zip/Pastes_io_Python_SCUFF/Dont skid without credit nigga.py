import requests
import threading
import tkinter as tk

def get_mrbeast_sub_count():
    channel_id = "UCX6OQ3DkcsbYNE6H8uQQuVA"
    response = requests.get(f"https://api-superplaycounts.onrender.com/api/youtube-channel-counter/user/{channel_id}")
    data = response.json()
    statistics = data['statistics'][0]['counts']
    for item in statistics:
        if item['value'] == 'subscribers':
            subscriber_count = item['count']
            break
    return subscriber_count

def update_subscriber_count():
    count_label.config(text=f"MrBeast's subscriber count: {get_mrbeast_sub_count()}")

def update_loop():
    while True:
        update_subscriber_count()
        root.update()
        threading.Timer(10, update_loop).start()

root = tk.Tk()
root.title("subcount thing credit me nigga if u finna skid my ass")

count_label = tk.Label(root, text="", font=("Trebuchet MS", 18))
count_label.pack(pady=20)

update_subscriber_count()

threading.Thread(target=update_loop).start()

root.mainloop()