from subprocess import check_output
from re import compile
from glob import iglob
import shlex
import sys

reg = compile(r"(e2\.)?m\.d\([-0-9]+L\)")

for file in check_output(shlex.split(f"find {sys.argv[1]} -type f")).decode('utf-8').strip().split('\n'):
    print(file)
    contents = open(file).read()
    src = {}
    ids = set()
    for match in reg.finditer(contents):
        text = match.group()
        str_id = text.split('(')[1][:-2]
        src[text] = str_id
        ids.add(str_id)
    if len(ids) == 0:
        continue
    rep = {}
    for line in check_output(shlex.split("java Deobfuscator "+" ".join(list(ids)))).decode('utf-8').strip().split("\n"):
        line = line.strip()
        if len(line) == 0:
            continue

        str_id, data = line.split(":", maxsplit=1)
        rep[str_id] = data
    
    modif = False
    for text, str_id in src.items():
        contents = contents.replace(text, f'"{rep[str_id]}"')
        modif = True

    if modif:
        print("replacing " + file)
        open(file, "w").write(contents)