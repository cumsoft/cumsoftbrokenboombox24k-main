import sys
from datetime import datetime

def days_passed(date1, date2):
    date_format = '%d-%m-%Y'
    date1_obj = datetime.strptime(date1, date_format)
    date2_obj = datetime.strptime(date2, date_format)

    return abs((date2_obj - date1_obj).days)

date1 = sys.argv[1]
date2 = sys.argv[2]

print(f"Liczba dni między {date1} a {date2}: {days_passed(date1, date2)} dni.")