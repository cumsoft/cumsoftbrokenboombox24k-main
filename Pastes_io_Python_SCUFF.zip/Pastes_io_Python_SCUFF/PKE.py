import requests
import bs4

def get_sales_data(card_name):
  """
  Gathers the most recent sales data for the specified card from eBay, TCGplayer, and Cardmarket.

  Args:
    card_name (str): The name of the trading card to search for.

  Returns:
    A dictionary containing the sales data for the card from each of the three websites.
  """

  sales_data = {}

  for website in ["ebay", "tcgplayer", "cardmarket"]:
    url = f"https://www.{website}.com/search?q={card_name}"
    response = requests.get(url)
    page = bs4.BeautifulSoup(response.content, "html.parser")

    sales = page.find_all("div", class_="srp-listing")
    for sale in sales:
      price = sale.find("span", class_="srp-price").text
      condition = sale.find("span", class_="srp-condition").text
      sales_data[website] = {
        "price": price,
        "condition": condition
      }

  return sales_data

def calculate_average_price(sales_data):
  """
  Calculates the average sale price for the specified card across all the websites.

  Args:
    sales_data (dict): A dictionary containing the sales data for the card from each of the three websites.

  Returns:
    The average sale price for the card.
  """

  prices = []
  for website in sales_data:
    prices.append(float(sales_data[website]["price"]))

  return sum(prices) / len(prices)

def recommend_price(card_name, condition):
  """
  Recommends a price for the specified card based on the average sale price and the condition of the card.

  Args:
    card_name (str): The name of the trading card to search for.
    condition (str): The condition of the card.

  Returns:
    The recommended price for the card.
  """

  sales_data = get_sales_data(card_name)
  average_price = calculate_average_price(sales_data)

  if condition == "Near Mint":
    recommended_price = average_price * 1.1
  elif condition == "Good":
    recommended_price = average_price * 0.9
  else:
    recommended_price = average_price

  return recommended_price

def main():
  card_name = input("Enter the name of the trading card: ")
  condition = input("Enter the condition of the card: ")

  recommended_price = recommend_price(card_name, condition)
  print(f"The recommended price for the card is {recommended_price}")

if __name__ == "__main__":
  main()