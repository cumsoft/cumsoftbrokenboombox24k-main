from functools import partial

import chex
import jax


class UniformReplayBuffer:
    def __init__(
        self,
        buffer_size: int,
        batch_size: int,
    ) -> None:
        self.buffer_size = buffer_size
        self.batch_size = batch_size

    @partial(jax.jit, static_argnums=(0))
    def add(
        self,
        buffer_state: dict,
        experience: tuple,
        idx: int,
    ) -> dict:
        observation, action, reward, next_observation, done = experience
        idx = idx % self.buffer_size

        buffer_state["observations"] = (
            buffer_state["observations"].at[idx].set(observation)
        )
        buffer_state["actions"] = buffer_state["actions"].at[idx].set(action)
        buffer_state["rewards"] = buffer_state["rewards"].at[idx].set(reward)
        buffer_state["next_observations"] = (
            buffer_state["next_observations"].at[idx].set(next_observation)
        )
        buffer_state["dones"] = buffer_state["dones"].at[idx].set(done)

        return buffer_state

    @partial(jax.jit, static_argnums=(0))
    def sample(
        self,
        key: chex.PRNGKey,
        buffer_state: dict,
        current_buffer_size: int,
    ):

        @partial(jax.vmap, in_axes=(0, None))  # iterate over the indexes
        def sample_batch(indexes, buffer):
            """
            For a given index, extracts all the values from the buffer
            """
            return jax.tree_map(lambda x: x[indexes], buffer)

        key, sampling_key = jax.random.split(key)
        indexes = jax.random.randint(
            sampling_key,
            shape=(self.batch_size,),
            minval=0,
            maxval=current_buffer_size,
        )
        experiences = sample_batch(indexes, buffer_state)

        return experiences, key