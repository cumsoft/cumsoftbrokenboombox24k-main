from itertools import combinations, product

def generate_combinations(variables, limit):
    memo = {}

    def product_count(values):
        """Calculate product count for given values."""
        count = 1
        for value in values:
            count *= len(value)
        return count

    def combine_variables(vars_list):
        """Generate all combinations of variables within the limit."""
        if not vars_list:
            return [{}]

        key = tuple((var, tuple(values)) for var, values in vars_list)
        if key in memo:
            return memo[key]

        results = []
        current_var, options = vars_list[0]
        for i in range(1, len(options) + 1):
            for subset in combinations(options, i):
                if product_count([subset]) > limit:
                    break  # Skip subsets that exceed the limit
                for result in combine_variables(vars_list[1:]):
                    new_combination = {current_var: subset, **result}
                    if product_count(new_combination.values()) <= limit:
                        results.append(new_combination)
        memo[key] = results
        return results

    # Initial call to generate combinations
    all_combinations = combine_variables(list(variables.items()))

    # Merging strategy to minimize configurations
    def merge_combinations(combinations):
        merged = []
        for combo in combinations:
            found = False
            for m in merged:
                if all(set(combo[var]).issubset(m[var]) for var in combo):
                    found = True
                    break
            if not found:
                merged.append(combo)
        return merged

    return merge_combinations(all_combinations)

# Variables definition
variables = {
    "***": ["total", "women", "men"],
    "country of birth": ["Norway", "Finland", "Sweden", "Denmark"],
    "year": ["2019", "2020", "2021", "2022", "2023"]
}

row_limit = 13

# Generate and optimize configurations
optimal_configs = generate_combinations(variables, row_limit)
print(f"Optimal Request Configurations (Total: {len(optimal_configs)}):")
for config in optimal_configs:
    print(config)