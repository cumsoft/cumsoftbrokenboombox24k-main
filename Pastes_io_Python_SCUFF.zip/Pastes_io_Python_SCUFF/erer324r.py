import hashlib
import binascii
import time
import threading

NUM_THREADS = 4  # Number of threads to use for multithreading

def check_combinations(start_hex, total_combinations, target_crc32, results, progress_callback):
    current_hex = start_hex
    attempts = 0

    while current_hex != "ffffffff":
        md5_hash = hashlib.md5(current_hex.encode()).hexdigest()
        crc32_hash = binascii.crc32(bytes.fromhex(md5_hash)) & 0xFFFFFFFF

        attempts += 1
        progress_percentage = (int(current_hex, 16) / total_combinations) * 100
        progress_callback(progress_percentage)

        if crc32_hash == target_crc32:
            results.append((current_hex.lower(), attempts))
            return

        # Increment to the next 8-character hexadecimal
        current_hex = hex(int(current_hex, 16) + NUM_THREADS)[2:].zfill(8)

    results.append((None, attempts))

def print_progress(progress_percentage):
    print(f"Progress: {progress_percentage:.2f}%")

def brute_force_md5_crc32():
    target_crc32 = binascii.crc32(b'\x00\x00\x00\x00') & 0xFFFFFFFF
    total_combinations = 16 ** 8  # Total 8-character hexadecimal combinations
    chunk_size = total_combinations // NUM_THREADS
    threads = []
    results = []

    for i in range(NUM_THREADS):
        start_hex = hex(i)[2:].zfill(8)
        t = threading.Thread(target=check_combinations, args=(start_hex, total_combinations, target_crc32, results, print_progress))
        threads.append(t)
        t.start()

    for t in threads:
        t.join()

    result_hex = None
    total_attempts = 0

    for hex_val, attempts in results:
        if hex_val is not None:
            result_hex = hex_val
        total_attempts += attempts

    return result_hex, total_attempts

result_hex, total_attempts = brute_force_md5_crc32()
print("Brute force completed.")
if result_hex:
    print(f"Match found! Hexadecimal Value: {result_hex}")
else:
    print("No match found.")

print(f"Total Attempts: {total_attempts}")