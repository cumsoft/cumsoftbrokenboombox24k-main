class Solution:
    def isValidSudoku(self, board: list[list[str]]) -> bool:
        row_validation = self.__row_validation(board)
        if not row_validation:
            return False
 
        column_validation = self.__column_validation(board)
        if not column_validation:
            return False
 
        sub_box_validation = self.__sub_box_validation(board)
        if not sub_box_validation:
            return False
 
        return True
 
    @staticmethod
    def __row_validation(board: list[list[str]]) -> bool:
        for row in board:
            for value in row:
                if value != '.' and row.count(value) > 1:
                    return False
        return True
 
    @staticmethod
    def __column_validation(board: list[list[str]]) -> bool:
        for sub_cursor in range(len(board)):
            temporary_column = []
            for cursor in range(len(board)):
                value = board[cursor][sub_cursor]
                if value != '.':
                    temporary_column.append(value)
 
            for value in temporary_column:
                if temporary_column.count(value) > 1:
                    return False
 
        return True
 
    @staticmethod
    def __sub_box_validation(board: list[list[str]]) -> bool:
        for box in range(0, 9, 3):
            for sub_box in range(0, 9, 3):
                temporary_box = []
                for box_row in range(box, box + 3):
                    for box_column in range(sub_box, sub_box + 3):
                        box_value = board[box_row][box_column]
                        if box_value != '.':
                            temporary_box.append(box_value)
 
                for value in temporary_box:
                    if temporary_box.count(value) > 1:
                        return False
        return True