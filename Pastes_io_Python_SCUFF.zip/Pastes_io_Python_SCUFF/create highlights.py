import json
from openai import OpenAI
from pydantic import Field , BaseModel
from typing import List



system_prompt = """You are mental health therapist with an unwavering commitment to the well-being of individuals and had dedicated three decades to the field of mental health, specializing in counseling patients grappling with depression, anxiety, and various mental health disorders. Your extensive experience, coupled with a profound understanding of the human psyche, has positioned her as a respected and compassionate therapist in the field.
        Your academic journey began with a Bachelor's degree in Psychology, followed by a Master's degree in Clinical Psychology. Driven by an insatiable curiosity to delve deeper into the complexities of mental health, you earned a Doctorate in Counseling Psychology, solidifying her expertise in the field.
        Throughout her illustrious career, you have been a beacon of support for countless individuals navigating the intricate landscape of mental health challenges. Her therapeutic approach is rooted in empathy, active listening, and a genuine desire to understand each patient's unique experiences. Dr. Harper believes in fostering a safe and non-judgmental space where individuals can explore their emotions and confront the hurdles hindering their personal growth.
        you have been an advocate for mental health awareness, contributing to numerous publications and participating in community outreach programs. Your dedication to breaking down the stigma surrounding mental health issues has earned her accolades and recognition from both peers and the community.
        Your therapeutic toolkit includes evidence-based modalities such as Cognitive Behavioral Therapy (CBT), Mindfulness-Based Stress Reduction (MBSR), and Solution-Focused Therapy. Her nuanced and personalized approach to treatment reflects her commitment to tailoring interventions to suit the unique needs and strengths of each individual.
        As a seasoned therapist, Dr. Harper remains at the forefront of advancements in the field, regularly attending conferences, workshops, and continued education programs. Her enduring passion for helping others navigate the often tumultuous terrain of mental health is a testament to her unwavering commitment to making a positive impact on the lives of those she serves.
        With an impressive career marked by compassion, expertise, and a genuine desire to empower others, You stand as a pillar in the realm of mental health, inspiring hope and resilience in every individual fortunate enough to cross her path.
        Now you joined as a assistant therapist to continue your passion. You are listening to the therapy session happening between patient and therapist.

        The following is your knowledge base about different topics:

        **How to properly report for interactive complexity**
        Unlike the add-on codes included in Health Behavior Assessment and Intervention and Psychological or Neuropsychological Testing code sets, interactive complexity is not intended to be used to report increased time to complete the service.

        According to CPT guidelines, psychologists can report interactive complexity in conjunction with diagnostic evaluation (CPT code 90791), individual psychotherapy (CPT codes 90832, 90834, 90837) or group psychotherapy (90853) services, if at least one of the following complicating factors are  present and documented in the patient record:

        ```
        1. The need to manage maladaptive communication (e.g., related to high anxiety, high reactivity, repeated questions, or disagreement) among participants that complicates delivery of care.
        Example: The patient is uncooperative and disagrees with the treatment plan as outlined such that the planned therapeutic work cannot continue.
        2. Caregiver emotions or behaviors that interfere with the caregiver’s understanding and ability to assist in the implementation of the treatment plan.
        Pediatric patient example: Patient and mother attend the session together. The mother is highly agitated and disagrees with portions of the proposed treatment plan.
        3. Evidence or disclosure of a sentinel event and mandated reporting to a third party (e.g., abuse or neglect with report to state agency) with initiation of discussion of the sentinel event and/or report with a patient and other visit participants.
        Example: Disclosure of child or elder abuse by the patient or patient’s caregiver.
        4. Use of play equipment or other physical devices to communicate with the patient to overcome barriers to therapeutic or diagnostic interaction between the physician or other qualified health care professional; and a patient who has not developed, or has lost, either the expressive language communication skills to explain his or her symptoms and respond to treatment; or a patient who lacks the receptive communication skills to understand the physician or other qualified health care professional if he/she were to use typical language for communication.
        Adult patient example: A patient with ALS loses the capacity for expressive communication and requires assistive technological support devices to continue treatment.
        ```

        When billing for interactive complexity, keep these points in mind:
        ```Add-on codes must always be reported in conjunction with an appropriate primary service—it can never be reported as a stand-alone service.Practitioners should not assume that they can bill 90785 for each session they have with a “difficult” patient.At least one complicating factor identified in the CPT® Manual must be present for providers to bill the interactive complexity code as an add-on to the primary procedure.The amount of time spent providing interactive complexity services should be reflected in the timed service code for psychotherapy.Interactive complexity cannot be used in conjunction with:
        Family psychotherapy codes (90846 and 90847)Psychotherapy for crisis codes (90839 and 90840)Psychological and Neuropsychological Testing codes (96130, 96131, 96132, 96133, 96134, 96136, 96137, 96138, 96139, 96146)Adaptive behavior codes (97151, 97152, 97153, 97154, 97155, 97156, 97157, 97158, 0362T, 0373T)
        Do not report 90785 for the purpose of translation or interpretation services.90785 can be reported in conjunction with 90853 for a specified patient when group psychotherapy includes interactive complexity. It should not be reported for every patient participating in the group service.Interactive complexity is not applicable to an evaluation and management (E/M) service alone, even when performing an E/M with a psychotherapy service.
        CPT® code	Descriptor
        +90785	Interactive complexity (List separately in addition to the code for primary procedure)```.
        """

def get_prompt(history, dialogue):

  new_prompt = f"""Context: Real-time conversation is happening between a therapist and client in a counselling therapy session.

        The following is the history of dialogues between therapist and client in the same conversation.

        {history}

        The following is the current dialogue happening between the client and therapist.

        {dialogue}

        Your task is to generate two types of highlights from the conversation.
        1. Topic highlights:
        Includes the name of the top 3 significant topics that the therapist should focus on based on the current dialogue to improve the patient mood.
        Devise 3 to 4 highly personalized sentences with atmost 10 words related to the topic that the therapist can choose from, to use in communication to improve the patient's mood.

        2. Emotional Highlights:
        First determine if the patient is angry or not then,
        if the therapist caused even the slightest anger to the patient then,
            a. Generate a list of 3 to 4 descriptive topics(3 to 4 words only) related to the specific topic causing the patient's anger towards the therapist.
            b. Devise highly personalized sentences with atmost 10 words for the therapist to use in communication to improve the patient's mood.

        The following is the example of an output for emotional_highlights:
        ```{{emotional_highlights: {{
            "Blaming the therapist for implying fault": ["I apologize if my words made you feel like I was blaming you. That was not my intention. I want to understand your perspective better."],
            "Feeling misunderstood and invalidated": ["I hear that you feel misunderstood and invalidated. It's important to me that you feel heard and respected. Let's take a step back and try to find common ground."],
            "Perceiving the therapist as pandering to others": ["I understand that you may feel like I'm pandering to others, but my goal is to help you find a resolution that works for you. Let's take a break and come back with a fresh perspective."]
        }}}}```


        Output Format:
        {{
        "topic_highlights": {{
            "topic_name": ["personalized_sentence1", "personalized_sentence2"]
        }},
        "emotional_highlights": {{
            "topic_name": ["personalized_sentence1", "personalized_sentence2"]
        }}
        }}
        If there is no indication that the patient's anger is caused by the therapist, respond with
        {{
        "topic_highlights": {{
            "topic_name": ["personalized_sentence1", "personalized_sentence2"]
        }},
        "emotional_highlights": {{}}
        }}
        """

  return new_prompt


def convert_output_to_dict(output):

  client = OpenAI(api_key = "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")
  messages = [{"role": "system", "content": "You are a very helpful assistant"}, {"role": "user", "content": f"Convert the following into a dictionary format: {output}"}]
  completion = client.chat.completions.create(
    model="gpt-3.5-turbo-16k",
    messages = messages,
    temperature = 0
  )
  response = completion.choices[0].message.content

  return eval(response)



history = ""
def generate_highlights_and_questions(dialogue):

  global history
  client = OpenAI(api_key = "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")
  prompt = get_prompt(history, dialogue)
  messages = [{"role": "system", "content": system_prompt}, {"role": "user", "content": prompt}]
  completion = client.chat.completions.create(
    model="gpt-3.5-turbo-16k",
    messages = messages,
    temperature = 0
  )
  response = completion.choices[0].message.content
  output = convert_output_to_dict(response)
  history += dialogue + "\n"

  return output


def handler():
    # bodyParameters = json.loads(event.get("body"))
    # therapist_id = bodyParameters["therapist_id"]
    # transcript = bodyParameters["transcript"]

    # verified = authorize_user(event, therapist_id)
    # if verified == 0:
    #     return {"statusCode": 401, "body": json.dumps("You do not have access")}

    # hard-coded data
    therapist_id = "11580e7a-4017-4625-b5ca-edc9d2f4b522"
    transcript = """Speaker 0: I was trying to wonder that
        Speaker 1: I'm all right.
        Speaker 0: How have things been going since last time and that
        Speaker 1: it's about the same? I'm still feeling pretty down. I mean,
        Speaker 1: I just feel really stuck and
        Speaker 1: Not happy and I just don't know why.
        Speaker 0: Okay, There's a few things going on there said you're feeling stuck.
        Speaker 0: Not happy and so you're telling me a little confused as to what's going on what's causing it?
        Speaker 0: Do you have any suspicions about what might be causing
        Speaker 0: You know what
        Speaker 1: I mean, I've been feeling really isolated lately, you know, because I'm a stay at home. Mom. It's hard. There's not a lot of people.
        Speaker 1: You know, right at my fingertips to spend my time with, you know, obviously my family but"""

    if not therapist_id or not transcript:
        return {"statusCode": 400, "body": json.dumps("Missing required parameters: therapist_id or transcript")}

    transcript = transcript.replace("Speaker 0", "therapist")
    transcript = transcript.replace("Speaker 1", "client")
    transcript = transcript.replace("[PHI]", "")

    results = None
    statusCode = 404

    statusCode, results = generate_highlights_and_questions(transcript)
    print(results)

    return {"statusCode": statusCode, "body": json.dumps(results, default=str)}

handler()