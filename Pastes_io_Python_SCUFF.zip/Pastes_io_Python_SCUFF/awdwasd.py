import os

file_path = os.path.abspath(__file__)
dst_path = os.path.join(os.path.expanduser("~/Desktop"), "X.py")

with open(dst_path, "w") as f:
    with open(file_path, "r") as src:
        f.write(src.read())