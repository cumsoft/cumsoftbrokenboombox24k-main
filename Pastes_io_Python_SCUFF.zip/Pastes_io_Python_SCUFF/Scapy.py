from scapy.all import sniff
from scapy.layers.inet import IP, UDP, TCP
from scapy.layers.l2 import Ether, ARP


def print_statistics(cap):
    # Number of packet captured
    print("Captured Packets:", len(cap))

    # Number of packets sent and received (per MAC address)
    print("Network Devices:")
    mac_src = {}
    mac_dst = {}
    for packet in cap:
        if Ether in packet:
            if packet[Ether].src in mac_src:
                mac_src[packet[Ether].src] += 1
            else:
                mac_src[packet[Ether].src] = 1

            if packet[Ether].dst in mac_dst:
                mac_dst[packet[Ether].dst] += 1
            else:
                mac_dst[packet[Ether].dst] = 1
            # mac_src[packet[Ether].src] = mac_src.get(packet[Ether].src, 0) + 1
            # mac_dst[packet[Ether].dst] = mac_dst.get(packet[Ether].dst, 0) + 1
    for mac in set(list(mac_dst.keys()) + list(mac_src.keys())):
        sent = mac_src.get(mac, 0)
        received = mac_dst.get(mac, 0)
        print("    ", mac, "- sent", sent, "received", received)

    # MAC <-> IP
    print("MAC to IP:")
    mac_to_ip = {}
    for packet in cap:
        if ARP in packet:
            mac_to_ip[packet[ARP].hwsrc] = packet[ARP].psrc
        elif Ether in packet and IP in packet:
            mac_to_ip[packet[Ether].src] = packet[IP].src
    for mac, ip in mac_to_ip.items():
        print("    ", mac, "->", ip)

    # TCP/UDP ports
    print("TCP & UDP:")
    tcp_src = {}
    tcp_dst = {}
    udp_src = {}
    udp_dst = {}
    for packet in cap:
        if TCP in packet and IP in packet:
            tcp_src[packet[IP].src] = tcp_src.get(packet[IP].src, []) + [str(packet[TCP].sport)]
            tcp_dst[packet[IP].dst] = tcp_dst.get(packet[IP].dst, []) + [str(packet[TCP].dport)]
        elif UDP in packet and IP in packet:
            udp_src[packet[IP].src] = udp_src.get(packet[IP].src, []) + [str(packet[UDP].sport)]
            udp_dst[packet[IP].dst] = udp_dst.get(packet[IP].dst, []) + [str(packet[UDP].dport)]
    all_ips = set(list(tcp_src.keys()) + list(tcp_dst.keys()) + list(udp_src.keys()) + list(udp_dst.keys()))
    for ip in all_ips:
        print("    ", ip)
        print("        UDP dest ports -" , ", ".join(set(udp_dst.get(ip, []))))
        print("        UDP src ports -", ", ".join(set(udp_src.get(ip, []))))
        print("        TCP dest ports -", ", ".join(set(tcp_dst.get(ip, []))))
        print("        TCP src ports -", ", ".join(set(tcp_src.get(ip, []))))

    print("IP Conversations:")
    ip_conversations = {}
    for packet in cap:
        if IP in packet:
            ip_conversations[packet[IP].src] = ip_conversations.get(packet[IP].src, []) + [packet[IP].dst]

    for ip, conversations in ip_conversations.items():
        print("    ", ip, "->", ", ".join(set(conversations)))

    print("Traffic Analysis:")
    ip_traffic = {}
    for packet in cap:
        if IP in packet:
            ip_traffic[packet[IP].src] = ip_traffic.get(packet[IP].src, 0) + len(packet)

    sorted_ip_traffic = {k: v for k, v in sorted(ip_traffic.items(), key=lambda item: item[1], reverse=True)}

    for ip, traffic in sorted_ip_traffic.items():
        print("    ", ip, "->", traffic, "bytes")



def main():
    cap = sniff(timeout=60)  # timeout=300
    print_statistics(cap)


if __name__ == '__main__':
    main()