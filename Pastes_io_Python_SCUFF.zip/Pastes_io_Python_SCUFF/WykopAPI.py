import requests
import json
import random

import config

SERVER = 'https://wykop.pl/api/v3/'

def auth():
    request_body = {
        "data": {
            "key": config.KEY,
            "secret": config.SECRETKEY
        }
    }

    response = requests.post(SERVER + 'auth', json=request_body)
    token = response.json()['data']['token']
    return token

def get_links(s, page="1", sort="newest", type="upcoming"):
    query = SERVER + 'links' + '?page=' + page + '&sort=' + sort + '&type=' + type
    response = s.get(query)
    return response

def post_entry(s, body):
    response = s.post(SERVER + 'entries', json=body)
    return response

def connect(s):
    response = s.get(SERVER + 'connect')
    return response

token = auth()

s = requests.Session()
s.headers.update({'Authorization': 'Bearer ' + token})

res = connect(s)
print(res.json())

config.USER_TOKEN = input("Podaj token: ")
print(config.USER_TOKEN)


headers = {
    "Authorization": f"Bearer {config.USER_TOKEN}",
}

body = {
  "data": {
    "content": "**foobar** __foobar__ [lorem](https://www.wykop.pl) impsum!!! #nsfw #wykop",
    "adult": False
  }
}

res = requests.post(SERVER + 'entries', json=body, headers=headers)

print(res.json())

s.close()