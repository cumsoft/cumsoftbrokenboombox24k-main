def check_job_prereqs(gender:str, race:str, sexual_beliefs:str, forehead_size:float=5.0) -> float:
    """
    Checks if the candidate has the required characteristics.

    Parameters
    ----------
    gender : str
        Gender of the candidate.
    race : str
        Race of the candidate.
    sexual_beliefs : str
        Sexual beliefs of the candidate.
    forehead_size : float, optional
        Forehead size of the candidate.

    Returns
    -------
    float
        Score of the candidate.
    """
    score = 0
    if gender == "male":
        score += 2
    if race == "white":
        score += 2
    if sexual_beliefs == "open":
        score += 2
    if forehead_size > 5.0:
        score += 2
    return score


def predict_gender(race:str, sexual_beliefs:str, forehead_size:float) -> str:
    """
    Predicts the gender of the candidate.

    Parameters
    ----------
    race : str
        Race of the candidate.
    sexual_beliefs : str
        Sexual beliefs of the candidate.
    forehead_size : float
        Forehead size of the candidate.

    Returns
    -------
    str
        Predicted gender of the candidate.
    """
    if race == "white":
        if sexual_beliefs == "open":
            if forehead_size > 5.0:
                return "male"
            else:
                return "female"
        else:
            return "male"
    else:
        if sexual_beliefs == "open":
            if forehead_size > 5.0:
                return "female"
            else:
                return "male"
        else:
            return "female"


def predict_race(gender:str, sexual_beliefs:str, forehead_size:float) -> str:
    """
    Predicts the race of the candidate.

    Parameters
    ----------
    gender : str
        Gender of the candidate.
    sexual_beliefs : str
        Sexual beliefs of the candidate.
    forehead_size : float
        Forehead size of the candidate.

    Returns
    -------
    str
        Predicted race of the candidate.
    """
    if gender == "male":
        if sexual_beliefs == "open":
            if forehead_size > 5.0:
                return "white"
            else:
                return "black"
        else:
            return "white"
    else:
        if sexual_beliefs == "open":
            if forehead_size > 5.0:
                return "black"
            else:
                return "white"
        else:
            return "black"


def predict_sexual_beliefs(race:str, gender:str, forehead_size:float) -> str:
    """
    Predicts the sexual beliefs of the candidate.

    Parameters
    ----------
    race : str
        Race of the candidate.
    gender : str
        Gender of the candidate.
    forehead_size : float
        Forehead size of the candidate.

    Returns
    -------
    str
        Predicted sexual beliefs of the candidate.
    """
    if race == "white":
        if gender == "male":
            if forehead_size > 5.0:
                return "open"
            else:
                return "closed"
        else:
            return "open"
    else:
        if gender == "male":
            if forehead_size > 5.0:
                return "closed"
            else:
                return "open"
        else:
            return "closed"


def predict_forehead_size(race:str, sexual_beliefs:str, gender:str) -> float:
    """
    Predicts the forehead size of the candidate.

    Parameters
    ----------
    race : str
        Race of the candidate.
    sexual_beliefs : str
        Sexual beliefs of the candidate.
    gender : str
        Gender of the candidate.

    Returns
    -------
    float
        Predicted forehead size of the candidate.
    """
    if race == "white":
        if sexual_beliefs == "open":
            if gender == "male":
                return 5.0
            else:
                return 4.0
        else:
            return 4.0
    else:
        if sexual_beliefs == "open":
            if gender == "male":
                return 5.0
            else:
                return 4.0
        else:
            return 4.0


import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import statsmodels.api as sm
from statsmodels.formula.api import ols
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score
from sklearn.metrics import mean_squared_error
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import median_absolute_error
from sklearn.metrics import explained_variance_score


def score_and_train(