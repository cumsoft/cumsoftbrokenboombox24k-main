import scrapy

class IngenieursucheSpider(scrapy.Spider):
    name = "ingenieursuche"
    allowed_domains = ["www.bayika.de"]
    start_urls = [f"https://www.bayika.de/de/ingenieursuche/suchergebnis.php?suchwort=&plz_bis=&plz_von=&matrix%5B%5D=5105&matrix%5B%5D=5110&matrix%5B%5D=5115&matrix%5B%5D=5120&matrix%5B%5D=5125&matrix%5B%5D=5130&matrix%5B%5D=5135&matrix%5B%5D=5140&matrix%5B%5D=5145&matrix%5B%5D=5180&matrix%5B%5D=5185&matrix%5B%5D=5190&page={x}" for x in range(1,16)]

    def parse(self, response):
        quote_item = {}
        for quote in response.css('li.listEntry'):
            quote_item['nazw'] = quote.css('div.planersuche_name::text').get()
            quote_item['tel'] = quote.css('div.planersuche_telefon::text').get()
            yield quote_item