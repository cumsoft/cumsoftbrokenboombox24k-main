# Create pass object
object_suffix = '1'
class_suffix = 'keyphone_entrance'
new_object = {
    "id": f"{issuer_id}.{object_suffix}",
    "classId": f"{issuer_id}.{class_suffix}",
    "state": "ACTIVE",
    "heroImage": {
        "sourceUri": {
            "uri": "https://farm4.staticflickr.com/3723/11177041115_6e6a3b6f49_o.jpg"
        },
        "contentDescription": {
            "defaultValue": {"language": "en-US", "value": "Hero image description"}
        },
    },
    "textModulesData": [
        {
            "header": "Text module header",
            "body": "Text module body",
            "id": "TEXT_MODULE_ID",
        }
    ],
    "linksModuleData": {
        "uris": [
            {
                "uri": "http://maps.google.com/",
                "description": "Link module URI description",
                "id": "LINK_MODULE_URI_ID",
            },
            {
                "uri": "tel:6505555555",
                "description": "Link module tel description",
                "id": "LINK_MODULE_TEL_ID",
            },
        ]
    },
    "imageModulesData": [
        {
            "mainImage": {
                "sourceUri": {
                    "uri": "http://farm4.staticflickr.com/3738/12440799783_3dc3c20606_b.jpg"
                },
                "contentDescription": {
                    "defaultValue": {
                        "language": "en-US",
                        "value": "Image module description",
                    }
                },
            },
            "id": "IMAGE_MODULE_ID",
        }
    ],
    "smartTapRedemptionValue": "KeyPhone is the best!",
    "barcode": {"type": "QR_CODE", "value": "QR code"},
    "cardTitle": {"defaultValue": {"language": "en-US", "value": "Generic card title"}},
    "header": {"defaultValue": {"language": "en-US", "value": "Generic header"}},
    "hexBackgroundColor": "#4285f4",
    "logo": {
        "sourceUri": {
            "uri": "https://storage.googleapis.com/wallet-lab-tools-codelab-artifacts-public/pass_google_logo.jpg"
        },
        "contentDescription": {
            "defaultValue": {"language": "en-US", "value": "Generic card logo"}
        },
    },
}

# Create the JWT claims
claims = {
    'iss': credentials.service_account_email,
    'aud': 'google',
    'origins': ['http://localhost:3000'],
    'typ': 'savetowallet',
    'payload': {
        'genericObjects': [new_object]
    }
}

# The service account credentials are used to sign the JWT
signer = crypt.RSASigner.from_service_account_file(key_file_path)
token = jwt.encode(signer, claims).decode('utf-8')

add_to_wallet_link = f'https://pay.google.com/gp/v/save/{token}'

print('Add to Google Wallet link')
print(f'\n\n{add_to_wallet_link}')