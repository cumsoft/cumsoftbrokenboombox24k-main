'''
polish_wiktionary_ipa
10.03.2024
Automatically adding IPA pronunciation of English words to Polish wiktionary

Installation of libraries is required:
pip install pywikibot
pip install requests
pip install bs4
pip install mwclient
'''

import pywikibot
import requests
from bs4 import BeautifulSoup
import mwclient


URL = "https://pl.wiktionary.org/w/api.php"
HEADERS = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'}
searching = "({{język angielski}}) ==\n{{wymowa}}\n{{znaczenia}}"

site = mwclient.Site('pl.wiktionary.org')
category = site.categories['angielski (indeks)']
for word in category:
    word = word.name
    site = pywikibot.Site("pl", "wiktionary")
    page = pywikibot.Page(site, word)
    text = page.text
    if searching in text:
        response = requests.get("https://dictionary.cambridge.org/pronunciation/english/" + word.lower().replace(' ', '-'), headers=HEADERS)
        soup = BeautifulSoup(response.text, "html.parser")
        
        count = 0
        names = soup.find_all("span", class_="term tb")
        for name in names:
            if name.get_text() == word:
                section = name.find_parent("div", class_="pron-block lmb-10")
                count += 1
        if count != 1:
            continue
        
        ipas = section.find_all("span", class_="ipa")
        if len(ipas) != 2:
            continue
        
        optionals = ipas[0].find_all("span", class_="sp dsp")
        if optionals:
            for optional in optionals:
                optional.string = f"({optional.text})"
        optionals = ipas[1].find_all("span", class_="sp dsp")
        if optionals:
            for optional in optionals:
                optional.string = f"({optional.text})"
        
        if ipas[0].text == ipas[1].text:
            british = ipas[0].text.replace('g', 'ɡ')
            american = ipas[0].text.replace('g', 'ɡ')
        else:
            british = ipas[0].text.replace('g', 'ɡ')
            american = ipas[1].text.replace('g', 'ɡ')
        
        new_text = text.replace(searching, "({{język angielski}}) ==\n{{wymowa}}\n: {{bryt}} {{IPA|" + british + "}}\n: {{amer}} {{IPA|" + american + "}}\n{{znaczenia}}")
        session = requests.Session()
        params = {
            "action": "query",
            "meta": "tokens",
            "format": "json"
        }
        response = session.get(url=URL, params=params)
        data = response.json()
        csrf_token = data['query']['tokens']['csrftoken']
        params = {
            "action": "edit",
            "title": word,
            "token": csrf_token,
            "format": "json",
            "text": new_text
        }
        
        response = session.post(URL, data=params)