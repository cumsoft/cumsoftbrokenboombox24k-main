import torch
start_time = None
min_elapsed_time = float('inf')
max_elapsed_time = float('-inf')
for text in texts:
    # Get timestamp (in seconds since epoch) just before making a prediction
    if start_time is None:
        start_time = torch.tensor([datetime.timestamp()]).unsqueeze(-1).cpu().numpy()[0]
        
    output = classifier(text, candidate_labels, multi_label=False)
    
    # Calculate elapsed time (in seconds)
    if start_time is not None:
        elapsed_time = datetime.timestamp() - start_time
        elapsed_time /= 3.15E+07  # Convert to seconds
        predictions.append(output['scores'].item())
        predictions.append((time.monotonic(), elapsed_time))

if len(predictions):
    predictions = sorted(predictions, reverse=True)
    min_elapsed_time = predictions[0][1]
    max_elapsed_time = predictions[-1][1]
    print(f'Minimum elapsed time: {min_elapsed_time:.3f} sec\nMaximum elapsed time: {max_elapsed_time:.3f} sec\nPredictions:\n{', '.join([f"({i}, {j}) for i, j in predictions])}\n')
else:
    print('No data to process. Please check your inputs.')