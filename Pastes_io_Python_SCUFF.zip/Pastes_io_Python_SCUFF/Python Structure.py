# débutants

cote = 4

perimeter = cote + cote + cote +cote

are = cote*cote

print('the are is', are, 'm3') 

print('the perimeter is', perimeter, 'm') 

# intermédiaire

cote = 4

perimeter = 4 * cote 

are = cote ** 2

print('the are is', are, 'm3') 

print('the perimeter is', perimeter, 'm')

# legends

class Carre:

    def __init__(self, cote):

        self.cote = cote

    def perimetre(self):

        return 4 * self.cote

    def aire(self):

        return self.cote ** 2

c = Carre(4)

print('L\'aire est de', c.aire(), 'm2')

print('Le périmètre est de', c.perimetre(), 'm')

# Jonathan Code