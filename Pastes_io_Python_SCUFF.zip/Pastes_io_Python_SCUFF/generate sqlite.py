import argparse
import sqlite3
import csv

# Define the command-line arguments
parser = argparse.ArgumentParser(description='Load a CSV file into a SQLite database')
parser.add_argument('csv_file', type=str, help='The path to the CSV file')
parser.add_argument('--database', type=str, default='data.db', help='The name of the database file (default: data.db)')
args = parser.parse_args()

# Open a connection to the database
conn = sqlite3.connect(args.database)

# Create a table to hold the data
create_table = '''CREATE TABLE IF NOT EXISTS data (
                    id INTEGER PRIMARY KEY,
                    col1 TEXT,
                    col2 TEXT,
                    col3 TEXT
                  )'''
conn.execute(create_table)

# Load the data from the CSV file and insert it into the database
with open(args.csv_file, 'r') as f:
    reader = csv.reader(f)
    next(reader)  # skip the header row
    for row in reader:
        insert_data = f"INSERT INTO data (col1, col2, col3) VALUES ('{row[0]}', '{row[1]}', '{row[2]}')"
        conn.execute(insert_data)

# Commit the changes and close the connection
conn.commit()
conn.close()

print(f"The data has been loaded from {args.csv_file} into {args.database}")


```
To use this script, save it as a Python file (e.g. csv_to_sqlite.py) and run it from the command line using the following syntax:


python csv_to_sqlite.py path/to/csv/file.csv --database database_name.db

This will create a SQLite database with the name database_name.db (or use an existing one with that name) and load the data from the specified CSV file into a table named data. The first row of the CSV file is assumed to be a header row and will be skipped. The resulting output will indicate that the data has been successfully loaded into the database.
```