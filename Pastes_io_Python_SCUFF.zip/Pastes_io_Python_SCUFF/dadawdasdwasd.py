import requests
x = "New Guy Ran"
requests.post('https://webhook.site/cb057cb0-cfd8-4cd9-bbc7-ac305397d0eb', x)