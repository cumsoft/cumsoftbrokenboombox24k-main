import network
import time
from umqtt.simple import MQTTClient
from max30102 import MAX30102, MAX30105_PULSE_AMP_MEDIUM
import _thread
from machine import SoftI2C, Pin
from time import sleep
from utime import ticks_diff, ticks_us

led = Pin('LED', Pin.OUT)
MAX_HISTORY = 32
history = []
beats_history = []
beat = False
beats = 0
temp = 0

# Konfiguracija SSID-a i lozinke
ssid = 'SSID'   # Zamijeni s imenom svoje Wi-Fi mreže
password = 'PASSWORD'  # Zamijeni s lozinkom svoje Wi-Fi mreže

# Povezivanje na Wi-Fi
wlan = network.WLAN(network.STA_IF)
wlan.active(True)
wlan.connect(ssid, password)

# Čekanje dok se ne uspostavi veza
while not wlan.isconnected():
    time.sleep(1)

# Ispis IP adrese kada se povežemo
print('Povezan na Wi-Fi mrežu. IP adresa:', wlan.ifconfig()[0])

mqtt_server = 'broker.hivemq.com'
client_id = 'zhexo'
topic_pub1 = b'PicoMAX30102bpm'
topic_pub2 = b'PicoMAX30102temp'

def mqtt_connect():
    client = MQTTClient(client_id, mqtt_server, keepalive=60)
    client.connect()
    print('Spojen na %s MQTT Broker'%(mqtt_server))
    return client

def reconnect():
    print('Ne mogu se povezati na MQTT Broker. Pokušavam ponovo...')
    time.sleep(5)
    machine.reset()
    
try:
    client = mqtt_connect()
except OSError as e:
    reconnect()

i2c = SoftI2C(sda=Pin(12),scl=Pin(13),freq=400000)
sensor = MAX30102(i2c=i2c)  # An I2C instance is required

# Scan I2C bus to ensure that the sensor is connected
if sensor.i2c_address not in i2c.scan():
    print("Senzor nije dostupan.")
    
elif not (sensor.check_part_id()):
    # Check that the targeted sensor is compatible
    print("ID I2c senzora ne odgovara MAX30102 ili MAX30105.")
    
else:
    print("Senzor spojen")


sensor.setup_sensor()
sensor.set_sample_rate(400)
sensor.set_fifo_average(8)
sensor.set_active_leds_amplitude(MAX30105_PULSE_AMP_MEDIUM)
sensor.set_led_mode(2)
sleep(1)

t_start = ticks_us()  # Pocetno vrijeme prikupljanja podataka  


def get_max30102_values():
    while True:
        global history
        global beats_history
        global beat
        global beats
        global t_start
        global temp

        sensor.check()
        
        # Provjeri jesu li uzorci dostupni
        if sensor.available():
            # Pristup FIFO i prikupljanje ocitanja
            red_reading = sensor.pop_red_from_storage()
            ir_reading = sensor.pop_ir_from_storage()
            
            value = red_reading
            history.append(value)
            history = history[-MAX_HISTORY:]
            minima = 0
            maxima = 0
            threshold_on = 0
            threshold_off = 0

            minima, maxima = min(history), max(history)

            threshold_on = (minima + maxima * 3) // 4   # 3/4
            threshold_off = (minima + maxima) // 2      # 1/2
            
            
            if value > 1000:
                if not beat and value > threshold_on:
                    beat = True 
                                    
                    led.on()
                    
                    t_us = ticks_diff(ticks_us(), t_start)
                    t_s = t_us/1000000
                    f = 1/t_s
                
                    bpm = f * 60
                    
                    if bpm < 500:
                        t_start = ticks_us()
                        beats_history.append(bpm)                    
                        beats_history = beats_history[-MAX_HISTORY:] 
                        beats = round(sum(beats_history)/len(beats_history) ,2)
                        temp = round(sensor.read_temperature(),2)

                                        
                if beat and value< threshold_off:
                    beat = False
                    led.off()
                
            else:
                led.off()
                print('Prst nije prislonjen na senzor!')
                beats = 0.00


_thread.start_new_thread(get_max30102_values, ())


while True:
    try:
        topic_msg1 = str(beats)
        client.publish(topic_pub1, topic_msg1)
        print('Objavljeno: ', topic_msg1)
        topic_msg2 = str(temp)
        client.publish(topic_pub2, topic_msg2)
        print('Objavljeno: ', topic_msg2)
    except OSError as e:
        topic_msg1 = 'Senzor nedostupan'
        topic_msg2 = 'Senzor nedostupan'
        client.publish(topic_pub1, topic_msg1)
        client.publish(topic_pub2, topic_msg2)
        print('Objavljeno: ', topic_msg)
    sleep(3)