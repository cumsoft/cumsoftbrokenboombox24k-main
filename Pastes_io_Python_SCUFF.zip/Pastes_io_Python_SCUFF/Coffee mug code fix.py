from enum import Enum
from datetime import datetime
import time
import random
import sys

class TimeOfDayEnum(Enum):
    MORNING = 1
    MIDDAY = 2
    AFTERNOON = 3
    EVENING = 4
    NIGHT = 5

def wake_up(time):
    if time == TimeOfDayEnum.MORNING:
        return True
    else:
        raise Exception("Wrong time to get up")
    
def current_time_of_day():
    currenthour = datetime.now().hour
    if (currenthour < 7) or (currenthour >= 23):
        return TimeOfDayEnum.NIGHT
    if currenthour <= 10:
        return TimeOfDayEnum.MORNING
    if currenthour <= 13:
        return TimeOfDayEnum.MIDDAY
    if currenthour < 18:
        return TimeOfDayEnum.AFTERNOON
    return TimeOfDayEnum.EVENING

class Mug:

    def __init__(self):
        self.__preferred_milk_sugar_level = random.randint(0,10)
        self.content = []
        self.sugarLevel = 0
        self.milkLevel = 0

    def add(self, item):
        self.content.append(item)

    def add_milk_and_sugar(self, amount=1):
        self.sugarLevel += amount
        self.milkLevel += amount

    @property
    def to_taste(self):
        return (self.sugarLevel == self.__preferred_milk_sugar_level) and (self.milkLevel == self.__preferred_milk_sugar_level)

if __name__ == '__main__':
    currentTime = TimeOfDayEnum.MORNING

    if wake_up(currentTime):
        coffeecounter = 0
        while currentTime.value <= 3: #All day long
            coffeecounter += 1
            myMug = Mug()
            myMug.add('coffee')
            myMug.add('*** water')
            while not myMug.to_taste:
                sys.stdout.write(f'\rCup nr. {coffeecounter}, added milk and suger: {myMug.milkLevel}')
                myMug.add_milk_and_sugar()
            currentTime = current_time_of_day()
        print('\nEnd of day!')
    else:
        raise Exception("Simply piss off")