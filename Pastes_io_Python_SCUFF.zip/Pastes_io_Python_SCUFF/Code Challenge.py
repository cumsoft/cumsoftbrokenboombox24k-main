import io

text = b"""200-400,600-800
200-300,400-500
500-700,700-900
200-800,300-700
600-600,400-600
200-600,400-800
"""

file = io.BytesIO(text)


def inside_range(file):

    idx = 0
    lines = file.read().splitlines()

    for line in lines:

        r1, r2 = line.split(b',')

        low1, high1 = r1.split(b'-')
        low2, high2 = r2.split(b'-')

        low1 = int(low1)
        high1 = int(high1)
        low2 = int(low2)
        high2 = int(high2)

        if low1 in range(low2, high2 + 1):
            if high1 in range(low2, high2 + 1):
                idx += 1
                continue

        if low2 in range(low1, high1 + 1):
            if high2 in range(low1, high1 + 1):
                idx += 1
                continue

    return idx

print(inside_range(file))