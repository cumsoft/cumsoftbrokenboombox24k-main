def convert(x, m):
    ans = 0
    q = 1

    for digit in x[::-1]:
        ans += int(digit) * q
        q *= m
    
    return ans


y = input()
a = input()
p = int(input())

y = convert(y, p)
a = convert(a, p)

print(y \% a)