import cv2
import dlib
import numpy as np

# Carregando o classificador de faces Haar Cascade
face_cascade = cv2.CascadeClassifier("haarcascade_frontalface_default.xml")

# Inicializando o detector de landmarks faciais
predictor = dlib.shape_predictor("shape_predictor_68_face_landmarks.dat")

# Capturando imagem da câmera
cap = cv2.VideoCapture(0)

while True:
    # Lendo frame da câmera
    ret, frame = cap.read()
    
    # Convertendo para escala de cinza
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    
    # Detectando faces no frame
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))
    
    # Desenhando retângulo em torno das faces detectadas
    for (x, y, w, h) in faces:
        cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2)
        
        # Detectando landmarks faciais
        shape = predictor(gray, dlib.rectangle(left=x, top=y, right=x + w, bottom=y + h))
        shape = np.array([[p.x, p.y] for p in shape.parts()])
        
        # Encontrando sorriso
        mouth = shape[48:60]
        smile = False
        for (x, y) in mouth:
            cv2.circle(frame, (x, y), 1, (0, 255, 0), -1)
            if y > shape[60][1]:
                smile = True
        
        # Escrevendo "Feliz" ou "Triste" na tela
        if smile:
            cv2.putText(frame, "Feliz", (x, y), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        else:
            cv2.putText(frame, "Triste", (x, y), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
    
    # Exibindo imagem resultante
    cv2.imshow("Reconhecimento Facial", frame)
    
    # Parando loop com a tecla 'q'
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Liberando recursos da câmera
cap.release()
cv2.destroy