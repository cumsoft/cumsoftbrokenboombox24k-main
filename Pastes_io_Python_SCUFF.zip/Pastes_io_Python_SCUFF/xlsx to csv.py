import time
import os
import pandas
 
 
print("(full)path to list of files/folders:")
path_to_f=str(input())
 
book = pandas.read_excel(path_to_f)
 
header=";".join(book.head())
result_name = "result_"+str(time.time())+".csv"
result_file = open(result_name,"w",encoding='utf-8-sig')
result_file.write(header+'\n')
 
for i in range (book.shape[0]):
    for j in range(book.shape[1]):
        list_help = str(str(book.iloc[i,j]))
        result_file.write(list_help+'\n')
 
result_file.close()