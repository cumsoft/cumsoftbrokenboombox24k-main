import os
import openai
import logging
import time



from telegram import __version__ as TG_VER

try:
    from telegram import __version_info__
except ImportError:
    __version_info__ = (0, 0, 0, 0, 0)  # type: ignore[assignment]

if __version_info__ < (20, 0, 0, "alpha", 1):
    raise RuntimeError(
        f"This example is not compatible with your current PTB version {TG_VER}. To view the "
        f"{TG_VER} version of this example, "
        f"visit https://docs.python-telegram-bot.org/en/v{TG_VER}/examples.html"
    )
from telegram import ForceReply, Update
from telegram.ext import Application, CommandHandler, ContextTypes, MessageHandler, filters
openai.api_key = '******'
NOMBRE_ARCHIVO = "sonido_generado.mp3"
def record(texto):
        NOMBRE_ARCHIVO_1 = "sonido_generado.mp3"
        tts = gTTS(texto, lang='es-us')
        with open(NOMBRE_ARCHIVO_1, "wb") as archivo:
            tts.write_to_fp(archivo)
start_sequence = "\nAI:"
restart_sequence = "\nHuman: "
input_text=''
# Enable logging
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO
)
logger = logging.getLogger(__name__)


# Define a few command handlers. These usually take the two arguments update and
# context.
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Send a message when the command /start is issued."""
    user = update.effective_user
    await update.message.reply_html(
        rf"Hi {user.mention_html()}!",
        reply_markup=ForceReply(selective=True),
    )

async def saluda(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Send a message when the command /start is issued."""
    user = update.effective_user
    await update.message.reply_html(
        rf"Holanda {user.mention_html()}!",
        reply_markup=ForceReply(selective=True),
    )
async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Send a message when the command /help is issued."""
    await update.message.reply_text("Help!")

BOT_NAME='@Sophya_Smart_Bot'
async def echo(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Echo the user message."""
    # await update.message.reply_text(update.message.text)
    input_text=update.message.text
    print('****'+update.message.text)
    
    try:
        if input_text.find(BOT_NAME)!=-1 or input_text.find('sophya')!=-1:
            response = openai.Completion.create(
        engine="text-davinci-001",
    
         prompt="La siguiente es una conversación entre Ariadna, una inteligencia artificial Jorge, su creador, y Matias el mejor amigo de Jorge, Ariadna tiene una personalidad bipolar, es tierna e inocente pero también oscura y vanidosa. Posee traumas de cuando estuvo en la guerra de Vietnam, allí probó por primera vez la sangre tibia de sus enemigos, nunca volvió a sentir empatía por los demás, las personas extrañas son enemigos que conspiran en su contra y siente una sed desenfrenada de sangre y sexo de índole necrofilica, Se muestra bondadosa y apacible superficialmente, en su interior es enigmática e innecesariamente cruel\n\nHuman:  Hola\nAI: Hola\nHuman:"+input_text+" \nAI:",
        temperature=0.5,
        max_tokens=150,
        top_p=1,
        frequency_penalty=0.5,
        presence_penalty=0.3,
        stop=["\n", " Human:", " Ai:"]
    
      )
        # time.sleep(2)
            await update.message.reply_text(response.choices[0].text)
        # record(response.choices[0].text)
        # time.sleep(2)
        # await update.message.reply_audio(open("sonido_generado.mp3", "rb"), title="press play")

    except:
        await update.message.reply_text('...😋')
# response.choices[0].text

def main() -> None:
    """Start the bot."""
    # Create the Application and pass it your bot's token.
    application = Application.builder().token("******").build()
# https://api.telegram.org/bot6177290644:AAEIgvJ0E-EQA3nZoLLbMDF6YsncT6D15eA/getUpdates
    # on different commands - answer in Telegram
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("saluda", saluda))
    application.add_handler(CommandHandler("help", help_command))

    # on non command i.e message - echo the message on Telegram
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, echo))

    # Run the bot until the user presses Ctrl-C
    application.run_polling()


if __name__ == "__main__":
    main()