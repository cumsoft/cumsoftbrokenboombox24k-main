from multiprocessing import Pool
import math
import time

def is_prime(num):
    if num < 2:
        return False
    if num == 2:
        return True
    if num % 2 == 0:
        return False
    for divisor in range(3, int(math.sqrt(num)) + 1, 2):
        if num % divisor == 0:
            return False
    return True

def generate_palindrome_prime(start, end):
    special_primes = []
    for i in range(start, end):
        str_i = str(i)
        palindrome = int(str_i + str_i[::-1])
        if palindrome > end:
            break
        if is_prime(palindrome):
            special_primes.append(palindrome)
    return special_primes

def parallel_processing(range_start, range_end, num_processes):
    pool = Pool(processes=num_processes)
    chunk_size = (range_end - range_start) // num_processes
    ranges = [(range_start + i * chunk_size, min(range_start + (i + 1) * chunk_size, range_end)) for i in range(num_processes)]
    
    results = pool.starmap(generate_palindrome_prime, ranges)
    pool.close()
    pool.join()
    return [prime for sublist in results for prime in sublist]

if __name__ == '__main__':
    range_start = 110000
    range_end = 150000
    num_processes = 4

    start_time = time.time()
    special_primes = parallel_processing(range_start, range_end, num_processes)
    end_time = time.time()

    print("Special numbers:", special_primes[:3], "...", special_primes[-3:])
    print("Total amount of special numbers:", len(special_primes))
    print("Time passed:", end_time - start_time, "seconds")