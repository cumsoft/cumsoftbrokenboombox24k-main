# Example pygame typewriter effect.
import string
import pygame

text_example = """Hello !
This is my example writer.
I prerender all letters.
I use pygame Sprite and Group classes.
I use pygame.time.set_timer.
Hit spacebar to reset writer."""

class LetterSprite(pygame.sprite.Sprite):
    def __init__(self, letter, position, location):
        super().__init__()
        self.image = letter
        self.rect = letter.get_rect(topleft=position)
        self.location = location

class LetterPen:
    def __init__(self, fontname, size, color, bcolor=None):
        self.font = pygame.font.Font(fontname, size)
        self.letters = {}

        data = string.ascii_letters + string.digits + string.punctuation
        for letter in data:
            self.letters[letter] = self.font.render(letter, 1, color, bcolor)

    def render(self, text, position):
        data = []
        y = position[1]
        lines = text.split('\n')
        linesize = self.font.get_linesize()

        for yenum, line in enumerate(lines):
            for xenum, letter in enumerate(line):
                if letter != ' ':
                    l = self.letters[letter]
                    # Just grabbing the width
                    x = self.font.size(line[:xenum])[0] + position[0]
                    sprite = LetterSprite(l, (x, y), (xenum, yenum))
                    data.append(sprite)

            y += linesize

        return data

class WriterText:
    def __init__(self, letters, interval):
        self.lgroup = pygame.sprite.Group()
        self.interval = interval
        self.letters = letters
        self.length = 0

        self.event_id = pygame.event.custom_type()
        pygame.time.set_timer(self.event_id, self.interval)

    def draw(self, surface):
        self.lgroup.draw(surface)

    def reset(self):
        self.length = 0
        self.lgroup.empty()
        pygame.time.set_timer(self.event_id, self.interval)

    def update(self):
        if self.length < len(self.letters):
            self.lgroup.add(self.letters[self.length])
            self.length += 1
        else:
            pygame.time.set_timer(self.event_id, 0)

def main():
    pygame.init()
    pygame.display.set_caption("Typing Example")
    surface = pygame.display.set_mode((600, 600))
    clock = pygame.time.Clock()
    rect = surface.get_rect()
    delta = 0
    fps = 0

    pen = LetterPen(None, 28, 'skyblue')
    letters = pen.render(text_example, (20, 20))
    # Higher interval for slower
    writer = WriterText(letters, 50)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == writer.event_id:
                writer.update()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    writer.reset()
            elif event.type == pygame.QUIT:
                running = False

        surface.fill('black')
        writer.draw(surface)
        pygame.display.flip()
        delta = clock.tick(fps)

    pygame.quit()

main()