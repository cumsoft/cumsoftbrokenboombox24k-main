# Project by: David Kafui Afflu
#
# Title: One, Two, Or You're Out


# Importing necessary libraries
import pygame as pg
import sys
import time
from pygame.locals import *

# Declaring global variables
    # Dynamic variables
turn = "Player 1"
winner = None
pile_height = 0
P1_score = 0
P2_score = 0

    # Static variables
width = 1000
height = 500

pile = [None for i in range(10)]    # Tracking pile status as 2d list

pg.init()   # Initialising pygame window

fps = 30    # Setting fps
CLOCK = pg.time.Clock() #Tracking time

# Setting up display and window title
screen = pg.display.set_mode((width, height + 100), 0, 32)
pg.display.set_caption("One, Two, Or You're Out")

# Loading thumbnails, backgrounds and rocks as pygame surfaces
game_start = pg.transform.scale(pg.image.load("Final_Project/Coverpage.png"), (width, height + 100))
instructions = pg.transform.scale(pg.image.load("Final_Project/Instructions.png"), (width, height + 100))
background = pg.transform.scale(pg.image.load("Final_Project/Background.png"), (width, height + 100))
P1_img = pg.transform.scale(pg.image.load("Final_Project/P1rock.png"), (86, 65))
P2_img = pg.transform.scale(pg.image.load("Final_Project/P2rock.png"), (86, 65))

# Creating a class for the option buttons to behave as sprites
class Button(pg.sprite.Sprite):
    # Getting the image for the sprite
    def __init__(self, image_path):
        super().__init__()
        self.image = pg.transform.scale(pg.image.load(image_path), (80, 80))
    
    # To draw it on the screen
    def draw(self, surface, pos):
        self.position = pos
        self.rect = self.image.get_rect(center = (pos[0]+40, pos[1]+40))
        surface.blit(self.image, self.position)

    # Checking if sprite has been clicked
    def is_clicked(self, x, y):
        return self.rect.collidepoint(x, y) #Returns boolean value

# Instantiating the two button sprites
opt_1 = Button("Final_Project/Opt1.png")
opt_2 = Button("Final_Project/Opt2.png")


def game_initiating_window():
    # Displaying coverpage over screen
    screen.blit(game_start, (0, 0))
    pg.display.update()
    time.sleep(3)   #Wait for 3 seconds

    # Displaying instructions page over screen
    screen.blit(instructions, (0, 0))
    pg.display.update()
    time.sleep(7)   #Wait for 7 seconds

    play_game()

def play_game():
    # Displaying game background and starting game
    screen.blit(background, (0, 0))

    # Displaying status message
    if winner is None:
        message = f"{turn}'s turn"
    else:
        message = f"{winner} Won!"
        
    # Setting message font, size, colour and position
    msg_font = pg.font.Font(None, 50)
    text = msg_font.render(message, 1, (255, 255, 255))
    text_rect = text.get_rect(center=(width/2, height+65))

    screen.blit(text, text_rect)    # Rendering message on screen

    # Displaying player scores
    scr_font = pg.font.Font(None, 40)
    score1 = scr_font.render(f"Score: {P1_score}", 1, (255, 0, 0))
    score2 = scr_font.render(f"Score: {P2_score}", 1, (255, 0, 0))
    score1_rect = score1.get_rect(center=(127, 96))
    score2_rect = score2.get_rect(center=(width-127, 96))
    screen.blit(score1, score1_rect)
    screen.blit(score2, score2_rect)

    # Rendering all blocks already placed
    global pile
    for level in pile:
        if level is not None:
            if level[0] == "P1":
                rock = P1_img
            else:
                rock = P2_img
            screen.blit(rock, level[1])

    pg.display.update()
    time.sleep(0.3) # Wait 0.3 seconds before next player's turn
    choose_rocks()

def choose_rocks():
    # Showing the buttons for a player to choose the number of rocks
    if winner is None:
        # Setting x coordinate based on the current player
        if turn == "Player 1":
            posx = 85 
        else:
            posx = width - 165

        # Drawing buttons in position on screen
        opt_1.draw(screen, (posx, (height/2)-45))
        opt_2.draw(screen, (posx, (height/2)+45))

        pg.display.update()

def user_click(x, y):
    # Initialising rock placement after mouse click
    if turn == "Player 1":
        if opt_1.is_clicked(x, y):
            # Player 1 chooses opt 1
            place_rock("P1")
        elif opt_2.is_clicked(x, y):
            # Player 1 chooses opt 2
            place_rock("P1")
            if pile_height < 10:
                place_rock("P1")
    elif turn == "Player 2":
        if opt_1.is_clicked(x, y):
            # Player 2 chooses opt 1
            place_rock("P2")
        elif opt_2.is_clicked(x, y):
            # Player 2 chooses opt 2
            place_rock("P2")
            if pile_height < 10:
                place_rock("P2")

    play_game()

def place_rock(player):
    global pile, pile_height, turn, winner

    posx = width/2 - 43 # The centre of the rock is in the horizontal middle
    posy = height - (pile_height+1)*50 + 5  # The level rises as the pile gets larger
    pile[pile_height] = [player, (posx, posy)]  # Adding the rock to the pile

    # Switching turns
    if player == "P1":
        turn = "Player 2"
    else:
        turn = "Player 1"
        
    # Increase registered pile height and check if pile is full
    pile_height += 1
    if pile_height == 10:
        winner = turn
        if turn[-1] == "1":
            global P1_score
            P1_score += 1
        else:
            global P2_score
            P2_score += 1


def reset_game():
    # Displaying restart message at bottom of screen
    screen.fill((148, 119, 75), (378, 547, 246, 40))
    font = pg.font.Font(None, 50)
    text = font.render("Game Restarting...", 1, (255, 255, 255))
    text_rect = text.get_rect(center=(width/2, height+65))
    screen.blit(text, text_rect)
    pg.display.update()
    time.sleep(0.5)

    # Resetting global variables to defaults
    global pile, pile_height, winner, turn
    turn = "Player 1"
    winner = None
    pile = [None for j in range(10)]
    pile_height = 0

    play_game() #Restart game


game_initiating_window()
while True:
	for event in pg.event.get():
		if event.type == pg.QUIT:
			pg.quit()
			sys.exit()
		elif event.type == pg.MOUSEBUTTONDOWN:
                    x, y = pg.mouse.get_pos()
                    user_click(x, y)

                    # Resetting game when a player wins
                    if winner:
                        time.sleep(2)
                        reset_game()