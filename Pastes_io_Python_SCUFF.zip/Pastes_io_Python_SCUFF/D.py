import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import io
import os


input_file_path = '"C:\Users\2201010\Documents\ReTAion\sample_data.xls"'

# Load the XLS file into a Pandas DataFrame
#df = pd.read_excel(input_file_path)

# Function to read different file type into a DataFrame

def read_file(file_path):
    _, file_extension = os.path.splitext(file_path)     

    if file_extension == '.csv': 
        df = pd.read_csv(file_path)
    elif file_extension == '.json':
        df = pd.read_json(file_path)
    elif file_extension =='.xml':
        df = pd.read_xml(file_path)
    elif file_extension == '.xls':
        df = pd.read_excel(file_path)
    elif file_extension == 'xlsx':
        df = pd.read_excel(file_path)
    elif file_extension == '.hdf':
        df = pd.read_hdf(file_path)           
    elif file_extension == '.sql':
        df = pd.read_sql(file_path)
    else:
        raise ValueError(f'Unsupported filetype: {file_path}')
      
    return df
#convert this data frame to a variable


# Check if the file exists

if os.path.exists(input_file_path):
    # Read the file into a Pandas DataFrame
    df = read_file(input_file_path)
    print("Data read successfully.")
    
else:
    print(f"The file '{input_file_path}' does not exist.")
    
# Basic information about the data
print("Data Information:")
print(df.info())


# Summary statistics for numeric columns
print("\nSummary Statistics for Numeric Columns:")
print(df.describe())

# Summary statistics for non-numeric (categorical) columns
print("\nSummary Statistics for Categorical Columns:")
print(df.describe(include=['object']))

# Count of missing values for each column
print("\nMissing Values:")
print(df.isnull().sum())

# Count of unique values for each column
print("\nUnique Value Counts:")
print(df.nunique())

# Sample of the first few rows of data
print("\nSample Data:")
print(df.head())

# Value counts for specific columns
print("\nValue Counts for 'Column_Name':")
print(df['City'].value_counts())

# Identify and display duplicate rows
duplicate_rows = df[df.duplicated()]
if not duplicate_rows.empty:
    print("Duplicate Rows:")
    print(duplicate_rows)
else:
    print("No duplicate rows found.")

# Identify and display missing values in columns
missing_values = df.isnull().sum()
if missing_values.any():
    print("\nMissing Values in Columns:")
    print(missing_values)
else:
    print("\nNo missing values found in any column.")

#Explore categorical columns
print("\nCategorical Column Value Counts:")
for column in df.select_dtypes(include='object'):
    print(df[column].value_counts())

# Visualize distributions of numerical columns
for column in df.select_dtypes(include=['int64', 'float64']):
    plt.figure(figsize=(8, 6))
    sns.histplot(df[column], kde=True)
    plt.title(f'Distribution of {column}')
    plt.xlabel(column)
    plt.ylabel('Frequency')
    plt.show()

# Visualize distributions of numerical columns with KDE plots
for column in df.select_dtypes(include=['int64', 'float64']):
    plt.figure(figsize=(10, 6))
    
    # Histogram
    plt.subplot(1, 2, 1)
    sns.histplot(df[column], bins=20, kde=True)
    plt.title(f'Distribution of {column}')
    plt.xlabel(column)
    plt.ylabel('Frequency')
    
    # KDE plot
    plt.subplot(1, 2, 2)
    sns.kdeplot(df[column], shade=True)
    plt.title(f'Density Plot of {column}')
    plt.xlabel(column)
    plt.ylabel('Density')
    
    plt.tight_layout()
    plt.show()

# Visualize relationships between variables (pairplot for numerical columns)
sns.pairplot(df)
plt.show()

# Visualize correlations between numerical variables (heatmap)
correlation_matrix = df.corr()
plt.figure(figsize=(10, 8))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt='.2f', linewidths=0.5)
plt.title('Correlation Matrix')
plt.show()