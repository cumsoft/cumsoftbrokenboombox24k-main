import imaplib
import email
from email.header import decode_header
from email.utils import getaddresses
from typing import Optional, Generator, Tuple
from time import perf_counter
 
 
def fetch_emails(mail: imaplib.IMAP4_SSL, criteria: str) -> Generator[bytes, None, None]:
    _, messages = mail.search(None, criteria)
    email_ids = messages[0].split()
    for email_id in reversed(email_ids):
        yield email_id
 
 
def find_otp(email_address: str, password: str) -> Tuple[float, Optional[int]]:
    with imaplib.IMAP4_SSL("outlook.office365.com") as mail:
        mail.login(email_address, password)
        mail.select("inbox")
        t0 = perf_counter()
        criteria = "ALL"
 
        for email_id in fetch_emails(mail, criteria):
            _, msg_data = mail.fetch(email_id, "(BODY[HEADER.FIELDS (SUBJECT FROM)])")
            email_message = email.message_from_bytes(msg_data[0][1])
 
            from_address = getaddresses(email_message.get_all('From', []))[0][1]
 
            if from_address != "info@x.com":
                continue
 
            subject, encoding = decode_header(email_message["Subject"])[0]
            if isinstance(subject, bytes):
                subject = subject.decode(encoding or "utf-8")
 
            return t0, int(''.join(filter(str.isdigit, subject)))
 
    return t0, None
 
if __name__ == "__main__":
    email_address, password = "ndidzu60inzi1@hotmail.com", "Nsq8Iu993824"
    t0, otp = find_otp(email_address, password)
    t1 = perf_counter()
    print(f"Time taken to find OTP using new_func: {otp}: {t1 - t0:.3f} seconds")