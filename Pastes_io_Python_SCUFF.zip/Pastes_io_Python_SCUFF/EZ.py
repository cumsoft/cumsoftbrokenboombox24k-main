def solution(args):
    # do dai substring
    sum = 0
    for substring_length in range(1, len(args)):
        relative_strings = [args[i:i + substring_length]
                            for i in range(0, len(args) - substring_length + 1)]
        sum = sum + count_relative(relative_strings)
    return sum

# tra ve so relaitve string trong 1 mang cac string


def count_relative(input):
    result = 0
    listDict = []
    for substring in input:
        listDict.append(string_todict(substring))
    for i in range(len(listDict)-1):
        for j in range(i+1, len(listDict)):
            if isEqual(listDict[i], listDict[j]):
                result += 1
    return result


def isEqual(input1, input2: dict):
    if len(input1.keys()) != len(input2.keys()):
        return False
    for k1 in input1.keys():
        if input1.get(k1) != input2.get(k1):
            return False
    return True


def string_todict(input):
    result = {}
    for char in input:
        if char in result:
            result[char] += 1
        else:
            result[char] = 1
    return result


print(solution("abca"))