import pandas as pd
import os
import csv

# ... (the rest of your code)

def load_files_into_dataframes(directory):
    files = ['Delivery Plan.csv', 'LQUA-Coverage.txt', 'RESB-Coverage.csv']
    dataframes = {}

    specified_columns = {
        'Delivery Plan.csv': ['Delivery_Plan_Material', 'Delivery_Plan_Vendor_Name', 'Delivery_Plan_Quantity', 'Delivery_Plan_Delivery_Date'],
        'LQUA-Coverage.txt': ['Plnt', 'Material', 'Typ', 'Stor. Bin', 'Stock', 'PutawayStk', 'Pick qty', 'Avail.stck',
                              'Sp.Stck No'],
        'RESB-Coverage.csv': ['RESB_Plant', 'RESB_Material', 'RESB_WO_ITM', 'RESB_Quantity', 'RESB_ReqmtsDate',
                              'RESB_WBS_Element', 'RESB_Effectivity', 'RESB_Work_Center', 'RESB_MPS_Date'],
        'LTAP_Open.txt': ['TO Number', 'Itm']
    }

    for file_name in files:
        file_path = os.path.join(directory, file_name)

        if file_name == 'LQUA-Coverage.txt':
            # Read the LQUA file and skip the first 3 rows
            try:
                df = pd.read_csv(file_path, delimiter='\t', header=0, encoding='utf-8', skiprows=3)
            except UnicodeDecodeError:
                df = pd.read_csv(file_path, delimiter='\t', header=0, encoding='ISO-8859-1', skiprows=3)
            
            # Check for column names that contain either "StorageBin" or "Stor. Bin" and rename accordingly
            col_names = df.columns.tolist()
            if 'StorageBin' in col_names:
                df.rename(columns={'StorageBin': 'Stor. Bin'}, inplace=True)
            elif 'Stor. Bin' in col_names:
                df.rename(columns={'Stor. Bin': 'StorageBin'}, inplace=True)
        else:
            # Adjust the delimiter based on the file extension
            delimiter_char = ',' if file_name.endswith('.csv') else '\t'

            try:
                df = pd.read_csv(file_path, delimiter=delimiter_char, header=0, encoding='utf-8')
            except UnicodeDecodeError:
                df = pd.read_csv(file_path, delimiter=delimiter_char, header=0, encoding='ISO-8859-1')

        df.columns = df.columns.str.strip()
        columns_to_keep = specified_columns[file_name]
        df = df[columns_to_keep]
        dataframes[file_name] = df

    return dataframes

# ... (the rest of your code)