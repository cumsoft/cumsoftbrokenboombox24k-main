#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
import requests
from datetime import datetime
from pprint import pprint

r = requests.get('https://api.openweathermap.org/data/2.5/weather?lat=-34.61&lon=-58.38&units=metric&lang=es&appid=6ce13bc6d5a965e991adaea8fce8676a')
datos = r.json()
pprint(datos)

print("Hora del pronóstico:")
print(datetime.fromtimestamp(datos['dt']))

print("Salida del Sol:")
print(datetime.fromtimestamp(datos['sys']['sunrise']))

print("Puesta del Sol:")
print(datetime.fromtimestamp(datos['sys']['sunset']))