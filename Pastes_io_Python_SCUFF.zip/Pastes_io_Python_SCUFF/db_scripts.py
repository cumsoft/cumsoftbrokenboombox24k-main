import sqlite3
from settings import *


db_name = 'blog.db'
conn = None
cursor = None

def open():
    global conn, cursor
    conn = sqlite3.connect(PATH + db_name)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

def close():
    cursor.close()
    conn.close()

def do(query, params = None):
    cursor.execute(query, params)
    conn.commit()
 
def getUser():
    open()
    cursor.execute('''SELECT * FROM user''')
    user = cursor.fetchone()
    close()
    
    return user

def getAuthData():
    open()
    cursor.execute('''SELECT * FROM users''')
    data = cursor.fetchone()
    close()

    return {'login' : data[0], 'password' : data[1]}

def updateInfo(data):
    open()
    do('''UPDATE users SET login = (?), password = (?)''', [data['login'], data['password']])
    do('''UPDATE info SET text = (?)''', [data['text']])
    if 'image' in data:
        do('''UPDATE info SET image = (?)''', [data['image']])
    close()

def getBlog(category):
    open()
    cursor.execute('''SELECT * FROM posts WHERE category = (?)''', [category])
    blog = cursor.fetchall()
    close()
    
    return blog

def addPost(category, post):
    open()
    cursor.execute('''INSERT INTO posts (category,text,datetime) VALUES((?),(?),DATE())''', [category, post])
    conn.commit()
    close()