# Initialise an empty list to store user inputs
user_inputs = []

while True:
    # Capture user input
    user_input = input("Enter a value (or 'exit' to quit): ")

    # Check if the user wants to exit
    if user_input.lower() == "exit":
        break  # Exit the loop if the user enters 'exit'
    
    # Add the user input to the list
    user_inputs.append(user_input)

# Display the list of user inputs
print("User inputs:")
for item in user_inputs:
    print(item)