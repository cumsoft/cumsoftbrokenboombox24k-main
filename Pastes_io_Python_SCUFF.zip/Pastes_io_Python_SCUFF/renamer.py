import os 
import sys 
import mediafile 
import discogs_client 


def get_path(*kwargs):
	#this function gets the directory path by executing a bash script which 
	#passes this path to python/initiates the python virtual environment
	#FUNCTION NAME AND RETURN OBJECT NEED NEW NAMES
	return path

def navigation(SOMETHING GOES HERE):
	#using os.walk to step through each folder
	pass

def get_media(old_folder_name):
#run regex query on the old_folder_name to get on of the following:
#		*VINYL
#		*WEB
#		*CASSETTE
#		*CD
	return media


def get_download_data(mediafile_metadata):
#use mediafile library to loop through each track to extract:
#	*all artists
#	*all track names
#and return a long string with no punctuation.
	return metadata


def get_format(get_download_format):
#use mediafile library to extract:
#	*format - either mp3, flac, wav
#	*bitrate 
	return download_format


def reject_download():
#if no folder called REJECTED DOWNLOADS exist:
#	*make folder REJECTED DOWNLOADS
#	*move download into REJECTED DOWNLOADS
	pass

def get_catno_matches(metadata):
#take the metadata generated from the get_download_data function
#and enter it as a query into the discogs_client
	return catno_matches


def compare_catnos(old_folder_name, catno_matches):
#if catno_matches = 1 result:
#	return new_catno
#elif one of catno_matches is in old_folder_name:
#	return new_catno
#elif there are matches of 95-99%
#	DO SOMETHING 
#	return new_catno
#else
#	reject_download()
	return new_catno, discogs_release_ID

def get_new_download_name(discogs_release_ID):
	#using the discogs release ID, fetch the artist/release name string from discogs API
	return new_download_name

def get_year(mediafile_metadata):
	#using mediafile, loop through each track
	#starting with the first year collected - if any errors, reject download.
	#if all good - return year.
	return year


def create_new_fol_name(new_catno, new_download_name, year, media, format):
#construct a new string using all previously created functions shown 
#as arguments used to create a new string
	return new_folder_name

if __name__ == '__main__':
	main():
#WRITE MAIN FUNCTION#