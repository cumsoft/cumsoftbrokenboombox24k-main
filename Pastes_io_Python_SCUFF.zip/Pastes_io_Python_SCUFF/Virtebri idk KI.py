def viterbi(obs, states, start_p, trans_p, emit_p):
    """
    Viterbi algorithm implementation.
    
    Args:
    - obs: a sequence of observations
    - states: a list of possible hidden states
    - start_p: a dict with initial probabilities for each state
    - trans_p: a dict with transition probabilities between states
    - emit_p: a dict with emission probabilities for each state/observation pair
    
    Returns:
    - path: a list of the most likely sequence of hidden states
    """
    T = len(obs)
    V = [{}]
    path = {}
 
    # Initialize base cases (t == 0)
    for state in states:
        V[0][state] = start_p[state] * emit_p[state][obs[0]]
        path[state] = [state]
 
    # Run Viterbi algorithm for t > 0
    for t in range(1, T):
        V.append({})
        newpath = {}
 
        for state in states:
            # Find the maximum probability and associated state for each observation
            (prob, max_state) = max((V[t-1][prev_state] * trans_p[prev_state][state] * emit_p[state][obs[t]], prev_state) for prev_state in states)
            
            V[t][state] = prob
            newpath[state] = path[max_state] + [state]
 
        # Update the path with the new path
        path = newpath
 
    # Find the maximum probability and associated path
    (prob, max_path) = max((V[T-1][state], path[state]) for state in states)
    
    return max_path