#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Filename: get_file_size.py
# Author: Jeoi Reqi

"""
Get File Size Script (In Bytes)

This script retrieves the size of a file named 'texty.txt' in the same directory
as the script. It utilizes a function, get_file_size, to get the file size.

Requirements:
- Python 3

Usage:
1. Save the script in the same directory as the 'texty.txt' file.
2. Run the script.
3. The script will display the size of the 'texty.txt' file in bytes.
"""

import os

def get_file_size(file):
    """Get file size.

    Args:
        file (str): Input file.

    Returns:
        int: Size of the file in bytes.

    """
    return os.stat(file).st_size

def main():
    # Specify the file path
    file_path = 'texty.txt'  # Replace 'texty.txt' with the actual file name if needed

    # Get file size
    size = get_file_size(file_path)

    # Display the result
    print(f"Size of the '{file_path}' file: {size} bytes")

if __name__ == "__main__":
    main()