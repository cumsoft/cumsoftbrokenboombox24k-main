import time
 
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright
 
def extract_data(row):
    name = row.find("h3").text.strip("\n").strip()
    capital = row.find("span", attrs={"class": "country-capital"}).text
    population = row.find("span", attrs={"class": "country-population"}).text
    area = row.find("span", attrs={"class": "country-area"}).text
 
    return {"name": name, "capital": capital, 'population': population, "area (km sq)": area}
 
 
start = time.time()
with sync_playwright() as p:
    # launch the browser instance and define a new context
    browser = p.chromium.launch()
    context = browser.new_context()
    # open a new tab and go to the website
    page = context.new_page()
    page.goto("https://www.scrapethissite.com/pages/")
    # click to the first page
    page.locator("a[href='/pages/simple/']").click()  
    # extract the data using beautiful soup
    soup = BeautifulSoup(page.inner_html("section[id='countries']>div[class='container']"), "html.parser")
    countries = soup.find_all("div", {"class": "country"})
 
    data = list(map(extract_data, countries))
 
    browser.close()
end = time.time()
 
print(f"The whole script took: {end-start:.4f}")