import openai
openai.api_key = "your_api_key_here"

def chat_with_chatgpt(prompt, model="gpt-3.5-turbo"):
	response = openai.Completion.create(
		engine=model,
		prompt=prompt,
        max_tokens=100,
        n=1,
        stop=None,
        temperature=0.5,
    )
    message = response.choices[0].text.strip()
    return message