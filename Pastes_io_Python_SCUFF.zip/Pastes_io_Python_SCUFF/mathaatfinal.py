Congruence(Number Theory):
1.
Finding GCD of given two numbers(a,b)
import math
def find_gcd(a, b):
return math.gcd(a, b) print(find_gcd(54, 24))
OUTPUT: 6
Express GCD of two numbers as Linear Combination d=au+bv
def gcd_linear_combination(a, b): x, y, u, v = 0, 1, 1, 0
while a != 0:
q, r = b//a, b%a
m, n = x-u*q, y-v*q
b, a, x, y, u, v = a, r, u, v, m, n
return b, x, y print(gcd_linear_combination(32, 14))
OUTPUT: (2, -3, 7)
or a=int(input("enter first number:"))
b=int(input("enter second number:")) c,d=a,b
x, y, u, v = 0, 1, 1, 0
while a != 0:
q, r = b//a, b%a
m, n = x-u*q, y-v*q
b, a, x, y, u, v = a, r, u, v, m, n
print("%d = %d * %d + %d * %d"%(b,c,x,d,y))
OUTPUT:
enter first number:14 enter second number:32 2 = 14 * 7 + 32 * -3
2.

 3. Solve the linear congruence ax=b(mod n) for all positive integer solutions
import math
def solve_linear_congruence(a, b, n):
N=n
gcd = math.gcd(a, n) value=gcd while(b>=n):
b=b-n
if (b % gcd != 0):
return "No solution"
a, b, n = int(a/gcd),int(b/gcd),int(n/gcd) N1=n
gcd = math.gcd(a, n)
if (b % gcd != 0):
return "No solution" x, y, u, v = 0, 1, 1, 0 while a != 0:
q, r = n//a, n%a
m, g = x-u*q, y-v*q
n, a, x, y, u, v = a, r, u, v, m, g
x0=b*x while(x0<0):
x0=x0+N1 print(x0)
for i in range(1,value):
print((x0 + i * int(N / value)) % N)
solve_linear_congruence(12,6,21)
OUTPUT: 4
11
18
4. Solving system of linear congruence-Chinese Remainder theorem (CRT)
def findMinX(num, rem, k): x = 1;
while(True):

 j = 0; while(j < k):
if (x % num[j] != rem[j]): break;
j += 1; if (j == k):
return x; x += 1;
num = [3, 5, 7];
rem = [2, 3, 2];
k = len(num);
print("x is", findMinX(num, rem, k));
OUTPUT: x is 23
Graph theory (Trees):
1. Kruskal's Algorithms for MST
class Graph:
def __init__(self, vertices):
self.V = vertices self.graph = []
def add_edge(self, u, v, w): self.graph.append([u, v, w])
def find(self, parent, i): if parent[i] == i:
return i
return self.find(parent, parent[i])
def apply_union(self, parent, rank, x, y): xroot = self.find(parent, x)
yroot = self.find(parent, y)
if rank[xroot] < rank[yroot]:
parent[xroot] = yroot
elif rank[xroot] > rank[yroot]:

 parent[yroot] = xroot else:
parent[yroot] = xroot rank[xroot] += 1
def kruskal_algo(self): result = []
i, e = 0, 0
self.graph = sorted(self.graph, key=lambda item: item[2]) parent = []
rank = []
for node in range(self.V):
parent.append(node)
rank.append(0) while e < self.V - 1:
u, v, w = self.graph[i] i= i+ 1
x = self.find(parent, u) y = self.find(parent, v) if x != y:
e = e +1
result.append([u, v, w]) self.apply_union(parent, rank, x, y)
for u, v, weight in result:
print("%d - %d: %d" % (u, v, weight))
g = Graph(4) g.add_edge(0, 1, 4) g.add_edge(0, 2, 4) g.add_edge(1, 2, 2) g.add_edge(1, 0, 4) g.add_edge(2, 0, 4) g.add_edge(2, 1, 2) g.add_edge(2, 3, 3) g.kruskal_algo()
OUTPUT: 1 - 2: 2
2 - 3: 3

 0 - 1: 4
2. Dijkstra's algorithm for the shortest path
def initial_graph() : return {
'A': {'B':1, 'C':4, 'D':2}, 'B': {'A':9, 'E':5},
'C': {'A':4, 'F':15},
'D': {'A':10, 'F':7},
'E': {'B':3, 'J':7},
'F': {'C':11, 'D':14, 'K':3, 'G':9}, 'G': {'F':12, 'I':4},
'H': {'J':13},
'I': {'G':6, 'J':7}, 'J': {'H':2, 'I':4}, 'K': {'F':6}
}
initial = 'A'
path = {}
adj_node = {}
queue = []
graph = initial_graph() for node in graph:
path[node] = float("inf") adj_node[node] = None queue.append(node)
path[initial] = 0 while queue:
key_min = queue[0]
min_val = path[key_min]
for n in range(1, len(queue)):
if path[queue[n]] < min_val: key_min = queue[n] min_val = path[key_min]
cur = key_min queue.remove(cur) print(cur)

 for i in graph[cur]:
alternate = graph[cur][i] + path[cur] if path[i] > alternate:
path[i] = alternate adj_node[i] = cur
x = 'H'
print('The path between A to H') print(x, end = '<-')
while True:
x = adj_node[x] if x is None:
print("")
break
print(x, end='<-')
OUTPUT: A
B
D
C
E
F
K
J
H
I
G
The path between A to H H<-J<-E<-B<-A<-