from django.db.models import F, ExpressionWrapper, fields

class RankTableView(APIView):
    def calculate_rank(self, priority):
        priorities = {'URGENT': 3, 'CRITICAL': 2, 'INFO': 1}
        return priorities.get(priority, 0)

    def get(self, request):
        qs = TextModel.objects.annotate(
            weighted_avg=ExpressionWrapper(
                F('avg_1') + F('avg_2'),
                output_field=fields.FloatField()
            ) / 2 * ExpressionWrapper(
                self.calculate_rank(F('report_type')),
                output_field=fields.IntegerField()
            )
        ).order_by('-weighted_avg')

        serializer = self.get_serializer(qs, many=True)

        return Response(serializer.data, status=status.HTTP_200_OK)