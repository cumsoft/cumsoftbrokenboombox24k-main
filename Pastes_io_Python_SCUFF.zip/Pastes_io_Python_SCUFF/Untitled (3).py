#!/usr/bin/env python3
# https://gist.githubusercontent.com/danielhoherd/6b87f6449c1091dce2ffc413754556bb/raw/ff1f738c64a53247f4278c5488158a043fc77689/gistfile0.txt
import multiprocessing
import subprocess
import shlex
import sys
import time
import cProfile
import pstats
import asyncio

# sample data obtained with
# curl -s https://s3.amazonaws.com/alexa-static/top-1m.csv.zip | unzip | head -n 100 top-1m.csv | awk -F ',' '{print $2}' > alexa-top-100.csv

def dig(queue: multiprocessing.Queue) -> None:
    """Perform a dig command for one host.  """
    while True:
        data = queue.get(block=True)
        if not data:
            break
        hostname = data[0]
        server = data[1]
        cmd = f"dig +short {hostname} {server}"
        dig_data = subprocess.check_output(shlex.split(cmd))

def main():
    servers = [
        "1.1.1.1",  # Cloudflare
        "1.0.0.1",  # Cloudflare
        "8.8.8.8",  # Google
        "8.8.4.4",  # Google
        "208.67.222.222",  # OpenDNS
        "208.67.220.220",  # OpenDNS
        "9.9.9.9",  # Quad9
        "149.112.112.112",  # Quad9
        "64.6.65.6",  # Verisign
        "64.6.64.6",  # Verisign
    ]


    queue = multiprocessing.Queue()
    pool = multiprocessing.Pool(16, dig,(queue,))

    start = time.perf_counter()
    with open('alexa-top-100.csv') as hostnames:
        for hostname in hostnames:
            # strip trailing newline
            hostname = hostname.split('\n')[0]
            for server in servers:
                queue.put((hostname, server))
    for worker in range(16):
        queue.put(None)
    queue.close()
    queue.join_thread()
    pool.close()
    pool.join()

    """ 
    finished: 4.01s

    real	0m4.147s
    user	0m8.252s
    sys	0m7.028s
    """
    elapsed = time.perf_counter() - start
    print(f'finished: {elapsed:.2f}s')

if __name__ == '__main__':
    main()