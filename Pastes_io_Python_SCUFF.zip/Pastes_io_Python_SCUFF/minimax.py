def evaluate_window(window: list[int]) -> int:
    player_pieces = window.count(1)
    server_pieces = window.count(-1)
    empty_pieces = window.count(0)

    # if there are 3 in a row of the player and 1 empty
    if player_pieces == 3 and empty_pieces == 1:
        return 100

    # if there are 2 in a row of the player and 2 empty
    elif player_pieces == 2 and empty_pieces == 2:
        return 10

    # if the server is close to winning    
    elif server_pieces == 3 and empty_pieces == 1:
        return -100

    elif server_pieces == 2 and empty_pieces == 2:
        return -10

    return 0

def evaluate(board: np.ndarray) -> int:
    rows, columns = board.shape
    score = 0

    center_column = columns // 2
    center_window = [i for i in list(board[:, center_column])]
    score += center_window.count(1) * 3

    # Score Horizontal
    for r in range(rows):
        row_array = [i for i in list(board[r, :])]
        score += sum(evaluate_window(row_array[c : c + 4]) for c in range(columns - 3))

    # Score Vertical
    for c in range(columns):
        col_array = [i for i in list(board[:, c])]
        score += sum(evaluate_window(col_array[r : r + 4]) for r in range(rows - 3))

    # Score positive sloped diagonal
    score += sum(evaluate_window([board[r + i][
        c + i] for i in range(4)]) for r in range(rows - 3) for c in range(columns - 3))

    # Score negative sloped diagonal
    score += sum(evaluate_window([board[r + 3 - i][c + i] for i in range(4)]) for r in range(rows - 3) for c in range(columns - 3))

    return score

def clone_env(env: ConnectFourEnv) -> ConnectFourEnv:
    """
    Creates a deep copy of the environment
    in order to simulate a move
    """
    return copy.deepcopy(env)

def step_for_reward(env: ConnectFourEnv, move: int) -> int:
    """
    Makes a move in the environment
    and returns the reward because that's the only thing we care about
    """
    _, reward, _, _ = env.step(move)
    return reward

def minimax(env: ConnectFourEnv, depth: int, alpha: int, beta: int, maximizing_player = True, reward = 0) -> int:
    moves = env.available_moves()

    # check if game is over and we have a winner
    if reward == 1 or reward == -1:
        return (None, np.inf * reward)
    
    # check if game is over and we have a draw or if there are no more moves
    if reward == 0.5 or len(moves) == 0:
        return (None, 0)
    
    # check if we have reached the maximum depth
    if depth == 0:
        return (None, evaluate(env.board))
    
    # initialize best move and value, will be overwritten later
    best_move = 0

    value = -np.inf if maximizing_player else np.inf

    for move in moves:
            # make a copy of the environment to simulate the move
            temp = clone_env(env)

            # make the move
            reward = step_for_reward(temp, move)
            temp.change_player()

            # change reward to be in the maximizing players view
            reward = -reward if not maximizing_player else reward

            # get the value of the next move
            _, next_value = minimax(temp, depth - 1, alpha, beta, not maximizing_player, reward)

            if maximizing_player:
                if next_value > value:
                    value = next_value
                    best_move = move

                alpha = max(alpha, value)

                if alpha >= beta:
                    break
            else:
                if next_value < value:
                    value = next_value
                    best_move = move

                beta = min(beta, value)
                
                if alpha >= beta:
                    break

    return best_move, value

    

def student_move(env: ConnectFourEnv):
    """
    Give it whatever input arguments you think are necessary
    (and change where it is called).
    The function should return a move from 0-6
    """

    start_time = time.time()

    move, _ = minimax(clone_env(env), MAX_DEPTH, -np.inf, np.inf)

    print("--- %s seconds ---" % (time.time() - start_time))
	
    return move