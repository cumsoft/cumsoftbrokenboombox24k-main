import pyttsx3
import PyPDF2
from pydub import AudioSegment
import re
import os

# Ensure ffmpeg and lame are installed for handling audio formats

# Function to clean and prepare text for TTS
def clean_text(text):
    text = re.sub(r'\s+', ' ', text)  # Replace multiple spaces with a single space
    return text.strip()

# Function to dynamically chunk text based on content
def dynamic_chunk_text(text, delimiter='. ', max_chunk_length=1000):
    sentences = text.split(delimiter)
    chunks = []
    current_chunk = ''

    for sentence in sentences:
        if len(current_chunk) + len(sentence) < max_chunk_length:
            current_chunk += sentence + delimiter
        else:
            chunks.append(current_chunk)
            current_chunk = sentence + delimiter
    if current_chunk:  # Add any remaining text as a chunk
        chunks.append(current_chunk)
    return chunks

# Function to handle audio file export
def export_audio(combined_audio, filename, format='wav'):
    if format.lower() == 'mp3':
        combined_audio.export(filename, format="mp3", bitrate="192k")
    else:  # Default to WAV if not MP3
        combined_audio.export(filename, format="wav")

# Choose the output audio format here (wav or mp3)
audio_format = 'mp3'  # Change to 'wav' if WAV format is preferred

# Initialize pyttsx3 speaker
speaker = pyttsx3.init()

try:
    # Open the PDF and prepare for reading
    with open('Brief answers.pdf', 'rb') as pdf_file:
        pdfreader = PyPDF2.PdfReader(pdf_file)
        full_text = ''

        # Extract and clean text from each page of the PDF
        for page_num in range(len(pdfreader.pages)):
            text = pdfreader.pages[page_num].extract_text()
            full_text += clean_text(text) + ' '

    # Dynamically chunk the cleaned text for better audio segmentation
    chunks = dynamic_chunk_text(full_text)
    combined_audio = AudioSegment.empty()

    # Generate audio for each chunk and combine them
    for i, chunk in enumerate(chunks):
        audio_filename = f'temp_part_{i+1}.{audio_format}'
        speaker.save_to_file(chunk, audio_filename)
        speaker.runAndWait()
        # Load the temporary audio file, add it to the combined audio, and then delete the file
        combined_audio += AudioSegment.from_file(audio_filename, format=audio_format)
        os.remove(audio_filename)  # Clean up temporary files

    # Export the combined audio to a single file in the selected format
    final_audio_filename = f"final_story.{audio_format}"
    export_audio(combined_audio, final_audio_filename, format=audio_format)
    print(f"Generated audio file: {final_audio_filename}")

except (PyPDF2.errors.PdfReadError, IOError) as e:
    print(f"Error reading PDF file: {e}")
except Exception as e:
    print(f"An error occurred: {e}")