import torch
from torch import autocast
from diffusers import StableDiffusionPipeline, LMSDiscreteScheduler
from datetime import datetime
import hashlib
import secrets
from transformers import CLIPTextModel, CLIPTokenizer
from diffusers import AutoencoderKL, UNet2DConditionModel, PNDMScheduler
from diffusers import LMSDiscreteScheduler

from PIL import Image
from tqdm.auto import tqdm

from pprint import pprint


#https://huggingface.co/blog/stable_diffusion

def latents_to_image(latents):
    # scale and decode the image latents with vae
    latents = 1 / 0.18215 * latents

    #pprint(vae.decode(latents))

    image = vae.decode(latents)
    image = image[0]
    #And finally, let's convert the image to PIL so we can display or save it.
    image = (image / 2 + 0.5).clamp(0, 1)
    image = image.detach().cpu().permute(0, 2, 3, 1).numpy()


    def numpy_to_pil(images):
        """
        Convert a numpy image or a batch of images to a PIL image.
        """
        if images.ndim == 3:
            images = images[None, ...]
        images = (images * 255).round().astype("uint8")
        pil_images = [Image.fromarray(image) for image in images]

        return pil_images

    images = numpy_to_pil(image)
    #images[0].save("test.png")
    return images[0]




# 1. Load the autoencoder model which will be used to decode the latents into image space. 
vae = AutoencoderKL.from_pretrained("CompVis/stable-diffusion-v1-4", subfolder="vae", use_auth_token=True)

# 2. Load the tokenizer and text encoder to tokenize and encode the text. 
tokenizer = CLIPTokenizer.from_pretrained("openai/clip-vit-large-patch14")
text_encoder = CLIPTextModel.from_pretrained("openai/clip-vit-large-patch14")

# 3. The UNet model for generating the latents.
unet = UNet2DConditionModel.from_pretrained("CompVis/stable-diffusion-v1-4", subfolder="unet", use_auth_token=True)



scheduler = LMSDiscreteScheduler(beta_start=0.00085, beta_end=0.012, beta_schedule="scaled_linear")


torch_device = "cuda"
vae.to(torch_device)
text_encoder.to(torch_device)
unet.to(torch_device) 


prompt = ["tentacles of the mind encapsulating consciousness, a digital painting, fine details, intricate details"]

height = 448                        # default height of Stable Diffusion
width = 448                        # default width of Stable Diffusion

num_inference_steps = 168           # Number of denoising steps

guidance_scale = 13.8               # Scale for classifier-free guidance

generator = torch.manual_seed(42*42*42)    # Seed generator to create the inital latent noise

batch_size = len(prompt)
text_input = tokenizer(prompt, padding="max_length", max_length=tokenizer.model_max_length, truncation=True, return_tensors="pt")
text_embeddings = text_encoder(text_input.input_ids.to(torch_device))[0]


max_length = text_input.input_ids.shape[-1]

uncond_input = tokenizer(
    [""] * batch_size, padding="max_length", max_length=max_length, return_tensors="pt"
)
uncond_embeddings = text_encoder(uncond_input.input_ids.to(torch_device))[0] 
text_embeddings = torch.cat([uncond_embeddings, text_embeddings])


latents_shape = (batch_size, unet.in_channels, height // 8, width // 8)
latents = torch.randn(
                latents_shape,
                generator=generator,
            )

latents = latents.to(torch_device)
scheduler.set_timesteps(num_inference_steps)
latents = latents * scheduler.sigmas[0]
scheduler.set_timesteps(num_inference_steps)

run_hash = hashlib.md5(str(datetime.utcnow()).encode('utf-8')).hexdigest()


with autocast("cuda"):
    for i, t in tqdm(enumerate(scheduler.timesteps)):
        # expand the latents if we are doing classifier-free guidance to avoid doing two forward passes.
        latent_model_input = torch.cat([latents] * 2)
        sigma = scheduler.sigmas[i]
        latent_model_input = latent_model_input / ((sigma**2 + 1) ** 0.5)

        # predict the noise residual
        with torch.no_grad():
            noise_pred = unet(latent_model_input, t, encoder_hidden_states=text_embeddings)['sample']

        # perform guidance
        noise_pred_uncond, noise_pred_text = noise_pred.chunk(2)
        noise_pred = noise_pred_uncond + guidance_scale * (noise_pred_text - noise_pred_uncond)

        # compute the previous noisy sample x_t -> x_t-1
        latents = scheduler.step(noise_pred, i, latents)['prev_sample']

        this_iteration = latents_to_image(latents)
        this_iteration.save("%s_%s.png"%(run_hash,str(i).zfill(4)))