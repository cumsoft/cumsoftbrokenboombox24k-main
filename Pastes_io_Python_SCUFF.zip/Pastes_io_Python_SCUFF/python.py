from tqdm import tqdm
def show_pred(df, i, win_size=(512,512), step=256, first_plot= True, inter_plot = False, final_plot = True, write=False, res_dir=None):
    s = df.loc[i]
    win_height, win_width = win_size

    geom = s['geometry']
    if geom.geom_type == 'Polygon':
        exteriors = [geom.exterior.xy]
    elif geom.geom_type == 'MultiPolygon':
        exteriors = [g.exterior.xy for g in geom.geoms]

    with rasterio.open(s['path']) as src:
        profile = src.profile
        profile['count'] = 1
        
        if first_plot:
            fig, ax = plt.subplots(figsize=(12, 8))
            rasterio.plot.show(src, ax=ax)
            
            for xs, ys in exteriors:
                ax.fill(xs, ys, alpha=0.5, fc='r', ec='none')

            plt.show()

        height, width = src.height, src.width

        window = Window(0, 0, width, height)
        img = src.read(window=window)

        wh_mask = np.zeros((height, width))

        print('width: {}, height: {}, width/step: {}, height/step: {}'.format(width, height, width/step, height/step))
        print(s['path'])
        
        if first_plot:
            fig, ax0 = plt.subplots(figsize=(12,8))
            rasterio.plot.show(src, ax=ax0)

        for px in range(0, height-win_height+1, step):
            for py in range(0, width-win_width+1, step):
                import time
                time.sleep(0.1)
                window = Window(py, px, win_width, win_height)

                b = rasterio.windows.bounds(window, src.transform)
                bbox = box(*b)
                bounds = bbox.bounds

                y1, x1 = src.index(bounds[0], bounds[1])
                y2, x2 = src.index(bounds[2], bounds[3])

                x0 = min(x1,x2)
                y0 = min(y1,y2)

                patch = src.read(window=window)
                # le modèle prend des images de taille [H,W,C]
                patch = np.transpose(patch, (1,2,0))

                with learn.no_bar(), learn.no_logging():
                    mask = learn.predict(patch)[0]

                wh_mask = update_mask(wh_mask, mask, px, py)
        
        window = Window(0, 0, width, height)
        img = src.read(window=window)
        print(img.shape, wh_mask.shape)

        if final_plot:
            rasterio.plot.show(img, ax=ax0)
            ax0.imshow(wh_mask, alpha=0.4)        
            plt.show()
    
    #pour écrire la prédiction
    if write:
        id_dep, id_zone = s['id'].split('-')
        if res_dir is None:
            res_dir = '/mnt/stores/store-DAI/equipiers/mvaccaro/photovoltaique/results/model'

        name = os.path.basename(s['path']).split('RVB')[0]+'MASK.tif'
        dir_to_write = Path(res_dir) / id_dep / id_zone
        file_to_write = Path(res_dir) / id_dep / id_zone / name
        
        if not os.path.exists(dir_to_write):
            os.makedirs(dir_to_write)

        with rasterio.open(file_to_write, 'w', **profile) as dst:
            pred = wh_mask[np.newaxis, :, :]
            dst.write(pred)