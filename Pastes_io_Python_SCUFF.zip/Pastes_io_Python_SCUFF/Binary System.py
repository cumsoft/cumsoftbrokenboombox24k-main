def bin_sum(a: str, b: str) -> str:
    res = []
 
    i = len(a) - 1
    j = len(b) - 1
    overflow = 0
    while i >= 0 and j >= 0:
        res.append(int(a[i]) ^ int(b[j]) ^ overflow)
        if a[i] == '1' and b[j] == '1':
            overflow = 1
        elif (a[i] == '1' or b[j] == '1') and overflow:
            overflow = 1
        else:
            overflow = 0
        i -= 1
        j -= 1
    
    while i >= 0:
        res.append(int(a[i]) ^ overflow)
        overflow = 1 if a[i] == '1' and overflow else 0
        if not overflow:
            return a[:i] + ''.join(map(str, reversed(res)))
        i -= 1
 
    while j >= 0:
        res.append(int(b[j]) ^ overflow)
        overflow = 1 if b[j] == '1' and overflow else 0
        if not overflow:
            return b[:j] + ''.join(map(str, reversed(res)))
        j -= 1
    
    if overflow:
        res.append(1)
 
    return ''.join(map(str, reversed(res)))
 
if __name__ == '__main__':
    t1 = input()
    t2 = input()
    print(bin_sum(t1, t2))