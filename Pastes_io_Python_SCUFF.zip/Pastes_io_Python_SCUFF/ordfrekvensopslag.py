#!/usr/bin/python3.11

import json
import os 
from pprint import pprint
import random
from xmlrpc.client import boolean
from dataclasses import dataclass
import requests
import time
import sys
import csv
import re




"""
    - hvis der for et lemma findes mindst én form, der optræder mindre end 5 gange i hyppighedslisten, slå det op i søgemaskinerne
    - hvis summen af forekomsterne i hyppighedslisten for alle formerne af et lemma er < 50, slå det op i søgemaskinerne
"""

@dataclass
class CorForm:
    form: str
    form_id: str
    form_count: int = 0


@dataclass
class CorLemma:
    lemma: str
    lemma_id: str
    forms: list[CorForm]


def get_lemma_id(cor_id: str) -> str:
    return ".".join(cor_id.split(".")[:2])


def get_form_id(cor_id: str) -> str:
    return ".".join(cor_id.split(".")[2:4])



def read_from_cor_csv(filename: str) -> list[CorLemma]:
    if not os.path.exists(filename):
        print("file not found: " + filename)
        sys.exit(1)
    
    cor_list = []

    with open(filename, "r", encoding="utf-8") as infile:
        tsv_reader = csv.DictReader(infile, delimiter="\t", fieldnames=["corid", "lemma", "glosse", "grf", "fuldform", "normeret"])
        for data in tsv_reader:
            cor_list.append(data)

    lemmas = dict()
    for l in cor_list:

        form = CorForm(l["fuldform"], get_form_id(l["corid"]))
        lemma_id = get_lemma_id(l["corid"])
        
        if lemma_id not in lemmas.keys():
            lemma = CorLemma(l["lemma"], lemma_id, [form])
            lemmas[lemma_id] = lemma
        else:
            lemma = lemmas[lemma_id]
            lemma.forms.append(form)
        
        
    return lemmas.values()

"""
    # augment cor_list with lemma-ids for n^2 -> n lemma_id calculations later
    for e in cor_list:
        e["lemma_id"] = get_lemma_id(e["corid"])

    unique_lemma_ids = {e["lemma_id"] for e in cor_list}

    data_lemmas = []
    lemma_count = 0
    for current_id in unique_lemma_ids:
        current_csv_forms = [e for e in cor_list if e["lemma_id"] == current_id]

        data_forms = []
        for c in current_csv_forms:
            data_forms.append(CorForm(c["fuldform"], get_form_id(c["corid"])))
        
        data_lemmas.append(CorLemma(current_csv_forms[0]["lemma"], current_id, data_forms))

        if lemma_count % 1000 == 0:
            print(lemma_count)
        lemma_count += 1

    return data_lemmas    
"""



if __name__ == "__main__":
    if not len(sys.argv) == 3:
        print("callme: " + sys.argv[0] + " <" + sys.argv[1] + "> <" + sys.argv[2] + ">")
        sys.exit(1)

    freqs = dict()
    with open(sys.argv[2], "r", encoding="utf-8") as infile:
        for l in infile.readlines():
            l_split = l.split("\t")
            freqs[l_split[0]] = 0 if l_split[1].strip() == "" else int(l_split[1].strip())

    lemmas = read_from_cor_csv(sys.argv[1])

    for l in lemmas:
        for f in l.forms:
            if f.form in freqs.keys():
                f.form_count = freqs[f.form]

    # condition 1: lemmas with at least one form with <5 hits in korp:
    lemma_ids_condition_1 = set()
    for l in lemmas:
        for f in l.forms:
            if f.form_count < 5:
                lemma_ids_condition_1.add(l.lemma_id)

    # condition 2: lemmas with sum(hits in korp for all forms) <50:
    lemma_ids_condition_2 = set()
    for l in lemmas:
        sum = 0
        for f in l.forms:
            sum += f.form_count
        
        if sum < 50:
            lemma_ids_condition_2.add(l.lemma_id)


    # totals:
    total_lemma_ids = lemma_ids_condition_1.union(lemma_ids_condition_2)
    total_lemma_list = [l for l in lemmas if l.lemma_id in total_lemma_ids]
    
    total_forms_list = []
    for l in lemmas:
        for f in l.forms:
            total_forms_list.append(f)

    seen_forms = []
    uniq_form_count = 0
    for f in total_forms_list:
        if f.form in seen_forms:
            continue;
        else:
            seen_forms.append(f.form)
            uniq_form_count += 1

    print("total number of needed lookups: " + str(uniq_form_counts))
    
"""
    total_num_lemmas = 
    total_num_forms = 
    cond1_num_lemmas = 

    cond2_num_lemmas =

    co
"""