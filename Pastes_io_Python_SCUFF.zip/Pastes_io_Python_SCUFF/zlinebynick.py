__module_name__ = "Zline by nick"
__module_version__ = "1.0"
__module_description__ = "Just a tool to zline an user by its nickname"
import hexchat, re, random

def getWhois(word, word_eol, userdata):
  rawMessage = word[1]
  toKillFile = "C:\\Users\\Camila\\AppData\\Roaming\\HexChat\\toKill"
  numberList = ["Voa lá no alto aviãaaaaoo...", "Lerê lerê, lereeeeeeeeeeeeeeeeeeeeeeee lereeeeeeeeeeeeeeeeeeeeeeee lio!", "Mission accomplished", "Oi, quer tc? Blz depois a gente se fala então!", "Forte abraço!"]

  try:
    exemptIP = ["127.0.0.1", "158.69.112.150", "54.94.138.125", "54.94.186.191", "3.99.95.11"]
    reIPv4 = re.compile(r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}')
    getIPv4 = reIPv4.search(rawMessage)
    userIPv4 = getIPv4[0]
    if not userIPv4 or userIPv4 in exemptIP:
      setToKill = open(toKillFile, "w")
      setToKill.write("0")
      setToKill.close()
      pass
    else:
      setToKill = open(toKillFile, "r")
      getKillStatus = setToKill.read()
      setToKill.close()
      if str(getKillStatus) == "1":
        hexchat.command("ZLINE *@" + getIPv4[0] + " 16h " + random.choice(numberList))
        setToKill = open(toKillFile, "w")
        setToKill.write("0")
        setToKill.close()
      else:
        pass
  except:
    pass
  try:
    exemptIPv6 = ["::1", "fe80::", "2a03:5180:f:2:", "2a03:5180:f:1:", "2001:67c:2f08:", "2600:1f1e:2c9:a500:", "2600:1f1e:f8d:c0a1:"]
    reIPv6 = re.compile(r'([a-z0-9]{4}:){1}([a-zA-Z0-9]{1,4}:?){3}')
    getIPv6 = reIPv6.search(rawMessage)
    userIPv6 = getIPv6[0]
    if not userIPv6 or userIPv6 in exemptIPv6:
      setToKill = open(toKillFile, "w")
      setToKill.write("0")
      setToKill.close()
      pass
    else:
      setToKill = open(toKillFile, "r")
      getKillStatus = setToKill.read()
      setToKill.close()
      if str(getKillStatus) == "1":
        hexchat.command("ZLINE *@" + getIPv6[0] + ":/64 16h " + random.choice(numberList))
        setToKill = open(toKillFile, "w")
        setToKill.write("0")
        setToKill.close()
      else:
        pass
  except:
    pass
  return hexchat.EAT_NONE

def getUser(word, word_eol, userdata):
  toKillFile = "C:\\Users\\Camila\\AppData\\Roaming\\HexChat\\toKill"
  setToKill = open(toKillFile, "w")
  setToKill.write("1")
  setToKill.close()
  hexchat.command("WHOIS " + word_eol[1])
  return hexchat.EAT_ALL

def dropKill(word, word_eol, userdata):
  toKillFile = "C:\\Users\\Camila\\AppData\\Roaming\\HexChat\\toKill"
  rawMessage = word[0]
  notFound = " :No such nick"
  if notFound in rawMessage:
    setToKill = open(toKillFile, "w")
    setToKill.write("0")
    setToKill.close()
  return hexchat.EAT_ALL

hexchat.hook_command("suck", getUser)
hexchat.hook_print("Server Text", dropKill)
hexchat.hook_print("WhoIs Special", getWhois)