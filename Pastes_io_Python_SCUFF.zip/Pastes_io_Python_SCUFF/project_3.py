import requests 
import time
import pandas

#nickname = "de03020701"
nickname = "gsontest@ya.ru"
cohort = "23"
url = "https://d5dg1j9kt695d30blp03.apigw.yandexcloud.net/"

generate_report_response = requests.post(
    f"{url}generate_report/",
    headers={
    "X-API-KEY": "5f55e6c0-e9e5-4a9c-b313-63c01fc31460",
    "X-Nickname": nickname,
    "X-Cohort": cohort
    }
).json()

task_id = generate_report_response["task_id"]

print('start loading')
time.sleep(120)
print(f'finish loading, task_id={task_id}')

get_report_response = requests.get (
    f"{url}get_report?task_id={task_id}",
    headers={
    "X-API-KEY": "5f55e6c0-e9e5-4a9c-b313-63c01fc31460",
    "X-Nickname": nickname,
    "X-Cohort": cohort
    }
).json()

report_id = get_report_response["data"]["report_id"]
file_names = ("customer_research.csv","user_order_log.csv","user_activity_log.csv","price_log.csv")
file_path = "/lessons/files/"
for i in file_names:
    url = f"https://storage.yandexcloud.net/s3-sprint3/cohort_{cohort}/{nickname}/project/{report_id}/{i}"
    data_from_file = pandas.read_csv(url)
    data_from_file.to_csv(file_path+i)