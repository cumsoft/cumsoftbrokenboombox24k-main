from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import logging

app = FastAPI()


# Define Pydantic models for request validation
class QueryResult(BaseModel):
    intent: dict
    parameters: dict


class Payload(BaseModel):
    queryResult: QueryResult


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

context_prod = None
context_color = None
context_size = None
context_quantity = None
context_phone = None
context_contact = None

async def handle_order_track(intent_name, parameters):
    try:
        order_id = parameters.get('number')
        logger.info(f"Received Intent: {intent_name}")
        logger.info(f"Received Parameters: {parameters}")
        logger.info(f"Order ID: {order_id}")

        if not order_id:
            raise ValueError("Order ID not provided")

        # Dummy status for the order
        dummy_status = "Processing"

        # Dummy product information
        products = [
            {"name": "Product1", "quantity": 3},
            {"name": "Product2", "quantity": 2},
            # Add more products if needed
        ]

        # Construct the fulfillment message with product information
        elements = [
            {
                "title": f"{int(order_id)} : {dummy_status}",
                "subtitle": f"Order ID: {order_id}",
            }
        ]

        for product in products:
            elements.append({
                "title": f"{product['name']} - Quantity: {product['quantity']}",
                "subtitle": "Product description goes here.",
            })

        fulfillment_message = {
            "fulfillmentMessages": [
                {
                    "payload": {
                        "facebook": {
                            "attachment": {
                                "type": "template",
                                "payload": {
                                    "template_type": "generic",
                                    "elements": elements
                                }
                            }
                        }
                    },
                    "platform": "FACEBOOK"
                }
            ]
        }

        # Log the response
        logger.info(f"Generated Response: {fulfillment_message}")

        # Return fulfillment message
        return JSONResponse(content=fulfillment_message)

    except (ValueError, TypeError) as e:
        # Handle specific data parsing errors
        logger.error(f"Error in handle_order_track: {str(e)}", exc_info=True)
        raise HTTPException(status_code=400, detail=f"Invalid data in payload: {str(e)}")

    except Exception as e:
        # Log the unexpected exception
        logger.error(f"Unexpected error in handle_order_track: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail="Internal Server Error")


async def handle_retrieve_prod_info(intent_name, parameters):
    global context_prod
    try:
        prod_id = parameters.get('prod')
        logger.info(f"Received Intent: {intent_name}")
        logger.info(f"Received Parameters: {parameters}")
        logger.info(f"Product ID: {prod_id}")

        if not prod_id:
            raise ValueError("Product ID not provided")

        context_prod = prod_id
        # Dummy data for illustration
        product_info = {
            "name": "Sample Product",
            "type": "Electronics",
            "stock": 10,
            "price": 99.99,
            "sizes": ["S", "M", "L"],
            "colors": ["Red", "Blue", "Green"]
        }

        # Construct the fulfillment message with product attributes
        fulfillment_message = {
            "fulfillmentMessages": [
                {
                    "payload": {
                        "facebook": {
                            "attachment": {
                                "type": "template",
                                "payload": {
                                    "template_type": "generic",
                                    "elements": [
                                        {
                                            "title": f"{product_info['name']} - {product_info['type']}",
                                            "subtitle": f"Stock: {product_info['stock']}, Price: {product_info['price']}",
                                        }
                                    ]
                                }
                            }
                        }
                    },
                    "platform": "FACEBOOK"
                },
                {
                    "quickReplies": {
                        "title": "Would you like to order this product?",
                        "quickReplies": ["Yes", "No"]
                    },
                    "platform": "FACEBOOK"
                }
            ],
            "outputContexts": [
                {
                    "name": "projects/newagent-cvrj/locations/global/agent/sessions/your-session-id/contexts/order_confirmation",
                    "lifespanCount": 2,
                    "parameters": {
                        "prod_id": prod_id
                    }
                }
            ]
        }

        # Log the response
        logger.info(f"Generated Response: {fulfillment_message}")

        # Return fulfillment message
        return JSONResponse(content=fulfillment_message)

    except (ValueError, TypeError) as e:
        # Handle specific data parsing errors
        logger.error(f"Error in handle_retrieve_prod_info: {str(e)}", exc_info=True)
        raise HTTPException(status_code=400, detail=f"Invalid data in payload: {str(e)}")

    except Exception as e:
        # Log the unexpected exception
        logger.error(f"Unexpected error in handle_retrieve_prod_info: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail="Internal Server Error")


async def handle_order_query_retrieve_prod_info_yes(intent_name, parameters):
    global context_prod
    logger.info(context_prod)

    fulfillment_message = {
        "fulfillmentMessages": [
            {
                "text": {
                    "text": [
                        "Please mention your prefered quantity, size and color"
                    ]
                }
            }
        ]
    }

    logger.info(fulfillment_message)

    return JSONResponse(content=fulfillment_message)


async def add_items(intent_name, parameters):
    global context_prod
    global context_size
    global context_color
    global context_quantity
    global context_phone
    global context_contact

    try:
        # Extract relevant information from the parameters
        context_quantity = parameters.get('number')
        context_color = parameters.get('color')
        context_size = parameters.get('size')

        import random
        order_id = f"ORDER_{random.randint(1000, 9999)}"

        fulfillment_message = {
            "fulfillmentMessages": [
                {
                    "text": {
                        "text": [
                            "Anything else or should i conform this?"
                        ]
                    }
                }
            ]
        }
        logger.info(fulfillment_message)
        return JSONResponse(content=fulfillment_message)

    except ValueError as e:
        # Handle specific errors
        logger.error(f"Error handling retrieve_cust_info: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))

    except Exception as e:
        # Log unexpected errors
        logger.error(f"Unexpected error handling retrieve_cust_info: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail="Internal Server Error")


async def handle_retrieve_cust_info(intent_name, parameters):
    try:
        # Extract relevant information from the parameters
        phone_number = parameters.get('phone-number')
        logger.info(f"Customer Phone Number: {phone_number}")

        import random
        order_id = f"ORDER_{random.randint(1000, 9999)}"

        fulfillment_message = {
            "fulfillmentMessages": [
                {
                    "text": {
                        "text": [
                            f"Your order has been conformed {order_id}. Please keep this safe."
                        ]
                    }
                }
            ]
        }
        logger.info(fulfillment_message)
        return JSONResponse(content=fulfillment_message)

    except ValueError as e:
        # Handle specific errors
        logger.error(f"Error handling retrieve_cust_info: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))

    except Exception as e:
        # Log unexpected errors
        logger.error(f"Unexpected error handling retrieve_cust_info: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail="Internal Server Error")


@app.post("/")
async def handle_request(request: Request, payload: Payload):
    try:
        # Extract the necessary information from the payload
        intent_name = payload.queryResult.intent.get("displayName")
        parameters = payload.queryResult.parameters

        # Logging
        logger.info(f"Received Intent: {intent_name}")
        logger.info(f"Received Parameters: {parameters}")

        # Handle specific intent
        if intent_name == "order.track - order_id":
            return await handle_order_track(intent_name, parameters)
        elif intent_name == "product.retrive_info":
            return await handle_retrieve_prod_info(intent_name, parameters)
        elif intent_name == "order.conformation":
            return await handle_order_query_retrieve_prod_info_yes(intent_name, parameters)
        elif intent_name == "order.retrive_cust_info":
            logger.info(payload)
            return await handle_retrieve_cust_info(intent_name, parameters)
        elif intent_name == "order.add_item":
            logger.info(payload)
            return await add_items(intent_name, parameters)


        else:
            return JSONResponse(content={"fulfillmentText": "Unhandled intent"})

    except KeyError as e:
        # Handle missing keys in the payload
        raise HTTPException(status_code=400, detail=f"Missing key in payload: {str(e)}")

    except (ValueError, TypeError) as e:
        # Handle specific data parsing errors
        raise HTTPException(status_code=400, detail=f"Invalid data in payload: {str(e)}")

    except Exception as e:
        # Log the unexpected exception
        logger.error(f"Unexpected error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail="Internal Server Error")