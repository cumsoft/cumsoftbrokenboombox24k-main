# namespace
import pygame
from pygame.locals import *
import sys
import random
import time
from tkinter import filedialog
from tkinter import *
 
pygame.init()  # Begin pygame
 
# Declaring variables to be used through the program
vec = pygame.math.Vector2
HEIGHT = 350
WIDTH = 700
ACC = 0.3
FRIC = -0.10
FPS = 60
FPS_CLOCK = pygame.time.Clock()
COUNT = 0
 
# Create the display surface
displaysurface = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Awesome RPG")
 
# light shade of the button
color_light = (170, 170, 170)
color_dark = (100, 100, 100)
color_white = (255, 255, 255)
 
# defining a font
headingfont = pygame.font.SysFont("Verdana", 40)
regularfont = pygame.font.SysFont('Corbel', 25)
smallerfont = pygame.font.SysFont('Corbel', 16)
text = regularfont.render('LOAD', True, color_light)
# Sets character movements animation
run_ani_R = [pygame.image.load("RPG Assets-20221007T151405Z-001/RPG Assets/Movement_Animations/Player_Sprite_R.png"), pygame.image.load("RPG Assets-20221007T151405Z-001/RPG Assets/Movement_Animations/Player_Sprite2_R.png"),
             pygame.image.load("RPG Assets-20221007T151405Z-001/RPG Assets/Movement_Animations/Player_Sprite3_R.png"), pygame.image.load("RPG Assets-20221007T151405Z-001/RPG Assets/Movement_Animations/Player_Sprite4_R.png"),
             pygame.image.load("RPG Assets-20221007T151405Z-001/RPG Assets/Movement_Animations/Player_Sprite5_R.png"), pygame.image.load("RPG Assets-20221007T151405Z-001/RPG Assets/Movement_Animations/Player_Sprite6_R.png"),
             pygame.image.load("RPG Assets-20221007T151405Z-001/RPG Assets/Movement_Animations/Player_Sprite_R.png")]
run_ani_L = [pygame.image.load("RPG Assets-20221007T151405Z-001/RPG Assets/Movement_Animations/Player_Sprite_L.png"), pygame.image.load("RPG Assets-20221007T151405Z-001/RPG Assets/Movement_Animations/Player_Sprite2_L.png"),
             pygame.image.load("RPG Assets-20221007T151405Z-001/RPG Assets/Movement_Animations/Player_Sprite3_L.png"), pygame.image.load("RPG Assets-20221007T151405Z-001/RPG Assets/Movement_Animations/Player_Sprite4_L.png"),
             pygame.image.load("RPG Assets-20221007T151405Z-001/RPG Assets/Movement_Animations/Player_Sprite5_L.png"), pygame.image.load("RPG Assets-20221007T151405Z-001/RPG Assets/Movement_Animations/Player_Sprite6_L.png"),
             pygame.image.load("RPG Assets-20221007T151405Z-001/RPG Assets/Movement_Animations/Player_Sprite_L.png")]
att_ani_L = [ pygame.image.load("RPG Assets-20221007T151405Z-001/RPG Assets/Attack_Animations/Player_Attack_L.png"), pygame.image.load("RPG Assets-20221007T151405Z-001/RPG Assets/Attack_Animations/Player_Attack2_L.png"),
             pygame.image.load("RPG Assets-20221007T151405Z-001/RPG Assets/Attack_Animations/Player_Attack2_L.png"), pygame.image.load("RPG Assets-20221007T151405Z-001/RPG Assets/Attack_Animations/Player_Attack3_L.png"),
             pygame.image.load("RPG Assets-20221007T151405Z-001/RPG Assets/Attack_Animations/Player_Attack3_L.png"), pygame.image.load("RPG Assets-20221007T151405Z-001/RPG Assets/Attack_Animations/Player_Attack4_L.png"),
             pygame.image.load("RPG Assets-20221007T151405Z-001/RPG Assets/Attack_Animations/Player_Attack4_L.png"), pygame.image.load("RPG Assets-20221007T151405Z-001/RPG Assets/Attack_Animations/Player_Attack5_L.png"),
             pygame.image.load("RPG Assets-20221007T151405Z-001/RPG Assets/Attack_Animations/Player_Attack5_L.png"), pygame.image.load("RPG Assets-20221007T151405Z-001/RPG Assets/Attack_Animations/Player_Attack_L.png"),
             pygame.image.load("RPG Assets-20221007T151405Z-001/RPG Assets/Movement_Animations/Player_Sprite_L.png")]
att_ani_R = [pygame.image.load("RPG Assets-20221007T151405Z-001/RPG Assets/Attack_Animations/Player_Attack_R.png"), pygame.image.load("RPG Assets-20221007T151405Z-001/RPG Assets/Attack_Animations/Player_Attack2_R.png"),
             pygame.image.load("RPG Assets-20221007T151405Z-001/RPG Assets/Attack_Animations/Player_Attack2_R.png"), pygame.image.load("RPG Assets-20221007T151405Z-001/RPG Assets/Attack_Animations/Player_Attack3_R.png"),
             pygame.image.load("RPG Assets-20221007T151405Z-001/RPG Assets/Attack_Animations/Player_Attack3_R.png"), pygame.image.load("RPG Assets-20221007T151405Z-001/RPG Assets/Attack_Animations/Player_Attack4_R.png"),
             pygame.image.load("RPG Assets-20221007T151405Z-001/RPG Assets/Attack_Animations/Player_Attack4_R.png"), pygame.image.load("RPG Assets-20221007T151405Z-001/RPG Assets/Attack_Animations/Player_Attack5_R.png"),
             pygame.image.load("RPG Assets-20221007T151405Z-001/RPG Assets/Attack_Animations/Player_Attack5_R.png"), pygame.image.load("RPG Assets-20221007T151405Z-001/RPG Assets/Attack_Animations/Player_Attack_R.png"),
             pygame.image.load("RPG Assets-20221007T151405Z-001/RPG Assets/Movement_Animations/Player_Sprite_R.png")]
 
class Background(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.bgimage = pygame.image.load("RPG Assets-20221007T151405Z-001/RPG Assets/World Building Assets/Background.png")
        self.rectBGimg = self.bgimage.get_rect()
        self.bgY = 0
        self.bgX = 0
 
    def render(self):
        displaysurface.blit(self.bgimage, (self.bgX, self.bgY))
 
 
class Ground(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.image.load("RPG Assets-20221007T151405Z-001/RPG Assets/World Building Assets/ground.png")
        self.rect = self.image.get_rect(center=(350, 350))
 
    def render(self):
        displaysurface.blit(self.image, (self.rect.x, self.rect.y))
 
 
class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.image.load("RPG Assets-20221007T151405Z-001/RPG Assets/World Building Assets/Player_Sprite_R.png")
# position of player to current target
        self.rect = self.image.get_rect()
        self.vx = 0
        self.pos = vec((340, 240))
        self.vel = vec(0,0)
        self.acc = vec (0,0)
        self.direction = "RIGHT"
# movement of player
        self.jumping = False
        self.running = False
        self.move_frame = 0
# combat of player
        self.attacking = False
        self.attack_frame = 0
# set attack animations in a loop
        self.attack_frame = True
 
 
    def move(self):
        self.acc = vec(0,0.5)
 
        if abs(self.vel.x) > 0.3:
            self.running = True
        else:
            self.running = False
 
# movement directions for player
        pressed_keys = pygame.key.get_pressed()
 
        if pressed_keys[K_a]:
            self.acc.x = -ACC
        if pressed_keys[K_d]:
            self.acc.x = ACC
 
# sets physics and velocity for movements
        self.acc.x += self.vel.x * FRIC
        self.vel += self.acc
        self.pos += self.vel + 0.5 * self.acc
 
# warps the player from one point to another
        if self.pos.x > WIDTH:
            self.pos.x = 0
 
        if self.pos.x < 0:
            self.pos.x = WIDTH
 
        self.rect.midbottom = self.pos
# gravity (physics checks)
    def gravity_check(self):
 
        hits = pygame.sprite.spritecollide(player, ground_group, False)
        if self.vel.y > 0:
            if hits:
                lowest = hits[0]
                if self.pos.y < lowest.rect.bottom:
                    self.pos.y = lowest.rect.top +1
                    self.vel.y = 0
                    self.jumping = False
 
# defines character updates to movements, jumps, attacks etc.
    def update(self):
        if self.move_frame > 6:
           self.move_frame = 0
           return
        if self.jumping == False and self.running == True:
            if self.vel.x > 0:
                self.image = run_ani_R[self.move_frame]
                self.direction = "RIGHT"
            else:
                self.image = run_ani_L[self.move_frame]
                self.direction = "LEFT"
            self.move_frame += 1
# defines character attacks
    def attack(self):
 # Player Attack Loops
        if player.attack_frame:
 
            if self.attack_frame > 5:
                self.attack_frame = 0
                self.attacking = False
 
            if self.direction == "LEFT":
                self.image = att_ani_L[self.attack_frame]
            elif self.direction == "RIGHT":
                self.image = att_ani_R[self.attack_frame]
# update the current attack
            self.attack_frame += 1
            player.attack_frame = False
        else:
            player.attack_frame = True
 
# defines character jump
    def jump(self):
        self.rect.x += 1
 
# checks if player is touching the ground
        hits = pygame.sprite.spritecollide(self, ground_group, False)
        self.rect.x -= 1
 
# if touching the ground, and not currently jumping, causes the player to jump
        if hits and not self.jumping:
            self.jumping = True
            self.vel.y = -12
 
 
class Enemy(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
 
player = Player()
background = Background()
ground = Ground()
 
# Ground collision detections
ground_group = pygame.sprite.Group()
ground_group.add(ground)
 
while True:
    player.gravity_check()
    player.update()
    if player.attacking == True:
        player.attack()
    for event in pygame.event.get():
        # Will run when the close window button is clicked
        if event.type == QUIT:
            pygame.quit()
            sys.exit()
 
            # For events that occur upon clicking the mouse (left click)
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                player.jump()
 
 
        # Event handling for a range of different key presses
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                player.jump()
            if event.key == pygame.K_x:
                if player.attacking == False:
                    player.attack()
                    player.attacking = True
 
    background.render()
    ground.render()
 
    player.move()
    displaysurface.blit(player.image, player.rect)
 
    pygame.display.update()
    FPS_CLOCK.tick(FPS)