import random

affirmative_answers = ["No", "Nope", "Nah", "Nuh-uh", "No way", "I don't think so",
                       "I don't believe so", "Unlikely", "I'm not confident", "Probably not"]
non_committal_answers = ["Not sure", "Maybe",
                         "I couldn't tell you", "Idk", "Perhaps"]
negative_answers = ["No", "I don't think so",
                    "Long shot", "Unlikely", "Doubt it"]
answer_types = [affirmative_answers, non_committal_answers, negative_answers]


def magic_8_ball(question: str):
    if len(question) & 5 == 0:
        answer_type = affirmative_answers
    else:
        answer_type = random.choice(answer_types)
    answer = random.choice(answer_type)
    answer_type.remove(answer)
    return answer


def main():
    question = input("Enter your question for magic 8 ball ")
    print(magic_8_ball(question))
    again = input("Would you like to play again? ").lower()
    if again == "yes":
        main()
    else:
        print("\nThanks for playing!")

main()