from datetime import datetime
import json
from dateutil.relativedelta import relativedelta
from datadog import api

api_key = "aaaa"
app_key = "bbb"
api.api_key = api_key
api.application_key = app_key

query = "p90:trace.http.request{env:prd,service:bankingpaymentslip}"
from_time = int((datetime.now() + relativedelta(days=-10)).timestamp())
to_time = int(datetime.now().timestamp())
interval = 300
length = "3600"

result = api.Metric.query(from_time=from_time, to_time=to_time, query=query, interval=interval, length=length)

print(result)
df = json.dumps(result)