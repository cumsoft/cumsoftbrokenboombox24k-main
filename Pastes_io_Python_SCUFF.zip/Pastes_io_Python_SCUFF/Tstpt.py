import tkinter as tk

from tkinter import ttk

from datetime import datetime

import ctypes

class ModernClock:

    def __init__(self, root):

        self.root = root

        self.root.title("Modern Clock")

        self.root.geometry("300x150")

        

        # Check if transparency is supported

        if self.root.attributes('-alpha') is not None:

            # Set transparency (adjust as needed)

            self.root.attributes('-alpha', 0.8)

        # Set background color to black

        self.root.configure(bg='#000000')

        # Create and configure clock label

        self.clock_label = ttk.Label(root, font=('calibri', 40, 'bold'), background='#000000', foreground='#00F5FF')

        self.clock_label.pack(anchor='center', pady=20)

        # Update clock display

        self.update_clock()

    def update_clock(self):

        # Get current time

        current_time = datetime.now().strftime('%H:%M:%S')

        

        # Update clock label text

        self.clock_label.config(text=current_time)

        # Schedule the update every 1000 milliseconds (1 second)

        self.root.after(1000, self.update_clock)

def main():

    # Set the title bar color for Windows

    if 'win' in tk.Tcl().eval('info patchlevel'):

        ctypes.windll.shcore.SetProcessDpiAwareness(1)

    

    # Create Tkinter root window

    root = tk.Tk()

    # Create the ModernClock instance

    ModernClock(root)

    # Run the Tkinter main loop

    root.mainloop()

if __name__ == "__main__":

    main()