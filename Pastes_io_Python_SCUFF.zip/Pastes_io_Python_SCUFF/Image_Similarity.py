from tkinter import Tcl #OK
import os #OK
import numpy as np #OK
import cv2 #OK
import time

# Locatia standard pentru toate frame-urile
folder_frames = '/Users/cristianpogan/Desktop/Python-Scripts/Server-Scripts/Image-Comparison/Similar-Frames'

# Numara cate fisiere sunt in folder
path, dirs, files = next(
    os.walk(folder_frames))
file_count = len(files)
print("Sunt ", file_count, " frame-uri")

print("-------------------")

file_list = os.listdir(folder_frames)
# Face un array cu denuminile fisierelor .jpeg
lista_frameuri = list(Tcl().call('lsort', '-dict', file_list))

#dir = sorted(os.listdir(os.getcwd()), key=len)
#print(lista_frameuri)

start = time.perf_counter()

for x in range(100):#len(lista_frameuri)-1):
	
	# ----------HASH comparison------------------------------------------
	frameX1 = os.path.join(folder_frames, lista_frameuri[x])
	frameX2 = os.path.join(folder_frames, lista_frameuri[x+1])
	# ----------Pregatirea imaginilor pentru MSE si SSIM----------------
    # load the images -- the original, the original + contrast,
    # and the original + photoshop
	frameX1CV = cv2.imread(frameX1)
	frameX2CV = cv2.imread(frameX2)
    # convert the images to grayscale
	image1 = cv2.cvtColor(frameX1CV, cv2.COLOR_BGR2GRAY)
	image2 = cv2.cvtColor(frameX2CV, cv2.COLOR_BGR2GRAY)
    # ----------MSE - Mean Squared Error - comparison-------------------
	MSEerr_result = np.sum((image1.astype("float") - image2.astype("float")) ** 2)
	MSEerr_result /= float(image1.shape[0] * image1.shape[1])
	# ----------Afisarea rezultatelor----------------------------------
	print(x, " intre: ", frameX1[-42:-5], "si", frameX2[-42:-5] , ": ", int(MSEerr_result))
	# Stergerea fisierelor asemanatoare
	#if diff == 0 or diff == 1:
	#    print("Removed ", frameX1)
	#    os.remove(frameX1)

end = time.perf_counter()
print(end - start)