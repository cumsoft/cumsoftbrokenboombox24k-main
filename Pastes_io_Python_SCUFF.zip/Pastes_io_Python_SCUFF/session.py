from polars import col, DataFrame
def filter(x):
    if x == True:
        return 'sessionid_interno'
    else:
        return 'sessionid_esterno'

def in_out_session1(dataf: DataFrame) -> DataFrame:
    selection = ['sessionid',  'inbound']

    query = dataf.lazy().select(selection).with_column(col('inbound').apply(filter).alias('tipo_sessione'))

    return query.collect()