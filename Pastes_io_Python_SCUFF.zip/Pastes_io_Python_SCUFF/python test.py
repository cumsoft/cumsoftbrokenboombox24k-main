import hashlib
import binascii
import time

def brute_force_md5_crc32():
    target_crc32 = binascii.crc32(bytes.fromhex("00000000")) & 0xFFFFFFFF
    current_hex = "00000000"
    attempts = 0
    total_combinations = 16 ** 8  # Total 8-character hexadecimal combinations

    while current_hex != "FFFFFFFF":
        md5_hash = hashlib.md5(bytes.fromhex(current_hex)).hexdigest()
        crc32_hash = binascii.crc32(bytes.fromhex(md5_hash)) & 0xFFFFFFFF

        attempts += 1
        progress_percentage = (attempts / total_combinations) * 100

        if crc32_hash == target_crc32:
            return current_hex, attempts, progress_percentage

        # Print progress report every 30 seconds
        if attempts % (total_combinations // 30) == 0:
            print(f"Progress: {progress_percentage:.2f}%")
            print(f"Current Hex: {current_hex}")

            # Pause for 30 seconds
            time.sleep(30)

        # Increment to the next 8-character hexadecimal
        current_hex = hex(int(current_hex, 16) + 1)[2:].upper().zfill(8)

    return None, attempts, progress_percentage

result_hex, total_attempts, final_progress = brute_force_md5_crc32()
print("Brute force completed.")
if result_hex:
    print(f"Match found! Hexadecimal Value: {result_hex}")
else:
    print("No match found.")

print(f"Total Attempts: {total_attempts}")
print(f"Final Progress: {final_progress:.2f}%")