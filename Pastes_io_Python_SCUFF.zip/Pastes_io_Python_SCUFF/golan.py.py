import numpy
import pylab
 
pylab.rcParams['font.size'] = 16
 
x_list = numpy.array(range(2002,2022))
eg_age = x_list - 1971
pylab.plot(x_list, eg_age, linewidth=4, label='EG')
 
wives = [{'name':'IL',
          'age at marriage':20,
          'year married':2002,
          'year divorced':2008},
         {'name':'RR',
          'age at marriage':21,
          'year married':2012,
          'year divorced':2017},
         {'name':'DG',
          'age at marriage':21,
          'year married':2020,
          'year divorced':2021}]
for wife in wives:
  x_list = numpy.linspace(wife['year married'], wife['year divorced'])
  y_list = x_list - x_list[0] + wife['age at marriage']
  pylab.plot(x_list, y_list, label=wife['name'], linewidth=4)
pylab.xlabel('Calendar Year')
pylab.ylabel('Age [Years]')
pylab.grid()
 
pylab.legend()

.................................................