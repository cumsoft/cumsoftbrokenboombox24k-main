from flask import Flask, request, make_response, redirect

app = Flask(__name__)

passcode = "1106"

todos = []

def check_passcode():
    if 'passcode' in request.cookies and request.cookies['passcode'] == passcode:
        return True
    else:
        return False

# Home page
@app.route("/")
def home():
    if check_passcode():
        todo_list = "<ul>"
        for i, todo in enumerate(todos):
            todo_list += f"<li>{todo} <a href='/delete_todo/{i}'>Delete</a></li>"
        todo_list += "</ul>"
        return f"""
            <html>
                <head>
                    <title>Hausaufgaben</title>
                </head>
                <body>
                    <h1>Hausaufgaben</h1>
                    <form action='/add_todo' method='POST'>
                        <label for='todo'>New To-Do:</label>
                        <input type='text' name='todo' id='todo' required>
                        <button type='submit'>Add</button>
                    </form>
                    {todo_list}
                </body>
            </html>
        """
    else:
        return redirect("/login")

# Login page
@app.route("/login")
def login():
    return """
        <html>
            <head>
                <title>Login</title>
            </head>
            <body>
                <h1>Login</h1>
                <form action='/validate_login' method='POST'>
                    <label for='passcode'>Passcode:</label>
                    <input type='password' name='passcode' id='passcode' required>
                    <button type='submit'>Submit</button>
                </form>
            </body>
        </html>
    """

# Login validation
@app.route("/validate_login", methods=["POST"])
def validate_login():
    if request.form['passcode'] == passcode:
        resp = make_response(redirect("/"))
        resp.set_cookie('passcode', passcode)
        return resp
    else:
        return "Invalid passcode. Please try again."

# Add a new to-do
@app.route("/add_todo", methods=["POST"])
def add_todo():
    todo = request.form['todo']
    todos.append(todo)
    return redirect("/")

# Delete a to-do
@app.route("/delete_todo/<int:index>")
def delete_todo(index):
    todos.pop(index)
    return redirect("/")

if __name__ == "__main__":
    app.run(debug=True)