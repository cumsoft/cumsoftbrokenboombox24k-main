from datetime import datetime
from os import name as os_name
from platform import platform, python_version, system

from discord import Color, Embed, File, __version__
from discord.ext import commands
from gpiozero import CPUTemperature
from psutil import (boot_time, cpu_count, cpu_freq, cpu_percent, 
                    disk_usage, virtual_memory)

class Brayne(commands.Cog):
    @commands.command(aliases=['about', 'info', 'ver', 'version'])
    async def brayne(self, ctx):
        #build embed
        embed = Embed(description=self.get_platform_info(), 
                      color=Color.blue())
        
        embed.add_field(name='__CPU__:', 
                        value=self.get_cpu_info(), inline=True)        
        embed.add_field(name='__Memory__:', 
                        value=self.get_memory_info(), inline=True)
        embed.add_field(name='__Disk__:', 
                        value=self.get_disk_info(), inline=True)

        embed.set_author(name="Bronson's BrAyNe",
                         icon_url="attachment://images_common_bbb.jpg")
        embed.set_thumbnail(url="attachment://images_brayne_brayne.png")

        #prepare local files for use in embed, then send
        with open('./images/common/bbb.jpg', 'rb') as f_icon:
            icon = File(f_icon)
        with open('./images/brayne/brayne.png', 'rb') as f_thumbnail:
            thumbnail = File(f_thumbnail)

        await ctx.reply(embed=embed, files=[icon, thumbnail])    
        
    @commands.Cog.listener()
    async def on_ready(self):
        #this is called when the bot is connected & ready, so we set our
        #launch_time variable here, stored for later use in getting bot uptime
        self.launch_time = datetime.now()

    def get_platform_info(self):
        #get system boot time as a Unix timestamp,
        #then convert it to a datetime object
        boot_timestamp = boot_time()
        booted_time = datetime.fromtimestamp(boot_timestamp)

        #build string of platform info for embed & pass it back
        platform_info = (
            f'**Bot version**: 420.69\n\n'

            f'**Python version**: {python_version()}\n'
            f'**discord.py API version**: {__version__}\n\n'

            f'**OS**: {platform()} ({os_name})\n\n'

            f'**Bot uptime**: {self.get_uptime(self.launch_time)}\n'
            f'**System uptime**: {self.get_uptime(booted_time)}'
        )

        return platform_info

    def get_cpu_info(self):
        #get cpu temp if on linux (raspberry pi)
        if system().lower() == "linux":
            cpu_temp = CPUTemperature()
            cpu_temp_f = cpu_temp.temperature * 9/5 + 32
            cpu_temp_f = f'{cpu_temp_f:.2f} °F'
        else:
            cpu_temp_f = 'N/A'

        #build string of cpu info for embed & pass it back
        cpu_info = (
            f'**Usage**: {cpu_percent(interval=1):.2f}%\n'
            f'**Core/Freq**: {cpu_count(logical=False)}x @ '
                           f'{cpu_freq().current / 1000:.2f} GHz '
                           f'(***max*** *{cpu_freq().max / 1000:.2f} GHz*)\n'
            f'**Temperature**: {cpu_temp_f}'
        )
    
        return cpu_info

    def get_memory_info(self):
        #build string of memory info for embed & pass it back
        memory_info = (
            f'**Used**: {virtual_memory().used / (1024 ** 3):.2f} GB\n'
            f'**Total**: {virtual_memory().total / (1024 ** 3):.2f} GB\n'
            f'({virtual_memory().percent:.2f}%)'
        )

        return memory_info

    def get_disk_info(self):
        #build string of disk info for embed & pass it back
        disk_info = (
            f'**Used**: {disk_usage('/').used / (1024 ** 3):.2f} GB\n'
            f'**Total**: {disk_usage('/').total / (1024 ** 3):.2f} GB\n'
            f'({disk_usage('/').percent:.2f}%)'
        )

        return disk_info

    def get_uptime(self, start_time):
        #get the time in-between now & provided start time
        delta = datetime.now() - start_time
        
        #calculate the values & return formatted uptime back
        days = delta.days
        hours, remainder = divmod(delta.seconds, 3600)
        minutes, seconds = divmod(remainder, 60)

        uptime = f'{days}d, {hours}h, {minutes}m, {seconds}s'
        return uptime

async def setup(bot):
    await bot.add_cog(Brayne(bot))