GRAVITY = (0, 0, 9.80665)  # (x, y, z)

# Define helper function to calculate magnitude of a vector
def magnitude(vector):
    return math.sqrt(sum(v**2 for v in vector))

# Define helper function to normalize a vector
def normalize(vector):
    mag = magnitude(vector)
    return tuple(v/mag for v in vector)

while True:
    # Read raw accelerometer readings from the ICM20948
    accel_x, accel_y, accel_z = icm.acceleration

    # Calculate gravity vector
    gravity = normalize((accel_x, accel_y, accel_z))

    # Remove the gravity effect from the accelerometer readings
    linear_accel_x = accel_x - gravity[0]
    linear_accel_y = accel_y - gravity[1]
    linear_accel_z = accel_z - gravity[2]

    linear_acceleration = (linear_accel_x, linear_accel_y, linear_accel_z)

    # Print the linear acceleration values
    print("Linear acceleration:", linear_acceleration)

    # Do something with the linear acceleration data

    time.sleep(0.1)  # Delay for 100ms