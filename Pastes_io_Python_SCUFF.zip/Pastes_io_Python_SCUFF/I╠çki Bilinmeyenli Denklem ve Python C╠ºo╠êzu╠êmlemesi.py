# NumPy Duru Aydın İki Bilinmeyenli Denklem ve Python Çözümlemesi
import numpy as np
# girdi olarak kullanıcıdan iki denklem isteme
print("İki bilinmeyenli denklemleri çözeceğiz.")
print("Denklemler aşağıdaki formatta olmalıdır:")
print("ax + by = c")
print("dx + ey = f")
a = float(input("a değerini girin: "))
b = float(input("b değerini girin: "))
c = float(input("c değerini girin: "))
d = float(input("d değerini girin: "))
e = float(input("e değerini girin: "))
f = float(input("f değerini girin: "))
# katsayı matrisi oluşturma
A = np.array([[a, b], [d, e]])
# sabitlar vektörü oluşturma
B = np.array([c, f])
# denklemlerin çözümünü hesaplama
X = np.linalg.solve(A, B)
# sonuçları ekrana yazdırma
print("\nx =", X[0])
print("y =", X[1])