import asyncio
import websockets
import threading,os

class InputThread(threading.Thread):
  def __init__(self, queue, event_loop):
    threading.Thread.__init__(self)
    self.queue = queue
    self.event_loop = event_loop

  def run(self):
    while True:
      a = input('> ')
      if a == '':
        continue
      asyncio.run_coroutine_threadsafe(self.queue.put(a), self.event_loop)


async def handle_connection(websocket, path, connections):
  print('connected')
  connections.add(websocket)

  try:
    async for message in websocket:
      print(f'received: {message}')
  except websockets.exceptions.ConnectionClosed:
    pass
  finally:
    connections.remove(websocket)

async def prompt_input(queue, connections):
  while True:
    a = await queue.get()
    if connections:
      await asyncio.wait([asyncio.create_task(client.send(a)) for client in connections])
async def main():
  connections = set()
  queue = asyncio.Queue()
  event_loop = asyncio.get_running_loop()
  input_thread = InputThread(queue, event_loop)
  input_thread.start()

  server = await websockets.serve(lambda ws, path: handle_connection(ws, path, connections), 'localhost', 8080)

  async with server:
    await prompt_input(queue, connections)

asyncio.run(main())