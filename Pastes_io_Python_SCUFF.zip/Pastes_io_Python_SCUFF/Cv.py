from collections import deque

def min_clicks_to_reach_end(N, links, start_page, end_page):

    

    graph = {}

    for i in range(N):

        graph[i + 1] = links[i]

    

    queue = deque()

    visited = set()

    clicks = 0

    

    queue.append(start_page)

    visited.add(start_page)

    while queue:

        

        level_size = len(queue)

        for _ in range(level_size):

            current_page = queue.popleft()

            

            if current_page == end_page:

                return clicks

            

            for linked_page in graph.get(current_page, []):

                if linked_page not in visited:

                    queue.append(linked_page)

                    visited.add(linked_page)

        clicks += 1

    

    return -1

N = int(input())

links = []

for i in range(N):

    links.append(list(map(int, input().split())))

start_page, end_page = map(int, input().split())

result = min_clicks_to_reach_end(N, links, start_page, end_page)

print(result)

*webpages