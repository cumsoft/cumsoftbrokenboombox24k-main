import requests

data = {
 "animes": [
  {
   "name": "Xian Wang de Richang Shenghuo\nXian Wang de Richang Shenghuo",
   "title": "Xian Wang de Richang Shenghuo",
   "des": "القصة تدور حول العبقري وانج لينج الذي لديه قوة وبراعة تفوق قدرته على التحكم بهما، والآن بعد أن أتمَّ السادسة عشرة من عمره، يواجه أكبر معاركه حتى الآن.",
   "info": "الحالة: مكتمل الاستديو: Haoliners Animation League سنة الإصدار: 2020 المدة: 19 دقيقة. الموسم: شتاء 2020 البلد: الصين النوع: أونا الحلقات: 15 تاريخ النشر: مايو 8, 2022",
   "image": "https://i0.wp.com/animetitans.net/wp-content/uploads/Xian-Wang-de-Richang-Shenghuo.jpg?resize=247,350",
   "ep": [
    {
     "name": "15",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=61&dl=SXhYbS9NSzlpNFNSMDRNeGhyelhsZz09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!vehXERaQ!Onoy8RE5M0KtOz5y1O9Ko0s09Izasx82y07L18NdrME"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.solidfiles.com/v/pd2X5jRdwy3B7"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/mKpo7Q-JbqfAyQ"
      },
      {
       "name": "720p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=19EFZNq0uSOJbBYKqa2UsoP4xbOF7CDeP&export=download"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/csibuvxbyoxu"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/KC4oDHMW57a7"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/ayqnor1ah5p4"
      }
     ]
    },
    {
     "name": "14",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=53&dl=a1RwcjhyNTJMT21DOXNBci9uQ1FBUT09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!jC5WURiI!2drpeRT-Zt0Gx7gHOnTaSpSq4-nKFZ4VhhsKPW2I_Js"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.solidfiles.com/v/2dPVw3pdpmzyK"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/N0LOava629J8Vw"
      },
      {
       "name": "720p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1O_mSHEjqfsjx5YjonDEFy_44SuD1JF20&export=download"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/jhp9bmqan16y"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/QS8v832U17R1"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/g5edo4v4qyf0"
      }
     ]
    },
    {
     "name": "13",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=14&dl=R3llbE9idkVZRlhjUjErOGlsNHVGZz09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!2CZQUBiA!UNhBNqNyI_N-uum2DePTUL29Dx2cRSAEsxchldC2CtI"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.solidfiles.com/v/eWVzpGpGXqpmD"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/y2-2n2aS3mdcxg"
      },
      {
       "name": "720p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1COLCItgGfQ7w28NJIOg1OWMoASeCM84h&export=download"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/sclz0aumuixh"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/kXUCgP8thKe3"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/z9uaq0tho31l"
      }
     ]
    },
    {
     "name": "12",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=4&dl=ZnhhRnJDVmRmMHpjOGtNUUhjL1E1UT09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!Tfw1hZIB!TAP2QbUqtae99IhllxcAZg1cnaKBn3x-3GOJpZ3l_2Y"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.solidfiles.com/v/a4krGeRPg2VLZ"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/b18j_QlbV6KOWg"
      },
      {
       "name": "720p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1Lpx2W_EL4QbutoB775UXy8NfzdtnGkXv&export=download"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/2uewmsmswirj"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/38hW7Gkt0h1u"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/ge5ombbwjua1"
      }
     ]
    },
    {
     "name": "11",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=53&dl=ZXk5L08yR2krZUxPUzFKMnFDMXpIZz09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!PWRy0Caa!CTskzTkMC9Y9Y-Q3EX0TTKAcWwGB_MKpaIUKsfBfjy4"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.solidfiles.com/v/NVp7XNMxQVzpv"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/-3EDSWwCfK9YBw"
      },
      {
       "name": "720p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=13qe4I99uTDJ5aYZQ7D6OLCRZsIvPU0CI&export=download"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/2vbaa8ys381y"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/gIfcWQYOauXy"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/0aoudt3v65e4"
      }
     ]
    },
    {
     "name": "10",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=51&dl=a1BCYi9JMDBFR0YwRUQ5OVZxZGtXZz09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!6a4AVBDY!O1rDG613YZNgOaEnys4vNb_5YMKVGwdV0wLTIGdC_po"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.solidfiles.com/v/dNW4vAz5nxm3q"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/0ZCEbJCIFyzdhA"
      },
      {
       "name": "720p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1LY5pvMZvZFt5XIF0bw4MGAHPwR5-qbna&export=download"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/xc2ozzllojoy"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/tL4JP20OuwjA"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/mk0vm6bqglq7"
      }
     ]
    },
    {
     "name": "9",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=51&dl=Wll1UTk5RFl3SUFOUG1lRjJlTGNYUT09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!zXA3DJwA!m9DO-FqxG067X8ppRPZK-Brs1NpNPF2FVCBFf8LBgT0"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.solidfiles.com/v/nkdZPkpd5apVv"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/kHqDjeN7r6ATmg"
      },
      {
       "name": "720p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1dB1qaROvpkzZo4cqurlphX-H_b6lR6Q6&export=download"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/mbxa59oadpzm"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/2Jh3T6o75675"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/3dp9m2hrxv8z"
      }
     ]
    },
    {
     "name": "8",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=56&dl=V3ZaOFVZQm5VTDJkZGcySlkwYlFqQT09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!aPJzFBiB!6b0h26-cK0-tOWMgwH90G3cFDBiIHSjqmCOBlN62rL0"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.solidfiles.com/v/NVp7XVnLBpAwg"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/fXMNzuKZVGKxLg"
      },
      {
       "name": "720p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1oONgujjjNzxdrq9jY2MkMq2HCG302KMf&export=download"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/pxnptpabeyqp"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/76yWVqF1GMh4"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/qu7axehwzaqf"
      }
     ]
    },
    {
     "name": "7",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=21&dl=YlAvczFuSXB5dWhiV1lOS0IzV3ZiQT09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!DL421aTQ!UkccVyu2rLItH_x2bDOsM6Esf1dD4yItHycEAsusGf8"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.solidfiles.com/v/GW37XWRapMQQW"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/QfmKwvykL1pf5w"
      },
      {
       "name": "720p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1rIG4Tl2IxEDB6gICjTk5yb9cAWfzzu84&export=download"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/uw1v4nnn7r7y"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/yEcTTt2tcQx4"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/93z3p6fqx3bq"
      }
     ]
    },
    {
     "name": "6",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=58&dl=RmxXR1RqR3dRM1Vlcm9rTmczbmF5Zz09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!TTIHnLLY!y0Fu2IBQD76yBg1d6f8EfjJI8L9GUvBaRbdCH3twr4s"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.solidfiles.com/v/AW67XW2ZM5wDQ"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/S27B4wt2lmJzug"
      },
      {
       "name": "720p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=19GxQoxtAKg2UJZlXqS_7mQwNubgDBYES&export=download"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/a3mqnihoayrw"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/818Utd113l7n"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/3mdijh4j4psl"
      }
     ]
    },
    {
     "name": "5",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=56&dl=SWVsblh5K05Pb0pXUURQZ21TNUw5QT09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!meImxYZT!uf94VCy65W139t6f5Kmu_MoeeWT8tAxo1Lqmp1Vrj5M"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.solidfiles.com/v/zeqrR6Me4LyPv"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/yh8Ui6axIH4leA"
      },
      {
       "name": "720p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1zsU9GKkgPi92hyeNKrkhhxNn-8iyrx5d&export=download"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/y4yo9gdxwj5l"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/Df6OK3v1d3Ok"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/hegpj0oschxh"
      }
     ]
    },
    {
     "name": "4",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=13&dl=OGVFRTJ2dTM4QnhuazZ1RnlZVlJoZz09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!CbxHRapS!xtNdvlxVEJsq5JCf5Ge87AwL5FOrgFrXZpAabLBo3TQ"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.solidfiles.com/v/6G4jdgpdgLPYK"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/4TY7oLwOXq0FKQ"
      },
      {
       "name": "720p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1C9q2zIb5lQC6EN1xaJHcoLup8oH7Z28H&export=download"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/ppdbxstqiarv"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/Nk2KOvpUl6m0"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/ocpmu6wb83n2"
      }
     ]
    },
    {
     "name": "3",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=53&dl=cGJjNlNoTFBqN2hoVVFSRkJPSklLUT09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!yPZAlJxB!a0KAvvLXbfAHKNy0FP2cz-rcLLJbYqElRa7mtcAsB9o"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.solidfiles.com/v/vNRQgw4w3jmnq"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/1hAcUgXN54hbmA"
      },
      {
       "name": "720p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1wehrGjksA4vnayklONP8DDZgVVJCEVSO&export=download"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/cpymxlbwv04r"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/5q8OTkVIIf17"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/4pp81cwscq3j"
      }
     ]
    },
    {
     "name": "2",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=58&dl=RXZKd3pVdnFpYU1Ib2Nuc1FLRmNQZz09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!mLpkkSxK!q8mAIYfpUdGsdSCxrVHi-GmOIAF3hHwl6pvSELipBcs"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.solidfiles.com/v/GW37XWRPagKp6"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/pEAPOgbbgLqKJA"
      },
      {
       "name": "720p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1bo5J1YiFs_vwkkjkhqMmOKUJ-bBnpK2K&export=download"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/fvc9mxkjgcvj"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/5r5C2pMDkIq8"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/qj68iqw4s5m2"
      }
     ]
    },
    {
     "name": "1",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=57&dl=dUQ1UmtzQ2pabkxMRjZnSkJNdHhHdz09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!WbAQQRjD!vdpjGrclNcEiP4n8IT_yZilf6TIVDUs9IDTVtJl7ptQ"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.solidfiles.com/v/pd2k7KWywKqKQ"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/qvZ54kNPWonENg"
      },
      {
       "name": "720p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1TZZMgrZ2RjVN7rjyUp5McGh11C0V64Dq&export=download"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/poicgsqolds4"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/W6bAF4BwmP3x"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/mpwhf31esicu"
      }
     ]
    }
   ]
  },
  {
   "name": "Xian Wang de Richang Shenghuo 2\nXian Wang de Richang Shenghuo 2",
   "title": "Xian Wang de Richang Shenghuo 2",
   "des": "تكملة لأحداث الموسم الأول من الحياة اليومية للملك الخالد والتي قصتها:\nوانغ لينغ هو وجود شبه لا يقهر مع قوى خارجة عن سيطرته ولكن الآن بعد أن بلغ السادسة عشرة من عمره يواجه أكبر معركته حتى الآن – المدرسة الثانوية العليا.",
   "info": "الحالة: مكتمل الاستديو: Haoliners Animation League سنة الإصدار: 2021 المدة: 19 دقيقة. الموسم: شتاء 2021 البلد: الصين النوع: أونا الحلقات: 12 تاريخ النشر: مايو 9, 2022",
   "image": "https://i3.wp.com/animetitans.net/wp-content/uploads/Xian-Wang-de-Richang-Shenghuo-%D8%A7%D9%84%D9%85%D9%88%D8%B3%D9%85-%D8%A7%D9%84%D8%AB%D8%A7%D9%86%D9%8A.jpg?resize=247,350",
   "ep": [
    {
     "name": "12",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=13&dl=TmRxYTM0VHBVUlp4ZjVTMnZDd2lMdz09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=13&dl=VVJzOHpHNUtzQ1hvNDF5Q215VWhZQT09"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://sbfull.com/d/aa5c8hp6g7wp.html"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://sbfull.com/d/xv0lwls6ewui.html"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://mega.nz/#!wvoiTCDK!JKCrEBihDGeRpDOfNQijTN8XQS1cai5wu4aTyeI6mUg"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!k34QWIRY!bw1xM_7tseQ9d6gXTc5UAPRUn6V_GmtopMj2yOjg8ok"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.solidfiles.com/v/x5qR872Vk4KgX"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.solidfiles.com/v/eZnk4zqQRZBzW"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1IRGMA-9wgV3MDyeZTbexpl1OfLV_7Tn3&export=download"
      },
      {
       "name": "720p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1oyIj4dg62aoiX3uGo0dI2AZ1s_9twM-z&export=download"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://disk.yandex.com/i/7zrRVjErv-2UxA"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/8oUAhRfr6BC9rQ"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.yourupload.com/watch/yVt7AeyAs7Y2"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/K0Jq810Xo4Fh"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://upvideo.to/v/dioriseqlw9o/"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/gswwvq8qtyf6/"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.mp4upload.com/v5020ybhsrwe"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/ol3v1nrzm2ck"
      }
     ]
    },
    {
     "name": "11",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=56&dl=QURpSzF4eHJaNzhySmNhZmNnb2lHQT09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=57&dl=ZFRiaFh3dWpnSnBHS1BiNVdLeWg3UT09"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://sbfull.com/d/574im3afikrj.html"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://sbfull.com/d/qorlht9h0e3f.html"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://mega.nz/#!UiphlRiY!hhFB0F05F9x9R5FmJpT26h_QgOYOQ-R7ankS4ElcUi4"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!1mpRBZbJ!xJkNUoCeMnLSBultxImOTpn01usM1XA30-bcEormDgQ"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.solidfiles.com/v/v5ZvKQdzwvVAN"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.solidfiles.com/v/4QAqGD6ydW6vp"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1vJGP6Io-ujQIYi1AEFDKTkwKFJGPRVAt&export=download"
      },
      {
       "name": "720p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1zqAP-066446kd3e40A1PpsBHjiSB_8OK&export=download"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://disk.yandex.com/i/1lIY8OSqbvDfgw"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/cV_agGBTozBFkQ"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.yourupload.com/watch/D6w5U6Trp70S"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/6L6s1Y374RO8"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://upvideo.to/v/dhypzyrjm78x/"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/ncnpkjbnerji/"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.mp4upload.com/nc205agp2afm"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/xgn48ruywch2"
      }
     ]
    },
    {
     "name": "10",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=51&dl=R256aU9MNzg1RURXUUxrdVdIKzdTQT09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=14&dl=Skh1RmMxTkNkVkR6OHRrU2pPd2gxZz09"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://sbfull.com/d/ph5hazt4gyin.html"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://sbfull.com/d/4y27404vr10x.html"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://mega.nz/#!AmpHVbzK!Kp_M1cVPB4NHyag4QaNRVK7L7Dg7Y2O4UB5QB7csie0"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!gjIi0aLT!cOKLGLQ3fwGuemz3DWB6Y0CtfPAiPjQdxOcHRsKFSSE"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.solidfiles.com/v/5MwX8Xm26pew5"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.solidfiles.com/v/RP5XRXAja3dxG"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1_i8PU4YWAuTOhgFDFNe7JE4IaYx-Hno-&export=download"
      },
      {
       "name": "720p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=15MSd0t9_Od_0fLSbqXx1btIvb0dxMlmT&export=download"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://disk.yandex.com/i/HxHRaZwYH-giRg"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/Xk2fxlk3KZvbvA"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.yourupload.com/watch/ml4snoL2JKX1"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/yTyj6Ve5uCyE"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://upvideo.to/v/mtdgkiwqyiz5/"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/2xdlrgiw8pdh/"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.mp4upload.com/ekzqtbmc4efq"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/lsa7g99s5kar"
      }
     ]
    },
    {
     "name": "9",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=55&dl=VWJrUkt2VTNiUGxKaVNvNEhlSWRsdz09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=13&dl=U2QzTjhVdDlaRXAwQ0ZjZ3ZTZ2NSdz09"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://mega.nz/#!EaFghT6C!qPr1EjSTD9HRwkrYHcKdJQbH9jtAub9Y1R823kKNuxc"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!FDVzWD7C!ycI_kdXEvXWExURCTo70N6HHUyxnrfI5Am3QJKvWCXk"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.solidfiles.com/v/BN5733nM3Npwz"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.solidfiles.com/v/WQ67jjZwwdy7Y"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://disk.yandex.com/i/lY10iTNajnjSGw"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/QBCot02UvfKoMA"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1I5XvamnWDaJa2odrJ55LhgETKWn0IpZf&export=download"
      },
      {
       "name": "720p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1ZajfXNmCb97iGac5KNOtOMnQwrMrR6fE&export=download"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://sbfull.com/d/3lrndzpbkpfm.html"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://sbfull.com/d/5jnq6n2a3yna.html"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.yourupload.com/watch/MUD0EEVK7nxI"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/O5Ywjf625E02"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://upvideo.to/v/udxrk636wana/"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/xjyuqos02m7y/"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.mp4upload.com/bjy2pvb8w05z"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/qzd4ar5t9pxm"
      }
     ]
    },
    {
     "name": "8",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=53&dl=ZjFTS3NET0lBdVYwRzFWZFRRem95Zz09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=51&dl=N3R6UkNxaWNSQ1VuU3NxeEliWlY4Zz09"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://mega.nz/#!yC5RVYrB!_CXEKJFVtp-lJpBoh9WSMhCK9M6CqeQ5UrFTP3h7U_k"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!TS43wQ5L!Qmm-ot863TiNw6368QTpedcvJkQ-UZneErQJcDzZBSg"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1JWyfkYj0EgzgTSDCrxlrYw2hGpfgpoJH&export=download"
      },
      {
       "name": "720p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1M6GatG1nKghJJP9_jTHaYn0lrDIixupG&export=download"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://disk.yandex.com/i/CGSKydT8ZFdF4g"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/mVHiLT9dGoYk1Q"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.yourupload.com/watch/uxqIiBgaayb4"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/ogA8ri0X66D8"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://upvideo.to/v/rtzwtla3upvr"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/ypppubyvzoir"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.mp4upload.com/l36spfqvyylz"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/ihll5b1abyh7"
      }
     ]
    },
    {
     "name": "7",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=61&dl=bkEvT0l3OEhvV21vMFd3L2JTQy9RZz09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=1&dl=TnFXNmgxcDZ2alBTeUo1OGNvUGw4dz09"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.solidfiles.com/v/8ZwnMarw85mWA"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.solidfiles.com/v/QnRDaQw4rxYjB"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1Ymwhszr3oorXRLJTlndY7Kz-DqujSHYT&export=download"
      },
      {
       "name": "720p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1CdC2lifNqMNSV4MDjqqOe67PBrzsMeMn&export=download"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://disk.yandex.com/i/TNyTMx1dkMqjUA"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/1lt-FDC_YhMvBQ"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://mega.nz/#!XehVnC5K!NwmWPbRPRuZgYSCTnFzTDZ26bT2KgHzZ3DqjHXj1x0E"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!vGYmlRQI!DSG-Z7NBpAqM0GoT7LevIUhi7bx9qNRAjSKCakRK52c"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.yourupload.com/watch/x4mHW5L672fx"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/aX5MeVGD0Si1"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://upvideo.to/v/ya7fjjxtccyj"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/lllwaugundn1"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.mp4upload.com/wy7tljxwh9ct"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/aq8fz2dy72mx"
      }
     ]
    },
    {
     "name": "6",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=59&dl=MkpKMEQ1clVnRXVFY3lVVWl3WVFMQT09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=56&dl=UHFYU0NtZGJEWm9SRTdRRUtXRFpzdz09"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.solidfiles.com/v/ZZKpqQwzBZ6LX"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.solidfiles.com/v/QnRDadYjadgQV"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1mph_jC7Gv-pBqJ1BzKwMCSLHSuYullo_&export=download"
      },
      {
       "name": "720p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1fqY1c-dSkTXtOu69ChywaO-qRfvWtgwV&export=download"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://disk.yandex.com/i/5gqOqGUBoQmbbw"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/6ZTVf1kD8Bt1mg"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://mega.nz/#!uPAhjZBC!os5ipmGra4zaJEcIa5h6y38CGdPqX5lq25cJhjv4qAw"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!yahynbRT!nYT_oXwZmfZJEZ4y0-2gMXVeZGOyYZKsqcRrAtpMSco"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.yourupload.com/watch/4j5X3Suq1uhy"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/uN5xHBPx0dy0"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://upvideo.to/v/8tiohw4qpter"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/zlpl1dus7csm"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.mp4upload.com/n2uodzxixwuo"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/ud968u851n4r"
      }
     ]
    },
    {
     "name": "5",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=59&dl=U1pibEtUdEx5T1JrUGlZanF0dU1VQT09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=13&dl=RVdtejA3OTV0K1d5RDA2RUVOdmxwdz09"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.solidfiles.com/v/nkd2xGAMMeZV2"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.solidfiles.com/v/kXY5BpnYa5KKd"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1y27ZtcXDaGVyjvkjdrk_R-RE9wemN0QG&export=download"
      },
      {
       "name": "720p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1TfF3v1dwyRmaB5fS1-PbIaUyFzbpow4I&export=download"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://disk.yandex.com/i/UwBgse3Otp65gA"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/QXIHXSddDgZPbg"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://mega.nz/#!WTZzlRDQ!FDjS8nLt4AN4BxLbakqr0pLfhr9XCoajzRgnr9fKbrg"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!CbAWkZYb!fwDLuh5y_6fpbumT7butOb-8o3RlQ3z0kbGmz3j50zs"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.yourupload.com/watch/w1xO77uPwV24"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/plwHF4eV6a3d"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://upvideo.to/v/0ro1fw5tjerv"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/u2fudvmpfoks"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.mp4upload.com/25anfcwlh18n"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/cmanvno2866h"
      }
     ]
    },
    {
     "name": "4",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=11&dl=OUNMeG8wMVp4bllZSmdpSmFteXV1QT09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=55&dl=cDZIRVFucG9sY0l3U0lqeFcvcFNFdz09"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.solidfiles.com/v/ZZKpW4BqnKYLn"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.solidfiles.com/v/pd2vqM3G6xayg"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1c5z0k46h4owkcAj4czLXrpED5Tni4Y6w&export=download"
      },
      {
       "name": "720p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1RGEa6_UKve8iZzNXaQpS5Ct83zOlezeX&export=download"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://disk.yandex.com/i/t-2bjz6nyUS5zQ"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/tKVJTashLcPJfw"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://mega.nz/#!CSZ2GLoa!Jt_fg2yJStYRGgcwyXNswagqcQvUz4kYkUyfGVe4UKw"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!SehziYKJ!Wf3PdHA2-Jn4D8--PmtfyQsWBjppLJJ5XZBFG1lwj1M"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.yourupload.com/watch/10xrH5Dm7D0K"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/I6G8Yv2MY81X"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://upvideo.to/v/y7t3hlifnatg"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/4jszksdzkwir"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.mp4upload.com/u667pf745ilk"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/5z42s77lib9h"
      }
     ]
    },
    {
     "name": "3",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=56&dl=ZXdUV1RvaU5mWkc2QkVQT0hNcmdxUT09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=60&dl=Sk9oWXdEOVA3amh6YlFhZVI0R0NRQT09"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.solidfiles.com/v/XLZaQ7yr3kAwj"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.solidfiles.com/v/2dPzqxZwVDmpn"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=16x0iOnbGXnaMDdJXJ7fCQ7sjgylgVqup&export=download"
      },
      {
       "name": "720p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1ykch79s8MVP8Vg8paHaSGo_bMYnXhXi6&export=download"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://disk.yandex.com/i/eTr3wfTLiB6tuQ"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/4RF-Bwg5QV36NA"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://mega.nz/#!rHBGlIDA!ubrZRJrflS1_CZv5w8rFMsmXBP_nqcvXgsEzbdEujcc"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!fTBWnCwK!yWK7vYH64IDjq-fP9KWxLvdGJYBXrRnSgzHOmvQM2Vw"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.yourupload.com/watch/aHlXhP1T54KE"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/J6JgHhqLFml2"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://upvideo.to/v/fylqgia9vks2"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/t83d0rt7hs3a"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.mp4upload.com/bkwdhgr32enb"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/z2btsr2qvzy2"
      }
     ]
    },
    {
     "name": "2",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=14&dl=VVRtakJlZ3Q2WmRnRGVYQmhMbGRBQT09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=52&dl=OG5DVXBxNUd1RzZ2Z0loWkh1VjJvUT09"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.solidfiles.com/v/8Zwn4x2PRrveY"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.solidfiles.com/v/5dmVZxwmPdeRL"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=14IxF4F_ScfL5nly-ZfkuSD10SYa_8uzO&export=download"
      },
      {
       "name": "720p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1lNwwgKQTG1_KNzg1YQGnffeeuV2CBKt-&export=download"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://disk.yandex.com/i/au-OmPCH41Nljw"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/f_SX5cZDHEy7WQ"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://mega.nz/#!LHgFkR4A!RFXDgK8azZrPtN6EMrHHcQQI-VUEQShZZv3UokYorjQ"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!7CRWgQzA!7YdUzamaCaYr5IpcrUkTU8MQ5GENpYOswWllSRw-L_k"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.yourupload.com/watch/aXAN3O3VNEnq"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/QAw8vkDDf376"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://upvideo.to/v/by4wmgiias4n"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/eqb8r3zmtyqm"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.mp4upload.com/easz0si9tlzf"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/9kll4ni6120n"
      }
     ]
    },
    {
     "name": "1",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=14&dl=THZRUTE1bERNYTltbGE3RDcrL2FIQT09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=61&dl=WWF2dmgwdXQxL0oyOHhUZGFiUld3dz09"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.solidfiles.com/v/GW3A25DD88qwX"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.solidfiles.com/v/qdaprz6naxRDP"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1p1xsDhWaeHSsJNFTq0ZQKw1IVD7dD5qH&export=download"
      },
      {
       "name": "720p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1x-UHKCkiWig3uDa0vlx-8EqGAXxiEHyz&export=download"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://disk.yandex.com/i/MHOowP94Y1AVNQ"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/dgoKSNWiR0Zfiw"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://mega.nz/#!mDZ2CYoT!ZrNOtuHZy_8-jb8lMB2BHxnprYpbBkZIHGLiTDmSYQM"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!bXpy2LIS!bQJahSy3BP6t4cD_96E8uo-1zknULnJb0Fy9C3c6YhU"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.yourupload.com/watch/vB4D8C6h4pmP"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/51TNJ0HbaR66"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://upvideo.to/v/zym6i4dyui9p"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/g45jyvvoi0da"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.mp4upload.com/k9m87qk2e3xj"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/asij27sizski"
      }
     ]
    }
   ]
  },
  {
   "name": "Xian Wang de Richang Shenghuo 3\nXian Wang de Richang Shenghuo 3",
   "title": "Xian Wang de Richang Shenghuo 3",
   "des": "تكملة لأحداث الموسم الثاني من الحياة اليومية للملك الخالد والتي قصتها:\nوانغ لينغ هو وجود شبه لا يقهر مع قوى خارجة عن سيطرته ولكن الآن بعد أن بلغ السادسة عشرة من عمره يواجه أكبر معركته حتى الآن – المدرسة الثانوية العليا.",
   "info": "الحالة: مكتمل سنة الإصدار: 2022 المدة: 20 دقيقة. الموسم: خريف 2022 البلد: الصين النوع: أونا الحلقات: 12 تاريخ النشر: سبتمبر 30, 2022",
   "image": "https://i2.wp.com/animetitans.net/wp-content/uploads/Xian-Wang-de-Richang-Shenghuo-3.jpg?resize=247,350",
   "ep": [
    {
     "name": "12",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=58&dl=UE1HRUFTMDZMT1pxTUwxSXJDRDkyUT09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=55&dl=MXdiT2tNUDdsZm9QUEp3NExtT1crQT09"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://sblongvu.com/d/h5efz763edxz.html"
      },
      {
       "name": "720p",
       "dowenload_url": "https://sblongvu.com/d/uahbg2kkxbke.html"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://mega.nz/#!Z7YmSbrK!8rwlbUz76iTJ_fp4cIj2cpmZObc9QVwO6sDZ4Vb73uk"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!Bnw2XRTS!ZnnvxU122I6ksonKWpHRKXcTNqKNwhoSNgFGyMRzyYc"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=14VUk7NNXT32uV7Kj9Gbn8mPKgSQkZLMI&export=download"
      },
      {
       "name": "720p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1gnBqIwFeceY-pAlLSwrAwUoBpZkeQV7e&export=download"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.yourupload.com/watch/7Jp7xc13fs1X"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/0kA72Kyq4Vup"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.fembed.com/f/x3y0nt56e13j5pw"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.fembed.com/f/5z3ylid1md-enjm"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://upvideo.to/v/ltz0pgjdbmkh/"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/vbnvle0byvym/"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.mp4upload.com/mzsl0srwg87x"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/z08pzeg7stch"
      }
     ]
    },
    {
     "name": "11",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=61&dl=NXp0RzB0bHl2MkwrNjhlTmd1V2xmQT09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=1&dl=M0FTdGF0VXdUaGk2YkZpWDdpVDAxUT09"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://sblongvu.com/d/9rxxcihqz4gc.html"
      },
      {
       "name": "720p",
       "dowenload_url": "https://sblongvu.com/d/16uxbr9rth51.html"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://mega.nz/#!pSEjnZ6D!Fr2d8-NYFmA-vjs6OF9okHDPYG-SAO-qXZET0WpBEBE"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!xSUWHAKL!1cCnf97v5Z1s97ref46KdkNde_PWQ3nsqLsNSSmKhHI"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1EvcnD31R-vxUH9AbBfIfBOTqjAsuVc4l&export=download"
      },
      {
       "name": "720p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1fuHCrf9A0L8LFE99GspWWNJ2cHA19s1p&export=download"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.yourupload.com/watch/JdVy5Iitxsvh"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/4YN7WquU6306"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.fembed.com/f/qzkrdiergkw1xq2"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.fembed.com/f/y63meael367141z"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://upvideo.to/v/5393s9tykva0/"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/gbzmhdgd4md2/"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.mp4upload.com/vxv5nhdcvfga"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/zovoew2tt90i"
      }
     ]
    },
    {
     "name": "10",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=55&dl=UkVHVjc3Tk5Tek8yc1hmcW1GbjllQT09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=54&dl=K2E0U0NMOFV2Uy9PVXRVMXRGanprZz09"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://sblongvu.com/d/zxxniu4a4pq9.html"
      },
      {
       "name": "720p",
       "dowenload_url": "https://sblongvu.com/d/cxfaa57336zh.html"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://mega.nz/#!QW1mkbQA!e7fKLFLsLFSDpI7gvvOpqrOmWFch6uOuMLe6X3LXyfE"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!9XtBQBQS!d6-8gQ0Zoa4TwO8mRpQl1OpPuYMwtB5ZiQHoti6R7e8"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1O9HubjALOZc56r8D6pU9f04hiOdkah2Z&export=download"
      },
      {
       "name": "720p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1STxLYYHulZP4--RV2_hLK4UzAf17wTUs&export=download"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://disk.yandex.com/i/6gV0GxlgCzmJGw"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/Y4esjwhFGCyWzw"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.yourupload.com/watch/0wt35rFM3A20"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/36Dq4h2nVWM1"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.fembed.com/f/6q4mki0y8y2zd07"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.fembed.com/f/rqzd3ie5z5n68m0"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://upvideo.to/v/mmlxc4w4entx/"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/ctgxvhyxofwd/"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.mp4upload.com/twpas1mgdjag"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/5f8q8cts8pqa"
      }
     ]
    },
    {
     "name": "9",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=58&dl=SFIwejg5aVZwM3ZoTGNSb2ZiZmcxUT09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=4&dl=NUNKWmwrV2Z3TjlWYWNLUWdlaUN3UT09"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://sblongvu.com/d/6q21jfrfonj5.html"
      },
      {
       "name": "720p",
       "dowenload_url": "https://sblongvu.com/d/khrf3ancg7rg.html"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://mega.nz/#!peF0UArJ!XyChgYEvttTCtYlk8EpTLW-SBtPlJ7I5HEcddxOOP3w"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!gWcBVBDY!FaHvpAzRODvizcqaB3tIjnkhfCW_TkQvJC70by0Wji4"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=14S9cHIrPsmH8HKQtOyCUWyP0iDsIVNL_&export=download"
      },
      {
       "name": "720p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1kxkA5BOwo4adradAxHEWuMuZoNOPCbtV&export=download"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://disk.yandex.com/i/6Lkq5bBAeoCuTw"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/1NZX9_JICSA7_A"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.yourupload.com/watch/RpDRQ7pNRwii"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/h6u1hUwL4IAs"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.fembed.com/f/5z3ylid1z1mj7kl"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.fembed.com/f/7l6ykag030e6xld"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://upvideo.to/v/mufyufnlihw7/"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/m9qft8dvaxik/"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.mp4upload.com/kvvzvmk3p7jl"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/qz3tq5lcxezv"
      }
     ]
    },
    {
     "name": "8",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=56&dl=ZDhESFM3RDBTVDI0MXZHMm9wdGJnZz09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=52&dl=bjRYRHFVeHhzQzZtQU5Ta1c1YW1IQT09"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://sblongvu.com/d/6bv2lf2toq6y.html"
      },
      {
       "name": "720p",
       "dowenload_url": "https://sblongvu.com/d/kic54lzyreso.html"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://mega.nz/#!VLcRRR5Y!nJ-SMMMUbImtJ-_X_aEQO1oGMkLuU-gdiF8iUZJXDg4"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!FOE0DDIb!cj_rAdhs0ai2w_qbdrv65yjo4aaZ9-Rx0r5bwXDbBSY"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1MYZyV-hRTZae5teS7uaJ2ohaOIo--pfI&export=download"
      },
      {
       "name": "720p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1PTTzJFJQoWcXvieNcYGZNGsY1yv67_Ua&export=download"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://disk.yandex.com/i/xkqXjNS9Qe9yLA"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/pd-tRxutdcm7Iw"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.yourupload.com/watch/wt20Tog6BMV2"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/O370oATr67LI"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.fembed.com/f/p12r7hmz7g43g0d"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.fembed.com/f/41wrehz156w2rrd"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://upvideo.to/v/9z2fpghfxjxc/"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/wv7zqd7q7s3i/"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.mp4upload.com/p5xp8jurdne2"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/u3ciaqkp8dxz"
      }
     ]
    },
    {
     "name": "7",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=51&dl=d09zU2ZZcHFRb3IwdDVDSXJZQW5EQT09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=13&dl=L0s3bWE2MnBlTHBqOFl4RVVRTEpRUT09"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://sbanh.com/d/v935l1uuvgas.html"
      },
      {
       "name": "720p",
       "dowenload_url": "https://sbanh.com/d/xkagdzgjkg7s.html"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://mega.nz/#!gPFXwI7J!iWrUWjsPVm36yrpnFDUVKpepzOJp07Yyw9c8kmK2VWQ"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!sWkznASJ!gLbDkqzpZ4wpoOg7laKdLS5GVjxz7ZNhOZNeS70yDlk"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.solidfiles.com/v/pewzqRRv5pqNW"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.solidfiles.com/v/4QqpLVjv5gkd3"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1KVqeujr-q8AUSRBXzx6LxutMQ1b9Re_b&export=download"
      },
      {
       "name": "720p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1Qpb7Qe5NzPUG0_qk-DNLBbr3fNsPBw6B&export=download"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.yourupload.com/watch/ppBVdYsQvF6j"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/bdx378cBxBSu"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.fembed.com/f/zd4-1uj0n80j65-"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.fembed.com/f/5z3ylid1grm8-8-"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://upvideo.to/v/kfk8fpn9bkwf/"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/dkk5hnif0bjo/"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.mp4upload.com/kuh3cee3s8mz"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/0xtc5d0lt5x7"
      }
     ]
    },
    {
     "name": "6",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=11&dl=WXh2a21WNCtCdlBQVktpTDVScWtTdz09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=59&dl=Rnc0bWlhUW9ZQXFmTVQ2Z1BaUzNMQT09"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://sbanh.com/d/hqgwfk6ghq2u.html"
      },
      {
       "name": "720p",
       "dowenload_url": "https://sbanh.com/d/fqh9gzn3s2eg.html"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://mega.nz/#!FLUyRAzQ!rsm0jxUb3OYGP4JGQ7Qzca8Noz2OjEUti_n4vi0qbHw"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!sW8DDZDQ!xrfrmVaOMHTcXQsOUg9MwoEDguLBH7-83ZU-vGiOLXk"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=12HKAaElI3OQhcNlwJNopEGLFW5HItQm_&export=download"
      },
      {
       "name": "720p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1n9sJ8Po-0Xgw_xjWYP6HHd3W5cmGPVN0&export=download"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.yourupload.com/watch/fqh8VyV614e3"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/4w6677HDKPh1"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.fembed.com/f/l3d4etng1w00-6w"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.fembed.com/f/d18qyhxgy5l8klk"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://upvideo.to/v/ybnipswhfngt/"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/ufijniqerixs/"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.mp4upload.com/gidetb3rsn5o"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/gbtgj80b39wj"
      }
     ]
    },
    {
     "name": "5",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=11&dl=VnhtNVRvZEkrYXMwOXJPRUFia29jQT09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=60&dl=dmpuVGgzNjdnb2RvY3d3ZDV4RXZwZz09"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://sbanh.com/d/arvnsmvkl6jr.html"
      },
      {
       "name": "720p",
       "dowenload_url": "https://sbanh.com/d/atlny4mwha6v.html"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://mega.nz/#!FbUDDCiS!xb5iKtP5hUKFUMWeKQg3MObDrUaiUW4_oxfHLO_mHJI"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!9ClmXQDY!05dZE5lvAIAJdSYF3fIOkZSmlGpqnJspiUtkJ8x_4uo"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1RCV3iT-ca2HmTG8b91A6WK7L6w2u46ZW&export=download"
      },
      {
       "name": "720p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1w48cMAchM-edJBbKToeC5-73ZJPZNKeH&export=download"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.yourupload.com/watch/6e746JmJVrTY"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/0H0jwj3Ww4RD"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.fembed.com/f/kw7npa37nq64dpl"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.fembed.com/f/x3y0nt56x-k70p4"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://upvideo.to/v/dbdpbxizlhst/"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/kd6pwxpjvorp/"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.mp4upload.com/1x2yvcr77w4n"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/mx9stxsifuxs"
      }
     ]
    },
    {
     "name": "4",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=54&dl=ZlhJSS92V2V4N3ZoTWkrc2w4WnMxdz09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=1&dl=dmtUZUdxd2RQTGdpbTJKY0pVOG83UT09"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://mega.nz/#!1P8UEQQQ!79J4H-Yp-pqStJ0m-sON5-bCcqnQ_qG0m20_JOPQIFs"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!ZClGAKrT!kG2vFOBexhYjt9oIStbsFBUyQUghiqBGH7PxrNO--Yk"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1ZjzQMyWd59RZKOtlVZKh_WdEMjJBAhTr&export=download"
      },
      {
       "name": "720p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1ECPI5F4xWfQYL6SjlcpsIkuwxnOrVdXO&export=download"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://disk.yandex.com/i/31Z5FUtiTNQYTg"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/csgbvDOTzcSnYQ"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.yourupload.com/watch/28YSo1t3v374"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/d3s50hyF7Qc3"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.fembed.com/f/x3y0nt5g6pm77yy"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.fembed.com/f/ez801i-jpxm46jw"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://upvideo.to/v/krh0zrwnfiye/"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/ozdogffhi7p8/"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.mp4upload.com/vg4f2u54nuae"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/wgtx5tm23vq7"
      }
     ]
    },
    {
     "name": "3",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=55&dl=c2l3TXFTRDRLV0lEb0tsYlo4ajBaUT09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=54&dl=UURNem8zNHZ0MHRHWHlHUXE0Z24wZz09"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://mega.nz/#!c1FhWRqT!SXsA0WkJ06WU3woObpp6d90KbzYDn9mn0dqFCZxyO1I"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!9hdRUJQD!5GxKE7upM7V1qBO0GapYo6IfqqAEeu8-HnZku9QdE0o"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=12M4GIFnloBwcKCZ-YcpHraMdzXfBBU6-&export=download"
      },
      {
       "name": "720p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=15kEK8eA62bLNoqKFqUpoxUGA4DegEOUZ&export=download"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://disk.yandex.com/i/t3wsX4OdCl8Pyg"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/SzbGnUWBI0ED2w"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.yourupload.com/watch/U3MaCEQA1VY1"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/AY5e8nHe3JIX"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.fembed.com/f/gl8epa-7542kqr6"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.fembed.com/f/2dw1nu24mywxqkr"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://upvideo.to/v/88bfahf442zx/"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/bu44ltpbbok8/"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.mp4upload.com/6n937unrinw7"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/2bats21pagtu"
      }
     ]
    },
    {
     "name": "2",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=57&dl=b2g0Q3NzNUk4OStuK2QrbGZuTk85QT09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=5&dl=Szg4ZWVCcVJQWkxCaHo0dW5nSENldz09"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://sblanh.com/d/6zujb89geuv7.html"
      },
      {
       "name": "720p",
       "dowenload_url": "https://sblanh.com/d/8igm5skrzwxp.html"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://mega.nz/#!RPNi3KSb!R_WxanUGyxpDI_vsmm5W6BYr6VTOIid1ePbGJFVoup8"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!xGMSHLgB!MARHLUaA7j_o_5POEreaQc-CPeN3nZ14kl6q3Xy2dhI"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1_ZR8StT8pqyr1YnQ3upuQ1SRJHIhPuOb&export=download"
      },
      {
       "name": "720p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1itSWfVk4vGeMeUgVmkuSAnUT-Sa_OrNx&export=download"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://disk.yandex.com/d/A4W_1lAsXBq66w"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/Ggkjf8IRlLv47A"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.yourupload.com/watch/uvpBaXmh8O81"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/n2E0f00m0nKQ"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.fembed.com/f/03w1xtljzp73r4y"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.fembed.com/f/03w1xtljz2zmyq7"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://upvideo.to/v/iiqcq5gunekt/"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/tyfba0zkjhyc/"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.mp4upload.com/nxtla366i04x"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/k00xjv5opnw0"
      }
     ]
    },
    {
     "name": "1",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=58&dl=bVI1RmlYdEpRMDVnamtwNTVpTkNxZz09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=57&dl=K2g3bEp2M0tGcmlHcDRabGhRd0pLZz09"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://sblanh.com/d/m6yevjo6y5et.html"
      },
      {
       "name": "720p",
       "dowenload_url": "https://sblanh.com/d/q9ak739cj39i.html"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://mega.nz/#!RStyBA5K!52Wz4_5TKdpSpuNL80cR283pgeU2zL2JuWXFcCTblAY"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!tTUghaZJ!Mpr9xewq33r4E-aW0LjjkPZlJXVnutkxvx5GfW1SIB0"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.solidfiles.com/v/Ng5xNe2Q7jqea"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.solidfiles.com/v/WQMn3zKjzrkdp"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1_ooFD-OkyVAn7FOv9VEONPoxhmHtEKqT&export=download"
      },
      {
       "name": "720p",
       "dowenload_url": "https://drive.google.com/u/0/uc?id=1QP5LYtmD04R_GbBTTgNlGj9PbNRp3Wmh&export=download"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://disk.yandex.com/i/1fFuyXgqdk0vDw"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/_Wn_5Fx9SNSRRA"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.yourupload.com/watch/10cj1opN30mE"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/C4sdX0PN3ja3"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://www.fembed.com/f/p12r7hm-pd48j1q"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.fembed.com/f/6q4mki07ndg8k8e"
      },
      {
       "name": "1080p",
       "dowenload_url": "https://upvideo.to/v/lvvzjz1jdss9/"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/ocdmid3ckkqd/"
      }
     ]
    }
   ]
  },
  {
   "name": "Xie Wang Zhui Qi\nXie Wang Zhui Qi",
   "title": "Xie Wang Zhui Qi",
   "des": "هي ، قاتلة مشهورة في القرن الحادي والعشرين ، عبرت بالفعل لتصبح ملكة جمال رابعة الأكثر فائدة من لا شيء لسو مانور. هو ، سمو الإمبراطورية جين إمبراطورية ، كان طاغية شيطاني متعجرف بلا روح مع موهبة لا مثيل لها. عرف الجميع أنها كانت حمقاء وجيدة من أجل لا شيء ، وتتنمر عليها كما يحلو لها. ولكن هو فقط ، الطاغية المتغطرس بالعين المتميزة ، لن يتخلى عنها حتى لو كانت حياته تعتمد عليه. في الوقت الحالي ، دعنا نرى فقط كيف يتصادم العنيد مقابل العنيد ويلعب في هذا العرض الجيد للمطارد والمطارد.",
   "info": "الحالة: مكتمل الاستديو: BigFireBird Animation, KJJ Animation سنة الإصدار: 2019 المدة: 13 دقيقة. البلد: الصين النوع: أونا الحلقات: 13 تاريخ النشر: أكتوبر 3, 2022",
   "image": "https://i3.wp.com/animetitans.net/wp-content/uploads/Xie-Wang-Zhui-Qi.jpg?resize=247,350",
   "ep": [
    {
     "name": "13",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=60&dl=YmxnM3RaOERnUVdVemRnUkFSUkp4Zz09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://sblanh.com/d/gocvgk6vqklb.html"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!1KV0AarJ!bVYZMUv6ktYVu7P3s4Vwy1CoAQ-RRJes592w5AZ-ieE"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/BRNGyEh7-CvBaA"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/uto9dg9uc7ws/"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/EdvCtG0DAUR3"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.fembed.com/f/3rwqltm5qy-82y1"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/62qpeohmb1dv"
      }
     ]
    },
    {
     "name": "12",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=14&dl=ejduWGFnMUYyRmZnZ2pwMlJ3SytJQT09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://sblanh.com/d/309qiijq5682.html"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!ceEngQyT!Ce2JfxtXyJBpDsnVNOUAYjBPGgad0IwKN91oiPlY-W4"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/Npcwyn9wiPH5LQ"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/0x5fg6pk2a8h/"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/ftySxjI2x4FA"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.fembed.com/f/16wnlaje1pwk3-k"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/lhm4s0ra4tbt"
      }
     ]
    },
    {
     "name": "11",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=5&dl=RExCNFJLY2g1OFdXV3U3Nnc4TjVrZz09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://sblanh.com/d/5nrmpf04u7fc.html"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!9GkXgS7T!tB2f0p2wItnA51vl_s9mWInfWx9nEy4tEbcloK82K-I"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/vvfi8uBmRCJ_Vg"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/ttkgiq3e01qc/"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/8EEpJUK6iI7W"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.fembed.com/f/2dw1nu24w5x3xk2"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/ek9b1akfbb2g"
      }
     ]
    },
    {
     "name": "10",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=11&dl=WmdjZkk0SG1RMEhsMXE3cVdVMWdFQT09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://sblanh.com/d/yn1u0k8nscu5.html"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/g9JyWbR11JgxNQ"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/tlw9kkxezibk/"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/OoEoCnWduR78"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.fembed.com/f/5z3ylid3m5pd5jn"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/p1knz4xrrixh"
      }
     ]
    },
    {
     "name": "9",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=50&dl=UVk3U0RadzlvKzdjZUJId2tsaHVBZz09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://sblanh.com/d/exopsvucnoaq.html"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/Q4U9d-lrfM_43Q"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/j4myknwj1nvj/"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/NdOwXT7G5Baf"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.fembed.com/f/7l6ykag-erwgelg"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/ljwxl18zdap7"
      }
     ]
    },
    {
     "name": "8",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=57&dl=bVovWkVIRmVXNTQwclY1aDZqbjBDUT09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://sblanh.com/d/vamudu4r8i2v.html"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!RKkkmZ5B!rwADctgDefBCZ7ohek5qNkqwE7IAu85NDH34iNCxCf8"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/2wUokA3N8vouEw"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/uiset01zdtxs/"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/sK112hpUsg2t"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.fembed.com/f/ez801i-j236x6ng"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/bi42zfa19t2k"
      }
     ]
    },
    {
     "name": "7",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=1&dl=Y3hIcWI2eWhXTUZlM3N2MFV0bTMyZz09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://sblanh.com/d/g9r10sw3gvg1.html"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!kK1BlSqT!7_Kb75pc7YkLMrwu51HNPkyGR1OSwwT7hZ5ZhPCmL8M"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/Zt1J_wSzVQa9kw"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/pknkffny4ygm/"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/4OyDL7DDdjd3"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.fembed.com/f/p12r7hm-pjr8d67"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/p4yzlhoosfr6"
      }
     ]
    },
    {
     "name": "6",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=58&dl=QlFSajNNMCtzQTRBMUg3WXg0UjJUQT09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://sblanh.com/d/0r0v2pprf2u4.html"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!9HsF0a6B!BSBE7f1qle83MPODYbUZiBwumC1wU0MgomjK57LZvFE"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/k0sXmhH8LZQubQ"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/z4qgzblitwxb/"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/Xsww244Ovg8j"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.fembed.com/f/2dw1nu24w5x1xz2"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/slyupdfyse4o"
      }
     ]
    },
    {
     "name": "5",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=59&dl=Q1ExdGlFdU51Uk8xUThaTDhQQXhZZz09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://sblanh.com/d/9p6tr6tnsszn.html"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!YCETzbpT!xeUTxg6wsreNH70RI9bto87OA8v-ZrinVIznniGppzY"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/x9lehnKhLnhFhA"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/wbyfcu9c9hkv/"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/mwCF0ljg8Y2S"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.fembed.com/f/x3y0nt5ge0lq6yw"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/ihqb90e2n52z"
      }
     ]
    },
    {
     "name": "4",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=1&dl=bEVZdTRwSVM5MnhiT0JVSWlMejBxQT09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://sblanh.com/d/9k8i1e7xdn20.html"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!ZPM3jQrJ!17U_W0HLxFvOF8SaITZQEnKXKqrw2P6k2GSKkijnoFU"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/bCJ77eR0icyoEQ"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/bq7z6v8czckb/"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/2oRx4viDr1st"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.fembed.com/f/03w1xtljz1p75gp"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/zc0yhto1ca61"
      }
     ]
    },
    {
     "name": "3",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=50&dl=S3N0YkNZQnNRcVdTQk1oSXRwVkRzZz09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://sblanh.com/d/b7lxtmbhnjja.html"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!0a8hBRjA!OFo5SNTlJyce1BoGL34fymnKOiGJTvQRn7CQYiB2ZcQ"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/klY9BLByX5uTBQ"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/qw0ew3qayz2v/"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/mYWwO7PAQtL5"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.fembed.com/f/qzkrdiel1-q86kx"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/jx04ac5cav7g"
      }
     ]
    },
    {
     "name": "2",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=55&dl=R25NbUdKUnd1Q2xOc2lVbDhEN3YzUT09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://sblanh.com/d/kja0883cwdmd.html"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!FTtEEIoA!MlQggK-64119mk83Qr6V_rRX7ky1-Lo98frHsOLh7t8"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/sO3AhdVQqaAO0A"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/vz8wnzh5lj0h/"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/rH476ip8yw6w"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.fembed.com/f/kw7npa3p60k5dg0"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/yrg0dns5gmlf"
      }
     ]
    },
    {
     "name": "1",
     "servers": [
      {
       "name": "الجودة"
      },
      {
       "name": "720p",
       "dowenload_url": "https://titanshd.xyz/episode/download.php?n=56&dl=UHJUV3F4VWFYZlFHOTg1c0pWRlVwZz09"
      },
      {
       "name": "720p",
       "dowenload_url": "https://sblanh.com/d/x7wrn44ogfg9.html"
      },
      {
       "name": "720p",
       "dowenload_url": "https://mega.nz/#!sOcHDYQA!PhonOi_Cm8YT6iW5zDTOcCWmzs7mGZ8REcshd_GyihA"
      },
      {
       "name": "720p",
       "dowenload_url": "https://disk.yandex.com/i/e4_B_4JJxWnHGg"
      },
      {
       "name": "720p",
       "dowenload_url": "https://upvideo.to/v/5stvkrwyu9br/"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.yourupload.com/watch/WMYUefChO4cG"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.fembed.com/f/7l6ykag-erw31qe"
      },
      {
       "name": "720p",
       "dowenload_url": "https://www.mp4upload.com/fwcyzwqbhk61"
      }
     ]
    }
   ]
  }
 ]
}

anime = data['animes'][0]
title = anime['title']
description = anime['des']
episodes = anime['ep']
info = anime['info']

print(f"""
Title: {title}

Description:
{description}

info:
{info}
""")

for episode in episodes:
    print(episode['name'])
    # يمكنك القيام بأي شيء آخر تريده بهذه البيانات
    # على سبيل المثال، يمكنك الحصول على جميع عناوين URL المتاحة
    for server in episode['servers']:
        print(server['dowenload_url'])