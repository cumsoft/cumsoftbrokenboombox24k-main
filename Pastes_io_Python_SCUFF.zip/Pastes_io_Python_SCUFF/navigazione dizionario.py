x = data
check = 0
while check == 0:

    print(type(x))
    if isinstance(x, list):
        for key in range(len(x)):
            #print(key)

            try:              
                x = x[key]
                
                break

            except:
                print(type(x))
                print(x[key])
                check = 1



    elif isinstance(x, dict):
        for key in x:
            #print(key)
            try:
                x = x[key]
                
                break

            except:
                print(type(x))
                print(key)
                check = 1
                
    else:
        print(x)
        check = 1