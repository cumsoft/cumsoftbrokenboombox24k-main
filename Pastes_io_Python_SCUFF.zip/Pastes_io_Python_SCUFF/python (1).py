import random
imie = input("Podaj imię: ")
def punkt_pierwszy(x):
    dlugosc  = len(str(x))
    print("Liczba składa się z {} cyfr".format(dlugosc))
    suma = 0
    parzyste = 0
    nieparzyste = 0 
    for liczba in str(x):
        suma = suma + int(liczba)
        if(int(liczba)%2==0):
            parzyste += 1
        if(int(liczba)%2!=0):
            nieparzyste += 1
    print("Suma liczb wynosi: {}".format(suma))
    print("Ilość cyfr parzystych: {}".format(parzyste))
    print("Ilość cyfr nieparzystych: {}".format(nieparzyste))

def losowe_liczby():
    lista = []
    for r in range(10):
        losowa = random.randint(1, 10)
        lista.append(losowa)
    return lista

def losowa_liczba():
    liczba = random.randint(1,100)
    return liczba

def sekwencje(sekwencja):
    sekwencja_male = sekwencja.lower()
    wystapienia = {}
    lista_liter = list(sekwencja_male)
    for litera in lista_liter:
        if litera in wystapienia:
            wystapienia[litera] += 1
        else: 
            wystapienia[litera] = 1
    print(wystapienia)
    wystapienia_sorted = sorted(wystapienia.keys())
    for litera in wystapienia_sorted:
        print("{} : {}".format(litera, wystapienia[litera]))

while(True):

    print("Witaj {}".format(imie))
    print("Wybierz jedną z opcji: \n 1 - Liczba naturalna \n 2 - Listy \n 3 - Zgadnij liczbę \n 4 - Ilość liter \n 5 - Pliki \n 0 - Koniec pracy")
    opcja = int(input("Podaj liczbę: "))
    while(opcja>=6 or opcja<0):
        print("Podałeś złą opcję!")
        opcja = int(input("Podaj liczbę: "))
    if(opcja==0):
        break
    elif(opcja==1):
        naturalna = int(input("Podaj liczbę naturalną: "))
        while(naturalna<0):
            print("Podaj liczbę naturalną!")
            naturalna = int(input("Podaj liczbę naturalną: "))
        punkt_pierwszy(naturalna)
    elif(opcja==2):
        lista1 = losowe_liczby()
        lista2 = losowe_liczby()
        lista_wspolne = []
        lista_roznica = []
        print(lista1, lista2)
        for x in range(len(lista1)):
            if(lista1[x] in lista2):
                if lista1[x] not in lista_wspolne:
                    lista_wspolne.append(lista1[x])
            if(lista1[x] not in lista2):
                lista_roznica.append(lista1[x])
        print("Lista ze wspólnymi elementami: {}".format(lista_wspolne))
        print("Różnica list: {}".format(lista_roznica))
    elif(opcja==3):
        liczba = losowa_liczba()
        wpisana = int(input("Podaj liczbę z zakresu 1-100: "))
        wpisywane = []
        proby = 0
        while(liczba!=wpisana):
            if(liczba>wpisana):
                print("Podana liczba jest mniejsza od wylosowanej. ")
                proby += 1
                wpisywane.append(wpisana)
                wpisana = int(input("Podaj liczbę z zakresu 1-100: "))
            elif(liczba<wpisana):
                print("Podana liczba jest większa od wylosowanej. ")
                proby += 1
                wpisywane.append(wpisana)
                wpisana = int(input("Podaj liczbę z zakresu 1-100: "))
        wpisywane.append(wpisana)
        proby += 1
        print("Podałeś prawidłową liczbę! ")
        with open('los.txt', 'w') as file:
            file.write("Liczby wpisane: ")
            file.write("\n")
            for num in wpisywane:
                   file.write(str(num)) 
                   file.write(" ")
            file.write("\n")
            file.write("Proby: ")
            file.write("\n")
            file.write(str(proby))
        wpisywane = []
        proby = 0
    elif(opcja==4):
        sekwencja = input("Wpisz sekwencję: ")
        if sekwencja.isalpha():
            sekwencje(sekwencja)
        else:
            print("Podano zły ciąg znaków. ")
    elif(opcja==5):
        with open("osoby.txt", "r") as file:
            with open('dane.txt', 'w') as output_file:
                for line in file:
                    imie, nazwisko, wiek = line.strip().split(' ')
                    print("{} {} {}".format(imie, nazwisko, wiek))
                    inicjaly = ''.join([x[0].upper() for x in (imie + " " + nazwisko).split()])
                    plec = nazwisko[-1]
                    if(plec=='a'):
                        plec = "K"
                    else:
                        plec = "M"
                    if (int(wiek)>=18):
                        status = "osoba pelnoletnia"
                    else:
                        status = "osoba niepelnoletnia"
                    output_file.write("{} - {} - {} \n".format(inicjaly, plec, status))
                print("Dane osob zostaly zapisane.")