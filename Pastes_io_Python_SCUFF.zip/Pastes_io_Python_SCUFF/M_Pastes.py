#!/usr/bin/python
#Original written By Mogid Khan
#MKT(Mogid Khan Termux) Brand
#Feel MKT POWER

import requests,os

logo="""\033[1;94m
 _  _ ___  ____ ____ ___ ____ ____ 
 |\/| |__] |__| |__|  |  |___ [__  
 |  | |    |  | |  |  |  |___ ___] 
 @\033[3;96mMogid Khan\033[0;1m"""


def create():
  os.system('clear')
  print(logo)
  file=input("\n (?) File Path >> ")
  content=open(file,"r").read()
  url = "https://pastebin.mozilla.org/"
  headers = {
      "Host": "pastebin.mozilla.org",
      "content-length": "141",
      "cache-control": "max-age=0",
      "upgrade-insecure-requests": "1",
      "origin": "https://pastebin.mozilla.org",
      "content-type": "application/x-www-form-urlencoded",
      "user-agent": "Mozilla/5.0 (Linux; Android 10; Mi A2 Lite Build/QKQ1.191002.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36",
      "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
      "x-requested-with": "com.android.chrome",
      "sec-fetch-site": "same-origin",
      "sec-fetch-mode": "navigate",
      "sec-fetch-user": "?1",
      "sec-fetch-dest": "document",
      "referer": "https://pastebin.mozilla.org/",
      "accept-encoding": "gzip, deflate, br",
      "accept-language": "en-GB,en-US;q=0.9,en;q=0.8",
      "cookie": "csrftoken=XSFZtE7Sj0L51eCdb32UTOJfo3v80zFYq2X52cAdFvW47lsDMdAXv7xOnG3pLhya"
  }
  data = {
      "csrfmiddlewaretoken": "BtUvgs6SdT4x0KAaTP2yyCKWhiYMJWPo4DcBP0zdzofw6RqAuZABaVyvgVw3uEIA",
      "title": "",
      "lexer": "python",
      "expires": "2073600",
      "content": content
  }
  response = requests.post(url, headers=headers, data=data, allow_redirects=False)
  try:
    link=url+response.headers["location"][1:]
    print("\n Paste Link >> \033[3;92m",link,"\033[0;1m")
    print(" Raw Data >> \033[3;92m",link+"/raw","\033[0;1m")
    open("/sdcard/mpastes.txt","a").write(f"{link}\t{link+'/raw'}\n")
    print(" Saved in >> \033[3;92m","/sdcard/mpastes.txt","\033[0;1m")
  except:print(" Failed to Paste")
  input("\n (?) Continue > ")

while True:
  create()