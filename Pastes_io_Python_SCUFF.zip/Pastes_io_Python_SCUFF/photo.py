# Import the modules
import os
import random
import requests
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

# Define the scopes and credentials for accessing Google Photos API
SCOPES = ['https://www.googleapis.com/auth/photoslibrary.readonly']
CLIENT_SECRET_FILE = 'client_secret.json' # Replace this with your own file path

# Create a flow object and get the authorization code from the user
flow = InstalledAppFlow.from_client_secrets_file(CLIENT_SECRET_FILE, SCOPES)
credentials = flow.run_console()

# Build a service object for interacting with the API
service = build('photoslibrary', 'v1', credentials=credentials)

# Define the start and end time for filtering the images (in RFC 3339 format)
start_time = '2020-01-01T00:00:00Z' # Replace this with your own value
end_time = '2020-12-31T23:59:59Z' # Replace this with your own value

# Define the number of images to download and the directory to save them
num_images = 10 # Replace this with your own value
save_dir = 'images' # Replace this with your own value

# Create a list to store the image ids and file names
image_ids = []
image_names = []

# Create a filter object for the API request based on the date range
filter_body = {
  "filters": {
    "dateFilter": {
      "ranges": [
        {
          "startDate": {
            "year": int(start_time[:4]),
            "month": int(start_time[5:7]),
            "day": int(start_time[8:10])
          },
          "endDate": {
            "year": int(end_time[:4]),
            "month": int(end_time[5:7]),
            "day": int(end_time[8:10])
          }
        }
      ]
    }
  }
}

# Loop through the pages of results from the API and append the image ids and file names to the list
page_token = None
while True:
  response = service.mediaItems().search(body=filter_body, pageToken=page_token).execute()
  if 'mediaItems' in response:
    for media_item in response['mediaItems']:
      image_ids.append(media_item['id'])
      image_names.append(media_item['filename'])
  if 'nextPageToken' in response:
    page_token = response['nextPageToken']
  else:
    break

# Check if there are enough images in the date range, otherwise raise an exception or print a message
if len(image_ids) < num_images:
  raise Exception(f"Only {len(image_ids)} images found in the date range, need at least {num_images}")
  # Alternatively, you can print a message and exit instead of raising an exception
  # print(f"Only {len(image_ids)} images found in the date range, need at least {num_images}")
  # exit()

# Randomly select num_images from the list of image ids and file names 
selected_ids = random.sample(image_ids, num_images)
selected_names = [image_names[image_ids.index(id)] for id in selected_ids]

# Loop through the selected ids and names and download each image using its base URL from the API 
for i in range(num_images):
  id = selected_ids[i]
  name = selected_names[i]
  
  # Get the media item object from the API using its id 
  media_item = service.mediaItems().get(mediaItemId=id).execute()
  
  # Get the base URL of the image 
  base_url = media_item['baseUrl']
  
  # Append '=d' to get an uncompressed version of each image 
  url = base_url + '=d'
  
  # Get a response object from sending a GET request to each url 
  response = requests.get(url)
  
   # Check if there is any error in downloading each image, otherwise save it to disk 
   if response.status_code != requests.codes.ok:
     print(f"Error downloading image {name}: {response.status_code}")
     continue
   
   else:
     # Get some info about each image such as size, extension, etc. 
     size_in_bytes= len(response.content)
     size_in_mb= round(size_in_bytes / (1024 *1024),2)
     extension= name.split('.')[-1]
     
     # Format a new file name according to specifications  
     new_name= f"{name}_{size_in_mb}.{extension}"
     
     print(f"Downloading image {name} as {new_name}")
     
     try:
       os.makedirs(save_dir)   
     except FileExistsError:
       pass
    # Write each binary content as an image file to disk 
    with open(os.path.join(save_dir,new_name),'wb') as f:
      f.write(response.content)🛑