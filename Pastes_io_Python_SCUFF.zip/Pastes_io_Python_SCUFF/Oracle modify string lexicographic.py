class Solution:
    def removeDuplicateLetters(self, s: str) -> str:
        vis=set()
        last = defaultdict(int)
        
        for i,j in enumerate(s): last[j]=i
        st=[]
        for i,j in enumerate(s):
            if j not in vis:
                while st and last[st[-1]]>i and st[-1]<=j:
                    vis.discard(st.pop())
                st.append(j)
                vis.add(j)
        return ''.join(st)