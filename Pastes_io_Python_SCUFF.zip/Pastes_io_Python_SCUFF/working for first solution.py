from z3 import *

order = 2
rs = order**2 + order + 1
cs = order + 1

fpp = ((2, 4, 6),
    (1, 4, 5),
    (4, 3, 7),
    (1, 2, 3),
    (7, 5, 2),
    (6, 7, 1),
    (3, 6, 5))

# rs x cs matrix of integer variables
X = [ [ Int("x_%s_%s" % (i+1, j+1)) for j in range(cs) ] 
      for i in range(rs) ]

def oneOf(x, lst):
    return Or([x == e for e in lst])

row_elems_c = [ oneOf(X[i][j], fpp[i]) for i in range(rs) for j in range(cs) ]

# each row contains a digit at most once
rows_c   = [ Distinct(X[i]) for i in range(rs) ]

# each column contains a digit at most once
cols_c   = [ Distinct([ X[i][j] for i in range(rs) ]) 
             for j in range(cs) ]

my_c = row_elems_c + rows_c + cols_c

s = Solver()
s.add(my_c)
if s.check() == sat:
    m = s.model()
    r = [ [ m.evaluate(X[i][j]) for j in range(cs) ] 
          for i in range(rs) ]
    print_matrix(r)
else:
    print ("failed to solve")

# num_solutions = 0
# while s.check() == sat:
#     num_solutions += 1
#     m = s.model()
#     r = [ [ m.evaluate(X[i][j]) for j in range(cs) ] 
#           for i in range(rs) ]
#     print_matrix(r)
#     s.add(Not(X == r))