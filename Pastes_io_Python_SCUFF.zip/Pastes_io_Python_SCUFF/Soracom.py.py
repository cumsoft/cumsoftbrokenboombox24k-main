import time
import json
import redis, csv, json, requests,os
import subprocess

from get_auth import get_auth 

timer = 15

cont = {}
alarms = {}


def test_service():

    try:
        api_key, token = get_auth()
        return True
    except:
        print(f"No Modem Service Found!")
        return False

headers = {
        'Accept': 'application/json',
        'X-Soracom-Api-Key': api_key,
        'X-Soracom-Token': token
    }


def get_json():

    json_file = '/home/pi/python/controller.json'

    try:
        with open('/home/pi/python/controller.json') as json_file:
            c = json.load(json_file)

    except Exception as err:
        print(f'Cannot load Controller Object! - {err}')

    return c


def get_modem():

    modem_str = subprocess.getoutput('mmcli -m 0 -J')
    modem = json.loads(modem_str)

    json_formatted_str = json.dumps(modem, indent=4)
    #print(json_formatted_str)

    return modem


def save_local_file(local_file):

    '''
    
    Write data to a file on local drive

    '''

    #cont, alarms = get_redis()

    f_local = open("/home/pi/python/logfile2.csv","a")

    csv_writer = csv.writer(f_local)
    csv_data = csv_writer.writerow(local_file.values())
   
    f_local.close()        


def transmit_data(cont):

    '''
    Send the current data to Soracom

    '''


    #DEBUGGING = cont['debugging']

    pressure = round(cont['pressure'],2)
    current = round(cont['current'],2)
    temp = round(cont['temp'],2)

    payload = {'id' : cont['gmid'],'s':cont['seq'], 'p':pressure, 'r':cont['runcycles'], 'f':cont['faults'], 'm':cont['mode'], 't':temp, 'c':current}

    try:
        response = requests.post("http://unified.soracom.io", data=json.dumps(payload), headers=headers, timeout=5)
    except requests.exceptions.ConnectTimeout:
        print("Error: Connection timeout. Is the modem connected?")
 
    save_local_file(payload)


def main():

    cnt = 1
    
    if test_service():

        modem = get_modem()
        #rconn.set("modem",json.dumps(modem))

        print(modem)
        signal_quality = modem['modem']['generic']['signal-quality']['value']

        print(f'Signal Quality: {signal_quality}')


        while True:

            print(f"Transmitting...{cnt}" )

            cont = None
            cont = get_json()

            if cont:
                transmit_data(cont)

            cnt+=1

            time.sleep(timer)

    else:

        time.sleep(10)
        main()



if __name__ == '__main__':
    main()