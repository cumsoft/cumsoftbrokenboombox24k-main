import socket
import ssl
import datetime
from urllib.parse import urlparse
from dateutil import parser
 
 
def notification(days):
    print(f"Пора обновить сертификат. Дней до истечения: {days}")
 
 
def check_ssl_expiry(domain):
    try:
        context = ssl.create_default_context()
        conn = context.wrap_socket(socket.socket(socket.AF_INET), server_hostname=domain)
        conn.settimeout(3.0)
 
        with conn:
            conn.connect((domain, 443))
            cert = conn.getpeercert()
 
            expiry_date = parser.parse(cert['notAfter'])
 
            days_until_expiry = (expiry_date.replace(tzinfo=None) - datetime.datetime.utcnow()).days
            print(f'Дней до истечения: {days_until_expiry}')
            if days_until_expiry < 30:
                notification(days_until_expiry)
 
    except (ssl.CertificateError, ssl.SSLError, socket.timeout, ConnectionRefusedError) as e:
        print(f"Ошибка при проверке SSL: {e}")
 
 
url = "https://shandy-dev.ru"
parsed_url = urlparse(url)
domain = parsed_url.netloc
 
check_ssl_expiry(domain)