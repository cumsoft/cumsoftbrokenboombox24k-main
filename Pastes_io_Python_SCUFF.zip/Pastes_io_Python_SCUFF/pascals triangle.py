def generate_pascals_triangle(num_rows):
    triangle = [[1] * (i + 1) for i in range(num_rows)]

    for i in range(2, num_rows):
        for j in range(1, i):
            triangle[i][j] = triangle[i - 1][j - 1] + triangle[i - 1][j]

    return triangle

def print_pascals_triangle(triangle):
    for row in triangle:
        print(" ".join(map(str, row)))

# Example: Generate Pascal's Triangle with 5 rows
num_rows = 5
pascals_triangle = generate_pascals_triangle(num_rows)

print("Pascal's Triangle:")
print_pascals_triangle(pascals_triangle)