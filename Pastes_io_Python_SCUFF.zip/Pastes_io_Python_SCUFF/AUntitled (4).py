import systemd.daemon

def create_and_start_transient_unit(unit_name, unit_content):
    # Create the transient unit
    with systemd.daemon.TransientUnitManager() as manager:
        unit = manager.load_from_string(unit_name, unit_content)
        unit.store()
        print(f"Transient unit '{unit_name}' created successfully.")

    # Start the transient unit
    unit = systemd.daemon.SystemdUnit(unit_name)
    unit.start()
    print(f"Transient unit '{unit_name}' started successfully.")

if __name__ == "__main__":
    unit_name = "example-transient.service"
    unit_content = """
    [Unit]
    Description=Example Transient Service

    [Service]
    Type=oneshot
    ExecStart=/bin/echo "Hello from transient service"
    """
    create_and_start_transient_unit(unit_name, unit_content)