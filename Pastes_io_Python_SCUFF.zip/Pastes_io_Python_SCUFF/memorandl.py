#!/bin/sh

base='https://memorandom.verdebinario.org/rnd'

urls='
	stowdy
	iomstb
	neovma
	dyunnf
	lpunds
	cogtre
	plwmny
	apovvr
	ecpmza
	yhcxxu
	mwpvhe
	cdwskj
	'

i=1

for path in $urls; do
	dir=$(printf '%02d' $i)
	mkdir -p "$dir"
	page=$(printf '%s/%02d_%s.php' $base $i $path)
	while [ $(ls "$dir" |wc -l) -lt 6 ] ; do
		curl --output-dir "$dir" -O "$base/$(curl -s $page |awk -F '"' '{print$6}')"
	done
	i=$((i+1))
done