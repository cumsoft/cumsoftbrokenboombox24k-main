# boilerplate code
import pygame # import pygame module

# pygame setup
pygame.init()
screen = pygame.display.set_mode((800,600)) # set size of screen, 800 pixels width, 600 pixels height

running = True # condition for infinite while loop

while running:
    # for loop for events (i.e. key pressed)
    for event in pygame.event.get(): # condition to quit the game
        if event.type == pygame.QUIT:
            running = False
    screen.fill("purple") # change the background fill to purple
    # render your game here
    pygame.display.update() # make sure screen refreshes every time