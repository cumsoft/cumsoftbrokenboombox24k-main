import subprocess as sp
import sys
import os
import time

def runAlone(exe) :
    if exe.endswith(".py"):
        process = sp.Popen(["python3.8", exe], stdout = sp.PIPE, stderr = sp.PIPE)
    else:
        process = sp.Popen([exe], stdout = sp.PIPE, stderr = sp.PIPE)
    start = time.time()
    stdout, _ = process.communicate()
    end = time.time()
    stdout = stdout.strip()
    for line in  stdout.strip().decode().splitlines() :
        print(line)
    return end - start

def runWithInput(exe, inData, exData) :
    if exe.endswith(".py"):
        process = sp.Popen(["python3.8", exe], stdin=sp.PIPE, stdout = sp.PIPE, stderr = sp.PIPE)
    else:
        process = sp.Popen([exe], stdin=sp.PIPE, stdout = sp.PIPE, stderr = sp.PIPE)
    start = time.time()
    stdout, _ = process.communicate(inData.encode())
    end = time.time()
    outLines = stdout.strip().decode().splitlines()
    exLines = exData.strip().splitlines()
    correct = outLines == exLines
    if correct == False :
        print("   wrong ---")
        for d, c in zip(outLines, exLines) :
            print(f"{d} {c} {'' if d==c else '---'}")
        print("all output:")
        for d in outLines :
            print(d)
        #last = outLines[0][-1]
        #exLast = exLines[0][-1]
        #print(f"my last {ord(last)}  ex last {ord(exLast)}")
        print("fail")
    return (correct, end - start)

if len(sys.argv) < 2 :
    exit()

exe = sys.argv[1]
if os.path.exists(exe) == False :
    print(f"exe {exe} does not exist")
    exit(0)

testCaseFolder = ""
if len(sys.argv) >= 3 :
    testCaseFolder = sys.argv[2]

if os.path.exists(testCaseFolder) :
    for fileName in os.listdir(testCaseFolder) :
        if fileName.endswith(".in") :
            outFileName = f"{os.path.splitext(fileName)[0]}.out"
            with open(os.path.join(testCaseFolder, fileName)) as inF :
                inData = inF.read()
                with open(os.path.join(testCaseFolder, outFileName)) as outF :
                    outData = outF.read()
                    correct, duration = runWithInput(exe, inData, outData)
                    print(f"input: {fileName}, output: {outFileName}, duration: {duration}")
                    if correct == False :
                        break
else :
    duration = runAlone(exe)
    print(f"duration: {duration}")