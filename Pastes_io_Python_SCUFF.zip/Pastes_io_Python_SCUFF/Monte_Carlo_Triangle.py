import matplotlib.pyplot as plt
import random

def area_of_triangle(n):
    num_points_in_triangle = 0
    num_points_total = 0
    
    plt.figure(figsize=(10,10))
    
    for _ in range(n):
        x = random.uniform(0,1)
        y = random.uniform(0,1)
        if x+y <= 1:
            num_points_in_triangle += 1
            plt.scatter(x,y, color='r')
        num_points_total += 1
    return (num_points_in_triangle/num_points_total)
 
print(area_of_triangle(1000))