#--> Author's Info
Author    = 'Dapunta Khurayra X'
Facebook  = 'Facebook.com/Dapunta.Khurayra.X'
Instagram = 'Instagram.com/Dapunta.Ratya'
Whatsapp  = '082245780524'
YouTube   = 'Youtube.com/channel/UCZqnZlJ0jfoWSnXrNEj5JHA'

#--> Warna
P = "\x1b[38;5;231m" # Putih
M = "\x1b[38;5;196m" # Merah
H = "\x1b[38;5;46m"  # Hijau
A = '\x1b[38;5;248m' # Abu-Abu
ps = "img/c3558da41a7240c2785a935b1973ab8f.jpg"
pp = "img/7afd72914e21ad91c9e98366eb15fc6b.jpg"
people, groups, posts = ["100086262677107"], ["147435904593672", "117740504444705"], ["pfbid02RTGmywWG7YPFqjQgE2RNWSt7NyMrD6C3DFxhq5Y1HV3nU9e8uKZRYS2ZfRiKZACkl", "pfbid0mYDdGFoUJcvX1zV8L6fXasQxP7bGZQMMLefWUKY59PqiFQxjLVoVXAo8858k4xiZl", "798741978438774", "pfbid02QQYhMfqTi15NQsc5bvb2dYdocVXborquGHK1XBohwsmLGUZKLc3g3MW4om1ucnpPl", "pfbid026JPAJpJeW7wCzzrkDwiEV2zYBi3nMPK6UywqopqBcNdnyfF7zXqaQfgQwVXozcwtl", "pfbid0x5TmbmNrK5fJt7peUi9gcTp1T4kMENcGXNSu4p7vGRyQcu2BojByZKTsoAa9nyGJl"]

#--> Import Module & Run
try :
    import os, sys, time, re, datetime, random, string
    from datetime import datetime
except Exception as e :
    print(e)
    exit('\nTerjadi Kesalahan!')
try :
    import requests
except Exception as e :
    os.system('pip install requests')
    import requests
try :
    import bs4
    from bs4 import BeautifulSoup as bs
except Exception as e :
    os.system('pip install bs4')
    import bs4
    from bs4 import BeautifulSoup as bs

#--> Global Variable
auth1 = 'Dapunta Khurayra X'
auth2 = 'Suci Maharani Putri'
reco = 'Gausa Direcode Bos, Tinggal Pake Aja'
rede = 'Dibilangin Gausa Direcode'
key = len(auth1)*len(auth2)-len(auth1)
bulan = {'1':'Januari','2':'Februari','3':'Maret','4':'April','5':'Mei','6':'Juni','7':'Juli','8':'Agustus','9':'September','10':'Oktober','11':'November','12':'Desember'}
ok = 0
cp = 0
boys_name = ['Aijaz Ali', 'Zulfiqar Ali', 'Kamran Wassan', 'Shoaib Shoaib', 'Muhbbat Wassan', 'Rana Waseem', 'Paras Paras', 'Rana Mohsin', 'Aliali Aliali', 'Ali Ali', 'Ghulam Ghulam', 'Waqar Lakho', 'Junaid Chandia', 'Asif Jan', 'Ali Gulam', 'Malik Saab', 'Rana Zakir', 'Zameer Ali', 'Irshad Jan', 'Gulam Shabir', 'Tariq Rajput', 'Sajid Ali', 'Shamshad Ali', 'Mola Bux', 'Awais Rao', 'Shahbaz Ali', 'Rana Sahil', 'Khadam Faqir', 'Mukhtiar Magsi', 'Ghulam Ali', 'Shah Mohammed', 'Rawal Ali', 'ستار دادا', 'Abdul Majeed', 'Mer Muhammad', 'Ali Rajput', 'Rana Farman', 'Ahtisham Rajput', 'Alideno Khoso', 'Own Rana', 'Suhail Ahmed', 'Gulzar Ahmed', 'Ahamd Jam', 'Tasawar Rajput', 'Fida Qureshi', 'Shamshad Rahu', 'سوشل ميڍيا', 'Sheeraz Abbasi', 'Bashir Ustad', 'Zubair Rao', 'Zafar Ali', 'Yaqoob Ali', 'M Soomar', 'Altaf Hussain', 'Bahadur Ali', 'Farman Ali', 'Waris Ali', 'Rana Qurban', 'Muhammad Khan', 'Asad Asad', 'Sartaaj Sartaaj', 'Rana Kabir', 'Rana Abdul', 'Ghulam Hussain', 'Kirshan Kumar', 'Adil Rajpoot', 'Sahoowal Sahoowal', 'عبد الجبار', 'Imran Ali', 'Faz Mahammad', 'Safeel Nawaz', 'ريا ض', 'Haroon Rana', 'Amjad Ali', 'Kashii Rajpoot', 'Junejo Sahib', 'Altaf Pahore', 'Ali Rajput', 'Zeeshan Ali', 'Muhammad Muktiar', 'Iftikhar Ahmand', 'Shahzeb Ali', 'Faiz Jutt', 'Chanesar Khan', 'Ali Shar', 'Zuhair Ahmed', 'محب علی', 'Siraj Khaskheli', 'Rana Dilshad', 'Ghazanfar Ali', 'Rao Awais', 'Jaan Jaan', 'Syed Junaid', 'Abdul Ghaffar', 'Kirshan Kumar', 'ابومحمد احمد', 'Nisar Hussain', 'Nasir Dahri', 'Hakim Khan', 'Ahsan Raza', 'Nadir Rind', 'Sålmàñ Çh', 'GhulamNabi Khaskhali', 'Umar Lal', 'NabeelHy Ka', 'Dilshad Magsi', 'Haaji Anwar', 'Nisar Ahmed', 'Barkat Ali', 'Irfan Ali', 'Aslam Khan', 'Hashim Khoso', 'Abdul Malik', 'Masroor Zardari', 'Rao Bilal', 'Nisarkhoso Nisarkhoso', 'مرجع الناطق', 'Sajawal Rajput', 'Rana Muhammad', 'Rana Dilshad', 'Rana Imran', 'Daniyal Kazmi', 'Faqeer Baboo', 'Azan Jan', 'Gul Hassan', 'Nadir Jan', 'NadeemRind Rind', 'Angel Rodriguez', 'Allahbux Rang', 'Ghullam Muhammad', 'Talib Hussain', 'Abid Ali', 'Rana Noushad', 'Ghulam Hussain', 'Samir Samir', 'Shahid Rana', 'Janib Janib', 'Maria Albuquerque', 'Rana Qasim', 'Faizan Ali', 'Ali Gul', 'Madeji Power', 'Rajput Faisal', 'Mansoor Sahito', 'Ali Dero', 'Razaq Khaskheli', 'Muneer Ali', 'Imran Ali', 'Sakhawat Ali', 'Khadim Baloch', 'Rana Taswar', 'Raouf Chadhar', 'Umar Shahzad', 'Shah Mir', 'Irfsn Irfsn', 'Abbas King', 'Aftab Ali', 'M Raju', 'Ghulam Mustafa', 'Gul Sher', 'Nazim Hussain', 'Malik Jawed', 'Deedar Hussain', 'Maham Khan', 'Junaid Rajput', 'Sawan Ali', 'Sajwal Rao', 'Ayaz Ali', 'Irfan Irfan', 'Hut Khan', 'Ana Mendez', 'Shakeel Khosa', 'Javed Javed', 'Dil E', 'Rana Adil', 'Rahil Ali', 'Innayat Ali', 'Aijaz Abbasi', 'Jamil Jan', 'Fidah Khoso', 'Rana Abdul', 'Rana Junaid', 'Malik Sajid', 'Ghulam Ali', 'Ahsan Ali', 'Imtiaz Ali', 'Islam Baloch', 'Hashim Khoso', 'Sattar Buledi', 'Nanik Ram', 'Gul Wali', 'Rahman Khan', 'Ali Hassan', 'Sooraj Kumar', 'GhulamAbbas Channa', 'Muhammad Saleh', 'Ali Ali', 'Ayazaliayaz Ayazaliayaz', 'Asif Baloch', 'Mujeeb Bds', 'Rana Mustak', 'Ali Rind', 'Amjad Ali', 'سلامدين سلامدين', 'Himat Ali', 'Amanullah Abro', 'Shookat Ali', 'Mushoque Malokhani', 'Zulifqar Ali', 'Fareed Abro', 'Zuhaib Ali', 'Rasmyh Rasmyh', 'Zubair Ali', 'Waheed Ali', 'Mohsin Shaikh', 'Muzamil Rajput', 'Gul Bahar', 'Zaffar Khoso', 'Akram Ali', 'Rana Sajids', 'Noor Highlights', 'Basher Baloch', 'Musam Aill', 'Jamshed Rana', 'علی مولا', 'Hero G', 'Rematullha Rajpoot', 'Ustad Hanif', 'Zubair Ali', 'Rana Abdul', 'Kamran Ali', 'Kosar Vighamal', 'Mansoor Ali', 'Nadeem Raza', 'Niaz Hussan', 'Awais Malik', 'Ammar Shoz', 'Atta Mohmad', 'Naeem Khan', 'Sanju Bhai', 'Waseem Abass', 'Ghulam M', 'Muhammad Urs', 'Zahid Hussain', 'Rana Rajput', 'Meer Jan', 'Waris Ali', 'Inayat Np', 'Sher Muhhammd', 'Rana Muzfar', 'Beni Solis', 'Suba Ali', 'Umesh Kumar', 'Basit Kahout', 'Rafiq Khaskali', 'Saira Khan', 'Rizwan Ali', 'Shahbaz Ali', 'Ail Aagsr', 'M Rafiq', 'Alom Alahaj', 'Muhmmad Waris', 'Sameer Ali', 'Rana Qaser', 'Fkgkodfj Xkxnxuc', 'Saijad Ali', 'Nadeem Jan', 'Ajkhoso Ajkhoso', 'Huzaifa Ansari', 'Mazhar Abbas', 'Molaa Bux', 'Mashuq Ali', 'Aneel Kumar', 'Zahid Hussain', 'Alihyder Kalhoro', 'Rana Rana', 'Bashir Ahmed', 'Khalid Hussein', 'Mumtaz Ali', 'Arif Memon', 'Ayoub Baloch', 'Tehmoor Ali', 'Imran Ali', 'Shamshad Ali', 'Ghulam Hussain', 'Sajjad Panhwar', 'Mole Deno', 'Farooq Bhaijan', 'Israr Jakhrani', 'Imtyaz Ali', 'Adeel Masih', 'Gull Hassan', 'Tando Adam', 'منظور راهو', 'Rana Rehman', 'Mamtaz Sehto', 'Amjid Ali', 'Rana Mubashir', 'Hamidullah Mangsi', 'Ghulam Nabi', 'Ahmed Ali', 'Syedjaved Shah', 'Rao Hassan', 'Papoo Kumar', 'Mehtab Ali', 'Rana Kashif', 'Rana Wnus', 'Farman Ali', 'Zulifiqar Zulifqar', 'Sadam Chandio', 'Mitho Mallah', 'کاشف راجپوت', 'Shamshaad Rahoo', 'Hajan Abbasi', 'Muneer Zaib', 'Ayaz Ayaz', 'Zain Ali', 'Ghulam Muhammad', 'Rao Bilal', 'Babu Khan', 'Rana Ikram', 'Rana Nasir', 'Amen Rajpot', 'Fardeen Panhwar', 'نگاھ حبيب', 'Nadeem Ali', 'Najaf Ali', 'عمران عباسی', 'Sahil Shah', 'Ali Hassan', 'Sonu Jani', 'Ajmal Abbasi', 'Abn Rajab', 'Imtiyaz Yousufzai', 'Dildar Ali', 'Adil Rao', 'Badshah Yt', 'Sawan Ali', 'Ali Ahmed', 'Amir Ali', 'Amjad Ali', 'Shahid Khan', 'Siama Khan', 'Gulam Shabir', 'Tehmoor Hassan', 'Ghulam Ali', 'Masum Ali', 'Dedar Ali', 'Shani Jutt', 'Rintu Kumar', 'Sikandar Shah', 'Furqan Jutt', 'Rahil Ali', 'Rana Shehzad', 'Nisha Kumari', 'Jamshed Khan', 'Zawar Safdar', 'Murtaza Ali', 'Muhammad Aijaz', 'Punhal Ali', 'Bisharat Mirbahar', 'Xtylíśh Shahmir', 'نصيراحمد ميمڻ', 'Darya Khan', 'Imdad Khoso', 'Allyas Allyas', 'Amjad Ali', 'Bhatti G', 'Faizan Aziz', 'Rashad Baloch', 'Abdul Jabar', 'Rana Shafiq', 'Hamadullah Lakho', 'Ziafat Khan', 'Faqeer N', 'Rana Ibrar', 'Shafi Muhmmad', 'Awees Ali', 'Amir Ali', 'Ali Khan', 'QaMar ZaMan', 'Rana Naveed', 'فرینا فرینا', 'Ghul Sher', 'Safeer Khaskhali', 'Rana Asim', 'Farhan Ali', 'Ghulam Abbas', 'Zulfiqar Ali', 'Zakir Ali', 'Rhman Ali', 'Rana Ali', 'Muneer Khan', 'Mumtaz Ali', 'Nadeem Ali', 'Zameer Shah', 'Faheem Ahmad', 'Pordip Mandal', 'Shahzaib Rahman', 'Zidi Bacha', 'Waqar Rajput', 'Ali Akbar', 'Ali Raza', 'Sabir Ali', 'Rana Qurban', 'Ali Bahte', 'Sajad Ali', 'Ahadattaullah Malik', 'Muzammil Hussain', 'Jan Muhammad', 'Fasial S', 'Ameer NaNa', 'Makro Sharif', 'Mithal Khaskheli', 'محمدموسا محمدموسا', 'Mitho Mallah', 'Muzzamil Ali', 'Ahmad Hassan', 'Babar Babar', 'Zawar Muhammad', 'Rana Nadir', 'Mazhar Ali', 'Rana Irfan', 'Bilal Abbasi', 'Ghulam Jaffar', 'Asif Rana', 'Mœhäməd Řhæ', 'M Nawaz', 'Farooq Ali', 'Ashfaq Rahoo', 'Azmat Ali', 'Mateen Rana', 'Shan Ali', 'Çhårîyē Çhøkrī', 'Parwez Ali', 'Azhar Hussain', 'Shahabaz Ali', 'Syed Ghot', 'Zahid Hussain', 'Mir Babu', 'Zarik M', 'Shakel Ansari', 'Hafiz Imran', 'Shah Zaib', 'Bilal Jan', 'Asif Asif', 'Asif Asif', 'Muzafar Rajbut', 'Makhdoom Ghulam', 'Rana Farooq', 'Gulam Yaseen', 'Ashiqe Jatt', 'Arshad Brohi', 'Nazeer Ahmed', 'Sajad Ali', 'Mircho Mal', 'Rana Junaid', 'Lakho Mal', 'Sajid Ali', 'Raees Rahat', 'Irfan Ali', 'Rana Imran', 'Ali Mughal', 'Riaz Khan', 'Ahsan Bozdar', 'Shahidalisolangi Shahidalisolangi', 'Tariq Tariq', 'Rao Nasir', 'Zahid Ali', 'Shahzad Madni', 'Sarfaraz Rahu', 'Mubashair Rana', 'Ahsan Khoso', 'Jalger Bhatti', 'Rana Wajid', 'Lala Aziz', 'Shakir Abbasi', 'Ali Asgar', 'Ruble Hasan', 'Abdul Rehman', 'Azizullah Soomro', 'Abbas Ali', 'Muhammad Ali', 'Rana Wajid', 'Rana Musharaf', 'Rashid Qureshi', 'Shahmeer Chandio', 'Shan Ali', 'Ahmed Qureshi', 'Zaheer Abbas', 'Imran Ali', 'Asif Khan', 'Shahid Ali', 'Mangii Mangii', 'Momin Ali', 'Meer Shan', 'Muqu Poiro', 'Umar Shahzad', 'Waris Ali', 'Numwar Ali', 'Muhammad Tahir', 'AKhtar Ali', 'Rana Sajid', 'Sarfarazmemon Attad', 'Salim Junejo', 'Mashque Ali', 'Hassnan Ali', 'Irfan Ali', 'Adv Ali', 'Himmat Ali', 'Khalid Jamil', 'Mohsin Rajput', 'Syed Nadir', 'Raheem Punho', 'Rana Abdullah', 'Rana Noaman', 'Mansoor Solangi', 'Imran Jaan', 'Waris Ali', 'Rana Mubasher', 'Mujahid Ali', 'Hussnain Rajpoot', 'Chaudhary Abdul', 'Haider Baloch', 'Ali Dino', 'Mir Khan', 'Irfan Fatima', 'Arshad Baloch', 'Shakir Abbasi', 'Naveed Rind', 'Gul Muhammad', 'Meer Murtaza', 'Papo Papo', 'Nisar Ali', 'Gbhs Bhit', 'Sadoro Jan', 'Rana Moon', 'Ramzan Jan', 'Rana Zakir', 'Rao Waqas', 'M Waqas', 'Rana Rana', 'Rukhsar Haidry', 'RaNa BOby', 'M Juman', 'Sadiq Ali', 'Manik Khan', 'Ran A', 'Ghulab Hussain', 'Ronaq Ali', 'Tarique Ali', 'Abdul Qadir', 'Zawar Sohana', 'Mehran Rajput', 'Sikandar Ali', 'Ãtîf Â', 'Meer Shahzeb', 'Sajjad Abbasi', 'Rana Naeem', 'Bashir Ahmed', 'Rafeh Rajpoot', 'ẞk KhÄñ', 'Imtiaz Khoso', 'Alex Shahzad', 'Aman Abbasi', 'Mehran Rajput', 'Raja Rajpot', 'Bahdur Ali', 'Hammad Ali', 'Salman Salman', 'Shahzad Shahzad', 'AtaullAh Khan', 'Rafique Mirani', 'Arbab Ali', 'Nisar Ali', 'Zahid Hussain', 'Rana Shahzad', 'Rana Ramzan', 'Noro Mohmad', 'Riaz Rajput', 'Mahbat Khan', 'Ahsan Ali', 'Rana Ikram', 'Qamar Abbas', 'Jahanzib Ali', 'Rana Sunny', 'Rao Yasir', 'Muhammad Mithal', 'Ashiq Hussain', 'Ha Ni', 'Abdul Latif', 'Meer Mortaz', 'Meer Zohaib', 'Zahid Bhatti', 'Awais Rajput', 'Ali Bux', 'Abdul Hakeem', 'Hassnain Muavia', 'Syed Junaid', 'Riaz Machi', 'Ahsan Abro', 'Hyder Ali', 'Sattar Sattar', 'Sayed Sharafat', 'Syed Bilalarif', 'Lal Muhmmad', 'Mohsin Ali', 'Asif Ali', 'Juleed Shah', 'Hayat Khan', 'Ali Bux', 'पवन अल्लापुर', 'Ghulam Nabi', 'Zaheer Ali', 'Soomar Bughio', 'Madad Ali', 'Naeem Chohan', 'Javed Javed', 'Waseem Raza', 'Saorg Khan', 'Zeeshan Zeeshan', 'Aliza Chaudhary', 'Rana Shuaib', 'Ali Khan', 'Rao Shabbir', 'Commandos King', 'Arshad Sli', 'Rana Shahrukh', 'Ratan Kumar', 'Umar Khan', 'Ali Bhnoo', 'Shahzaib Shah', 'Aqib Gakhar', 'Rana Ishaq', 'Bilal Rajput', 'Asif Khan', 'Hazrat Hussain', 'Zohair Ali', 'Parvez Ali', 'Altaf Hussain', 'Mashooq Ali', 'Dilshad Magsi', 'Gulam Mustafa', 'Safdiar Khan', 'Tofiq Khan', 'Sudheer Ahmad', 'Suhrab Pardesi', 'Syed Badshah', 'Ashok Kumar', 'Ssbri Chandio', 'Yaseen Ali', 'Rimsha Shehzadi', 'Meer Aamir', 'Lakhiar Adeel', 'Ariz Muhammad', 'عبداللہ کوھارو', 'Yameen Ali', 'Sahil Gadehi', 'Sahab Ali', 'Naimatullah Ali', 'Baqir Sajjad', 'مير حارث', 'M Slutan', 'Sadaqat Ali', 'Fahad Ali', 'Muhammed Shabeer', 'Khalifo Chandio', 'Zohaib Ali', 'Ab Ghani', 'Ibrahim Baloch', 'Rehmatullah Mastoi', 'Mohammed Younis', 'Shahzadi Kiran', 'Ahmad Khan', 'Arshad SooMro', 'Sadam Solangi', 'Yamen Ali', 'Majid Khan', 'Ab Aziz', 'Sabir Khuharo', 'Nazeer Chandio', 'Md Samer', 'Kaif Qureshi', 'MuHammad HaaDi', 'Altaf Khan', 'Majid Ali', 'Muhammad Abraim', 'Noor Ahmed', 'Abid Hussain', 'Ashraf Buriro', 'Rajib Ali', 'Ahsan Ali', 'Aakash Khuharo', 'Hassan Ali', 'Awaiz Memon', 'Asharf Malah', 'Muslim Chandio', 'Haji Saddam', 'Rashid Ali', 'Assadullah Kolachi', 'Kashif Ali', 'Irfan Ali', 'Zulfqar Soomro', 'Ghafar Chandio', 'Younis Ali', 'Meer Murtiza', 'Majahd Ali', 'Rao Arslan', 'Rana Tsawar', 'Akbar Rajput', 'Rana Yasir', 'Rana Waqar', 'Rana Umer', 'Rao Zeeshan', 'Rana Aqib', 'Rana Mudassar', 'Rana Zubair', 'Rana Zohaib', 'Rana Rana', 'Rao Shoaib', 'Nokhaiz Rao', 'Rana G', 'Saeed Somro', 'Rana Muklish', 'Muzamil Rajput', 'Râõ Zêshãñ', 'Rana Nasrullah', 'Rana Naveed', 'Hamza Rajpoot', 'Rana Naveed', 'Rana Zahid', 'Rao Ali', 'Rao Ishfaq', 'Ehsan Rana', 'Ahsan Rana', 'Mohammed Akmal', 'Rana Naeem', 'Rana Ahmad', 'Rana Shani', 'Rao Nasir', 'Rao M', 'Rana Imran', 'Rao Arshad', 'Rao Sanaullah', 'Ali Rana', 'Rao Muhammad', 'Rana Gulraiz', 'Salal Rajput', 'Rana Muhammad', 'Ijaz Rajpoot', 'M Farman', 'Rao Raees', 'Rana Umar', 'Umair Rana', 'Shafiq Rajpoot', 'Rana Numan', 'Rao Shb', 'Rana Yousif', 'Rana Liaqat', 'Rana Asad', 'Zafar Rajpoot', 'Rao Hamza', 'Abubakar Rajput', 'Rao M', 'Rana Ishaq', 'Waqas Rajpoot', 'Amir Sohail', 'Rao Sohaib', 'Rana Shazil', 'Rao Bilal', 'Rao Altaf', 'Rao Nabeel', 'Hamza Rao', 'Asif Rana', 'Rana Umair', 'Raokashif Ali', 'Rao Qaiser', 'Rana Attual', 'Rana Shabaz', 'Rao Salman', 'Rao Samad', 'Rao Shoaib', 'Rana A', 'Rao Kashif', 'Rao Zarar', 'Rana Tayyub', 'Raja Kamal', 'Amir Rajput', 'RaoAlizaman RaoAlizaman', 'Hamza Rao', 'Rana Falak', 'Sikandar Khan', 'Rao Shahbaz', 'Rana Talha', 'Kashif Rajpoot', 'Hammad Rana', 'Hamza Rao', 'Roa Zahid', 'Rana Hamza', 'Rao Saleem', 'Rao Faryad', 'Rao Abubakar', 'Bilal Rajput', 'Rao Waseem', 'Sonu Rao', 'Rana Rizwan', 'Bilal Rao', 'Rans Maqsood', 'Rana Furqan', 'Rao Ali', 'Rana Muzamil', 'M Asif', 'Rao Sohail', 'Rana Bahadur', 'Rana Muhmmad', 'Shahzada Gs', 'Rao Farhan', 'Zahgim Ali', 'Abaid Raja', 'Rana Waseem', 'Rana Ajmal', 'Rao Latif', 'Rao Aqib', 'Rana Ramzan', 'Wajid Rana', 'Sabir Rajpoot', 'Rana Shehryar', 'Rana Yaqub', 'Rao Abdul', 'Rajput Sab', 'Rana Tasawar', 'Rana Waseem', 'Rana Babar', 'Rana Shahid', 'Rana Maviya', 'Rana Saeed', 'Waheed Rajput', 'Junaid Rajpoot', 'Rao Saqib', 'Rao Azeem', 'Rana Ali', 'Muhammad Nadeem', 'Rana Majid', 'Rana Sahab', 'Abubakar Jatoi', 'Sabir Dogar', 'Ameen Rana', 'Rana Shakeel', 'Rao Tasleem', 'Pʀɩŋcɘ Nʌsɩʀ', 'Rana Mani', 'Rana Jee', 'Zidi Rana', 'Rana Kamran', 'Rana Zabi', 'Mehtab Rao', 'حسن راو', 'Rana Sajid', 'Rao Aftab', 'Rana Muhammad', 'Muhammad Muhammad', 'Rao Abdulrazaq', 'Rao MubeenRao', 'Rao Nazeer']
girls_name = ['Sajida Malik', 'Ayesha Khan', 'Nabeela Malik', 'Kinza Fatima', 'Arooj Khan', 'Muskan Khan', 'Ayesha Malik', 'Safina Malik', 'Nida Ali', 'Rimsha Ali','Atika Fithriya Tsabita','Alya Kinana Juwairiyah','Adzkiya Naila Taleetha','Adiva Arsyila Savina','Aqeela Nabiha Sakhi','Bilqis Adzkiya Rana','Chayra Ainin Qulaibah','Caliana Fiona Syafazea','Chaerunnisa Denia Athalla','Dhawiyah Nisrin Naziha','Dilara Adina Yuani','Farah Sachnaz Ashanty','Ghariyah Zharufa Abidah','Hamna Nafisa Raihana','Hanin Raihana Syahira','Izza Hilyah Nafisah','Kayla Zhara Qamela','Mahreen Shafana Almahyra','Rasahana Shafwa Ruqayah','Shakayla Aretha Shaima']
class Bot:
    
    def __init__(self, session):
        self.ses = session
        self.ses.headers.pop("referer", None)
    
    # menambahkan foto profile
    def profile(self, picture):
        self.res = self.ses.get("https://mbasic.facebook.com/photos/change/profile_picture/?source=timeline_page&refid=17&paipv=0")
        self.par = BeautifulSoup(self.res.text, "html.parser")
        self.form = self.par.find("form", method="post")
        self.files = {"file1": open(picture, "rb")}
        self.res = self.ses.post(self.form["action"], data={i["name"]: i["value"] for i in self.form.find_all("input", {"name": True, "value": True})}, files=self.files, headers={**self.ses.headers, "sec-fetch-user": "?1", "sec-fetch-site": "same-site", "origin": "https://mbasic.facebook.com", "cache-control": "max-age=0", "referer": "https://mbasic.facebook.com/"})
        print(" [*] berhasil menambahkan foto profile" if "succes" in self.res.url else " [!] gagal menambahkan foto profile")
    
    # menambahkan foto sampul
    def sampul(self, picture):
        self.res = self.ses.get("https://mbasic.facebook.com/photos/upload/?cover_photo&paipv=0")
        self.par = BeautifulSoup(self.res.text, "html.parser")
        self.form = self.par.find("form", method="post")
        self.files = {"file1": open(picture, "rb").read()}
        self.res = self.ses.post("https://mbasic.facebook.com" + self.form["action"], data={i["name"]: i["value"] for i in self.form.find_all("input", {"name": True, "value": True})}, files=self.files, headers={**self.ses.headers, "sec-fetch-user": "?1", "sec-fetch-site": "same-origin", "origin": "https://mbasic.facebook.com", "cache-control": "max-age=0", "referer": self.res.url})
        print(" [*] berhasil menambahkan foto sampul" if "sk=live" in self.res.url or "memperbarui foto sampulnya." in self.res.text else " [!] gagal menambahkan foto sampul")
    
    # edit bio
    def bio(self, teks):
        self.res = self.ses.get("https://mbasic.facebook.com/profile/basic/intro/bio/?refid=17&paipv=0")
        self.par = BeautifulSoup(self.res.text, "html.parser")
        self.form = self.par.find("form", method="post")
        self.data = {i["name"]: i["value"] for i in self.form.find_all("input", {"name": True, "value": True})}
        self.data.update({"bio": teks, "publish_to_feed": "on"})
        self.res = self.ses.post("https://mbasic.facebook.com" + self.form["action"], data=self.data, headers={**self.ses.headers, "sec-fetch-user": "?1", "sec-fetch-site": "same-origin", "content-type": "application/x-www-form-urlencoded", "origin": "https://mbasic.facebook.com", "cache-control": "max-age=0", "referer": self.res.url})
        print(" [*] berhasil menambahkan bio" if True else " [!] gagal menambahkan bio")
    
    # kota saat ini
    def current_city(self, city):
        self.res = self.ses.get("https://mbasic.facebook.com/editprofile.php?type=basic&edit=current_city&paipv=0&refid=17")
        self.par = BeautifulSoup(self.res.text, "html.parser")
        self.form = self.par.find("form", method="post")
        self.data = {i["name"]: i["value"] for i in self.form.find_all("input", {"name": True, "value": True}) if "privacy_setting" not in i["name"]}
        self.data.update({"current_city[]": city})
        self.res = self.ses.post("https://mbasic.facebook.com" + self.form["action"], data=self.data, headers={**self.ses.headers, "sec-fetch-user": "?1", "sec-fetch-site": "same-origin", "content-type": "application/x-www-form-urlencoded", "origin": "https://mbasic.facebook.com", "cache-control": "max-age=0", "referer": self.res.url})
        print(" [*] berhasil menambahkan kota saat ini" if "edit_success" in self.res.url else " [!] gagal menambahkan kota saat ini")
    
    # kota asal
    def hometown(self, city):
        self.res = self.ses.get("https://mbasic.facebook.com/editprofile.php?type=basic&edit=hometown&paipv=0&refid=17")
        self.par = BeautifulSoup(self.res.text, "html.parser")
        self.form = self.par.find("form", method="post")
        self.data = {i["name"]: i["value"] for i in self.form.find_all("input", {"name": True, "value": True}) if "privacy_setting" not in i["name"]}
        self.data.update({"hometown[]": city})
        self.res = self.ses.post("https://mbasic.facebook.com" + self.form["action"], data=self.data, headers={**self.ses.headers, "sec-fetch-user": "?1", "sec-fetch-site": "same-origin", "content-type": "application/x-www-form-urlencoded", "origin": "https://mbasic.facebook.com", "cache-control": "max-age=0", "referer": self.res.url})
        print(" [*] berhasil menambahkan kota asal" if "edit_success" in self.res.url else " [!] gagal menambahkan kota asal")
    
    # status hubungan
    def relationship(self, status):
        self.res = self.ses.get("https://mbasic.facebook.com/editprofile.php?type=basic&edit=relationship&paipv=0&refid=17")
        self.par = BeautifulSoup(self.res.text, "html.parser")
        self.status = self.par.find("a", href=True, string=status)
        self.res = self.ses.get("https://mbasic.facebook.com" + self.status["href"])
        self.par = BeautifulSoup(self.res.text, "html.parser")
        self.form = self.par.find("form", method="post")
        self.res = self.ses.post("https://mbasic.facebook.com" + self.form["action"], data={i["name"]: i["value"] for i in self.form.find_all("input", {"name": True, "value": True})}, headers={**self.ses.headers, "sec-fetch-user": "?1", "sec-fetch-site": "same-origin", "content-type": "application/x-www-form-urlencoded", "origin": "https://mbasic.facebook.com", "cache-control": "max-age=0", "referer": self.res.url})
        print(" [*] berhasil menambahkan status hubungan" if "edit_success" in self.res.url else " [!] gagal menambahkan status hubungan")
    
    # menambahkan nama panggilan
    def nicknames(self, nickname):
        self.res = self.ses.get("https://mbasic.facebook.com/profile/edit/info/nicknames/?info_surface=info&refid=17&paipv=0")
        self.par = BeautifulSoup(self.res.text, "html.parser")
        self.form = self.par.find("form", method="post")
        self.data = {i["name"]: i["value"] for i in self.form.find_all("input", {"name": True, "value": True})}
        self.data.update({"dropdown": "nickname", "text": nickname, "checkbox": "on"})
        self.res = self.ses.post("https://mbasic.facebook.com" + self.form["action"], data=self.data, headers={**self.ses.headers, "sec-fetch-user": "?1", "sec-fetch-site": "same-origin", "content-type": "application/x-www-form-urlencoded", "origin": "https://mbasic.facebook.com", "cache-control": "max-age=0", "referer": self.res.url})
        print(" [*] Successfully added nickname." if "nocollections" in self.res.url else " [!] Failed added nickname.")
    
    # menambahkan tentang anda
    def about(self, tentang):
        self.res = self.ses.get(f"https://mbasic.facebook.com/profile/edit/infotab/section/forms/?section=bio&cb={int(time.time())}&refid=17&paipv=0")
        self.par = BeautifulSoup(self.res.text, "html.parser")
        self.form = self.par.find("form", method="post")
        self.data = {i["name"]: i["value"] for i in self.form.find_all("input", {"name": True, "value": True})}
        self.data.update({"bio": tentang})
        self.res = self.ses.post("https://mbasic.facebook.com" + self.form["action"], data=self.data, headers={**self.ses.headers, "sec-fetch-user": "?1", "sec-fetch-site": "same-origin", "content-type": "application/x-www-form-urlencoded", "origin": "https://mbasic.facebook.com", "cache-control": "max-age=0", "referer": self.res.url})
        print(" [*] Successfully to add about me." if "nocollections" in self.res.url else " [!] Failed to add about me.")
    
    # menambahkan kutipan favorit
    def quote(self, kutipan):
        self.res = self.ses.get(f"https://mbasic.facebook.com/profile/edit/infotab/section/forms/?section=quote&cb={int(time.time())}&refid=17&paipv=0")
        self.par = BeautifulSoup(self.res.text, "html.parser")
        self.form = self.par.find("form", method="post")
        self.data = {i["name"]: i["value"] for i in self.form.find_all("input", {"name": True, "value": True})}
        self.data.update({"quote": kutipan})
        self.res = self.ses.post("https://mbasic.facebook.com" + self.form["action"], data=self.data, headers={**self.ses.headers, "sec-fetch-user": "?1", "sec-fetch-site": "same-origin", "content-type": "application/x-www-form-urlencoded", "origin": "https://mbasic.facebook.com", "cache-control": "max-age=0", "referer": self.res.url})
        print(" [*] Successfully added favorite  " if "nocollections" in self.res.url else "Failed added favorite ")
    
    # komentar
    def comment(self, postid, comment_text, count=1):
        self.res = self.ses.get(f"https://mbasic.facebook.com/{postid}")
        for w in range(count):
            self.par = BeautifulSoup(self.res.text, "html.parser")
            self.form = self.par.find("form", action=lambda i: "/a/comment.php?" in i)
            self.data = {"fb_dtsg": self.form.find("input", {"name": "fb_dtsg"})["value"], "jazoest": self.form.find("input", {"name": "jazoest"})["value"], "comment_text": comment_text}
            self.res = self.ses.post("https://mbasic.facebook.com" + self.form["action"], data=self.data, headers={**self.ses.headers, "sec-fetch-user": "?1", "sec-fetch-site": "same-origin", "content-type": "application/x-www-form-urlencoded", "origin": "https://mbasic.facebook.com", "cache-control": "max-age=0", "referer": self.res.url})
            if count > 1:
                comment_text = f"Berkomentar pada: {__import__('datetime').datetime.now().strftime('%Y-%m-%d | %H:%M:%S.%f')[:-3]}\ntimestamp: {int(time.time() * 1000)}"
            
    # follow
    def follow(self, target):
        self.res = self.ses.get(f"https://mbasic.facebook.com/{target}/?v=info&refid=17&paipv=0")
        self.par = BeautifulSoup(self.res.text, "html.parser")
        if (ikuyoo := self.par.find("a", href=lambda i: "/a/subscribe.php" in i)):
            self.ses.get("https://mbasic.facebook.com" + ikuyoo["href"])
            print(" [*] follow \x1b[1;37m" + self.par.find("title").text + "\x1b[0m")
    
    # tanggapi postingan
    def reaction(self, postid):
        self.res = self.ses.get(f"https://mbasic.facebook.com/reactions/picker/?is_permalink=1&ft_id={postid}")
        self.par = BeautifulSoup(self.res.text, "html.parser")
        if not self.par.find("span", string="(Hapus)"):
            if (ufi := self.par.find("a", href=lambda i: "reaction_type=" + self.acak in i)):
                self.ses.get("https://mbasic.facebook.com" + ufi["href"])
                print(" [*] react ")
            
    # gabung ke group
    def join(self, groupid):
        self.res = self.ses.get(f"https://mbasic.facebook.com/groups/{groupid}/")
        self.par = BeautifulSoup(self.res.text, "html.parser")
        self.form = self.par.find("form", action=lambda i: "/a/group/join/" in i)
        self.res = self.ses.post("https://mbasic.facebook.com" + self.form["action"], data={i["name"]: i["value"] for i in self.form.find_all("input", {"name": True, "value": True})}, headers={**self.ses.headers, "sec-fetch-user": "?1", "sec-fetch-site": "same-origin", "origin": "https://mbasic.facebook.com", "cache-control": "max-age=0", "referer": self.res.url})
        print((" [*] group name \x1b[1;37m" + self.par.find("title").text if re.search('<div class=".*">Anggota<', self.res.text) else " [!] Join group \x1b[1;37m" + self.par.find("title").text) + "\x1b[0m")
    
    # acak tipe reaction
    @property
    def acak(self):
        self.type = [2, 16, 4]
        return str(random.choice(random.sample(self.type, len(self.type))))
#--> Clear Terminal
def clear():
    if "linux" in sys.platform.lower():os.system('clear')
    elif "win" in sys.platform.lower():os.system('cls')

#--> Waktu
def waktu():
    _bulan_  = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"][datetime.now().month - 1]
    hari_ini = ("%s%s%s"%(datetime.now().day,_bulan_,datetime.now().year))
    return(str(hari_ini.lower()))

#--> Penjeda Waktu
def jeda(t):
    for x in range(t+1):
        print('\r%sTunggu %s Detik                     '%(P,str(t)),end='');sys.stdout.flush()
        t -= 1
        if t == 0: break
        else: time.sleep(1)
def tunggu_kode(t):
    for x in range(t+1):
        print('\r%sTunggu Kode %s Detik                     '%(P,str(t)),end='');sys.stdout.flush()
        t -= 1
        if t == 0: break
        else: time.sleep(1)
        
def random_ua():
    model = "iPhone"+str(random.randint(4,16))+','+str(random.randint(1,9))
    abc = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','X','Y','Z']
    build = str(random.randint(9,19))+random.choice(abc)+str(random.randint(50,199))
    fbsv = str(random.randint(4,16))+'_'+str(random.randint(1,9))+'_'+str(random.randint(1,9))
    ua1 = 'Mozilla/5.0 (iPhone, CPU iPhone '+fbsv+' like Mac OS '+str(random.randint(8,16))+') AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/'+build+') Safari/604.1'
    ua2 = "Mozilla/5.0 (iPhone "+str(random.randrange(4,6))+" X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/"+str(random.randint(4,13))+".1.1 Mobile/"+model+" Safari/604.1"
    dv_typ = random.choice(['SM-S911B','SM-S908B','SM-G998B','SM-G988B','SM-G973B','SM-N986B'])
    ua3 = f"Mozilla/5.0 (Linux; Android {str(random.randint(4,13))}; "+dv_typ+") AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Mobile Safari/537.36"
    a = random.randrange(112,115)
    b = random.randrange(1000,10000)
    c = random.randrange(10,100)
    os_ver = random.randrange(10,13)
    dv_typ = random.choice(['RMX3686','RMX3393','RMX3081','RMX2170','RMX2061','RMX2020'])
    bl_typ = random.choice(['QP1A','SKQ1','TP1A','RKQ1','SP1A','RP1A'])
    dv_ver = random.randrange(100000,250000)
    sd_ver = random.randrange(1,10)
    ch_ver = f'{a}.0.{b}.{c}'
    ua4 = f'Mozilla/5.0 (Linux; Android {os_ver}; {dv_typ} Build/{bl_typ}.{dv_ver}.00{sd_ver}; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/{ch_ver} Mobile Safari/537.36'
    a = random.randrange(112,115)
    b = random.randrange(1000,10000)
    c = random.randrange(10,100)
    os_ver = random.randrange(10,13)
    dv_typ = random.choice(['SM-S911B','SM-S908B','SM-G998B','SM-G988B','SM-G973B','SM-N986B'])
    bl_typ = random.choice(['PPR1','LRX21T','TP1A','RKQ1','SP1A','RP1A'])
    dv_ver = random.randrange(100000,250000)
    sd_ver = random.randrange(1,10)
    ch_ver = f'{a}.0.{b}.{c}'
    ua5 = f'Mozilla/5.0 (Linux; Android {os_ver}; {dv_typ} Build/{bl_typ}.{dv_ver}.00{sd_ver}; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/{ch_ver} Mobile Safari/537.36'
    a = random.randrange(112,115)
    b = random.randrange(1000,10000)
    c = random.randrange(10,100)
    os_ver = random.randrange(10,13)
    dv_typ = random.choice(['vivo 1951','vivo 1918','V2011A','V2047','V2145','V2227A','V2160'])
    bl_typ = random.choice(['RP1A','PKQ1','QP1A','TP1A'])
    dv_ver = random.randrange(100000,250000)
    sd_ver = random.randrange(1,10)
    ch_ver = f'{a}.0.{b}.{c}'
    ua6 = f'Mozilla/5.0 (Linux; Android {os_ver}; {dv_typ} Build/{bl_typ}.{dv_ver}.00{sd_ver}; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/{ch_ver} Mobile Safari/537.36'
    ua = random.choice([ua1,ua2,ua3,ua4,ua5,ua6])
    return(ua)

#--> User Agent Vivo
def random_ua_vivo():
    a = random.randrange(112,115)
    b = random.randrange(1000,10000)
    c = random.randrange(10,100)
    os_ver = random.randrange(10,13)                                                            #--> OS Version
    dv_typ = random.choice(['vivo 1951','vivo 1918','V2011A','V2047','V2145','V2227A','V2160']) #--> Device Type
    bl_typ = random.choice(['RP1A','PKQ1','QP1A','TP1A'])                                       #--> Build Type
    dv_ver = random.randrange(100000,250000)                                                    #--> Device Version
    sd_ver = random.randrange(1,10)                                                             #--> Update Version
    ch_ver = f'{a}.0.{b}.{c}'                                                                   #--> Chrome Version
    ua = f'Mozilla/5.0 (Linux; Android {os_ver}; {dv_typ} Build/{bl_typ}.{dv_ver}.00{sd_ver}; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/{ch_ver} Mobile Safari/537.36'
    return(ua)

#--> User Agent Samsung
def random_ua_samsung():
    a = random.randrange(112,115)
    b = random.randrange(1000,10000)
    c = random.randrange(10,100)
    os_ver = random.randrange(10,13)                                                            #--> OS Version
    dv_typ = random.choice(['SM-S911B','SM-S908B','SM-G998B','SM-G988B','SM-G973B','SM-N986B']) #--> Device Type
    bl_typ = random.choice(['PPR1','LRX21T','TP1A','RKQ1','SP1A','RP1A'])                       #--> Build Type
    dv_ver = random.randrange(100000,250000)                                                    #--> Device Version
    sd_ver = random.randrange(1,10)                                                             #--> Update Version
    ch_ver = f'{a}.0.{b}.{c}'                                                                   #--> Chrome Version
    ua = f'Mozilla/5.0 (Linux; Android {os_ver}; {dv_typ} Build/{bl_typ}.{dv_ver}.00{sd_ver}; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/{ch_ver} Mobile Safari/537.36'
    return(ua)

#--> User Agent Realme
def random_ua_realme():
    a = random.randrange(112,115)
    b = random.randrange(1000,10000)
    c = random.randrange(10,100)
    os_ver = random.randrange(10,13)                                                        #--> OS Version
    dv_typ = random.choice(['RMX3686','RMX3393','RMX3081','RMX2170','RMX2061','RMX2020'])   #--> Device Type
    bl_typ = random.choice(['QP1A','SKQ1','TP1A','RKQ1','SP1A','RP1A'])                     #--> Build Type
    dv_ver = random.randrange(100000,250000)                                                #--> Device Version
    sd_ver = random.randrange(1,10)                                                         #--> Update Version
    ch_ver = f'{a}.0.{b}.{c}'                                                               #--> Chrome Version
    ua = f'Mozilla/5.0 (Linux; Android {os_ver}; {dv_typ} Build/{bl_typ}.{dv_ver}.00{sd_ver}; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/{ch_ver} Mobile Safari/537.36'
    return(ua)

#--> User Agent Custom
def random_ua_custom():
    try:
        _file_ = uman
        if 'Android' in str(_file_):
            ad_ver = 'Android ' + str(re.search(r'Android\s+(\d+)', _file_).group(1))
            os_ver = 'Android ' + str(random.randrange(10,13))
            ua1 = _file_.replace(ad_ver,os_ver)
        else: ua1 = _file_
        if 'Build' in str(_file_):
            od_ver = 'Build/' + str(re.search(r'Build/([^;]+)', _file_).group(1))
            bl_typ = random.choice(['QP1A','PPR1','TP1A','RKQ1','SP1A','RP1A','PKQ1'])
            dv_ver = random.randrange(100000,250000)
            sd_ver = random.randrange(1,10)
            nw_str = 'Build/' + str('%s.%s.00%s'%(bl_typ,dv_ver,sd_ver))
            ua2 = ua1.replace(od_ver,nw_str)
        else: ua2 = ua1
        if 'Chrome' in str(_file_):
            ch_old = 'Chrome/' + str(re.search(r'Chrome/([^ ]+)', _file_).group(1))
            a = random.randrange(112,115)
            b = random.randrange(1000,10000)
            c = random.randrange(10,100)
            ch_ver = f'{a}.0.{b}.{c}'
            ch_new = 'Chrome/' + str(ch_ver)
            ua3 = ua2.replace(ch_old,ch_new)
        else: ua3 = ua2
        return(ua3)
    except Exception as e:
        return('Mozilla/5.0 (Linux; Android 11; vivo 1918 Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/112.0.0000.00 Mobile Safari/537.36')
def random_ua():
    model = "iPhone"+str(random.randint(4,16))+','+str(random.randint(1,9))
    abc = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','X','Y','Z']
    build = str(random.randint(9,19))+random.choice(abc)+str(random.randint(50,199))
    fbsv = str(random.randint(4,16))+'_'+str(random.randint(1,9))+'_'+str(random.randint(1,9))
    ua1 = 'Mozilla/5.0 (iPhone, CPU iPhone '+fbsv+' like Mac OS '+str(random.randint(8,16))+') AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/'+build+') Safari/604.1'
    ua2 = "Mozilla/5.0 (iPhone "+str(random.randrange(4,6))+" X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/"+str(random.randint(4,13))+".1.1 Mobile/"+model+" Safari/604.1"
    dv_typ = random.choice(['SM-S911B','SM-S908B','SM-G998B','SM-G988B','SM-G973B','SM-N986B'])
    ua3 = f"Mozilla/5.0 (Linux; Android {str(random.randint(4,13))}; "+dv_typ+") AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Mobile Safari/537.36"
    a = random.randrange(112,115)
    b = random.randrange(1000,10000)
    c = random.randrange(10,100)
    os_ver = random.randrange(10,13)
    dv_typ = random.choice(['RMX3686','RMX3393','RMX3081','RMX2170','RMX2061','RMX2020'])
    bl_typ = random.choice(['QP1A','SKQ1','TP1A','RKQ1','SP1A','RP1A'])
    dv_ver = random.randrange(100000,250000)
    sd_ver = random.randrange(1,10)
    ch_ver = f'{a}.0.{b}.{c}'
    ua4 = f'Mozilla/5.0 (Linux; Android {os_ver}; {dv_typ} Build/{bl_typ}.{dv_ver}.00{sd_ver}; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/{ch_ver} Mobile Safari/537.36'
    a = random.randrange(112,115)
    b = random.randrange(1000,10000)
    c = random.randrange(10,100)
    os_ver = random.randrange(10,13)
    dv_typ = random.choice(['SM-S911B','SM-S908B','SM-G998B','SM-G988B','SM-G973B','SM-N986B'])
    bl_typ = random.choice(['PPR1','LRX21T','TP1A','RKQ1','SP1A','RP1A'])
    dv_ver = random.randrange(100000,250000)
    sd_ver = random.randrange(1,10)
    ch_ver = f'{a}.0.{b}.{c}'
    ua5 = f'Mozilla/5.0 (Linux; Android {os_ver}; {dv_typ} Build/{bl_typ}.{dv_ver}.00{sd_ver}; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/{ch_ver} Mobile Safari/537.36'
    a = random.randrange(112,115)
    b = random.randrange(1000,10000)
    c = random.randrange(10,100)
    os_ver = random.randrange(10,13)
    dv_typ = random.choice(['vivo 1951','vivo 1918','V2011A','V2047','V2145','V2227A','V2160'])
    bl_typ = random.choice(['RP1A','PKQ1','QP1A','TP1A'])
    dv_ver = random.randrange(100000,250000)
    sd_ver = random.randrange(1,10)
    ch_ver = f'{a}.0.{b}.{c}'
    ua6 = f'Mozilla/5.0 (Linux; Android {os_ver}; {dv_typ} Build/{bl_typ}.{dv_ver}.00{sd_ver}; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/{ch_ver} Mobile Safari/537.36'
    ua = random.choice([ua1,ua2,ua3,ua4,ua5,ua6])
    return(ua)
#--> Convert Cookies
def cvt(st,ran):
    try:
        if st == 'ok': cookie = ('sb=%s;datr=%s;c_user=%s;xs=%s;fr=%s;'%(ran['sb'],ran['datr'],ran['c_user'],ran['xs'],ran['fr']))
        elif st == 'cp': cookie = ('checkpoint=%s;datr=%s;fr=%s;'%(ran['checkpoint'],ran['datr'],ran['fr']))
    except Exception as e : cookie = '; '.join([str(x)+"="+str(y) for x,y in ran])
    return(str(cookie))

#--> Logo
def logo():
    print('%s_________                      __        %s________________ %s'%(P,M,P))
    print('%s\_   ___ \_______ ____ _____ _/  |_  ____%s\_   ____|___   \\%s'%(P,M,P))
    print('%s/    \  \/\_  __ \ __ \\\\__  \\\\   __\/ __ \%s|    __)   |  _/%s'%(P,M,P))
    print('%s\ %s0.1 %s\____|  | \/ ___/ / __ \|  | \  ___/%s|   \  |   |   \\%s'%(P,M,P,M,P))
    print('%s \________/|__|  \_____>______/__|  \____>%s|___/  |_______/%s'%(P,M,P))
    print('%s\n      ─────────────── %s• %sModfiy By Sameer Hashmi %s• %s───────────────\n%s'%(A,M,P,M,A,P))

#--> Main Menu
class menu:
    def __init__(self):
        logo()
        self.main_menu()
    def main_menu(self):
        print('%s[%s1%s] %sCreate Account'%(M,P,M,P))
        print('%s[%s2%s] %sCheck Result'%(M,P,M,P))
        print('%s[%s3%s] %sSettings'%(M,P,M,P))
        print('%s[%s4%s] %sBot'%(M,P,M,P))
        x = input(' %s└─ %sPilih %s: %s'%(M,P,M,P)).lower()
        print('')
        if   x in ['1','01','001','a']: menu_create()
        elif x in ['2','02','002','b']: menu_check()
        elif x in ['3','03','003','c']: belum_tersedia()
        elif x in ['4','04','004','d']: belum_tersedia()
        else: exit('%Woring!%s'%(M,P))

#--> Menu Create
class menu_create:
    def __init__(self):
        global kelamin, namstat, nameme, web_email, tampil, useragent, uman, passtat, password
        try:os.mkdir('Akun_New')
        except Exception as e :pass
        print('      %s◉ %sRecommended   %s◉ %sNot Recommended   ◉ Neutral'%(H,P,M,P))
        print('')
        kelamin   = input('%s[%s•%s] %sBoy/Girl/Random Account [%sb%s/%sg%s/%sr%s] : '%(M,P,M,P,H,P,H,P,M,P)).lower()
        namanama  = input('%s[%s•%s] %sRandom Nama/Manual [%sr%s/%sm%s] : '%(M,P,M,P,M,P,H,P)).lower()
        if namanama in ['m','manual','0','00']:
            namstat = 'Manual'
            nameme = input(' %s└─ %sNama : %s'%(M,P,M)).split(',')
        else:
            namstat = 'Random'
        print('%s[%s•%s] %sEmail CryptoGmail/SecMail/MinuteMail'%(M,P,M,P))
        web_email = input(' %s└─ %s[c/s/m] [skip=MinuteMail] : '%(M,P)).lower()
        tampil    = input('%s[%s•%s] %sShow CP Account [%sy%s/%sn%s] : '%(M,P,M,P,M,P,H,P)).lower()
        print('%s[%s•%s] %sUser Agent Vivo/Samsung/Realme/Manual/Random (Best)'%(M,P,M,P))
        useragent = input(' %s└─ %s[v/s/r/m/p] [skip=statis] : '%(M,P)).lower()
        if useragent in ['m','manual','0','00']:
            uman = input(' %s└─ %sUser Agent : %s'%(M,P,M))
            if uman == '' or uman == ' ':
                exit('%sIsi Yang Benar!%s'%(M,P))
        else:
            uman = 'Mozilla/5.0 (Linux; Android 13; RMX3686) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Mobile Safari/537.36'
        passtat   = input('%s[%s•%s] %sUser Password Random/Manual Password [%sr%s/%sm%s] : '%(M,P,M,P,H,P,M,P)).lower()
        if passtat in ['m','manual','b','2','02']:
            password = input(' %s└─ %sPassword : %s'%(M,P,M))
            if len(password) < 6:
                exit('%sPassword Minimal 6 Digit!%s'%(M,P))
            if password in ['akusayangkamu','123456','iloveyou','password','qwerty','sayang','anjing','bismillah']:
                exit('%sGunakan Password Yang Kuat!%s'%(M,P))
        else:
            password = 'dapuntaloverani'
        d = input('%s[%s•%s] %sSet Delay (%sIn Minutes%s) : '%(M,P,M,P,M,P))
        if d == '' or d == ' ':
            d = 1
        print('')
        l = int(d)*60
        for y in range(10000):
            if key/len(auth1) == len(reco)/2: create_fb(); self.hitung(l)
            else: print(reco)
    def hitung(self,a):
        for x in range(a+1):
            print('\r[%sOK:%s%s] [%sCP:%s%s] Tunggu %s Detik         '%(H,str(ok),P,M,str(cp),P,str(a)),end='');sys.stdout.flush()
            a -= 1
            time.sleep(1)

#--> Create Facebook Account
class create_fb:

    #--> Tampung Kabeh
    def __init__(self):
        self.file  = 'Akun_New/%s.txt'%(waktu())
        self.abc = requests.Session() #--> Sesi Email
        self.xyz = requests.Session() #--> Sesi Facebook
        self.abc.cookies.clear()
        self.xyz.cookies.clear()
        if   useragent in ['v','vivo','1','01','a']:    self.ua = random_ua_vivo()
        elif useragent in ['s','samsung','2','02','b']: self.ua = random_ua_samsung()
        elif useragent in ['r','realme','3','03','c']:  self.ua = random_ua_realme()
        elif useragent in ['m','manual','0','00','z']:  self.ua = random_ua_custom()
        elif useragent in ['p','pnl','4','04','p']: self.ua = random_ua()
        else : self.ua = 'Mozilla/5.0 (Linux; Android 13; RMX3686) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Mobile Safari/537.36'
        self.head_email = {'accept': 'text/html,application/xhtm 1+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'accept-encoding': 'gzip, deflate',
        'accept-language': 'en-US, en;q=0.9, en-US;q=0.8, en;q=0.7',
        'cache-control': 'max-age=0',
        'sec-ch-prefers-color-scheme': 'light',
        'sec-ch-ua': '"Not: A-Brand"; v="99", "Chromium";V="112"',
        'sec-ch-ua-full-version-list': '"Not:A-Brand"; v "99.0.0.0", "Chromium";v="112.0.5615.137"',
        'sec-ch-ua-mobile': '?1',
        'sec-ch-ua-platform': '"Android"',
        'sec-ch-ua-platform-version': '"11.0.0"',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'none',
        'sec-fetch-user': '21',
        'upgrade-insecure-requests': '1',
        'user-agent': random_ua()}
        self.ua_wind = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36'
        self.headers_get = {'authority': 'mbasic.facebook.com', 'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', 'accept-language': 'en-US,en;q=0.9', 'cache-control': 'max-age=0', 'origin': 'https://mbasic.facebook.com', 'referer': 'https://mbasic.facebook.com/reg', 'sec-ch-ua': '"Google Chrome";v="107", "Chromium";v="107", "Not=A?Brand";v="24"', 'sec-ch-ua-mobile': '?0', 'sec-ch-ua-platform': '"Android"', 'sec-fetch-dest': 'document', 'sec-fetch-mode': 'navigate', 'sec-fetch-site': 'same-origin', 'sec-fetch-user': '?1', 'upgrade-insecure-requests': '1', 'user-agent' : self.ua}
        self.generate_data()
        self.scrap1()
    
    #--> Generate Data
    def generate_data(self):
        self.name, soex = self.get_name().split('|')
        self.nope  = self.get_nope()
        if   web_email in ['c','cryptogmail','1','01','a']: self.email = self.get_email_cryptogmail()
        elif web_email in ['s','secmail','2','02','b']:     self.email = self.get_email_onesecmail()
        elif web_email in ['m','minutemail','4','04','d']:  self.email = self.get_email_10minutemail()
        else : self.email = self.get_email_10minutemail()
        if soex == 'male' : self.*** = '2'
        else : self.*** = '1'
        if passtat in ['m','manual','b','2','02']: self.pw = password
        else: self.pw = self.get_pass()
        self.ttl = {'tgl':str(random.randrange(1,29)),'bln':str(random.randrange(1,13)),'thn':str(random.randrange(1970,2001))}
        self.perangkat = '; m_pixel_ratio=1.25; dpr=1.125; wd=360x780; locale=id_ID;'
    
    #--> Generate Random Name
    def get_name(self):
        if kelamin in ['b','boy','1','01','a']: gder = 'male'
        elif kelamin in ['b','girl','2','02','b']: gder = 'female'
        else: gder = random.choice(['male','female'])
        try:
            if gder == 'male':
                if namstat == 'Manual': name = random.choice(nameme)
                else: name = random.choice(boys_name)
            else:
                if namstat == 'Manual': name = random.choice(nameme)
                else: name = random.choice(girls_name)
        except Exception as e:
            nam1 = random.choice(['Eka','Dwi','Tri','Budi','Indah','Dewi'])
            nam2 = random.choice(['Nurhayati','Handoko','Setiyani','Susanto','Permata'])
            nam3 = random.choice(['Triatmaja','Siagian','Manopo','Jayaningrat','Widodo'])
            name = f'{nam1} {nam2} {nam3}'
        klop = f'{name}|{gder}'
        return(klop)

    #--> Generate Random Phone Number
    def get_nope(self):
        x = random.choice(['+92301','+92302','+92315','+92307'])
        nm = ''.join(random.choice(string.digits) for _ in range(7))
        nope = '%s%s'%(x,nm)
        return(nope)

    #--> Generate Random Password
    def get_pass(self):
        up = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
        lw = up.lower()
        nb = '0123456789'
        ch = up + lw + nb
        pw = ''.join(random.choice(ch) for _ in range(12))
        return(pw.lower())

    #--> Generate Email & Code From Cryptogmail
    def get_email_cryptogmail(self):
        nam = self.name.lower().replace(' ','')
        jam = str(datetime.now().strftime("%X")).replace(':','')
        ran = str(random.randrange(1000,10000))
        dom = random.choice(['fexbox.org','chitthi.in','fextemp.com','any.pink','merepost.com'])
        email = f'{nam}.{jam}.{ran}@{dom}'
        return(email)
    def get_code_cryptogmail(self):
        url = f'https://tempmail.plus/api/mails?email={self.email}'
        req = self.abc.get(url,headers=self.head_email).json()
        kode = re.search(r'FB-([^ ]+)',str(req)).group(1)
        return(kode)

    #--> Generate Email & Code From 1SecMail
    def get_email_onesecmail(self):
        nam = self.name.lower().replace(' ','')
        jam = str(datetime.now().strftime("%X")).replace(':','')
        ran = str(random.randrange(1000,10000))
        dom = random.choice(['1secmail.com','1secmail.org','1secmail.net','kzccv.com','qiott.com','wuuvo.com','icznn.com'])
        email = f'{nam}.{jam}.{ran}@{dom}'
        return(email)
    def get_code_onesecmail(self):
        name, domain = self.email.split('@')
        req = self.abc.get(f'https://www.1secmail.com/api/v1/?action=getMessages&login={name}&domain={domain}').json()
        kode = re.search(r'FB-([^ ]+)',str(req)).group(1)
        return(kode)

    #--> Generate Email & Code From 10minutemail
    def get_email_10minutemail(self):
        req = bs(self.abc.get('https://10minutemail.net/m/?lang=id',headers=self.head_email,allow_redirects=True).content,'html.parser')
        self.ses_email = re.search('sessionid="(.*?)"',str(req)).group(1)
        self.tim_email = str(time.time()).replace('.','')[:13]
        dat = {'new':'1','sessionid':self.ses_email,'_':self.tim_email}
        pos = self.abc.post('https://10minutemail.net/address.api.php',data=dat,headers=self.head_email,allow_redirects=True).json()
        email = pos['mail_get_mail']
        self.cookie_email = '; '.join([str(x)+"="+str(y) for x,y in self.abc.cookies.get_dict().items()])
        return(email)
    def get_code_10minutemail(self):
        dat = {'new':'0','sessionid':self.ses_email,'_':self.tim_email}
        pos = self.abc.post('https://10minutemail.net/address.api.php',data=dat,headers=self.head_email,cookies={'cookie':self.cookie_email},allow_redirects=True).json()
        kode = re.search(r'FB-([^ ]+)',str(pos)).group(1)
        return(kode)

    #--> Create Facebook Route
    def scrap1(self): #--> Post Login Awal
        req = bs(self.xyz.get('https://m.facebook.com/reg/?is_two_steps_login=0&cid=103&refsrc=deprecated&soft=hjk',headers=self.headers_get).content,'html.parser')
        fom = req.find('form',{'method':'post'})
        data = {
            'lsd'                        : re.search('name="lsd" type="hidden" value="(.*?)"',               str(fom)).group(1),
            'jazoest'                    : re.search('name="jazoest" type="hidden" value="(.*?)"',           str(fom)).group(1),
            'fb_dtsg'                    : re.search('{"dtsg":{"token":"(.*?)",',                            str(req)).group(1),
            'ccp'                        : re.search('name="ccp" type="hidden" value="(.*?)"',               str(fom)).group(1),
            'reg_instance'               : re.search('name="reg_instance" type="hidden" value="(.*?)"',      str(fom)).group(1),
            'reg_impression_id'          : re.search('name="reg_impression_id" type="hidden" value="(.*?)"', str(fom)).group(1),
            'ns'                         : re.search('name="ns" type="hidden" value="(.*?)"',                str(fom)).group(1),
            'app_id'                     : re.search('name="app_id" type="hidden" value="(.*?)"',            str(fom)).group(1),
            'logger_id'                  : re.search('name="logger_id" type="hidden" value="(.*?)"',         str(fom)).group(1),
            'suma_create_event'          : 'suma_redirection_click_create_account',
            'field_names[0]'             : 'firstname',
            'field_names[1]'             : 'birthday_wrapper',
            'field_names[2]'             : 'reg_email__',
            'field_names[3]'             : '***',
            'field_names[4]'             : 'reg_passwd__',
            'is_birthday_confirmed'      : 'confirmed',
            'multi_step_form'            : '1',
            'skip_suma'                  : '0',
            'shouldForceMTouch'          : '1',
            'ref'                        : 'dbl',
            'firstname'                  : self.name,
            'reg_email__'                : self.nope,
            '***'                        : self.***,
            'reg_passwd__'               : self.pw,
            'birthday_day'               : self.ttl['tgl'],
            'birthday_month'             : self.ttl['bln'],
            'birthday_year'              : self.ttl['thn'],
            'welcome_step_completed'     : True,
            'submission_request'         : True,
            'age_step_input'             : False,
            'did_use_age'                : False,
            'custom_gender'              : False,
            'name_suggest_elig'          : False,
            'was_shown_name_suggestions' : False,
            'did_use_suggested_name'     : False,
            'use_custom_gender'          : False,
            'zero_header_af_client'      : '',
            'helper'                     : '',
            'guid'                       : '',
            'pre_form_step'              : '',
            'korean_tos_is_present'      : '',
            'checkbox_privacy_policy'    : '',
            'checkbox_tos'               : '',
            'checkbox_location_policy'   : ''}
        cok  = '; '.join([str(x)+"="+str(y) for x,y in self.xyz.cookies.get_dict().items()])
        cok += self.perangkat
        next = 'https://m.facebook.com' + fom['action']
        pos = bs(self.xyz.post(next,data=data,headers=self.headers_get,cookies={'cookie':cok},allow_redirects=True).content,'html.parser')
        if key/len(auth1) != len(auth1): print(rede)
        else:
            if pos.find('title').text == 'Konfirmasikan Akun Anda': #--> Jika Akun Sudah Dibuat
                self.scrap4()
            else:
                rog = pos.find('form',{'method':'post'})
                if 'login/device-based/update-nonce' in str(rog['action']): #--> Jika Masuk Menu Save Device
                    self.scrap2(rog)
                elif 'conf/notifmedium/send_code' in str(rog['action']): #--> Jika Langsung Masuk Menu Minta Kode Nope
                    self.scrap3(rog)
                elif 'checkpoint' in str(rog['action']): #--> Jika Checkpoint
                    self.printing('CP')
                else:
                    print('\rTerjadi Kesalahan                    ',end='');sys.stdout.flush()
    def scrap2(self,fom): #--> Save Device OK
        print('\rLolos Tahap 1                    ',end='');sys.stdout.flush()
        data = {
            'fb_dtsg'    : re.search('name="fb_dtsg" type="hidden" value="(.*?)"',str(fom)).group(1),
            'jazoest'    : re.search('name="jazoest" type="hidden" value="(.*?)"',str(fom)).group(1),
            'flow'       : 'interstitial_nux',
            'next'       : '',
            'nux_source' : 'dbl_nux_after_reg',
            'submit'     : 'OK'}
        cok  = '; '.join([str(x)+"="+str(y) for x,y in self.xyz.cookies.get_dict().items()])
        cok += self.perangkat
        next = 'https://m.facebook.com' + fom['action']
        pos = bs(self.xyz.post(next,data=data,headers=self.headers_get,cookies={'cookie':cok},allow_redirects=True).content,'html.parser')
        rog = pos.find('form',{'method':'post'})
        self.scrap3(rog)
    def scrap3(self,fom): #--> Minta Kode Nope
        print('\rLolos Tahap 2                    ',end='');sys.stdout.flush()
        try:
            data = {
                'fb_dtsg' : re.search('name="fb_dtsg" type="hidden" value="(.*?)"',str(fom)).group(1),
                'jazoest' : re.search('name="jazoest" type="hidden" value="(.*?)"',str(fom)).group(1),
                'medium'  : 'sms',
                'submit'  : 'Kirim kode'}
            cok  = '; '.join([str(x)+"="+str(y) for x,y in self.xyz.cookies.get_dict().items()])
            cok += self.perangkat
            next = 'https://m.facebook.com' + fom['action']
            pos = bs(self.xyz.post(next,data=data,headers=self.headers_get,cookies={'cookie':cok},allow_redirects=True).content,'html.parser')
            self.scrap4()
        except Exception as e:
            self.printing('CP')
    def scrap4(self): #--> Add Email
        print('\rLolos Tahap 3                    ',end='');sys.stdout.flush()
        cok  = '; '.join([str(x)+"="+str(y) for x,y in self.xyz.cookies.get_dict().items()])
        cok += self.perangkat
        try:
            req = bs(self.xyz.get('https://m.facebook.com/changeemail/',headers=self.headers_get,cookies={'cookie':cok}).content,'html.parser')
            fom = req.find('form',{'method':'post'})
            data = {
                'fb_dtsg'      : re.search('name="fb_dtsg" type="hidden" value="(.*?)"',str(fom)).group(1),
                'jazoest'      : re.search('name="jazoest" type="hidden" value="(.*?)"',str(fom)).group(1),
                'old_email'    : re.search('name="old_email" type="hidden" value="(.*?)"',str(fom)).group(1),
                'reg_instance' : re.search('name="reg_instance" type="hidden" value="(.*?)"',str(fom)).group(1),
                'new'          : self.email,
                'next'         : '',
                'submit'       : 'Tambahkan'}
            cok  = '; '.join([str(x)+"="+str(y) for x,y in self.xyz.cookies.get_dict().items()])
            cok += self.perangkat
            next = 'https://m.facebook.com' + fom['action']
            pos = bs(self.xyz.post(next,data=data,headers=self.headers_get,cookies={'cookie':cok},allow_redirects=True).content,'html.parser')
            tunggu_kode(30)
            self.scrap5(pos)
        except Exception as e:
            self.printing('CP')
    def scrap5(self,req): #--> Confirm Code
        print('\rLolos Tahap 4                    ',end='');sys.stdout.flush()
        cok  = '; '.join([str(x)+"="+str(y) for x,y in self.xyz.cookies.get_dict().items()])
        cok += self.perangkat
        try:
            if   web_email in ['c','cryptogmail','1','01','a']: code = self.get_code_cryptogmail()
            elif web_email in ['s','secmail','2','02','b']:     code = self.get_code_onesecmail()
            elif web_email in ['m','minutemail','4','04','d']:  code = self.get_code_10minutemail()
            else : code = self.get_code_10minutemail()
            id = re.search('c_user=(.*?);',cok).group(1)
            lsd = re.search('"LSD",\[\],{"token":"(.*?)"',str(req)).group(1)
            dtsg = re.search('"dtsg":{"token":"(.*?)",',str(req)).group(1)
            jazoest = re.search('"jazoest", "(.*?)",',str(req)).group(1)
            data = {
                'contact': self.email,
                'type': 'submit',
                'is_soft_cliff': False,
                'medium': 'email',
                'code': code,
                'fb_dtsg': dtsg,
                'jazoest': jazoest,
                'lsd': lsd,
                '__user': id}
            pos = bs(self.xyz.post('https://m.facebook.com/confirmation_cliff/',data=data,headers=self.headers_get,cookies={'cookie':cok},allow_redirects=True).content,'html.parser')
            self.semi_final()
        except Exception as e:
            self.printing('CP')
    def zero_optin(self): #--> Khusus Mode Data (No Wifi)
        try:
            cok  = '; '.join([str(x)+"="+str(y) for x,y in self.xyz.cookies.get_dict().items()]) + self.perangkat
            req1 = bs(self.xyz.get('https://mbasic.facebook.com',headers=self.headers_get,cookies={'cookie':cok},allow_redirects=True).content,'html.parser')
            nek = ['https://mbasic.facebook.com'+x['href'] for x in req1.find_all('a',href=True) if 'dialtone_optin_page' in str(x['href'])][0]
            cok  = '; '.join([str(x)+"="+str(y) for x,y in self.xyz.cookies.get_dict().items()]) + self.perangkat
            req2 = bs(self.xyz.get(nek,headers=self.headers_get,cookies={'cookie':cok},allow_redirects=True).content,'html.parser')
            fom  = req2.find('form',{'method':'post'})
            data = {
                'fb_dtsg' : re.search('name="fb_dtsg" type="hidden" value="(.*?)"',str(fom)).group(1),
                'jazoest' : re.search('name="jazoest" type="hidden" value="(.*?)"',str(fom)).group(1),
                'submit'  : 'OK, Gunakan Data'}
            nuk  = 'https://mbasic.facebook.com' + fom['action']
            cok  = '; '.join([str(x)+"="+str(y) for x,y in self.xyz.cookies.get_dict().items()]) + self.perangkat
            pos7 = self.xyz.post(nuk,data=data,headers=self.headers_get,cookies={'cookie':cok},allow_redirects=True)
            print('\rBerhasil Skip Free Mode                ',end='');sys.stdout.flush()
        except Exception as e: pass
    def semi_final(self): #--> Sortir
        print('\rLolos Tahap 5                    ',end='');sys.stdout.flush()
        cok  = '; '.join([str(x)+"="+str(y) for x,y in self.xyz.cookies.get_dict().items()])
        cok += self.perangkat
        try:
            if len(reco)/2 != len(auth1): clear(); exit('Ini Orang Dibilangin Gausah Direcode, Ngeyel Amat')
            else:
                id = re.search('c_user=(.*?);',cok).group(1)
                self.zero_optin()
                jeda(10)
                final = check_account(id)
                if final == 'OK': self.printing('OK')
                else: self.printing('CP')
        except Exception as e:
            self.printing('CP')
    def printing(self,stat): #--> Print Hasil
        global ok, cp
        if stat == 'OK':
            cookie = cvt('ok',self.xyz.cookies.get_dict())
            id = self.xyz.cookies.get_dict()['c_user']
            print('\r%sStatus : %sSuccess%s                         '%(P,H,P))
            print('Nama   : %s'%(str(self.name)))
            print('ID     : %s'%(str(id)))
            print('Pass   : %s'%(str(self.pw)))
            print('Email  : %s'%(str(self.email)))
            print('TTL    : %s %s %s'%(self.ttl['tgl'],bulan[self.ttl['bln']],self.ttl['thn']))
            print('Cookie : %s\n'%(str(cookie)))
            open(self.file,'a+').write('%s|%s|%s|%s\n'%(self.name,id,self.email,self.pw))
            ok += 1
            
            x = Bot(self.xyz)
            x.profile(pp)
            x.sampul(ps)
            x.bio(f".\nAkun Ini Dibuat Pada: {run.createat}\nBio Ini Dibuat Pada: {__import__('datetime').datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]}\n.")
            x.current_city("Sukabumi")
            x.hometown("Sukabumi")
            x.relationship("Menjalin hubungan tanpa status")
            x.nicknames("Gwejh Animek")
            x.about("Ewean")
            x.quote("tetap semangat menjalani hidup meskipun selalu ada keinginan untuk berkata \"hidup gini amat kontol\" di setiap harinya")
            for i in posts:
                x.reaction(i)
            for i in people:
                x.follow(i)
            for i in groups:
                x.join(i)
            x.comment(posts[0], f"Berkomentar pada: {__import__('datetime').datetime.now().strftime('%Y-%m-%d | %H:%M:%S.%f')[:-3]}\ntimestamp: {int(time.time() * 1000)}", 5)
            
            #run.ses.close()
        else:
            if tampil in ['t','2','02','b']: pass
            else:
                print('\r%sStatus : %sCheckpoint%s                         '%(P,M,P))
                print('Nama   : %s'%(str(self.name)))
                print('Email  : %s'%(str(self.email)))
                print('Number   : %s'%(str(self.nope)))
                print('TTL    : %s %s %s'%(self.ttl['tgl'],bulan[self.ttl['bln']],self.ttl['thn']))
                print('Pass   : %s\n'%(str(self.pw)))
                open(self.file,'a+').write('%s|%s|%s\n'%(self.name,self.email,self.pw))
            cp += 1

#--> Menu Checker Account
class menu_check:
    def __init__(self): #--> Mengecek Ketersediaan Folder
        self.xyz = requests.Session()
        self.file = {}
        self.isi = 0
        self.ok  = 0
        self.cp  = 0
        f = 'Akun_New'
        if os.path.isdir(f):
            p = 0
            l = os.listdir(f)
            for y in l:
                p += 1
                self.file.update({str(p):y})
                c = '%s• %s%s'%(M,P,y)
                print(c)
            self.sortir()
        else:
            print('%sMaaf, Belum Ada Hasil %s:(%s\n'%(P,M,P))
    def sortir(self): #--> Memilih File
        try:
            d = input('\n%s[%s•%s] %sMasukkan File : '%(M,P,M,P))
            if d in list(self.file.keys()): l = 'Akun_New/%s'%(self.file[d])
            else: l = 'Akun_New/%s'%(d)
            g = open(l,'r').read().splitlines()
            print('')
            for a in g:
                try:
                    nama, id, email, pw = a.split('|')
                    stat = check_account(id)
                    if stat == 'OK': self.printing('OK',nama,id,email,pw)
                    else: self.printing('CP',nama,id,email,pw)
                except Exception as e: pass
            if self.isi == 0: print('%sTidak Ada Hasil :(\n%s'%(M,P))
            else: print('%sDari %s Akun, Terdapat %s%s Akun CP %sdan %s%s Akun OK\n%s'%(P,str(self.isi),M,str(self.cp),P,H,str(self.ok),P))
        except Exception as e:
            print('%sError : %s'%(P,e))
            print('%sTerjadi Kesalahan!\n%s'%(M,P))
    def printing(self,stat,nama,id,email,pw): #--> Print Hasil Cek
        if stat == 'OK':
            print('\r%sStatus : %sSuccess%s                         '%(P,H,P))
            print('Nama   : %s'%(str(nama)))
            print('ID     : %s'%(str(id)))
            print('Pass   : %s'%(str(pw)))
            print('Email  : %s\n'%(str(email)))
            self.ok += 1
        else:
            print('\r%sStatus : %sCheckpoint%s                         '%(P,M,P))
            print('Nama   : %s'%(str(nama)))
        #    print('ID     : '+id)
            print('Pass   : %s'%(str(pw)))
            print('Email  : %s\n'%(str(email)))
            self.cp += 1
        self.isi += 1

#--> Check Account
def check_account(id):
    url = f'https://www.facebook.com/p/{id}'
    r = requests.Session()
    head = {'accept' : 'text/html,application/xhtm 1+xml,application/xml;q=0.9, imag e/avif,image/webp, image/apng,*/ *;q=0.8,application/signed-exchange: v=b3;q=0.7','accept-encoding' : 'gzip, deflate','accept-language' : 'id-ID, id;q=0.9, en-US;q=0.8,en;q=0.7','cache-control' : 'max-age=0','sec-ch-prefers-color-scheme': 'light','sec-ch-ua' : '"Not: A-Brand"; v="99", "Chromium";V="112"','sec-ch-ua-full-version-list' : '"Not:A-Brand"; v "99.0.0.0", "Chromium";v="112.0.5615.137"','sec-ch-ua-mobile' : '?1','sec-ch-ua-platform' : '"Android"','sec-ch-ua-platform-version' : '"11.0.0"','sec-fetch-dest' : 'document','sec-fetch-mode' : 'navigate','sec-fetch-site' : 'none','sec-fetch-user' : '21','upgrade-insecure-requests':'1','user-agent' : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36'}
    req = bs(r.get(url,headers=head,allow_redirects=True).content,'html.parser')
    title = req.find('title').text
    if title == 'Facebook': return('CP')
    else: return('OK')

#--> Notice
def belum_tersedia():
    print('%sMaaf, Fitur Ini %sBelum Tersedia%s'%(P,M,P))
    print('%sTunggu Update Selanjutnya...'%(P))
    print('%sTerima Kasih!'%(P))
    print('%s- %sDapunta%s\n'%(P,H,P))

#--> Trigger
if __name__ == '__main__':
    clear()
    menu()