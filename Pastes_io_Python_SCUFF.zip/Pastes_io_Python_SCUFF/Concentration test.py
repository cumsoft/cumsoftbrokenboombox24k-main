<pre><code class="language-python">
import time
import random

# Define the length of the test in seconds
test_length = 60

# Generate a list of random numbers to memorize
number_list = [random.randint(1, 9) for i in range(10)]

# Show the user the list of numbers to memorize
print("Memorize this list of numbers:")
print(number_list)

# Wait for a short period to let the user memorize the numbers
time.sleep(5)

# Clear the screen
print("\n" * 100)

# Start the test
print("Enter the list of numbers you just saw:")
start_time = time.time()
user_input = input()
end_time = time.time()

# Check the user's input
if user_input == " ".join([str(num) for num in number_list]):
    print("Congratulations, you got it right!")
else:
    print("Sorry, that's incorrect.")

# Calculate the user's reaction time
reaction_time = end_time - start_time

# Display the user's score
print(f"Your reaction time was {reaction_time:.2f} seconds.")
</code></pre>