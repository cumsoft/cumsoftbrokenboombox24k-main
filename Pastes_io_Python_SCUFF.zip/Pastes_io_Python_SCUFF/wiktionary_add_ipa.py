'''
pip install requests
pip install bs4
'''


import requests
from bs4 import BeautifulSoup


URL = "https://pl.wiktionary.org/w/api.php"
HEADERS = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'}
SEARCHING = "({{język angielski}}) ==\n{{wymowa}}\n{{znaczenia}}"
PARAMS = {"action": "query", "format": "json", "list": "categorymembers", "cmtitle": "Kategoria:angielski (indeks)", "cmlimit": 1}


def get_ipas(word):
    response = requests.get("https://dictionary.cambridge.org/pronunciation/english/" + word.lower().replace(' ', '-'), headers=HEADERS)
    soup = BeautifulSoup(response.text, "html.parser")
    
    count = 0
    names = soup.find_all("span", class_="term tb")
    for name in names:
        if name.get_text() == word:
            section = name.find_parent("div", class_="pron-block lmb-10")
            count += 1
    if count != 1:
        return False, False
    
    ipas = section.find_all("span", class_="ipa")
    if len(ipas) != 2:
        return False, False
    
    optionals = ipas[0].find_all("span", class_="sp dsp")
    if optionals:
        for optional in optionals:
            optional.string = '(' + optional.text + ')'
    optionals = ipas[1].find_all("span", class_="sp dsp")
    if optionals:
        for optional in optionals:
            optional.string = '(' + optional.text + ')'
    
    if ipas[0].text == ipas[1].text:
        british = ipas[0].text.replace('g', 'ɡ')
        american = ipas[0].text.replace('g', 'ɡ')
    else:
        british = ipas[0].text.replace('g', 'ɡ')
        american = ipas[1].text.replace('g', 'ɡ')
    return british, american


def get_word_content(word):
    response = requests.get(URL, params={"action": "query", "format": "json", "prop": "revisions", "titles": word, "rvprop": "content"})
    data = response.json()
    page_id = list(data["query"]["pages"].keys())[0]
    word_content = data["query"]["pages"][page_id]["revisions"][0]["*"]
    return word_content


def update_word(word):
    #print(word)
    word_content = get_word_content(word)
    if not SEARCHING in word_content:
        return
    british, american = get_ipas(word)
    if not british:
        return
    session = requests.Session()
    response = session.get(url=URL, params={"action": "query", "meta": "tokens", "format": "json"})
    data = response.json()
    
    response = session.post(URL, data={"action": "edit", "title": word, "token": data['query']['tokens']['csrftoken'], "format": "json", "text": word_content.replace(SEARCHING, "({{język angielski}}) ==\n{{wymowa}}\n: {{bryt}} {{IPA|" + british + "}}\n: {{amer}} {{IPA|" + american + "}}\n{{znaczenia}}")})


def main():
    while True:
        content = requests.get("https://pl.wiktionary.org/w/api.php", params=PARAMS, headers=HEADERS).json()
        for word in content['query']['categorymembers']:
            update_word(word['title'])
        if 'continue' not in content:
            break
        PARAMS['cmcontinue'] = content['continue']['cmcontinue']

main()