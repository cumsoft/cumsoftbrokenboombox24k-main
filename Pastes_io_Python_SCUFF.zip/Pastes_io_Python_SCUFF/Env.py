# .env for Dynamic Deployment

# Development Settings
DEBUG=True
SECRET_KEY='django-insecure-5)m04++av&n=%91w5wp=ux826t&s5n$fu=@%feb$8z)y79a8d^'
ALLOWED_HOSTS=["*"]
CELERY_BROKER_URL = 'amqp://nybsys:nybsys123!@192.168.0.11:5672/dev_host'
FTP_HOST=192.168.0.11
FTP_USERNAME=nybsys
FTP_PASSWORD=NybSys123!
DATABASE_NAME=nybcell
DATABASE_HOST=192.168.0.11
DATABASE_USER=sa
DATABASE_PASSWORD=NybSys@123!
DATABASE_PORT=1433
DATABASE_DRIVER=ODBC Driver 17 for SQL Server
DATABASE_NAME2=nybsys
DATABASE_NAME3=invoice_backup
DOMAIN_NAME=dev.nybcell.com
LOG_APIS="http://192.168.0.11:5000/status, http://192.168.0.11:5000/status"
TEST_API_URL = 'http://192.168.0.11:8000/'
IMEI_API_URL = "https://www.imei.info/api/checkimei/"
IMEI_KEY = "47171708c862ea60a16b4e345f7005359e806e75ec1589c54a77aa2539b2d906"
IP_API_URL = "http://ip-api.com/json/"
REQUIREMENT_SALES_EMAIL= "sales@nybsys.com"
OTP_SENDER_EMAIL = 'commsoft@nybsys.com'
OTP_SENDER_PASSWORD = 'aaczbkjupmxpgbyc'
FIREBASE_DYNAMIC_LINK = 'https://firebasedynamiclinks.googleapis.com/v1/shortLinks?key'
USER_INVITATION_FIREBASE_API_KEY = 'AIzaSyBLEtHDAB7b10eziSf3CkQb2Jw8urnOfIo'