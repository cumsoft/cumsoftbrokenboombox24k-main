from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QListWidget, QTextEdit, QHBoxLayout, QPushButton, \
    QVBoxLayout, QLineEdit, QLabel
from PyQt5.QtGui import QIcon, QFont
from PyQt5 import QtCore, QtWidgets
import urllib.parse as up
import requests
import sys
import re
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.firefox.service import Service
from selenium.webdriver.firefox.options import Options


class CopyableListWidget(QListWidget):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def keyPressEvent(self, event):
        if event.key() == QtCore.Qt.Key_C and event.modifiers() == QtCore.Qt.ControlModifier:
            self.copy_selected_text()
        else:
            super().keyPressEvent(event)

    def contextMenuEvent(self, event):
        menu = QtWidgets.QMenu(self)
        copy_action = menu.addAction("Copy")
        copy_action.triggered.connect(self.copy_selected_text)
        menu.exec_(event.globalPos())

    def copy_selected_text(self):
        selected_text = self.currentItem().text() if self.currentItem() else ""
        selected_text = selected_text.split("(", 1)[0].strip()  # remove text within parentheses
        QtWidgets.QApplication.clipboard().setText(selected_text)


class MyWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        # Set window title
        self.setWindowTitle("Help")

        # Set window icon
        icon_path = r"C:\Users\jurad\Desktop\Capture2Text_v4.6.3_64bit\Bot Assets\GUI_widget.png"
        self.setWindowIcon(QIcon(icon_path))

        # Create central widget
        central_widget = QWidget(self)
        self.setCentralWidget(central_widget)

        # Create layout
        layout = QVBoxLayout()

        # Create QLineEdit and Search Button
        self.search_edit = QLineEdit(self)
        search_button = QPushButton("Search")
        search_button.clicked.connect(self.translate)

        # Connect returnPressed signal of QLineEdit to clicked signal of search button
        self.search_edit.returnPressed.connect(search_button.click)

        # Create widget for the search box and button
        search_widget = QWidget(self)
        search_layout = QHBoxLayout()
        search_layout.addWidget(QLabel("Enter text here:"))
        search_layout.addWidget(self.search_edit)
        search_layout.addWidget(search_button)
        search_widget.setLayout(search_layout)

        # Add search widget to layout
        layout.addWidget(search_widget)

        # Create non-clickable textbox
        self.non_clickable_textbox = QLabel(self)
        self.non_clickable_textbox.setText("Example String")
        self.non_clickable_textbox.setAlignment(QtCore.Qt.AlignVCenter | QtCore.Qt.AlignRight)
        search_layout.addWidget(self.non_clickable_textbox)

        # Create icon layout
        icon_layout = QHBoxLayout()

        # Create icons
        icon1 = QPushButton()
        icon1.setIcon(QIcon("C:/Users/jurad/Desktop/Capture2Text_v4.6.3_64bit/Bot Assets/jisho icon.png"))
        icon1.setFixedSize(75, 75)
        icon1.setIconSize(QtCore.QSize(75, 75))
        icon1.setToolTip("Show Details")
        icon1.clicked.connect(self.show_details)

        icon2 = QPushButton()
        icon2.setIcon(QIcon(r"C:\Users\jurad\Desktop\Capture2Text_v4.6.3_64bit\Bot Assets\reibun_icon.png"))
        icon2.setFixedSize(75, 75)
        icon2.setIconSize(QtCore.QSize(75, 75))
        icon2.setToolTip("Show Details")
        icon2.clicked.connect(self.sentences)

        icon3 = QPushButton(QIcon("icon3.png"), "")
        icon3.setFixedSize(75, 75)
        icon3.setToolTip("Function 3")
        icon3.clicked.connect(self.function3)

        icon4 = QPushButton(QIcon("icon4.png"), "")
        icon4.setFixedSize(75, 75)
        icon4.setToolTip("Function 4")
        icon4.clicked.connect(self.function4)

        icon5 = QPushButton(QIcon("icon5.png"), "")
        icon5.setFixedSize(75, 75)
        icon5.setToolTip("Function 5")
        icon5.clicked.connect(self.function5)

        # Add icons to icon layout
        icon_layout.addWidget(icon1)
        icon_layout.addWidget(icon2)
        icon_layout.addWidget(icon3)
        icon_layout.addWidget(icon4)
        icon_layout.addWidget(icon5)

        # Create listbox and QTextEdit
        self.listbox = CopyableListWidget(self)
        self.listbox.currentItemChanged.connect(self.update_commonality)
        self.text_edit = QTextEdit(self)

        # Set the font size to 14
        font = QFont()
        font.setPointSize(14)
        self.listbox.setFont(font)
        self.text_edit.setFont(font)

        # Create widget for the listbox and QTextEdit
        list_text_widget = QWidget(self)
        list_text_layout = QHBoxLayout()
        list_text_layout.addWidget(self.listbox)
        list_text_layout.addWidget(self.text_edit)
        list_text_widget.setLayout(list_text_layout)

        # Add widgets to layout
        layout.addLayout(icon_layout)
        layout.addWidget(list_text_widget)

        # Set layout to central widget
        central_widget.setLayout(layout)

    def translate(self):
        try:
            translate = self.search_edit.text()
            jisho_url = f"https://jisho.org/api/v1/search/words?keyword={up.quote(translate)}"
            data = requests.get(jisho_url).json()["data"]

            self.d = {}

            for i in data:
                word = i['japanese'][0].get('word', '')
                reading = i['japanese'][0].get('reading', '')

                if not word:
                    word = reading

                key = word + ' (' + reading + ')'
                self.d[key] = i

            self.listbox.clear()

            for i, r in enumerate(self.d):
                self.listbox.addItem(r)
            self.listbox.setCurrentRow(0)
        except Exception as e:
            print(f"An error occurred: {e}")

    def show_details(self):
        item = self.listbox.currentItem()
        if item is not None:
            result = self.d[item.text()]

            self.text_edit.clear()
            self.text_edit.append(f"Japanese: {result['japanese'][0].get('word', '')}\n")
            if "reading" in result["japanese"][0]:
                self.text_edit.append(f"Reading: {result['japanese'][0]['reading']}\n")
            self.text_edit.append("English: ")
            for m in result["senses"]:
                if "english_definitions" in m:
                    self.text_edit.append(f"{', '.join(m['english_definitions'])}; ")
                if "tags" in m and "Common word" in m["tags"]:
                    self.text_edit.append("(Common word); ")

    def sentences(self):
        selected_word = self.listbox.currentItem().text().split("(", 1)[0].strip()
        if selected_word:
            # Set up Selenium WebDriver
            binary_path = 'C:\\Users\\jurad\\AppData\\Local\\Mozilla Firefox\\firefox.exe'
            options = Options()
            options.binary_location = binary_path
            options.add_argument('-headless')  # Run WebDriver invisibly
            service = Service(executable_path='c:\\webdrivers\\geckodriver.exe')
            driver = webdriver.Firefox(service=service, options=options)

            # navigate to website
            driver.get(f"https://www.kanshudo.com/searcht?q={up.quote(selected_word)}")

            # get HTML
            html = driver.page_source

            # create soup
            soup = BeautifulSoup(html, 'html.parser')

            # find the desired sentences
            tatoeba_divs = soup.find_all("div", class_="tatoeba")
            tatoeba_divs = list(filter(lambda x: x.find("div", class_="furigana") is not None, tatoeba_divs))

            self.text_edit.clear()

            for tatoeba_div in tatoeba_divs:
                # Get furigana text
                furigana_list = [furigana.get_text() for furigana in tatoeba_div.find_all("div", class_="furigana")]

                # Extract the Japanese sentence
                sentence = tatoeba_div.get_text(strip=True).replace("(click the icon for English translation)", "")
                sentence = sentence.replace("。", "。\n")

                # Remove furigana from the sentence
                full_sentence = sentence
                for furi in furigana_list:
                    full_sentence = full_sentence.replace(furi, "", 1)

                # Print the Japanese sentence without furigana
                self.text_edit.append(full_sentence)

            driver.quit()

    def update_commonality(self):
        s = self.listbox.currentRow()
        if s == -1:
            return None
        i = s
        result = self.d[self.listbox.item(i).text()]
        word = result['japanese'][0].get('word', '')

        if not word:
            return None

        try:
            url = f'https://jpdb.io/search?q={up.quote(word)}'
            response = requests.get(url)
            soup = BeautifulSoup(response.content, 'html.parser')
            commonality_tag = soup.find('div', class_='tag tooltip')

            if commonality_tag:
                commonality_text = commonality_tag.text.strip()
                commonality_number = re.search(r'\d+', commonality_text)
                if commonality_number:
                    commonality = commonality_number.group()
                else:
                    commonality = "N/A"
            else:
                commonality = "N/A"
        except Exception as e:
            print(f"An error occurred in update_commonality: {e}")
            commonality = "N/A"

        self.non_clickable_textbox.setText(f"Top\n {commonality}")

    def function3(self):
        print("Function 3")

    def function4(self):
        print("Function 4")

    def function5(self):
        print("Function 5")

    def search(self):
        search_text = self.findChild(QLineEdit, '').text()
        print(f"Searching for: {search_text}")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MyWindow()
    window.show()
    sys.exit(app.exec_())