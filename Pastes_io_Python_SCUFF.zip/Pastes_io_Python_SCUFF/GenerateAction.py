import hashlib
import json
import base64
import requests
import uuid
from typing import Dict, Optional
from uuid import uuid4
from craftgate.craftgate_options import *
options = CraftgateOptions()
path = "/payment/v1/cards"
request = {
  "price": 100.0,
  "paidPrice": 100.0,
  "walletPrice": 0.0,
  "installment": 1,
  "conversationId": "456d1297-908e-4bd6-a13b-4be31a6e47d5",
  "currency" :"TRY",
  "paymentGroup":"PRODUCT",
   "card": {
    "cardHolderName": "Haluk Demir",
    "cardNumber": "5258640000000001",
    "expireYear": "2044",
    "expireMonth": "07",
    "cvc": "000"
  },
  "items": [
    {
      "name": "Item 1",
      "price": 30.0,
      "externalId": "123d1297-839e-4bd6-a13b-4be31a6e12a8"
    },
    {
      "name": "Item 2",
      "price": 50.0,
      "externalId": "789d1297-839e-4bd6-a13b-4be31a6e13f7"
    },
    {
      "name": "Item 3",
      "price": 20.0,
      "externalId": "3a1d1297-839e-4bd6-a13b-4be31a6e18e6"
    }
  ]
}

generate(options,path,request)
'z/Y3RfjQKxg3m+ePtK+sjWewc45sw4jUy3TM+03Xw4s='