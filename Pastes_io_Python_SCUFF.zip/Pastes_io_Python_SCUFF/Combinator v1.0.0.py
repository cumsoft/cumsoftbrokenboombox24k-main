"""
Author @Uviware

Usage:
Run the main.py file using 'python/python3 main.py' in the console
Input the correct directory in which you want to combine your combo files
Check the 'Results.txt' for your combined combos or the "category".txt file
if you chose to auto-sort the combos based on their file name.

Version 1.0.0
- Load all files from a directory
- Read the file content from the loaded files
- Line duplicates are removed by default
- File validation to ensure only plaintext files are read
- Combine the total file content into one file or into categorized files
"""

import os
import time
import sys


def load_files(directory, exclude_files):
    file_paths = []
    for root, _, files in os.walk(directory):
        for file in files:
            if file.endswith('.txt') and file not in exclude_files:
                file_path = os.path.join(root, file)
                file_paths.append(file_path)
                print(f'Loaded {file}...')
            else:
                if file not in exclude_files:
                    print(f'Error: {file} is not a .txt file. Skipping.')
    return file_paths


def read_files(file_paths):
    lines = []
    for file_path in file_paths:
        with open(file_path, 'r', encoding='latin-1') as file:
            for line in file:
                stripped_line = line.strip()
                if stripped_line:
                    lines.append(stripped_line)
    return list(set(lines))


def combine_lines(lines):
    combined_text = '\n'.join(lines)
    return combined_text


def write_to_file(combined_text, output_filename):
    if os.path.exists(output_filename):
        choice = input(f"\nThe file {output_filename} already exists. Do you want to overwrite the data inside? (yes/no):\n\n").lower()
        if choice == 'yes':
            os.remove(output_filename)
            mode = 'w'
        if choice == 'no':
            mode = 'a'
        else:
            print('Did not receive a yes/no response, exiting...')
            time.sleep(3)
            sys.exit()
    else:
        mode = 'w'

    if mode == 'w':
        with open(output_filename, mode) as file:
            file.write(combined_text)
            total_lines = combined_text.count('\n') + 1
            print(f"Total lines written: {total_lines} to {output_filename}!")

            file.flush()
            os.fsync(file.fileno())

    if mode == 'a':
        with open(output_filename, mode) as file:
            file.write(combined_text)
            total_lines = combined_text.count('\n') + 1
            print(f"Total lines appended: {total_lines} to {output_filename}!")

            file.flush()
            os.fsync(file.fileno())



def categorize_and_write_files(file_paths):
    categories = {
        'FOOD': [],
        'STREAMING': [],
        'VPN': [],
        'GAMING': [],
        'SHOPPING': [],
        'MAIL': [],
        'ALL': []
    }

    for file_path in file_paths:
        file_name = os.path.basename(file_path)
        with open(file_path, 'r', encoding='latin-1') as file:
            lines = [line.strip() for line in file if line.strip()]

        categorized = False
        for category in categories:
            if category in file_name.upper():
                categories[category].extend(lines)
                categorized = True
                break

        if not categorized:
            categories['ALL'].extend(lines)

    for category, lines in categories.items():
        if lines:
            combined_text = combine_lines(lines)
            output_filename = os.path.join(directory, f'{category.lower()}_combined.txt')
            write_to_file(combined_text, output_filename)


if __name__ == '__main__':
    directory = input('Please enter the directory where all the combo files are located:\n\n')

    categories = ['food', 'streaming', 'vpn', 'gaming', 'shopping', 'mail', 'all']
    exclude_files = [f"{category.lower()}_combined.txt" for category in categories]
    exclude_files.append('Results.txt')

    try:
        os.listdir(directory)
        print(f'Directory exists: {directory}')
    except FileNotFoundError:
        print(f'Directory {directory} does not exist, exiting...')
        time.sleep(3)
        sys.exit()


    file_paths = load_files(directory, exclude_files)

    sort_choice = input("\nDo you want to sort the files by category, example VPN/STREAMING/FOOD? (yes/no):\n\n").lower()
    if sort_choice == 'yes':
        categorize_and_write_files(file_paths)
    if sort_choice == 'no':
        lines = read_files(file_paths)
        combined_text = combine_lines(lines)
        output_file = os.path.join(directory, 'Results.txt')
        if output_file:
            overwrite_choice = input('Do you want to overwrite the "Results.txt" file? (yes/no):\n\n').lower()
            if overwrite_choice == 'yes':
                write_to_file(combined_text, output_file)
            print('\nNothing to write, exiting...')
            time.sleep(3)
    else:
        print('Did not receive a yes/no response, exiting...')
        time.sleep(3)
        sys.exit()