import re
from sys import stdin
 
PATTERN = r'\b[A-Z][a-z]+\b - \b[A-Z][a-z]+\b : [0-9][0-9].[0-9][0-9].[0-9][0-9][0-9][0-9]\b'
input_str = stdin.read()
res = re.findall(PATTERN, input_str)
 
print(res)