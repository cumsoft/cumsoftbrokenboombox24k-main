import cv2
import numpy as np

from typer import Typer


app = Typer()


@app.command()
def main(src_path, bg_path):

    img = cv2.imread(src_path)

    # arka plani da alalim, boyutlarin esit olmasi gerekecek.
    # duruma gore maskleri resize etmek yeterli olur
    background = cv2.imread(bg_path)
    background = cv2.resize(background, tuple(img.shape[:2]))

    # grayscale gorsel uzerinde adaptive thresholding uygulayarak maske olusturuyoruz
    gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
    # burada thresholding uyguluyoruz, 51 ve 10 degerleri deneme yanilma ile bulunmus degerler
    thresh = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY_INV, 51, 10)

    cv2.imshow('grayscale', gray)

    # bu fonksiyon ile thresholding uyguladigimiz resimdeki konturleri buluyoruz
    contours, hierarchy = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # en buyuk kontoru bulalim
    contour_sizes = [(cv2.contourArea(contour), contour) for contour in contours]
    biggest_contour = max(contour_sizes, key=lambda x: x[0])[1]

    # o kontur icin maske olusturalim
    mask = np.zeros(img.shape, np.uint8)
    cv2.drawContours(mask, [biggest_contour], -1, (255, 255, 255), -1)

    cv2.imshow('En buyuk konturun maskesi', mask)

    # maskeyi orijinal gorsele uygulayalim
    masked_image = cv2.bitwise_and(img, mask)

    cv2.imshow('Maskelenmis gorsel', masked_image)

    # gelmisken bir de bounding box ekleyelim
    x, y, w, h = cv2.boundingRect(biggest_contour)
    cv2.rectangle(masked_image, (x, y), (x + w, y + h), (0, 255, 0), 2)

    cv2.imshow('bounding box eklenen gorsel', masked_image)


    cv2.imshow("Arka plan", background)

    # graffitiyi yerlestirmek icin maskeyi kullanacagiz
    background[np.where(mask == 255)] = img[np.where(mask == 255)]

    cv2.imshow('Sonuc', background)

    # gorseli exportlayalim
    cv2.imwrite('sonuc.jpg', background)

    if cv2.waitKey(0) & 0xFF == ord('q'):
        cv2.destroyAllWindows()



if __name__ == "__main__":
    app()