import requests
from bs4 import BeautifulSoup

# Set the base URL for the imDb website
base_url = 'https://m.imdb.com/list/ls024863935/'

# Set the number of pages to scrape
num_pages = 13

# Initialize an empty list to store the movies
movies = []

# Iterate over the pages and scrape the movie information
for i in range(num_pages):
  # Build the URL for the page
  if i > 1:
    url = f'{base_url}?page={page_num}'
  else:
    url = base_url

  # Send a request to the imDb website and parse the response with Beautiful Soup
  response = requests.get(url)
  soup = BeautifulSoup(response.text, 'html.parser')

  # Extract the movie information from the HTML
  for movie_div in soup.find_all('div', class_='lister-item-content'):
    title = movie_div.h3.a.text
    year = movie_div.h3.find('span', class_='lister-item-year').text
    rating = movie_div.strong.text
    movies.append({
      'title': title,
      'year': year,
      'rating': rating,
      'column1': 'N',
      'column2': 'N'
    })

# Write movie information to a CSV file
with open('movies.csv', 'w', newline='') as csvfile:
  fieldnames = ['title', 'year', 'rating', 'column1', 'column2']
  writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

  writer.writeheader()
  for movie in movies:
    writer.writerow(movie)