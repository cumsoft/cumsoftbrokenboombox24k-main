import arcade
import random
import arcade.gui

SCREEN_WIDTH = 725
SCREEN_HEIGHT = 607

meteors = [":resources:images/space_shooter/meteorGrey_big2.png",
           ":resources:images/space_shooter/meteorGrey_big1.png",
           ":resources:images/space_shooter/meteorGrey_med1.png",
           ":resources:images/space_shooter/meteorGrey_small2.png",
           ":resources:images/space_shooter/meteorGrey_med2.png",
           ]

levels = [
    ("Level 1", True, 10, 20, 1),
    ("Level 2", False, 20, 30, 2),
    ("Level 3", False, 30, 40, 3),
    ("Venus", False, 40, 50, 4),
]


class StartMenu(arcade.View):
    def on_show(self):
        arcade.set_background_color(arcade.csscolor.BLACK)

    def on_draw(self):
        arcade.start_render()
        arcade.draw_lrwh_rectangle_textured(-200, 0, SCREEN_WIDTH * 2, SCREEN_HEIGHT * 2,
                                            arcade.load_texture(":resources:images/backgrounds/stars.png"))

        arcade.draw_text("Битва в космосе", SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2,
                         arcade.color.WHITE, font_size=70, anchor_x="center")

        arcade.draw_text("Чтобы начать игру, нажмите ENTER", SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2 - 75,
                         arcade.color.WHITE, font_size=20, anchor_x="center")

    def on_key_press(self, key, modifiers):
        """Вызывается всякий раз, когда нажимается кнопка """
        if key == arcade.key.ENTER:
            level_menu = LevelMenu()
            level_menu.setup()
            self.window.show_view(level_menu)

class GameOver(arcade.View):
    def on_show(self):
        arcade.set_background_color(arcade.csscolor.BLACK)

    def on_draw(self):
        arcade.start_render()
        arcade.draw_lrwh_rectangle_textured(-200, 0, SCREEN_WIDTH * 2, SCREEN_HEIGHT * 2,
                                            arcade.load_texture(":resources:images/backgrounds/stars.png"))

        arcade.draw_text("Вы проиграли", SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2,
                         arcade.color.WHITE, font_size=70, anchor_x="center")

        arcade.draw_text("Чтобы вернуться в меню, нажмите ENTER", SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2 - 75,
                         arcade.color.WHITE, font_size=20, anchor_x="center")

    def on_key_press(self, key, modifiers):
        """Вызывается всякий раз, когда нажимается кнопка """
        if key == arcade.key.ENTER:
            level_menu = LevelMenu()
            level_menu.setup()
            self.window.show_view(level_menu)

class WinMenu(arcade.View):
    def __init__(self, level, coins):
        super().__init__()

        self.level = level
        self.coins = coins

    def on_show(self):
        arcade.set_background_color(arcade.csscolor.BLACK)

    def on_draw(self):
        arcade.start_render()
        arcade.draw_lrwh_rectangle_textured(-200, 0, SCREEN_WIDTH * 2, SCREEN_HEIGHT * 2,
                                            arcade.load_texture(":resources:images/backgrounds/stars.png"))

        arcade.draw_text(f"Уровень {self.level} пройден!", SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2,
                         arcade.color.WHITE, font_size=40, anchor_x="center")

        arcade.draw_text(f"Вам засчитались {self.coins} монет!", SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2 - 75,
                         arcade.color.WHITE, font_size=20, anchor_x="center")

    def on_key_press(self, key, modifiers):
        """Вызывается всякий раз, когда нажимается кнопка """
        if key == arcade.key.ENTER:
            level_menu = LevelMenu()
            level_menu.setup()
            self.window.show_view(level_menu)

class LevelMenu(arcade.View):
    def setup(self):
        for level in levels:
            print(level)

    def on_show(self):
        arcade.set_background_color(arcade.csscolor.BLACK)

    def on_draw(self):
        arcade.start_render()
        arcade.draw_lrwh_rectangle_textured(-200, 0, SCREEN_WIDTH * 2, SCREEN_HEIGHT * 2,
                                            arcade.load_texture(":resources:images/backgrounds/stars.png"))

        offset = 0
        for level in levels:
            arcade.draw_text(level[0], SCREEN_WIDTH / 2, (SCREEN_HEIGHT - 100) - offset,
                             arcade.color.WHITE, font_size=20, anchor_x="center")
            offset = offset + 50

    def on_key_press(self, key, modifiers):
        """Вызывается всякий раз, когда нажимается кнопка """
        if key == arcade.key.KEY_1 and levels[0][1] == True:
            game_view = GameView(levels[0][2], levels[0][3], levels[0][4])
            #game_view.setup()
            self.window.show_view(game_view)
        if key == arcade.key.KEY_2 and levels[1][1] == True:
            game_view = GameView(levels[1][2], levels[1][3], levels[1][4])
            #game_view.setup()
            self.window.show_view(game_view)

class GameView(arcade.View):
    def __init__(self, number_enemies, number_coins, level_number):
        super().__init__()
        self.window.set_mouse_visible(False)

        self.number_enemies = number_enemies
        self.number_coins = number_coins
        self.level_number = level_number

        self.player_list = arcade.SpriteList()
        self.coin_list = arcade.SpriteList()
        self.enemies_list = arcade.SpriteList()
        self.bullet_list = arcade.SpriteList()

        self.counter = 0
        self.lives = 3

        # Setup sprites

        self.player_sprite = arcade.Sprite(":resources:images/space_shooter/playerShip1_green.png", 0.5)
        self.player_sprite.center_x = 100
        self.player_sprite.center_y = 100
        self.player_list.append(self.player_sprite)

        for i in range(number_coins):
            self.coin = arcade.Sprite(":resources:images/items/coinGold.png", 0.3)
            self.coin.center_x = random.randrange(SCREEN_WIDTH)
            self.coin.center_y = random.randrange(SCREEN_HEIGHT)
            self.coin.velocity = (0, 1*random.randrange(1, 5))
            self.coin_list.append(self.coin)

        for i in range(number_enemies):
            self.enemy = arcade.Sprite(random.choice(meteors), 0.3)
            self.enemy.center_x = random.randrange(SCREEN_WIDTH)
            self.enemy.center_y = random.randrange(SCREEN_HEIGHT)
            self.enemy.velocity = (0, -1 * random.randrange(1, 5))
            self.enemies_list.append(self.enemy)

    def on_show(self):
        arcade.set_background_color(arcade.csscolor.BLACK)

    def on_draw(self):
        arcade.start_render()

        arcade.draw_lrwh_rectangle_textured(-200, 0, SCREEN_WIDTH * 2, SCREEN_HEIGHT * 2,
                                            arcade.load_texture(":resources:images/backgrounds/stars.png"))

        self.player_list.draw()
        self.coin_list.draw()
        self.enemies_list.draw()
        self.bullet_list.draw()

    def update(self, delta_time):
        self.coin_list.update()
        self.enemies_list.update()

        for i in self.coin_list:
            if i.center_y > SCREEN_HEIGHT:
                i.center_y = 0
        for i in self.enemies_list:
            if i.center_y < 0:
                i.center_y = SCREEN_HEIGHT

        coins_hit_list = self.player_sprite.collides_with_list(self.coin_list)
        for coin in coins_hit_list:
            coin.remove_from_sprite_lists()  # метод, который удаляет прайт из списка
            self.counter += 1

        enemies_hit_list = self.player_sprite.collides_with_list(self.enemies_list)
        for enemy in enemies_hit_list:
            enemy.remove_from_sprite_lists()
            self.counter -= 1
            self.lives -= 1

        if self.lives <= 0:
            self.window.show_view(GameOver())

        if len(self.coin_list) <= 0:
            self.window.show_view(WinMenu(self.level_number,self.counter))

    def on_mouse_motion(self, x, y, dx, dy):
        """ Обработка движения мыши """
        # Перемещаем центр спрайта игрока в соответствии с положением мыши по осям x и y.
        self.player_sprite.center_x = x
        self.player_sprite.center_y = y

def main():
    window = arcade.Window(SCREEN_WIDTH, SCREEN_HEIGHT, "BattleShip!")
    window.show_view(StartMenu())
    arcade.run()


main()