import numpy as np
from glob import glob

#Anpassen
from docutils.nodes import header

path = "C:/temp/regen/RW2017.002_202201_asc/"
ergebnis = path + "summe.asc"

#Pfad auslesen und Dateinamen speichern
files = glob(path + "*.asc")
count =len(files)

#Größe des Rasters raussuchen (bsp. 1100 * 900 Zellen)
dimensions = np.loadtxt(files[0], skiprows=6).shape

#Header aus erster Datei kopieren
with open(files[0]) as input_file:
    head_rows = [next(input_file) for _ in range(6)]

#Header Zeilen zu einem String
header = ''.join(head_rows)
#Letzten Zeilenumbruch löschen, sonst Leerzeile in Zeile 7
header = header[:-1]

#Leeres Raster erstellen
summe = np.zeros(dimensions)

#jede ASC durchgehen
for idx, file in enumerate(files):
    print(f"Datei {idx} von {count}")
    #Raster laden
    tag = np.loadtxt(file, skiprows=6)
    #-9999 durch 0 ersetzne
    tag[tag == -9999] = 0
    #Werte auf Summe addieren
    summe += tag

#Null wieder auf -999 setzen
summe[summe == 0] = -9999

np.savetxt(ergebnis, summe, header = header,  comments='')