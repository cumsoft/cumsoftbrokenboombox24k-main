import requests
from telegram import Bot, Update
from telegram.ext import Updater, CommandHandler, CallbackContext
from web3 import Web3

TOKEN = 'TELEGRAM_BOT_TOKEN'
WEB3_URL = 'https://rpc-mainnet.kcc.network'
KUSV3_ADDRESS = Web3.to_checksum_address('0xfd7a0e0a629402d92cb665d2a64fe6d22bf08a66')
WKCS_ADDRESS = Web3.to_checksum_address('0x4446fc4eb47f2f6586f9faab68b3498f86c07521')
POOL_ADDRESS = Web3.to_checksum_address('0x6bC7279D1DfCfCb968a8389c7Fc642Ae7728AD3d')
DEX_LINK = 'https://v3.kuswap.finance'

MIN_ABI = [
    {
      "constant": True,
      "inputs": [{"name": "_owner", "type": "address"}],
      "name": "balanceOf",
      "outputs": [{"name": "balance", "type": "uint256"}],
      "type": "function"
    }
]

w3 = Web3(Web3.HTTPProvider(WEB3_URL))

def get_exchange_rate():
    kusv3Contract = w3.eth.contract(address=KUSV3_ADDRESS, abi=MIN_ABI)
    wkcsContract = w3.eth.contract(address=WKCS_ADDRESS, abi=MIN_ABI)
    kusv3Balance = kusv3Contract.functions.balanceOf(POOL_ADDRESS).call()
    wkcsBalance = wkcsContract.functions.balanceOf(POOL_ADDRESS).call()
    exchangeRate = wkcsBalance / kusv3Balance
    return exchangeRate

def kusv3_price(update: Update, context: CallbackContext) -> None:
    try:
        exchangeRate = get_exchange_rate()
        reverseExchangeRate = 1 / exchangeRate
        response = requests.get('https://api.coingecko.com/api/v3/simple/price?ids=kucoin-shares&vs_currencies=btc,ltc,doge,eth,dfi,rvn,bnb,tron,usd,gbp,eur')
        data = response.json()
        kcsPrice = data['kucoin-shares']
        message = "1 KUSv3 = {:.8f} wKCS\n".format(exchangeRate) + \
                  "1 wKCS = {:.8f} KUSv3\n\n".format(reverseExchangeRate) + \
                  "Price of KUSv3:\n"
        for currency, price in kcsPrice.items():
            kusv3Price = price * exchangeRate
            message += "{}: {:.8f}\n".format(currency.upper(), kusv3Price)
        
        message += "\nCheck out the DEX here: [KuSwap V3]({})".format(DEX_LINK)
        update.message.reply_text(message, parse_mode='Markdown', disable_web_page_preview=True)
    except Exception as e:
        update.message.reply_text("Error fetching exchange rate: " + str(e))

def main() -> None:
    updater = Updater(TOKEN)
    dp = updater.dispatcher
    dp.add_handler(CommandHandler("KUSv3", kusv3_price))
    updater.start_polling()
    updater.idle()

if __name__ == '__main__':
    main()