def index(request: HttpRequest) -> HttpResponse:
    posts = Post.objects.select_related('author')
    page = paginate(request, posts)
    return render(
        request,
        'posts/index.html',
        {'page_obj': page},
    )