###########################
# Hittade info här:
# https://medium.com/analytics-vidhya/how-to-scrape-a-table-from-website-using-python-ce90d0cfb607
###########################
#
# Paket att installera######
# pip install pandas
# pip install beautifulsoup4
# pip install lxml
###########################


import requests
import json
from bs4 import BeautifulSoup #BeautifulSoupe (pip install beautifulsoup4)
import pandas as pd #(pip install pandas)

# Denna kan vara https://bensinpriser.nu/stationer/<VARIABEL FÖR BENSINTYP>/<VARIABEL FÖR LÄN>/<VARIABEL FÖR STAD>
URL = "https://bensinpriser.nu/stationer/95/stockholms-lan/stockholm"
page = requests.get(URL)

# Gör om data till lxml för att manipulera bäättre
soup = BeautifulSoup(page.content, "lxml") #(pip install lxml)

# Leta efter table vid namnet "price_table"
# https://bensinpriser.nu/stationer/95/stockholms-lan/stockholm -> Tryck F12 och välj Inspector för att hitta table namn
results = soup.find('table', id="price_table")

# Lägg in allt som är i en HTML "tr" (table row) i en array.
# Mer info: https://www.w3schools.com/tags/tag_tr.asp
headers = []
for i in results.find_all('tr'):
    title = i.text
    headers.append(title)

# Printa allt i variabeln (alla stationer)
print(headers)

# Printa enstaka stationer
print(headers[5])