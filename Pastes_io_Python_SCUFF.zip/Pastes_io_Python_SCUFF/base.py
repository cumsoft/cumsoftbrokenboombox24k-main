#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# DB-API: es una API estandar para implementar motores de bases de datos
# relacionales

# SQLite   -> en la biblioteca std

# Bibliotecas de terceros (pip install)
# MySQL, MariaDB ---> mysql-connector-python, PyMySQL, MySQLdb
# PostgreSQL ---> psycopg, pg8000
# SQL Server --> pymssql, pyodbc
# Oracle  --> cx_Oracle

import sqlite3

# la funcion connect me conecta a una base de datos existente. Si no existe,
# la crea
conn = sqlite3.connect("base.sqlite")

# para poder ejecutar una consulta debo crear un cursor:
cursor = conn.cursor()

# Primera consulta: creo una tabla 'personas'
cursor.execute("CREATE TABLE IF NOT EXISTS personas (nombre TEXT, edad NUMERIC)")

# Para guardar los cambios debo hacer un commit
conn.commit()

# creo una tupla de datos
personas = (
        ("Pablo",25),
        ("Juana",19),
        ("Julio",27)
)

# Cargo datos en la tabla
for nombre, edad in personas:
    cursor.execute("INSERT INTO personas VALUES (?,?)",(nombre,edad))
    conn.commit()
    
# Leo datos desde una tabla
cursor.execute("SELECT * FROM personas")
datos = cursor.fetchall()  # para imprimir un solo dato: fetchone()
print(datos)