numlist = ['','ONE','TWO','THREE','FOUR','FIVE','SIX','SEVEN','EIGHT','NINE','TEN','ELEVEN','TWELVE','THIRTEEN','FOURTEEN','FIFTEEN','SIXTEEN','SEVENTEEN','EIGHTEEN','NINETEEN']
hundend = ['', '', 'TWENTY' , 'THIRTY' , 'FORTY' , 'FIFTY' , 'SIXTY', 'SEVENTY','EIGHTY','NINETY']
done = False
while done != True:
    try: 
        numb = int(input("Enter a number: "))
    except:
        print('')
        print('Please enter a valid number.')
        print('')
    else:
        done = True
        strNumb = str(numb)
        lenNum = len(strNumb)
        print('')
        print('YOUR NUMBER IS')
        print('')
        if numb == 0:
            print('ZERO')
        if lenNum >= 1 and numb != 0 and lenNum <= 3 and numb <= 19:
            print(numlist[numb])
        elif lenNum >= 1 and numb != 0 and lenNum <= 3 and numb >= 20 and numb <= 99:
            print(str(hundend[int(strNumb[0])]) + " " + str(numlist[int(strNumb[1])]))
        elif numb >= 100:
            if strNumb[1] == '0' and strNumb[2] == '0':
                print(str(numlist[int(strNumb[0])]) + ' HUNDRED')
            elif strNumb[1] == '0':
                print(str(numlist[int(strNumb[0])]) + ' HUNDRED AND ' + str(numlist[int(strNumb[2])]))
            elif numb <= 999:
                print(str(numlist[int(strNumb[0])]) + ' HUNDRED AND ' + str(hundend[int(strNumb[1])]) + ' ' + str(numlist[int(strNumb[2])]))