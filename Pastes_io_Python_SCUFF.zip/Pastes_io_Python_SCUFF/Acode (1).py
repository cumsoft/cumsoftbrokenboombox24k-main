# ------------------------------------------
# 
# 	Project:      Tanker Tortoises
#	Author:       Wyatt
# 
# ------------------------------------------

#imports
from vex import *
import math

#code
#lock
isAllowed = False
while ( not(isAllowed)):
    if (controller_1.buttonX.pressing() and controller_1.buttonB.pressing() and controller_1.buttonDown.pressing() and controller_1.buttonLeft.pressing() and ( not controller_1.buttonUp.pressing() ) and ( not controller_1.buttonRight.pressing() and ( not controller_1.buttonY.pressing() ) and ( not controller_1.buttonA.pressing() ))):
        isAllowed = True
batterywarned = False
#setup
controller_1.rumble('-.-- ..')
play_vexcode_sound("evil laugh")
led_a.on()
led_b.on()
led_c.on()
led_d.on()
led_e.on()
led_f.on()
led_g.on()
led_h.on()
#defs
arm_motor.set_timeout(2,SECONDS)
claw_motor.set_timeout(2,SECONDS)
def ln(x, n):
    return n * ((x ** (1/n)) - 1)
screenanim = 1
gear = 10
reverse = 'False'
motor_right.set_stopping(HOLD)
motor_left.set_stopping(HOLD)
def updateScreen(screenanim1):
    controller_1.screen.set_cursor(1, 1)
    controller_1.screen.clear_row(1)
    controller_1.screen.print('Battery:', (brain.battery.capacity()), '%')
    controller_1.screen.next_row()
    controller_1.screen.clear_row(2)
    controller_1.screen.print('Gear:', gear)
    controller_1.screen.next_row()
    controller_1.screen.clear_row(3)
    controller_1.screen.print("placeholder")

#button callbacks

#loop
while True:
    if ( brain.battery.capacity() <= 10 and not batterywarned ):
        batterywarned = True
        controller_1.rumble("----")
    if ( controller_1.buttonR1.pressing() ):
        arm_motor.spin_for(FORWARD, 1, TURNS, wait=False)
    if ( controller_1.buttonR2.pressing() ):
        arm_motor.spin_for(REVERSE, 1, TURNS, wait=False)
    if ( controller_1.buttonL1.pressing() ):
        claw_motor.spin_for(FORWARD, 1, TURNS, wait=False)
    if ( controller_1.buttonL2.pressing() ):
        claw_motor.spin_for(REVERSE, 1, TURNS, wait=False)
    if ( gear == 11 ):
        controller_1.rumble('.')
    motor_left.spin(FORWARD)
    motor_right.spin(FORWARD)
    if ( gear == 11 ):
        motor_left.set_velocity(100 - controller_1.axis2.position(), PERCENT)
        motor_right.set_velocity(100 - controller_1.axis3.position(), PERCENT)
    else:
        motor_left.set_velocity( (controller_1.axis3.position() * (gear / 10 )) * 1, PERCENT)
        motor_right.set_velocity( (controller_1.axis2.position() * (gear / 10 )) * 1, PERCENT)
    updateScreen(screenanim)
    if ( controller_1.buttonUp.pressing() and gear < 10 ):
        gear = gear + 1
    if ( controller_1.buttonDown.pressing() and gear > 1 ):
        gear = gear - 1
    if ( controller_1.buttonUp.pressing() and gear == 10 ):
        gear = 1
    if ( controller_1.buttonDown.pressing() and gear == 1 ):
        gear = 10