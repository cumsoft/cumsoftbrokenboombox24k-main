# Welcome To Yuvi's Easy Mathematics.
Number1 = float(input("Type In The Number You Want To Change;"))
Number2 = float(input("Type In The Second Number; "))

print("Available Operations Are; + , - , * , / , % , **, // .")

print("If You Don't Know What These Mean, + Is Addition - Is Subtraction * Is Multiplication / Is Division % Is Modulus ** Is Power And // Is Floor Division.")
select = input("Select Operations; ")

if select == "+":
    print(Number1, "+", Number2, "=", Number1 + Number2)

elif select == "-":
    print(Number1, "-", Number2, "=", Number1 - Number2)

elif select == "*":
    print(Number1, "*", Number2, "=", Number1 * Number2)

elif select == "/":
    print(Number1, "/", Number2, "=", Number1 / Number2)

elif select == "%":
    print(Number1, "%", Number2, "=", Number1 % Number2)

elif select == "**":
    print(Number1, "**", Number2, "=", Number1 ** Number2)

elif select == "//":
    print(Number1, "//", Number2, "=", Number1 // Number2)
# All Mathematic Signs Are Used In This Code, Mathematic Fractions, Other Math Methods Are Coming Soon!

else:
    print("Not Valid, Not Supported, Try + , - , * , / , % , ** , // .")