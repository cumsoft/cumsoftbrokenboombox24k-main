def sec_diff(a, b):
    getIntData = lambda str: (int(str[:2]), int(str[5:7]), int(str[10:12]))
 
    h1, m1, s1 = getIntData(a)
    h2, m2, s2 = getIntData(b)
 
    total1 = h1 * 60 * 60 + m1 * 60 + s1
    total2 = h2 * 60 * 60 + m2 * 60 + s2
    return total2 - total1
 
if __name__ == "__main__":
    print(sec_diff('11 : 22 : 33', '11 : 22 : 35'))