import idautils

def decrypt_string(instr):
    out = ""
    for c in instr:
        out += chr(c ^ 0x17)
    return out

def find_saved_addr(addr):
    offset = 0
    ptr = addr
    for i in range(10):    
        if idc.print_insn_mnem(ptr) == "mov" and idc.print_operand(ptr, 1) == 'eax':
            print("FoundX " + hex(addr+i))
            offset = idc.get_operand_value(ptr, 0)
            break
        ptr = idc.next_head(ptr)
    return offset
    
def find_str(addr):
    out = b""
    ptr = addr
    while 1:    
        if idc.print_insn_mnem(ptr) == "push":
            print("Found " + hex(ptr))
            string_ea = idc.get_operand_value(ptr, 0)
            break
        ptr = idc.prev_head(ptr)
    
    i = 0
    while 1:
        c = get_bytes(string_ea+i, 1)
        if c == b'\x00':
            break
        out += c
        i+=1
    return string_ea, out

for x in idautils.XrefsTo(0x100014AE):
    addr, out_str = find_str(x.frm)
    api_name = decrypt_string(out_str)
    if addr:
        idc.set_name(addr, "str_" + api_name, SN_NOCHECK)
    fnc_addr = find_saved_addr(x.frm)
    if fnc_addr:
         idc.set_name(fnc_addr,api_name + "_api",SN_NOCHECK)