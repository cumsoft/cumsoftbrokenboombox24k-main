import os
import sys
import shutil

print("Hello world")

video = (".avi")
img = (".jpg")
archive = ()

def is_video(movefile):
    print(os.path.splitext(movefile)[1] in video)
    return os.path.splitext(movefile)[1] in video


def is_image(movefile):
    print(os.path.splitext(movefile)[1] in img)
    return os.path.splitext(movefile)[1] in img


def is_archive(movefile):
    print(os.path.splitext(movefile)[1] in archive)
    return os.path.splitext(movefile)[1] in archive


for movefile in os.listdir():
    if is_video(movefile):
        if not os.path.exists("Vids"):
            os.mkdir("Vids")
        shutil.move(movefile, "Vids")
    elif is_image(movefile):
            if not os.path.exists("Pics"):
               os.mkdir("Pics")
            shutil.move(movefile, "Pics")