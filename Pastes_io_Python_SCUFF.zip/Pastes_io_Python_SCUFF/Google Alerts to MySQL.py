from time import mktime
import feedparser
import datetime
import time
import re
import urllib.parse
import mysql.connector
from mysql.connector import errorcode
import pandas as pd

# Connect to the database:
link = mysql.connector.connect(user='username',
                                    password='password', 
                                    host='127.0.0.1', 
                                    database='db_name')

cursor=link.cursor()

# Function to strip out non-ASCII characters that wind up in feeds and junk stuff up.
def strip_non_ascii(string):
    ''' Returns the string without non ASCII characters'''
    stripped = (c for c in string if 0 < ord(c) < 127)
    return ''.join(stripped)
 
# Import the list of MTC feeds
from feedlist import feed_URLS

# Parse the URLS with Feedparser, and extend/append the list of posts
# This requires a file named 'feedlist.py' which contains a list named 'feed_URLS'
posts = []
for url in feed_URLS:
  posts.extend(feedparser.parse(url).entries)
 
# Capture some data about the run for the log file
feedCount = str(len(feed_URLS)) # Count the feeds
postCount = str(len(posts)) # Count the posts
runTime = str(time.strftime('%m-%d-%Y %H:%M')) # Capture the date/time to string

# Set current date/time of script run
currentDT = datetime.datetime.now()
cleanDate = currentDT.strftime("%Y-%m-%d %H:%M:%S")
 
# Strip annoying annoying characters in titles and content
for post in posts:
  post.title = re.sub('<b>', '', post.title)
  post.title = re.sub('</b>', '', post.title)
  post.title = re.sub('\u2014', '-', post.title) # emdash
  post.title = re.sub('\u201c', '&quot;', post.title) # left double quote
  post.title = re.sub('\u201d', '&quot;', post.title) # right double quote
  post.title = strip_non_ascii(post.title)
  post.content[0].value = re.sub('<b>', '', post.content[0].value)
  post.content[0].value = re.sub('</b>', '', post.content[0].value)
  post.content[0].value = re.sub('\u2014', '-', post.content[0].value) # emdash
  post.content[0].value = re.sub('\u201c', '&quot;', post.content[0].value) # left double quote
  post.content[0].value = re.sub('\u201d', '&quot;', post.content[0].value) # right double quote
  post.content[0].value = re.sub('&nbsp;', ' ', post.content[0].value) # non-breaking space
  post.content[0].value = re.sub('&quot;', '\"', post.content[0].value) # htmlquote
  post.content[0].value = strip_non_ascii(post.content[0].value)

# Read the blacklist.txt file to use against the posts
blacklist_file = open("/path/to/blacklist.txt", "r")
blacklist = blacklist_file.read().splitlines()

# Export just the necessary values into a clean list:
cleanposts = []

for post in posts:
  published = int(mktime(post.published_parsed))
  title = post.title
  excerpt = post.content[0].value
  parts = urllib.parse.urlparse(post.link)
  data  = urllib.parse.parse_qs(parts.query)
  url = data['url'][0]
  cleanposts.append([published, title, excerpt, url])

# Create a new Pandas dataframe and import the clean posts into for domain filtering
columns = ['published', 'title', 'excerpt', 'url']
df = pd.DataFrame(cleanposts, columns=columns)

# fdf is the Filtered Data Frame, with blacklisted domain articles stripped
fdf = df[~df['url'].str.contains('|'.join(blacklist))]

if len(fdf) > 0:
  print("Feeds read:", feedCount)
  print("Raw posts:", postCount)
  print("Filtered posts:", len(fdf))
else:
  print("Feeds read:", feedCount)
  print("Raw posts:", postCount)
  print("Filtered posts:", len(fdf))
  print("No articles to post.")

# Insert into the database
for i in fdf.index:
  # Preparing SQL query to INSERT a record into the database.
  insert_stmt = (
    "INSERT INTO news(PUBLISHED, TITLE, EXCERPT, LINK)" 
    "VALUES (%s, %s, %s, %s)"
    )

  data = (int(fdf['published'][i]), fdf['title'][i], fdf['excerpt'][i], fdf['url'][i])
  
  try:

    cursor.execute(insert_stmt, data)
    link.commit()
    # print("Articles added:", cursor.rowcount)
    print(fdf['title'][i])
    print(fdf['excerpt'][i])
    print(fdf['url'][i])
    print('\n')

  except mysql.connector.Error as err:
    print(err)
    print("Error Code:", err.errno)
    print("SQLSTATE", err.sqlstate)
    print("Message", err.msg)

cursor.close()
link.close()