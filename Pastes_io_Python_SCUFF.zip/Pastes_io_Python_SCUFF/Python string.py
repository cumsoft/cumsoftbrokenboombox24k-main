import string
 
print("string.ascii_letters ", string.ascii_letters)
print("string.ascii_lowercase ", string.ascii_lowercase)
print("string.ascii_uppercase ", string.ascii_uppercase)
print("string.digits ", string.digits)
print("string.punctuation ", string.punctuation)
 
import random
lista = ['Poniedziałek','Wtorek','Środa','Czwartek']
print(random.choice(lista))
 
x=0
while x<10:
    print(x, random.choice(lista))
    x+=1
 
print(''.join(lista))
print(','.join(lista))
 
print([random.choice(string.ascii_uppercase + string.ascii_lowercase + string.digits + string.punctuation) for ilosc in range(11)])
print(''.join([random.choice(string.ascii_uppercase + string.ascii_lowercase + string.digits + string.punctuation) for ilosc in range(21)]))