import argparse
import csv
import os
import simplekml

# Function to convert a CSV file to a KML file
def convert_csv_to_kml(csv_file, output_dir='data'):
    """
    Converts a CSV file to a KML file.

    Args:
        csv_file (str): The path to the CSV file.
        output_dir (str, optional): The directory to save the KML file to.

    Returns:
        None
    """

    kml = simplekml.Kml()

    with open(csv_file, 'r') as file:
        csv_reader = csv.reader(file)
        next(csv_reader)  # Skip the first row (header)
        for row in csv_reader:
            timestamp = row[0]
            latitude = row[1]
            longitude = row[2]
            temperature = row[3]
            humidity = row[4]

            kml.newpoint(
                name=timestamp,
                coords=[(longitude, latitude)],
                description=f"Temperature: {temperature}, Humidity: {humidity}"
            )

    kml_file_name = os.path.splitext(os.path.basename(csv_file))[0] + '.kml'
    kml_file_path = os.path.join(output_dir, kml_file_name)
    kml.save(kml_file_path)
    print(f'Successfully created file \'{kml_file_name}\'')

# Main function
def main():
    """
    The main function of the program.

    Returns:
        None
    """

    parser = argparse.ArgumentParser(description='CSV to KML Converter')
    parser.add_argument('csv_file', help='the CSV file to use')
    parser.add_argument('--output-dir', '-o', default='data',
                        help='directory to save KML files (default: "data")')

    args = parser.parse_args()

    # Check if the file has a .csv extension, and add it if not
    if not args.csv_file.endswith('.csv'):
        args.csv_file += '.csv'

    # Check if the --dir parameter is provided and adjust the directory accordingly
    if args.csv_file.startswith('data/') or args.csv_file.startswith('csv-files/'):
        csv_file_path = args.csv_file
    else:
        csv_file_path = os.path.join(args.output_dir, args.csv_file)

    # Check if the file exists, and if not, display an error message
    if not os.path.exists(csv_file_path):
        print(f'Error: Could not find file \'{csv_file_path}\'')
        return

    convert_csv_to_kml(csv_file_path, args.output_dir)

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("Conversion interrupted (Keyboard Interrupt)")
    except FileNotFoundError:
        print(f"Error: Could not find file \'{args.output_dir}/{args.csv_file}'")