def getUA():

    dalv=random.choice(["1.6.0","2.1.0"])

    andv=random.randint(9,15)

    b2=f"{random.randint(100000,999999)}.{str(random.randint(1,999)).zfill(3)}"

    return f"Dalvik/{dalv} (Linux; U; Android {andv}; Platinum_B4P Build/QP1A.{b2}) [FBAN/FBIOS;FBAV/411.1.0.29.112;FBBV/441216526;FBDV/Platinum_B4P;FBMD/iPhone;FBSN/iPhone OS;FBSV/{andv};FBSS/2;FBCR/;FBID/phone;FBLC/en;FBOP/5]"