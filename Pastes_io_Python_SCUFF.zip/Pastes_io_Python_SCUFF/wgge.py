import board

import busio

import adafruit_mlx90640

import time

import numpy as np

import matplotlib.pyplot as plt

# Dimensions of the thermal camera image

IMAGE_WIDTH = 24

IMAGE_HEIGHT = 32

# Initialize I2C bus and MLX90640 sensor

i2c = busio.I2C(board.SCL, board.SDA, frequency=800000)

mlx = adafruit_mlx90640.MLX90640(i2c)

mlx.refresh_rate = adafruit_mlx90640.RefreshRate.REFRESH_2_HZ

# Reset the MLX90640 sensor

mlx.set_mode(adafruit_mlx90640.Mode.SLEEP)

# Set up the data array to hold the thermal camera image data

data = np.zeros((IMAGE_HEIGHT, IMAGE_WIDTH))

# Loop to read the temperature data from the sensor and populate the data array

while True:

    # Wake up the sensor and read the temperature data

    mlx.set_mode(adafruit_mlx90640.Mode.CONTINUOUS)

    mlx.getFrame(data)

    # Plot the thermal image using matplotlib

    plt.imshow(data, cmap='***', vmin=20, vmax=50)

    plt.colorbar()

    plt.show()

    # Wait for a bit before refreshing the image

    time.sleep(1)