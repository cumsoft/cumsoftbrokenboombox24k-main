w, h = 1000, 1000
step = 50
margin_x = w/8
margin_y = h/8

def setup():
    size(w, h)
    strokeWeight(15)
    fill(205, 66, 116)
    square(0,0,w)
    fill(205, 66, 116)
    square(w/90,h/90,88*w/90)    
    fill(0,0,0)
    square(w/30,h/30,28*w/30)    
    #corner color
    fill(184, 206, 159)
    #top left
    square(w/30,h/30,2*w/30) 
    #top right
    square(27*w/30,h/30,2*w/30)
    #bottom left
    square(w/30,h/30 + 26*h/30,2*w/30) 
    #bottom rigth
    square(27*h/30,h/30 + 26*h/30,2*w/30)             
    #mini squares
    counter = 0
    for j in range(3*w/30, 26*w/30,w/30):
        fill(184, 206, 159)
        if counter%3==0:
            fill(0,0,0)
        square(j,h/30,w/30)
        square(j,28*h/30,w/30)
        square(h/30,j,h/30)
        square(28*h/30,j,h/30)
        counter+=1        
    fill(205, 66, 116)
    square(w/15,h/15,13*w/15)
    fill(255, 231, 135)
    square(w/10,h/10,8*w/10)
    for x in range(margin_x, w - margin_x, step):
        for y in range(margin_y, h - margin_y, step):
            drawLine(x, y, step, step)
    save("Examples/rug.jpg")
def drawLine(x, y, width, height):
    leftToRight = random(1) >= 0.6

    if leftToRight:
        line(x, y, x + width, y + height)
    else:
        line(x + width, y, x, y + height)