import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import make_blobs

# Activation function (sigmoid)
def sigmoid(x):
    return 1 / (1 + np.exp(-x))

# Derivative of the sigmoid function
def sigmoid_derivative(x):
    return x * (1 - x)

# Initialize weights and biases
input_size = 3
hidden_size = 3
output_size = 1

np.random.seed(42)
weights_input_hidden = np.random.rand(input_size, hidden_size)
bias_hidden = np.zeros((1, hidden_size))
weights_hidden_output = np.random.rand(hidden_size, output_size)
bias_output = np.zeros((1, output_size))

# Training
learning_rate = 0.1
epochs = 1000

X, Y = make_blobs(n_samples=100, centers=2, n_features=3, random_state=0)

# Lists to store errors and epochs
errors = []

for epoch in range(epochs):
    # Forward pass
    hidden_inputs = np.dot(X, weights_input_hidden) + bias_hidden
    hidden_outputs = sigmoid(hidden_inputs)

    final_inputs = np.dot(hidden_outputs, weights_hidden_output) + bias_output
    final_outputs = sigmoid(final_inputs)

    # Backward pass
    output_errors = Y.reshape(-1, 1) - final_outputs
    output_delta = output_errors * sigmoid_derivative(final_outputs)

    hidden_errors = output_delta.dot(weights_hidden_output.T)
    hidden_delta = hidden_errors * sigmoid_derivative(hidden_outputs)

    # Update weights and biases
    weights_hidden_output += hidden_outputs.T.dot(output_delta) * learning_rate
    bias_output += np.sum(output_delta, axis=0, keepdims=True) * learning_rate
    weights_input_hidden += X.T.dot(hidden_delta) * learning_rate
    bias_hidden += np.sum(hidden_delta, axis=0, keepdims=True) * learning_rate

    # Calculate and store the error
    loss = np.mean(np.abs(output_errors))
    errors.append(loss)

    if epoch % 100 == 0:
        print(f'Epoch {epoch}, Loss: {loss}')

# Plot the error vs. epoch
plt.plot(range(epochs), errors, marker='o')
plt.title('Training Error vs. Epoch')
plt.xlabel('Epoch')
plt.ylabel('Training Error')
plt.show()