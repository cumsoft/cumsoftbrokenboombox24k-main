def send_mail(from_address, to_address, subject, body, attachment=None):
    """
    Sends an email with optional attachment.

    Args:
        from_address (str): The email address to send the email from.
        to_address (str): The email address to send the email to.
        subject (str): The subject of the email.
        body (str): The body of the email.
        attachment (str, optional): The path to the attachment file.

    Raises:
        Exception: If there was an error sending the email.

    Returns:
        None
    """
    attachment_option = f"-a '{attachment}'" if attachment else ""
    print(f"Sending email from {from_address} to {to_address} with subject '{subject}' and attachment '{attachment}'.")

    send_mail_cmd = f"echo '{body}' | mail -s '{subject}' {attachment_option} -r '{from_address}' '{to_address}'"
    
    try:
        result = subprocess.check_output(send_mail_cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print("Email sent successfully.")
    except subprocess.CalledProcessError as e:
        raise Exception(f"Error sending email: {e.output}")