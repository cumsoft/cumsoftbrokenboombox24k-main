from zenrows import ZenRowsClient
 
client = ZenRowsClient(API_KEY)
url = "https://www.amazon.com/Crockpot-Electric-Portable-20-Ounce-Licorice/dp/B09BDGFSWS"
params = {"js_render":"true","premium_proxy":"true","device":"desktop","autoparse":"true"}
 
response = client.get(url, params=params)
 
print(response.json())