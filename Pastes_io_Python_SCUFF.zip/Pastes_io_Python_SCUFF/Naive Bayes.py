def naive_bayes(texts, likelihood, prior):
    '''
    Parameters:
    texts (list of lists) -
        - texts[i][k] = k'th token of i'th text
    likelihood (dict of dicts) 
        - likelihood[y][x] = Laplace-smoothed likelihood of bigram x given y,
          where x is in the format 'word1*-*-*-*word2'
    prior (float)
        - prior = the prior probability of the class called "pos"

    Output:
    hypotheses (list)
        - hypotheses[i] = class label for the i'th text
    '''
    #raise RuntimeError("You need to write this part!")

    hypotheses = []
    for text in texts:
        pos_sum = 0
        neg_sum = 0
        for token in range(len(text)-1):
            if ((text[token] in stopwords) and (text[token+1] in stopwords)):
                continue
            bigram = '{0}*-*-*-*{1}'.format(text[token],text[token+1])
            if (likelihood['pos'][bigram] == 0):
                continue
            try:
                pos_sum += math.log(likelihood['pos'][bigram]) 
            except KeyError: 
                pos_sum += math.log(likelihood['pos']['OOV'])
            
        pos_sum = pos_sum + math.log(prior)

        for token in range(len(text)-1):
            if ((text[token] in stopwords) and (text[token+1] in stopwords)):
                continue
            bigram = '{0}*-*-*-*{1}'.format(text[token],text[token+1])
            if (likelihood['neg'][bigram] == 0):
                continue
            try:
                neg_sum += math.log(likelihood['neg'][bigram]) 
            except KeyError: 
                neg_sum += math.log(likelihood['neg']['OOV'])

        neg_sum = neg_sum + math.log((1-prior)) 

        if pos_sum > neg_sum:
            hypotheses.append('pos')
        if pos_sum < neg_sum:
            hypotheses.append('neg')
        if pos_sum == neg_sum:
            hypotheses.append('undecided')
        
    return hypotheses