from lark import Lark

# Define the grammar for valid email addresses in Lark format
grammar = """
start: EMAIL

EMAIL: USERNAME "@" DOMAIN "." TLD

USERNAME: /[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*/

DOMAIN: /[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*/

TLD: /[a-zA-Z]{2,}/
"""

# Create the LALR parser
parser = Lark(grammar, start="start", parser="lalr")

# Test the parser on some example email addresses
valid_emails = [
    "john.doe@example.com",
    "jane_doe123@example.co.uk",
    "foo.bar-baz+qux@example.edu",
]

invalid_emails = [
    "notanemailaddress",
    "foo@bar",
    "@example.com",
    "example.com",
]

for email in valid_emails + invalid_emails:
    try:
        parser.parse(email)
        print(f"{email} is a valid email address")
    except:
        print(f"{email} is not a valid email address")