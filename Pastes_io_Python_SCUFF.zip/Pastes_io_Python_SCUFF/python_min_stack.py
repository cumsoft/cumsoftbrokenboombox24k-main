class MinStack:

    def __init__(self):
        self.stack = []
        self.min_stack = []
        self.min_val = 0
        

    def push(self, val: int) -> None:
        if not self.stack:
            self.stack.append(val)
            self.min_val = val
            self.min_stack.append(min_val)
        else:
            self.stack.append(val)
            if val<self.min_val:
                self.min_val = val
                self.min_stack.append(min_stack)

        

    def pop(self) -> None:
        if self.stack[-1] == self.min_stack[-1]:
            self.min_stack.pop()
        slef.stack.pop()
        

    def top(self) -> int:
        return self.stack[-1]

        

    def getMin(self) -> int:
        return self.min_stack[-1]