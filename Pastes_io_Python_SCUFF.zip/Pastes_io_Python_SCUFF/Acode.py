import os

def list_files_in_folder(folder_path):
    try:
        # Get a list of all files in the specified folder
        files = [f for f in os.listdir(folder_path) if os.path.isfile(os.path.join(folder_path, f))]

        if not files:
            print("No files found in the specified folder.")
        else:
            print("Files in the folder:")
            for file in files:
                print(file)

    except FileNotFoundError:
        print("Folder not found. Please provide a valid folder path.")

if __name__ == "__main__":
    # Replace 'C:\\Your\\Folder\\Path' with the actual folder path
    folder_path = r'C:\Your\Folder\Path'

    list_files_in_folder(folder_path)