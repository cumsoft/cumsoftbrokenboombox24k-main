import tkinter as tk
import random
from tkinter import messagebox
from math import pi

class PongGame:
    def __init__(self, root):
        self.root = root
        self.root.title("Pong Game")
        self.canvas = tk.Canvas(root, width=600, height=400, bg="black")
        self.canvas.pack()
        self.fireball_size = 15
        self.toggler = False
        self.max_score = 15
        self.sSfF = 0
        self.info_button = tk.Button(root, text="?", command=self.show_game_info)
        self.info_button.place(x=570, y=10)
        self.ball = self.canvas.create_oval(290, 190, 310, 210, fill="white")
        self.is_info_displayed = False
        self.paddle_left = self.canvas.create_rectangle(10, 150, 30, 250, fill="white")
        self.paddle_right = self.canvas.create_rectangle(570, 150, 590, 250, fill="white")
        self.score_left = 0
        self.score_right = 0
        self.score_display = self.canvas.create_text(
            300, 30, text=f"{self.score_left} - {self.score_right}", fill="white", font=("Helvetica", 16)
        )
        self.ability_meter = 0
        self.ability_max = 5
        self.ability_ready = False
        self.ability_active = False
        self.ability_bar = self.canvas.create_rectangle(0, 0, 600, 10, fill="red", outline="green")
        self.title_text = self.canvas.create_text(300, 170, text="Pong The Game 2", fill="white", font=("Helvetica", 24))
        self.tittle_text = self.canvas.create_text(298, 168, text="Pong The Game 2", fill="gray", font=("Helvetica", 24))
        self.subtitle_text = self.canvas.create_text(300, 220, text="Aperte 'Iniciar' para começar!", fill="white", font=("Helvetica", 10))
        self.ball_speed = [2, 2]
        self.paddle_right_speed = 1
        self.is_game_running = False
        self.root.bind("<Motion>", self.move_paddle)
        self.root.bind("<Button-1>", self.activate_ability)
        self.start_button = tk.Button(root, text="Iniciar", command=self.start_game)
        self.start_button.pack()

    def move_paddle(self, event):
        y = event.y
        self.canvas.coords(self.paddle_left, 10, y - 50, 30, y + 50)

    def check_game_winner(self):
      if self.score_left == self.max_score or self.score_right == self.max_score:
          winner = "Esquerda" if self.score_left == self.max_score else "Direita"
          messagebox.showinfo("Fim de Jogo", f"O jogador da {winner} venceu!")
          self.reset_game()

    def reset_game(self):
      self.is_game_running = False
      self.start_button.config(state="normal")
      self.title_text = self.canvas.create_text(300, 170, text="Pong The Game 2", fill="white", font=("Helvetica", 24))
      self.tittle_text = self.canvas.create_text(298, 168, text="Pong The Game 2", fill="gray", font=("Helvetica", 24))
      self.subtitle_text = self.canvas.create_text(300, 220, text="Aperte 'Iniciar' para começar!", fill="white", font=("Helvetica", 10))
      self.score_left = 0
      self.score_right = 0
      self.canvas.itemconfig(self.score_display, text=f"{self.score_left} - {self.score_right}")
      self.ability_meter = 0
      self.update_ability_bar()
      self.reset_ball()

    def shoot_fireball(self):
      if self.score_left % 2 == 0 and self.score_left != 0 and self.toggler == False:
          fireball = self.canvas.create_oval(
              self.canvas.coords(self.paddle_right)[0] - 20,
              self.canvas.coords(self.paddle_right)[1],
              self.canvas.coords(self.paddle_right)[0],
              self.canvas.coords(self.paddle_right)[3],
              fill="yellow",
              outline="red",
          )
          fireball_speed = 3
          self.toggler = True
          def move_fireball():
              nonlocal fireball
              self.canvas.move(fireball, -fireball_speed, 0)
              fireball_pos = self.canvas.coords(fireball)
              if fireball_pos[2] <= 0:
                  self.canvas.delete(fireball)
                  return
              if self.check_collision(self.paddle_left, fireball_pos):
                  self.handle_fireball_collision(fireball)
                  self.canvas.delete(fireball)
                  return
              self.root.after(10, move_fireball)
          move_fireball()

    def handle_fireball_collision(self, fireball):
      self.update_score(1)

    def start_game(self):
        if not self.is_game_running:
            self.is_game_running = True
            self.start_button.config(state="disabled")
            self.canvas.delete(self.title_text)
            self.canvas.delete(self.subtitle_text)
            self.canvas.delete(self.tittle_text)
            self.move_ball()
            self.move_ai_paddle()

    def move_ball(self):
        if self.is_game_running and self.is_info_displayed == False:
            self.canvas.move(self.ball, self.ball_speed[0], self.ball_speed[1])
            ball_pos = self.canvas.coords(self.ball)
            if ball_pos[1] <= 0 or ball_pos[3] >= 400:
                self.ball_speed[1] *= -1
            if ball_pos[0] <= 0 or ball_pos[2] >= 600:
                self.update_score()
            elif self.check_collision(self.paddle_left, ball_pos) or self.check_collision(self.paddle_right, ball_pos):
                self.handle_paddle_collision(ball_pos)
            if self.ability_active:
                self.check_ability_duration()
            self.root.after(10, self.move_ball)
        else:
            self.root.after(10, self.move_ball)

    def check_collision(self, paddle, ball_pos):
        paddle_pos = self.canvas.coords(paddle)
        return (
            ball_pos[2] >= paddle_pos[0]
            and ball_pos[0] <= paddle_pos[2]
            and ball_pos[3] >= paddle_pos[1]
            and ball_pos[1] <= paddle_pos[3]
        )

    def update_score(self, set=None):
        ball_pos = self.canvas.coords(self.ball)
        if self.score_left > self.sSfF:
          self.sSfF = self.score_left
          self.toggler = False
        if set == 1:
          self.score_left -= 1
        elif ball_pos[0] <= 0:
            if self.check_collision(self.paddle_left, ball_pos):
                self.handle_ability_gain()
            self.score_right += 1
        elif ball_pos[2] >= 600:
            self.score_left += 1
        self.canvas.itemconfig(self.score_display, text=f"{self.score_left} - {self.score_right}")
        if self.score_left % 2 == 0 and self.score_left != 0:
          self.shoot_fireball()
        self.reset_ball()
        self.check_game_winner()

    def reset_ball(self):
        self.canvas.coords(self.ball, 290, 190, 310, 210)
        self.ball_speed = [random.choice([-2, 2]), random.choice([-2, 2])]

    def move_ai_paddle(self):
        paddle_pos = self.canvas.coords(self.paddle_right)
        ball_pos = self.canvas.coords(self.ball)
        if ball_pos[1] < paddle_pos[1]:
            self.canvas.move(self.paddle_right, 0, -self.paddle_right_speed)
        elif ball_pos[3] > paddle_pos[3]:
            self.canvas.move(self.paddle_right, 0, self.paddle_right_speed)
        self.root.after(10, self.move_ai_paddle)

    def handle_paddle_collision(self, ball_pos):
        if self.check_collision(self.paddle_left, ball_pos):
            self.ball_speed[0] *= -1
            paddle_center = (self.canvas.coords(self.paddle_left)[1] + self.canvas.coords(self.paddle_left)[3]) / 2
            relative_collision_point = (ball_pos[1] + ball_pos[3]) / 2 - paddle_center
            self.ball_speed[1] = relative_collision_point / 10
            if not self.ability_active:
                self.handle_ability_gain()
        elif self.check_collision(self.paddle_right, ball_pos):
            self.ball_speed[0] *= -1
            paddle_center = (self.canvas.coords(self.paddle_right)[1] + self.canvas.coords(self.paddle_right)[3]) / 2
            relative_collision_point = (ball_pos[1] + ball_pos[3]) / 2 - paddle_center
            self.ball_speed[1] = relative_collision_point / 10

    def handle_ability_gain(self):
        if not self.ability_active and self.ability_meter < self.ability_max:
            self.ability_meter += 1
            self.update_ability_bar()

    def update_ability_bar(self):
        fill_width = (self.ability_meter / self.ability_max) * 600
        self.canvas.coords(self.ability_bar, 0, 0, fill_width, 10)
        if self.ability_meter == self.ability_max:
            self.ability_ready = True
            self.canvas.itemconfig(self.ability_bar, fill="green", outline="green")
        else:
            self.ability_ready = False
            self.canvas.itemconfig(self.ability_bar, fill="red", outline="red")

    def activate_ability(self, event):
        if self.ability_ready and not self.ability_active:
            self.ability_active = True
            self.ability_ready = False
            self.canvas.itemconfig(self.paddle_left, outline="blue")
            self.increase_paddle_size()
            self.root.after(5000, self.deactivate_ability)

    def show_game_info(self):
      self.is_info_displayed = not self.is_info_displayed
      info_text = "Pong The Game 2\n\nControles:\n- Mova a barra esquerda com o mouse.\n- Clique com o botão esquerdo para ativar\n a habilidade (quando disponível).\nObjetivo: Pontue fazendo com que a bola encoste no gol adversário."
      tk.messagebox.showinfo("Informações do Jogo", info_text)
      self.is_info_displayed = not self.is_info_displayed

    def deactivate_ability(self):
        self.ability_active = False
        self.reset_paddle_size()
        self.ability_meter = 0
        self.update_ability_bar()
        if not self.ability_ready:
            self.canvas.itemconfig(self.paddle_left, outline="")

    def check_ability_duration(self):
        if self.ability_active:
            self.root.after(10, self.check_ability_duration)
        else:
            self.reset_paddle_size()
            self.update_ability_bar()

    def increase_paddle_size(self):
        current_coords = self.canvas.coords(self.paddle_left)
        self.canvas.coords(self.paddle_left, current_coords[0], current_coords[1] - 25, current_coords[2], current_coords[3] + 40)

    def reset_paddle_size(self):
        current_coords = self.canvas.coords(self.paddle_left)
        self.canvas.coords(self.paddle_left, current_coords[0], current_coords[1] + 25, current_coords[2], current_coords[3] - 40)

if __name__ == "__main__":
    root = tk.Tk()
    game = PongGame(root)
    root.mainloop()