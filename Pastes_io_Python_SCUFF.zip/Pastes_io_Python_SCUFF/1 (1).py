/coffeeone:
    get:
      operationId: "coffee.readone"
      tags:
        - "Coffee 1"
      summary: "The coffee data structure for our server application"
      description: "Read the list of coffee drinks"
      responses:
        200:
          description: "Successful read coffee list operation"
          schema:
            type: "array"
            items:
              properties:
                coffee_name:
                  type: "string"
                milk:
                  type: "string"
                timestamp:
                  type: "string"