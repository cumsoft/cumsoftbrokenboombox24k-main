import ctypes

from ctypes import wintypes

# Constants for Virtual Key Codes (e.g., VK_SPACE = 0x20)

VK_KEY = 0x20  # Replace with the virtual-key code of the desired key

# Function prototype for GetAsyncKeyState

user32 = ctypes.WinDLL('user32', use_last_error=True)

user32.GetAsyncKeyState.restype = wintypes.SHORT

user32.GetAsyncKeyState.argtypes = [wintypes.INT]

def is_key_first_pressed(vk: int) -> bool:

    # High-order bit indicates if the key is down

    # Low-order bit indicates if the key was pressed after the previous call

    return (user32.GetAsyncKeyState(vk) & 0x8000) != 0

def main():

    key_was_pressed = False

    while True:

        if is_key_first_pressed(VK_KEY):

            if not key_was_pressed:

                print("Key first pressed")

                key_was_pressed = True

        else:

            key_was_pressed = False

if __name__ == "__main__":

    main()