#factorial
def fact(a):
    if a==1:
        return 1
    else:
        return fact(a-1)*a

print(fact(6))

#palindrome
def check(s):
    if len(s)<=1:
        return True
    else:
        if s[0]==s[-1]:
            return check(s[1:-1])
        else:
            return False

print(check("MADAM"))

#fibonacci
def f(m):
    if m==1 or m==0:
        return 1
    else:
        return f(m-1)+f(m-2)
print(f(12))

#memoisation
def f(m,D):
    if m in D:
        return D[m]
    else:
        D[m]=f(m-1,D)+f(m-2,D)
        return D[m]

D={0:1,1:1}
x=int(input("Enter number"))
print(f(x,D))