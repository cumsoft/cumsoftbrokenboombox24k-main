import pygame
import random
from enum import Enum

class Yon(Enum):
    sol    = 1
    sag    = 2
    yukari = 3
    asagi  = 4


pencere_en = 640
pencere_boy = 480
aralik = 20

en_sayi = int(pencere_en/aralik)
boy_sayi = int(pencere_boy/aralik)

pygame.init()
pencere = pygame.display.set_mode((pencere_en, pencere_boy))
clock = pygame.time.Clock()
running = True
yilan = [[10, 1], [9, 1], [8, 1], [7, 1], [6, 1], [5, 1], [4, 1], [3, 1]]
arial_yazitipi = pygame.font.SysFont('arial', 40)
oyun_bitti = False
yon = Yon.sag

yem = None
yem_sure = 0

while running:

    yilan_parcalari = []
 
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RIGHT and yon != Yon.sol:
                yon = Yon.sag
            elif event.key == pygame.K_LEFT and yon != Yon.sag:
                yon = Yon.sol
            elif event.key == pygame.K_UP and yon != Yon.asagi:
                yon = Yon.yukari
            elif event.key == pygame.K_DOWN and yon != Yon.yukari:
                yon = Yon.asagi



    pencere.fill("white")

    if not yem:
        yem = (random.randint(0, en_sayi), random.randint(0, boy_sayi))
        yem_sure = random.randint(50, 80)

    if yem and not oyun_bitti:
        yem_nesnesi = pygame.draw.rect(pencere, (50, 90, 190), (yem[0]*aralik, yem[1]*aralik, aralik, aralik))

    for x in range(0, en_sayi+1):
        pygame.draw.line(pencere, (200, 200, 200), (x*aralik, 0), (x*aralik, pencere_boy))

    for y in range(0, boy_sayi+1):
        pygame.draw.line(pencere, (200, 200, 200), (0, y*aralik),(pencere_en,  y*aralik))


    for i, parca in enumerate(yilan):
        
        p = pygame.draw.rect(pencere, (0,255,0), (parca[0]*aralik, parca[1]*aralik, aralik, aralik) )
        if not i:
            bas = p
        else:
            if bas.colliderect(p):
                oyun_bitti = True

    if yem:
        if yem_nesnesi.colliderect((yilan[0][0]*aralik, yilan[0][1]*aralik, aralik, aralik)):
            yilan.insert(0, [yilan[0][0]+1, yilan[0][1]])
            yem = None

    if (yilan[0][0] == en_sayi) or (yilan[0][0] == -1) or (yilan[0][1] == -1) or (yilan[0][1] == boy_sayi):
        oyun_bitti = True


    if not oyun_bitti:

        del yilan[-1]

        if yon == Yon.sag:
            yilan.insert(0, [yilan[0][0]+1, yilan[0][1]])

        elif yon == Yon.sol:
            yilan.insert(0, [yilan[0][0]-1, yilan[0][1]])

        elif yon == Yon.asagi:
            yilan.insert(0, [yilan[0][0], yilan[0][1]+1])

        elif yon == Yon.yukari:
            yilan.insert(0, [yilan[0][0], yilan[0][1]-1])


    yem_sure -= 1
    
    if yem_sure == 0:
        yem = None

    if oyun_bitti:
        oyun_bitti_render = arial_yazitipi.render('Oyun Bitti', False, (255, 0, 0))
        pencere.blit(oyun_bitti_render, (200,200))


    pygame.display.flip()

    clock.tick(5)

pygame.quit()