import heapq
import numpy as np

# Define the goal state
goal_state = np.array([[1, 2, 3],
                       [4, 5, 6],
                       [7, 8, 0]])

# Define the misplaced tile heuristic
def heuristic(state):
    return np.sum(state != goal_state)

# Define actions (up, down, left, right, diagonal)
def actions(state):
    zero_position = np.where(state == 0)
    zero_i, zero_j = zero_position[0][0], zero_position[1][0]
    possible_actions = []
    for di in [-1, 0, 1]:
        for dj in [-1, 0, 1]:
            if di == 0 and dj == 0:
                continue
            if 0 <= zero_i + di < 3 and 0 <= zero_j + dj < 3:
                possible_actions.append((zero_i + di, zero_j + dj))
    return possible_actions

# Define the A* search algorithm
def astar(initial_state):
    frontier = [(heuristic(initial_state), 0, initial_state.tolist(), [initial_state])]
    explored = set()
    while frontier:
        _, cost, state, path = heapq.heappop(frontier)
        state_array = np.array(state)
        if np.array_equal(state_array, goal_state):
            return cost, path
        explored.add(tuple(map(tuple, state_array)))
        zero_position = np.where(state_array == 0)
        zero_i, zero_j = zero_position[0][0], zero_position[1][0]
        for action in actions(state_array):
            new_state = state_array.copy()
            new_state[action[0], action[1]], new_state[zero_i, zero_j] = new_state[zero_i, zero_j], new_state[action[0], action[1]]
            if tuple(map(tuple, new_state)) not in explored:
                new_path = path + [new_state.tolist()]
                heapq.heappush(frontier, (cost + 1 + heuristic(new_state), cost + 1, new_state.tolist(), new_path))
    return float('inf'), []

# Test the algorithm
initial_state = np.array([[1, 2, 3],
                          [7, 8, 5],
                          [4, 6, 0]])

min_moves, path = astar(initial_state)
print("Minimum number of moves to reach the goal state:", min_moves)
print("Path to goal state:")
for step, state in enumerate(path):
    print("Step", step + 1)
    print(np.array(state))