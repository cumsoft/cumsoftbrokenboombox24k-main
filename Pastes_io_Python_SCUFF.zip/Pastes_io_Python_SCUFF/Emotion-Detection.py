from threading import Thread
from keras.utils import img_to_array
from keras.models import load_model
import numpy as np
import time
import cv2
from kivy.graphics.texture import Texture
from kivy.clock import Clock
from kivy.uix.image import Image
from kivy.app import App
import kivy
kivy.require('2.1.0')  # replace with your current kivy version !

# from keras.preprocessing import image


class KivyCamera(Image):
    def __init__(self, capture, **kwargs):
        super(KivyCamera, self).__init__(**kwargs)
        self.capture = capture
        Clock.schedule_interval(self.update, 1.0 / 30)

    # def start(self):
    #     Thread(target=self.update, args=()).start()
    #     return self

    def update(self, dt):

        model = load_model('model/model.hdf5', compile=False)

        # dictionary of emotion classes
        emotion_labels = {0: 'Angry', 1: 'Disgust', 2: 'Fear',
                          3: 'Happy', 4: 'Neutral', 5: 'Sad', 6: 'Surprise'}

        # Dimension of the req. input image
        img_width, img_height = 64, 64

        faceCascade = cv2.CascadeClassifier(
            "haarcascade_frontalface_alt2.xml")

        ret, frame = self.capture.read()
        if ret:

            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = faceCascade.detectMultiScale(
                gray, scaleFactor=1.3, minNeighbors=5)

            for (x, y, w, h) in faces:

                roi_gray = gray[y:y+h, x:x+w]
                roi_gray = cv2.resize(roi_gray, (img_width, img_height))

                img = img_to_array(roi_gray)
                img = np.expand_dims(img, axis=0)
                img /= 255

                predictions = model(img)
                index = np.argmax(predictions)
                label = emotion_labels[index]

                cv2.rectangle(frame, (x, y), (x + w, y + h),
                              (255, 0, 0), 2)  # added
                cv2.putText(frame, label, (x, y-10),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 0, 0), 2)
                time.sleep(0.09)

            # convert it to texture

            buf1 = cv2.flip(frame, 0).tobytes()
            image_texture = Texture.create(
                size=(frame.shape[1], frame.shape[0]), colorfmt='bgr')
            image_texture.blit_buffer(buf1, colorfmt='bgr', bufferfmt='ubyte')
            # display image from the texture
            self.texture = image_texture


class CamApp(App):
    # def start(self):
    #     Thread(target=self.build, args=()).start()
    #     return self

    def build(self):
        self.capture = cv2.VideoCapture(0)
        self.my_camera = KivyCamera(capture=self.capture)
        return self.my_camera

    def on_stop(self):
        # without this, app will not exit even if the window is closed
        self.capture.release()


if __name__ == '__main__':
    CamApp().run()