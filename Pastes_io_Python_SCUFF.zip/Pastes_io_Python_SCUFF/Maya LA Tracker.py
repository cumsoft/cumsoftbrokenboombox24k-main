import requests
import json

# Get the amount of asset by tier
def get_asset_amount_by_tier(asset) -> list:
    url = "https://mayanode.mayachain.info/mayachain/pool/" + asset + "/liquidity_providers"

    # Get list of providers
    providers = requests.get(url).json()

    # Initialize the return list
    tierList = [0.0, 0.0, 0.0]
    for entry in providers:
        if "asset_address" not in entry:
            continue
        # Get the providers maya address and look up the tier
        assetAmount = int(entry['pending_asset']) / pow(10, 8)
        mayaAddr = entry['cacao_address']
        tierDataJSON = requests.get(
            "https://mayanode.mayachain.info/mayachain/liquidity_auction_tier/" + asset + "/" + mayaAddr).json()

        # Extract the tier and add the BTC amount to the respective Tier
        index = tierDataJSON['tier'] - 1 # list is 0-indexed
        print("Adding " + str(assetAmount) + " " +
              asset + " to tier: " + str(index + 1))
        tierList[index] += assetAmount

    return tierList

def print_tier_list(asset, asset_price, tier_list : list):
    print(asset + " Tier distribution:")
    for num in tier_list:
        if asset_price != 1.0:
            pc = ""
            if(num != 0):
                pc = "\t(" + str(percentage(num, sum(tier_list))) + " %)"
            price_string = " ~ " + str(num * asset_price) + " USD "
            print("Tier " + str(tier_list.index(num) + 1) + ": " + str(num) + " " + asset + price_string + pc)
        else:
            pc = ""
            if(num != 0):
                pc = "\t(" + str(percentage(num, sum(tier_list))) + " %)"
            print("Tier " + str(tier_list.index(num) + 1) + ": " + str(num) + " " + asset + pc)
    print_total_amount_per_tier(asset, tier_list, asset_price)

    print()

def percentage(part, whole):
  return 100 * float(part)/float(whole)

def print_total_amount_per_tier(asset, tier_list : list, asset_price):
    total = sum(tier_list)
    if asset_price == 1.0:
        print("Total amount of " + asset + ": " + str(total) + " USD")
    else:
        print("Total amount of " + asset + ": " + str(total) + "\t~ " + str(total * asset_price) + " USD")




## Main Entry

# Get the current price data
tokenPrices = requests.get(
    "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,thorchain&vs_currencies=usd").json()
btc_price_usd = tokenPrices["bitcoin"]["usd"]
eth_price_usd = tokenPrices["ethereum"]["usd"]
rune_price_usd = tokenPrices["thorchain"]["usd"]

# Set up lists of assets
assets = ["BTC.BTC", "ETH.ETH", "THOR.RUNE", "ETH.USDC-0XA0B86991C6218B36C1D19D4A2E9EB0CE3606EB48",
          "ETH.USDT-0XDAC17F958D2EE523A2206206994597C13D831EC7"]
assetStrings = ["BTC", "ETH", "RUNE", "USDC", "USDT"]
assetPrices = [btc_price_usd, eth_price_usd, rune_price_usd, 1.0, 1.0]


tier_lists = {}
# Get the amount of assets per tier
for asset in assets:
    tierList = get_asset_amount_by_tier(asset)
    tier_lists[asset] = tierList

# Print out the amount per tier 
for asset in assets:
    index = assets.index(asset)
    print_tier_list(assetStrings[index], assetPrices[index], tier_lists[asset])

# Print out the totals
total = 0.0
for asset in assets:
    index = assets.index(asset)
    tierList = tier_lists[asset]
    for num in tierList:
        total += num * assetPrices[index]

print("Total value (USD) of all assets: " + str(total))