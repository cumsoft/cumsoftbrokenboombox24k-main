import tkinter as tk
import random

class PongGame:
    def __init__(self, root):
        self.root = root
        self.root.title("Pong Game")

        self.canvas = tk.Canvas(root, width=600, height=400, bg="black")
        self.canvas.pack()

        self.ball = self.canvas.create_oval(290, 190, 310, 210, fill="white")
        self.paddle_left = self.canvas.create_rectangle(10, 150, 30, 250, fill="white")
        self.paddle_right = self.canvas.create_rectangle(570, 150, 590, 250, fill="white")

        self.score_left = 0
        self.score_right = 0

        self.score_display = self.canvas.create_text(
            300, 30, text=f"{self.score_left} - {self.score_right}", fill="white", font=("Helvetica", 16)
        )

        self.ability_meter = 0
        self.ability_max = 5
        self.ability_ready = False
        self.ability_active = False

        self.ability_bar = self.canvas.create_rectangle(0, 0, 600, 10, fill="red", outline="green")

        self.ball_speed = [2, 2]
        self.paddle_right_speed = 2
        self.is_game_running = False

        self.root.bind("<Motion>", self.move_paddle)
        self.root.bind("<Button-1>", self.activate_ability)  # Botão esquerdo do mouse
        self.start_button = tk.Button(root, text="Iniciar", command=self.start_game)
        self.start_button.pack()

    def move_paddle(self, event):
        y = event.y
        self.canvas.coords(self.paddle_left, 10, y - 50, 30, y + 50)

    def start_game(self):
        if not self.is_game_running:
            self.is_game_running = True
            self.start_button.config(state="disabled")
            self.move_ball()
            self.move_ai_paddle()

    def move_ball(self):
        if self.is_game_running:
            self.canvas.move(self.ball, self.ball_speed[0], self.ball_speed[1])

            ball_pos = self.canvas.coords(self.ball)

            if ball_pos[1] <= 0 or ball_pos[3] >= 400:
                # Bola atinge a parte superior ou inferior do canvas
                self.ball_speed[1] *= -1

            if ball_pos[0] <= 0 or ball_pos[2] >= 600:
                # Bola atinge a lateral esquerda ou direita do canvas
                self.update_score()

            elif self.check_collision(self.paddle_left, ball_pos) or self.check_collision(self.paddle_right, ball_pos):
                # Bola atinge uma das barras
                self.handle_paddle_collision(ball_pos)

            if self.ability_active:
                self.check_ability_duration()

            self.root.after(10, self.move_ball)

    def check_collision(self, paddle, ball_pos):
        paddle_pos = self.canvas.coords(paddle)
        return (
            ball_pos[2] >= paddle_pos[0]
            and ball_pos[0] <= paddle_pos[2]
            and ball_pos[3] >= paddle_pos[1]
            and ball_pos[1] <= paddle_pos[3]
        )

    def update_score(self):
        ball_pos = self.canvas.coords(self.ball)

        if ball_pos[0] <= 0:
            if self.check_collision(self.paddle_left, ball_pos):
                # Ganha ponto no medidor apenas quando a barra da esquerda rebater a bola
                self.handle_ability_gain()
            self.score_right += 1
        elif ball_pos[2] >= 600:
            self.score_left += 1

        self.canvas.itemconfig(self.score_display, text=f"{self.score_left} - {self.score_right}")

        self.reset_ball()

    def reset_ball(self):
        self.canvas.coords(self.ball, 290, 190, 310, 210)

    def move_ai_paddle(self):
        paddle_pos = self.canvas.coords(self.paddle_right)
        ball_pos = self.canvas.coords(self.ball)

        if ball_pos[1] < paddle_pos[1]:
            self.canvas.move(self.paddle_right, 0, -self.paddle_right_speed)
        elif ball_pos[3] > paddle_pos[3]:
            self.canvas.move(self.paddle_right, 0, self.paddle_right_speed)

        self.root.after(10, self.move_ai_paddle)

    def handle_paddle_collision(self, ball_pos):
        if self.check_collision(self.paddle_left, ball_pos):
            self.ball_speed[0] *= -1  # Inverte a direção horizontal

            # Ajusta a direção vertical com base na posição de impacto na barra
            paddle_center = (self.canvas.coords(self.paddle_left)[1] + self.canvas.coords(self.paddle_left)[3]) / 2
            relative_collision_point = (ball_pos[1] + ball_pos[3]) / 2 - paddle_center
            self.ball_speed[1] = relative_collision_point / 10

            if not self.ability_active:
                self.handle_ability_gain()

        elif self.check_collision(self.paddle_right, ball_pos):
            self.ball_speed[0] *= -1  # Inverte a direção horizontal

            # Ajusta a direção vertical com base na posição de impacto na barra
            paddle_center = (self.canvas.coords(self.paddle_right)[1] + self.canvas.coords(self.paddle_right)[3]) / 2
            relative_collision_point = (ball_pos[1] + ball_pos[3]) / 2 - paddle_center
            self.ball_speed[1] = relative_collision_point / 10

    def handle_ability_gain(self):
        if not self.ability_active and self.ability_meter < self.ability_max:
            self.ability_meter += 1
            self.update_ability_bar()

    def update_ability_bar(self):
      fill_width = (self.ability_meter / self.ability_max) * 600
      self.canvas.coords(self.ability_bar, 0, 0, fill_width, 10)

      if self.ability_meter == self.ability_max:
        self.ability_ready = True
        self.canvas.itemconfig(self.ability_bar, fill="green", outline="green")
      else:
        self.ability_ready = False
        self.canvas.itemconfig(self.ability_bar, fill="red", outline="red")


    def activate_ability(self, event):
      if self.ability_ready and not self.ability_active:
          self.ability_active = True
          self.ability_ready = False
          self.canvas.itemconfig(self.paddle_left, outline="blue")  # Muda a outline para azul
          self.increase_paddle_size()
          self.root.after(3000, self.deactivate_ability)
  

    def deactivate_ability(self):
      self.ability_active = False
      self.reset_paddle_size()
      self.ability_meter = 0
      self.update_ability_bar()
      if not self.ability_ready:  # Se a habilidade não estiver pronta, restaura a cor padrão
        self.canvas.itemconfig(self.paddle_left, outline="")


    def check_ability_duration(self):
        if self.ability_active:
            self.root.after(10, self.check_ability_duration)
        else:
            self.reset_paddle_size()
            self.update_ability_bar()

    def increase_paddle_size(self):
        current_coords = self.canvas.coords(self.paddle_left)
        self.canvas.coords(self.paddle_left, current_coords[0], current_coords[1] - 25, current_coords[2], current_coords[3] + 25)

    def reset_paddle_size(self):
        current_coords = self.canvas.coords(self.paddle_left)
        self.canvas.coords(self.paddle_left, current_coords[0], current_coords[1] + 25, current_coords[2], current_coords[3] - 25)

if __name__ == "__main__":
    root = tk.Tk()
    game = PongGame(root)
    root.mainloop()