import math

class MagnetometerCalibration:
    def __init__(self):
        self.offset = [0, 0, 0]
        self.scale = [1, 1, 1]

    def calibrate(self, raw_data):
        # Calculate the mean values for each component
        mean_values = [sum(raw_data[:, i]) / len(raw_data) for i in range(3)]

        # Calculate the offset as the negative of the mean values
        self.offset = [-mean for mean in mean_values]

        # Calculate the scale factor as the reciprocal of the standard deviation
        std_values = [math.sqrt(sum((raw_data[i, j] - mean_values[j]) ** 2 for i in range(len(raw_data))) / len(raw_data)) for j in range(3)]
        self.scale = [1 / std if std != 0 else 1 for std in std_values]

    def compensate(self, raw_data):
        # Apply calibration compensation
        compensated_data = [(raw_data[i] + self.offset[i]) * self.scale[i] for i in range(3)]
        return compensated_data

def calculate_heading(magnetometer_data):
    # Normalize the magnetometer data
    norm = math.sqrt(sum([comp ** 2 for comp in magnetometer_data]))
    normalized_data = [comp / norm for comp in magnetometer_data]

    # Calculate the tilt-compensated heading
    heading = math.atan2(normalized_data[1], normalized_data[0])
    if heading < 0:
        heading += 2 * math.pi

    # Convert heading to degrees
    heading_degrees = math.degrees(heading)
    
    return heading_degrees

# Example usage:
# Assuming you have a 2D numpy array named 'raw_magnetometer_data' containing the raw magnetometer readings

# Create a calibration object
calibration = MagnetometerCalibration()

# Perform calibration using the raw magnetometer data
calibration.calibrate(raw_magnetometer_data)

# Compensate the magnetometer data
compensated_data = calibration.compensate(raw_magnetometer_data)

# Calculate the heading in degrees using the compensated magnetometer data
heading_degrees = calculate_heading(compensated_data)