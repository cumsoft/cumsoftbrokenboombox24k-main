from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path, include

handler404 = "app_main.views.custom_page_not_found_view"

urlpatterns = [
    path('admin/', admin.site.urls),
    path("", include("app_main.urls", "app_main")),
    path("flight/", include("app_flight.urls", "app_flight")),
    path("tour/", include("app_tour.urls", "app_tour")),
    path('ckeditor/', include('ckeditor_uploader.urls')),
] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)