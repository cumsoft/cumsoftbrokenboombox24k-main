import pickle

with open("myfile.pkl", 'rb') as fp:
	data = pickle.load(fp)

print(data)