__author__ = 'thuesdays@gmail.com'

import random
import time

import requests

SEARCH_URL = 'https://api.debank.com/feed/search?q=lucky&start=0&limit=1000'
proxy_map = {'176.97.223.83': 64162,
             '213.166.82.45': 64524,
             '31.216.57.234': 64380,
             '185.232.16.75': 64432,
             '91.247.183.26': 64608}
proxies_http = [f"http://CTWVdXqv:HHM67Kkg@{key}:{val}/" for key, val in proxy_map.items()]
proxies_https = [f"https://CTWVdXqv:HHM67Kkg@{key}:{val}/" for key, val in proxy_map.items()]
session = requests.Session()


def search():
    draws = []
    resp = session.get(SEARCH_URL)
    if resp.status_code == 429:
        for p in proxies_http:
            proxies = {
                "http": p,
            }
            resp = requests.get(SEARCH_URL, proxies=proxies)
            if resp.status_code == 200:
                break
    if resp.status_code == 200:
        data = resp.json()
        error_code = data.get('error_code')
        if error_code == 0:
            feeds = data.get('data').get('feeds')
            count = data.get('data').get('total_count')
            print(f'Found {count} posts with search text=lucky.')
            for post_data in feeds:
                if post_data.get('article').get('draw') is not None:
                    draw = post_data.get('article').get('draw')
                    is_settled = draw.get('is_settled')
                    if not is_settled:
                        draws.append(post_data)
    else:
        print(f'ERROR: {resp.status_code} {resp.reason} {resp.text}')
    return draws


if __name__ == '__main__':
    draws = search()
    print(f'Found {len(draws)} active Lucky Draws.')
    1+1