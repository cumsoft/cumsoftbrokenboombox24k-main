import bpy

# Check if the main group empty exists, if not create it
if "FK_ROCKS_GROUP" not in bpy.data.objects:
    main_empty = bpy.data.objects.new("FK_ROCKS_GROUP", None)
    bpy.context.collection.objects.link(main_empty)
else:
    main_empty = bpy.data.objects["FK_ROCKS_GROUP"]

def create_lods_for_object(obj):
    # Create the empty parent object
    empty = bpy.data.objects.new(obj.name, None)
    obj.users_collection[0].objects.link(empty)  # Link to the same collection as the original object
    empty.location = obj.location

    # Set the empty's parent to the main group empty
    empty.parent = main_empty

    # Duplicate the object for LOD00
    lod00 = obj.copy()
    lod00.data = obj.data.copy()
    lod00.name = obj.name + "_LOD00"
    obj.users_collection[0].objects.link(lod00)
    lod00.location = (0, 0, 0)
    lod00.parent = empty

    # Duplicate the object for LOD01
    lod01 = lod00.copy()
    lod01.data = lod00.data.copy()
    lod01.name = obj.name + "_LOD01"
    obj.users_collection[0].objects.link(lod01)
    lod01.location = (0, 0, 0)
    lod01.parent = empty

    # Add the decimate modifier to LOD01
    decimate_mod_01 = lod01.modifiers.new(name="Decimate_LOD01", type='DECIMATE')
    decimate_mod_01.ratio = 0.3

    # Duplicate the object for LOD02
    lod02 = lod00.copy()
    lod02.data = lod00.data.copy()
    lod02.name = obj.name + "_LOD02"
    obj.users_collection[0].objects.link(lod02)
    lod02.location = (0, 0, 0)
    lod02.parent = empty

    # Add the decimate modifier to LOD02 for planar decimation
    decimate_mod_02 = lod02.modifiers.new(name="Decimate_LOD02", type='DECIMATE')
    decimate_mod_02.decimate_type = 'DISSOLVE'
    decimate_mod_02.angle_limit = 120 * (3.14159 / 180)  # Convert degrees to radians
    decimate_mod_02.delimit = {'UV'}
    decimate_mod_02.use_dissolve_boundaries = True  # Enable All Boundaries

    # Unlink the original object (optional: if you want to delete it)
    obj.users_collection[0].objects.unlink(obj)

# Iterate over all selected objects
for obj in bpy.context.selected_objects:
    create_lods_for_object(obj)

# Update the 3D view
bpy.ops.wm.redraw_timer(type='DRAW', iterations=1)