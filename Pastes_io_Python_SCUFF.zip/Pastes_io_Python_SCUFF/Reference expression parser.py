#!/usr/bin/env python
# coding: utf-8

# In[1]:


class AST:
    def __init__(self, _type=None, val=None, children=None):
        self.type = _type
        self.val = val
        if children == None:
            children = []
        else:
            for ch in children:
                assert isinstance(ch, AST)
        self.children = children

    def reprSelf(self):
        if self.val != None:
            return f'({self.type}, {self.val})'
        else:
            return f'({self.type})'
    
    def reprHelper(self, rec=0):
        S = 'ast: '
        if rec: S += '|' * rec
        S += self.reprSelf() 
        if len(self.children):
            for ch in self.children:
                S2 = ch.reprHelper(rec+1)
                S += '\n' + S2
        return S
    
    def __repr__(self):
        return self.reprHelper()
        
    def add(self, child):
        assert isinstance(child, AST)
        self.children.append(child)


# In[2]:


class OpInfo:
    def __init__(self, precedence=0, arity=2, assoc='left'):
        self.precedence = precedence
        self.arity = arity
        self.assoc = assoc
    def __repr__(self):
        S = f'prec {self.precedence}, '
        if self.arity == 1:
            S += 'unary '
        elif self.arity == 2:
            S += 'binary'
        else:
            S += f'arity {self.arity}'
        S += f'({self.prefix})'
        return S


# In[3]:


OpDict = {
    ',':OpInfo(0, assoc='right'),
    '+':OpInfo(1),
    '-':OpInfo(1),
    '*':OpInfo(2),
    '/':OpInfo(2),
    '%':OpInfo(2),
    '&':OpInfo(4, arity=1),
    '[]':OpInfo(4),
    '()':OpInfo(4),
    '()0':OpInfo(4, arity=1),
    '=':OpInfo(5),
    '+=':OpInfo(5),
    '-=':OpInfo(5),
    '*=':OpInfo(5),
    '/=':OpInfo(5),
    '%=':OpInfo(5),
    '==':OpInfo(6),
    '<':OpInfo(6),
    '>':OpInfo(6),
    '++':OpInfo(7, arity=1),
    '--':OpInfo(7, arity=1)
}


# In[4]:


class ExampleExprParser:
    def __init__(self):
        self.debug = 0
        self.reset()
    
    def reset(self):
        self.out_stack = []
        self.op_stack = []
        self.ast = None
    
    def is_term(self, tok):
        return tok in 'qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM0123456789'
    
    def is_op(self, tok):
        return tok in OpDict
    
    def paren_on_op_stack(self):
        return len(self.op_stack) and (self.op_stack[-1] == '(')
            
    def bracket_on_op_stack(self):
        return len(self.op_stack) and (self.op_stack[-1] == '[')
            
    def op_on_op_stack(self):
        if len(self.op_stack) and self.is_op(self.op_stack[-1]):
            return self.op_stack[-1]
        else:
            return None
    
    def term_on_out_stack(self):
        return len(self.out_stack) and self.is_term(self.out_stack[-1])
    
    def dbg_print(self, msg):
        if self.debug: print(msg)
    
    def to_ast(self, tok):
        if self.is_op(tok):
            oi = OpDict[tok]
            args = []
            for i in range(oi.arity):
                arg_tok = self.out_stack.pop()
                arg_ast = self.to_ast(arg_tok)
                args.append(arg_ast)
            return AST('op', tok, args)
        if self.is_term(tok):
            return AST('term', tok)
        #assert False
        print(f'error: to_ast: whats this? [{tok}]')    
            
    #Shunting-yard algorithm from Wikipedia
    def parse(self, S):
        self.reset()
        Toks = S.split()
        print(f'{Toks} ->')
        self.dbg_print(f'parsing expr [{Toks}]')
        prevTok = ''
        for tok in Toks:
            assert self.is_term(tok) or self.is_op(tok) or tok in '()[]', print(f'owo whats this? [{tok}]')
            if self.is_term(tok):
                self.dbg_print(f'push term [{tok}] to output stack')
                self.out_stack.append(tok)
            #if tok == '['
            if self.is_op(tok):
                self.dbg_print(f'got op [{tok}]')
                O1 = tok
                while(self.op_on_op_stack()):
                    O2 = self.op_on_op_stack()
                    if O2:
                        oi1 = OpDict[O1]
                        oi2 = OpDict[O2]
                        if (oi2.precedence > oi1.precedence) or                            ((oi2.precedence == oi1.precedence) and oi2.assoc == 'left'):
                            self.dbg_print(f'popping op [{O2}] from op_stack to out_stack')
                            self.op_stack.pop()
                            self.out_stack.append(O2)
                        else: break
                    else: break
                self.op_stack.append(O1)
            if tok == '[':
                self.dbg_print('got left-bracket [')
                self.op_stack.append(tok)
            if tok == ']':
                self.dbg_print('got right-bracket ]')
                while self.op_on_op_stack():
                    O = self.op_stack.pop()
                    self.dbg_print(f'popping op [{O}] from op_stack to out_stack')
                    self.out_stack.append(O)
                assert self.bracket_on_op_stack()
                self.op_stack.pop()
                self.op_stack.append('[]')
            if tok == '(':
                self.dbg_print('got left-paren (')
                if self.is_term(prevTok):#self.term_on_out_stack():
                    self.op_stack.append('f(')
                else:
                    self.op_stack.append(tok)
            if tok == ')':
                self.dbg_print('got right-paren )')
                while self.op_on_op_stack():
                    O = self.op_stack.pop()
                    self.dbg_print(f'popping op [{O}] from op_stack to out_stack')
                    self.out_stack.append(O)
                #assert self.paren_on_op_stack()
                assert len(self.op_stack)
                if self.op_stack[-1] == '(':
                    self.op_stack.pop() # pop ( and discard it
                elif self.op_stack[-1] == 'f(':
                    self.op_stack.pop()
                    if prevTok == '(':
                        self.out_stack.append('()0')
                    else:
                        self.out_stack.append('()')
                else:
                    assert False
            prevTok = tok
            
        self.dbg_print('popping remaining operators')
        while len(self.op_stack):
            O = self.op_stack.pop()
            self.dbg_print(f'popping op [{O}] from op_stack to out_stack')
            self.out_stack.append(O)
        self.dbg_print('conveted expression to RPN, resulting stack:')
        print(self.out_stack)
        
        if len(self.out_stack):
            tok = self.out_stack.pop()
            ast = self.to_ast(tok)
        #assert len(self.out_stack) == 0
        if len(self.out_stack) != 0: print(f'error, tokens remain: [{self.out_stack}]')
        return ast


# In[5]:


ex = ExampleExprParser()
print(ex.parse("1 + 2 * 3"))
print(ex.parse("1 * 2 + 3"))
print(ex.parse("1 * ( 2 + 3 )"))
print(ex.parse("1 * A [ S + 2 ]"))
print(ex.parse("1 + f ( 2 / 3 ) * 4 "))
print(ex.parse("1 + f ( ) * 2"))
print(ex.parse("1 + f ( 2 / 3 , 4 % 5 ) * 6"))
print(ex.parse("f ( 1 , 2 , 3 , 4 )"))


# In[ ]: