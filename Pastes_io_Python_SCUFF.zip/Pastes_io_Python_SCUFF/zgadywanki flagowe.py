# importowanie bibliotek
import turtle
import random

# deklarowanie zmiennych
lifes = 3
points = 0
t = turtle.Turtle()
correctGuessIndex = 0
userGuess = 0

# ustawienia
t.speed(5) # 1:slowest, 3:slow, 5:normal, 10:fast, 0:fastest



def generateNewGuess():
 # losowa generacja
 correctGuessIndex = random.randint(0, 3)
 return correctGuessIndex

  
def drawFlagToGuess_Poland():
 t.color("red")
 t.penup()
 t.goto(-180, 0)
 t.pendown()
 t.goto(-180, -120)
 t.goto(180, -120)
 t.goto(180, 0)
 t.goto(-180, 0)
 t.fillcolor("red")
 
 t.color("black")
 t.goto(-180, 120)
 t.goto(180, 120)
 t.goto(180, 0)
 
def drawFlagToGuess_Monako():
 t.color("black")
 t.penup()
 t.goto(-180, 0)
 t.pendown()
 t.goto(-180, -120)
 t.goto(180, -120)
 t.goto(180, 0)
 t.goto(-180, 0)
 
 t.color("red")
 t.goto(-180, 120)
 t.goto(180, 120)
 t.goto(180, 0)
 t.fillcolor("red")
 
def drawFlagToGuess_Ukrainian():
 t.color("blue")
 t.penup()
 t.goto(-180, 0)
 t.pendown()
 t.goto(-180, -120)
 t.goto(180, -120)
 t.goto(180, 0)
 t.goto(-180, 0)
 t.fillcolor("blue")
 
 t.color("yellow")
 t.goto(-180, 120)
 t.goto(180, 120)
 t.goto(180, 0)
 t.fillcolor("yellow")
  

while lifes >= 0:

  generateNewGuess()
  correctGuess = generateNewGuess()
  
  # print(correctGuess)
  # 0 polska
  # 1 monako
  # 2 ukraina

  print("punkty: " + str(points))
  print("zycia: " + str(lifes))
  print("nZgadnij flage, wybierz z: nPolska  [kliknij 0] nMonako  [kliknij 1] nUkraina [kliknij 2]")

  if (correctGuess == 0):
    drawFlagToGuess_Poland()
  if (correctGuess == 1):
    drawFlagToGuess_Monako()
  if (correctGuess == 2):
    drawFlagToGuess_Ukrainian()

  userInput = input()
  if (userInput == str(correctGuess)):
    print("zgadles, +1 punkt")
    points += 1
  else:
    print("nie zgadles, -1 zycie")
    lifes -= 1


#if (lifes >= 0):
#  drawFlagToGuess()
#else:
print("przegrana, wynik: " + str(points))