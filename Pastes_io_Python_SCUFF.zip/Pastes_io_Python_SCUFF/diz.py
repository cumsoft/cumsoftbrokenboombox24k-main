import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow_model_optimization.quantization.keras import vitis_quantize

def training_dataset_gen():
    # Directory containing your image data
    data_dir = '/path/to/your/images'

    # Parameters for your data preprocessing
    image_size = (640, 640)
    batch_size = 10

    datagen = ImageDataGenerator(rescale=1./255)
    generator = datagen.flow_from_directory(
        data_dir,
        target_size=image_size,
        batch_size=batch_size,
        class_mode=None,
        shuffle=False
    )

    while True:
        try:
            x, y = generator.next()
            print(f"Loaded batch: x.shape={x.shape}, y.shape={y.shape}")
            yield x, y
        except Exception as e:
            print(f"Error loading batch: {e}")
            raise StopIteration

# Load the SavedModel
loaded_model = tf.saved_model.load('best_saved_model/best_saved_model')

# Get the signature keys of the model
signature_keys = list(loaded_model.signatures.keys())

# Get the concrete function for inference
infer = loaded_model.signatures[signature_keys[0]]

# Get the input and output details
input_shape = (640, 640, 3)
output_shape = (1, 25200, 9)

# Create a Sequential model
sequential_model = tf.keras.Sequential([
    tf.keras.layers.InputLayer(input_shape=input_shape),
    tf.keras.layers.Lambda(lambda x: infer(x)['output_0']),
])

# Create TensorFlow tensor specs for the generator output
output_signature = (tf.TensorSpec(shape=(None,) + input_shape, dtype=tf.float32),
                    tf.TensorSpec(shape=(None,) + output_shape, dtype=tf.float32))

# Create a TensorFlow dataset from the generator function
calib_dataset = tf.data.Dataset.from_generator(training_dataset_gen,
                                               output_signature=output_signature)

# Quantize the model
quantizer = vitis_quantize.VitisQuantizer(sequential_model)
quantized_model = quantizer.quantize_model(calib_dataset=calib_dataset,
                                           calib_steps=100,
                                           calib_batch_size=10)