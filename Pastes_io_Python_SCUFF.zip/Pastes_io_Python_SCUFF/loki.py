import sys
import os
import argparse
import traceback
import yara         # install 'yara-python' module not the outdated 'yara' module
import re
import stat
import psutil
import platform
import signal as signal_module
from sys import platform as _platform
from subprocess import Popen, PIPE
from collections import Counter
import datetime
from bisect import bisect_left
from concurrent.futures import ThreadPoolExecutor
import queue
import subprocess
# LOKI Modules
from lib.lokilogger import *
from lib.levenshtein import LevCheck

from lib.helpers import *
from lib.pesieve import PESieve
from lib.doublepulsar import DoublePulsar
from lib.vuln_checker import VulnChecker

# Platform
os_platform = ""

if _platform == "linux" or _platform == "linux2":
    os_platform = "linux"

if os_platform == "":
    print("Unable to determine platform - LOKI is lost.")
    sys.exit(1)

# Predefined Evil Extensions
EVIL_EXTENSIONS = [".vbs", ".ps", ".ps1", ".rar", ".tmp", ".bas", ".bat", ".chm", ".cmd", ".com", ".cpl",
                   ".crt", ".dll", ".exe", ".hta", ".js", ".lnk", ".msc", ".ocx", ".pcd", ".pif", ".pot", ".pdf",
                   ".reg", ".scr", ".sct", ".sys", ".url", ".vb", ".vbe", ".wsc", ".wsf", ".wsh", ".ct", ".t",
                   ".input", ".war", ".jsp", ".jspx", ".php", ".asp", ".aspx", ".doc", ".docx", ".pdf", ".xls", ".xlsx", ".ppt",
                   ".pptx", ".tmp", ".log", ".dump", ".pwd", ".w", ".txt", ".conf", ".cfg", ".conf", ".config", ".psd1",
                   ".psm1", ".ps1xml", ".clixml", ".psc1", ".pssc", ".pl", ".www", ".rdp", ".jar", ".docm", ".sys"]

SCRIPT_EXTENSIONS = [".asp", ".vbs", ".ps1", ".bas", ".bat", ".js", ".vb", ".vbe", ".wsc", ".wsf",
                     ".wsh", ".jsp", ".jspx", ".php", ".asp", ".aspx", ".psd1", ".psm1", ".ps1xml", ".clixml", ".psc1",
                     ".pssc", ".pl"]

SCRIPT_TYPES = ["VBS", "PHP", "JSP", "ASP", "BATCH"]


def ioc_contains(sorted_list, value):
    # returns true if sorted_list contains value
    index = bisect_left(sorted_list, value)
    return index != len(sorted_list) and sorted_list[index] == value


class Loki(object):

    # Signatures
    yara_rules = []
    filename_iocs = []
    hashes_md5 = {}
    hashes_sha1 = {}
    hashes_sha256 = {}
    false_hashes = {}
    c2_server = {}

    # Yara rule directories
    yara_rule_directories = []

    # Excludes (list of regex that match within the whole path) (user-defined via excludes.cfg)
    fullExcludes = []
    # Platform specific excludes (match the beginning of the full path) (not user-defined)
    startExcludes = []

    # File type magics
    filetype_magics = {}
    max_filetype_magics = 0

    # Predefined paths to skip (Linux platform)
    LINUX_PATH_SKIPS_START = set(["/proc", "/dev", "/sys/kernel/debug", "/sys/kernel/slab", "/sys/devices", "/usr/src/linux"])
    MOUNTED_DEVICES = set(["/media", "/volumes"])
    LINUX_PATH_SKIPS_END = set(["/initctl"])

    def __init__(self, intense_mode, threads, memory_limit):
        self.args = args
        self.set_memory_limit(memory_limit)
        self.threads = threads
        self.ignore_paths = []
        # create queue for file paths
        self.queue = queue.Queue()

        # Scan Mode
        self.intense_mode = intense_mode

        # Get application path
        self.app_path = get_application_path()


        # Check if signature database is present
        sig_dir = os.path.join(self.app_path, "signature-base")
        if not os.path.exists(sig_dir) or os.listdir(sig_dir) == []:
            logger.log("NOTICE", "Init", "The 'signature-base' subdirectory doesn't exist or is empty. "
                                         "Trying to retrieve the signature database automatically.")
            updateLoki(sigsOnly=True)

        # Excludes
        self.initialize_excludes(os.path.join(self.app_path, "config/excludes.cfg".replace("/", os.sep)))

        # Set IOC path
        self.ioc_path = os.path.join(self.app_path, "signature-base/iocs/".replace("/", os.sep))

        # Yara rule directories
        self.yara_rule_directories.append(os.path.join(self.app_path, "signature-base/yara".replace("/", os.sep)))
        self.yara_rule_directories.append(os.path.join(self.app_path, "signature-base/iocs/yara".replace("/", os.sep)))
        self.yara_rule_directories.append(os.path.join(self.app_path, "signature-base/3rdparty".replace("/", os.sep)))

        # Read IOCs -------------------------------------------------------
        # File Name IOCs (all files in iocs that contain 'filename')
        self.initialize_filename_iocs(self.ioc_path)
        logger.log("INFO", "Init", "File Name Characteristics initialized with %s regex patterns" % len(self.filename_iocs))

        # C2 based IOCs (all files in iocs that contain 'c2')
        self.initialize_c2_iocs(self.ioc_path)
        logger.log("INFO", "Init", "C2 server indicators initialized with %s elements" % len(self.c2_server.keys()))

        # Hash based IOCs (all files in iocs that contain 'hash')
        self.initialize_hash_iocs(self.ioc_path)
        logger.log("INFO", "Init", "Malicious MD5 Hashes initialized with %s hashes" % len(self.hashes_md5.keys()))
        logger.log("INFO", "Init", "Malicious SHA1 Hashes initialized with %s hashes" % len(self.hashes_sha1.keys()))
        logger.log("INFO", "Init", "Malicious SHA256 Hashes initialized with %s hashes" % len(self.hashes_sha256.keys()))

        # Hash based False Positives (all files in iocs that contain 'hash' and 'falsepositive')
        self.initialize_hash_iocs(self.ioc_path, false_positive=True)
        logger.log("INFO", "Init", "False Positive Hashes initialized with %s hashes" % len(self.false_hashes.keys()))

        # Compile Yara Rules
        self.initialize_yara_rules()

        # Initialize File Type Magic signatures
        self.initialize_filetype_magics(os.path.join(self.app_path, 'signature-base/misc/file-type-signatures.txt'.replace("/", os.sep)))

        # Levenshtein Checker
        self.LevCheck = LevCheck()

    def set_memory_limit(self, limit_gb):
        import resource

        # Convert the memory limit from GB to bytes
        memory_limit = limit_gb * 1024 * 1024 * 1024

        try:
            resource.setrlimit(resource.RLIMIT_AS, (memory_limit, memory_limit))
            logger.log("INFO", "Init", "Memory limit set to {} GB".format(limit_gb))
        except Exception as e:
            logger.log("ERROR", "Init", "Failed to set memory limit: {}".format(e))

    def scan_path(self, path, depth=0):
        if any([re.match(x, path) for x in self.ignore_paths]):
            return

        if self.args.max_depth and depth >= self.args.max_depth:
            return

        try:
            items = os.listdir(path)
        except Exception as e:
            logger.warning("Error listing files in %s: %s" % (path, e))
            return

        # Multi-threading using ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=self.threads) as executor:
            for item in items:
                item_path = os.path.join(path, item)
                logger.log("INFO","init","Scanning %s" % item_path)
                if os.path.isdir(item_path) and not os.path.islink(item_path):
                    executor.submit(self.scan_path, item_path, depth + 1)
                elif os.path.isfile(item_path):
                 
                   # Read the file data
                    try:
                        with open(item_path, 'rb') as f:
                            file_data = f.read()
                    except Exception as e:
                        logger.warning("Error reading file %s: %s" % (item_path, e))
                        continue
                
                    # Get file information
                    file_name = os.path.basename(item_path)
                    file_extension = os.path.splitext(item_path)[1].lower()
                    file_type = get_file_type(item_path, self.filetype_magics, self.max_filetype_magics, logger)
                    md5 = generateHashes(file_data)

                    # Call the scan_data function for the file
                    results = self.scan_data(
                        fileData=file_data,
                        fileType=file_type,
                        fileName=file_name,
                        filePath=item_path,
                        extension=file_extension,
                        md5=md5
                    )

                    # Process the results from scan_data
                    for score, rule, description, reference, matched_strings, author in results:
                        # Determine message type based on the score
                        if score >= self.args.a:
                            message_type = "ALERT"
                        elif score >= self.args.w:
                            message_type = "WARNING"
                        elif score >= self.args.n:
                            message_type = "NOTICE"
                        else:
                            continue

                        # Build the message
                        message = f"Yara Rule MATCH: {rule} SUBSCORE: {score} DESCRIPTION: {description} REF: {reference} AUTHOR: {author}"
                        if matched_strings:
                            message += f" MATCHES: {matched_strings}"

                        # Log the message
                        logger.log(message_type, "FileScan", message)

    def get_changed_files_from_git(self):
        try:
            output = subprocess.check_output(['git', 'whatchanged', '--since=7.days', '--pretty=format:', '--name-only']).decode('utf-8')
            changed_files = [line.strip() for line in output.splitlines() if line.strip()]
            return changed_files
        except subprocess.CalledProcessError as e:
            logger.warning("Error getting changed files from git: %s" % e)
            return []
    '''
    def scan_changed_files(self, changed_files):
        # Multi-threading using ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=self.threads) as executor:
            for item_path in changed_files:
                logger.log("INFO", "init", "Scanning %s" % item_path)
                if os.path.isfile(item_path):
                    # Read the file data
                    try:
                        with open(item_path, 'rb') as f:
                            file_data = f.read()
                    except Exception as e:
                        logger.warning("Error reading file %s: %s" % (item_path, e))
                        continue

                    # Get file information
                    file_name = os.path.basename(item_path)
                    file_extension = os.path.splitext(item_path)[1].lower()
                    file_type = get_file_type(item_path, self.filetype_magics, self.max_filetype_magics, logger)
                    md5 = generateHashes(file_data)

                    # Call the scan_data function for the file
                    results = self.scan_data(
                        fileData=file_data,
                        fileType=file_type,
                        fileName=file_name,
                        filePath=item_path,
                        extension=file_extension,
                        md5=md5
                    )

                    # Process the results from scan_data
                    for score, rule, description, reference, matched_strings, author in results:
                        # Determine message type based on the score
                        if score >= self.args.a:
                            message_type = "ALERT"
                        elif score >= self.args.w:
                            message_type = "WARNING"
                        elif score >= self.args.n:
                            message_type = "NOTICE"
                        else:
                            continue

                        # Build the message
                        message = f"Yara Rule MATCH: {rule} SUBSCORE: {score} DESCRIPTION: {description} REF: {reference} AUTHOR: {author}"
                        if matched_strings:
                            message += f" MATCHES: {matched_strings}"

                        # Log the message
                        logger.log(message_type, "FileScan", message)
                else:
                    logger.warning(f"{item_path} is not a valid file.")

'''
    def scan_data(self, fileData, fileType="-", fileName="-", filePath="-", extension="-", md5="-"):

        # Convert all parameters to string
        fileType = str(fileType)
        fileName = str(fileName)
        filePath = str(filePath)
        extension = str(extension)
        md5 = str(md5)
        # Scan parameters
        #print fileType, fileName, filePath, extension, md5
        # Scan with yara
        try:
            for rules in self.yara_rules:
                # Process rules
                for rule in rules:
                    try:
                        matches = rules.match(data=fileData,
                                              externals={'filename': fileName,
                                                         'filepath': filePath,
                                                         'extension': extension,
                                                         'filetype': fileType,
                                                         'md5': md5},
                                              timeout=60)
                    except Exception as e:
                        if logger.debug:
                            traceback.print_exc()
                    else:

                # If matched
                        if matches:
                            for match in matches:
                            
                                score = 70
                                description = "not set"
                                reference = "-"
                                author = "-"

                                # Built-in rules have meta fields (cannot be expected from custom rules)
                                if hasattr(match, 'meta'):
                                
                                    if 'description' in match.meta:
                                        description = match.meta['description']
                                    if 'cluster' in match.meta:
                                        description = "IceWater Cluster {0}".format(match.meta['cluster'])

                                    if 'reference' in match.meta:
                                        reference = match.meta['reference']
                                    if 'viz_url' in match.meta:
                                        reference = match.meta['viz_url']
                                    if 'author' in match.meta:
                                        author = match.meta['author']

                                    # If a score is given
                                    if 'score' in match.meta:
                                        score = int(match.meta['score'])

                                # Matching strings
                                matched_strings = ""
                                if hasattr(match, 'strings'):
                                    # Get matching strings
                                    matched_strings = self.get_string_matches(match.strings)

                                yield score, match.rule, description, reference, matched_strings, author

        except Exception as e:
            if logger.debug:
                traceback.print_exc()


    def initialize_c2_iocs(self, ioc_directory):
        try:
            for ioc_filename in os.listdir(ioc_directory):
                try:
                    if 'c2' in ioc_filename:
                        with codecs.open(os.path.join(ioc_directory, ioc_filename), 'r', encoding='utf-8') as file:
                            lines = file.readlines()

                            # Last Comment Line
                            last_comment = ""

                            for line in lines:
                                try:
                                    # Comments and empty lines
                                    if re.search(r'^#', line) or re.search(r'^[\s]*$', line):
                                        last_comment = line.lstrip("#").lstrip(" ").rstrip("\n")
                                        continue

                                    # Split the IOC line
                                    if ";" in line:
                                        line = line.rstrip(" ").rstrip("\n\r")
                                        row = line.split(';')
                                        c2 = row[0]
                                        # LOKI doesn't use the C2 score (only THOR Lite)
                                        # score = row[1]

                                        # Elements without description
                                    else:
                                        c2 = line

                                    # Check length
                                    if len(c2) < 4:
                                        logger.log("NOTICE", "Init",
                                                   "C2 server definition is suspiciously short - will not add %s" %c2)
                                        continue

                                    # Add to the LOKI iocs
                                    self.c2_server[c2.lower()] = last_comment

                                except Exception as e:
                                    logger.log("ERROR", "Init",  "Cannot read line: %s" % line)
                                    if logger.debug:
                                        sys.exit(1)
                except OSError as e:
                    logger.log("ERROR", "Init",  "No such file or directory")
        except Exception as e:
            traceback.print_exc()
            logger.log("ERROR", "Init", "Error reading Hash file: %s" % ioc_filename)
    def get_string_matches(self, strings):
        try:
            string_matches = []
            matching_strings = ""
            for string in strings:
                # print string
                extract = string.identifier
                if not extract in string_matches:
                    string_matches.append(extract)

            string_num = 1
            for string in string_matches:
                matching_strings += " Str" + str(string_num) + ": " + removeNonAscii(string)
                string_num += 1

            # Limit string
            if len(matching_strings) > 140:
                matching_strings = matching_strings[:140] + " ... (truncated)"

            return matching_strings.lstrip(" ")
        except:
            traceback.print_exc()

    def initialize_filename_iocs(self, ioc_directory):

        try:
            for ioc_filename in os.listdir(ioc_directory):
                if 'filename' in ioc_filename:
                    with codecs.open(os.path.join(ioc_directory, ioc_filename), 'r', encoding='utf-8') as file:
                        for line in file:
                            lines = file.readlines()

                        # Last Comment Line
                        last_comment = ""
                        # Initialize score variable
                        score = 0
                        # Initialize empty description
                        desc = ""

                        for line in lines:
                            try:
                                # Empty
                                if re.search(r'^[\s]*$', line):
                                    continue

                                # Comments
                                if re.search(r'^#', line):
                                    last_comment = line.lstrip("#").lstrip(" ").rstrip("\n")
                                    continue

                                # Elements with description
                                if ";" in line:
                                    line = line.rstrip(" ").rstrip("\n\r")
                                    row = line.split(';')
                                    regex = row[0]
                                    score = row[1]
                                    if len(row) > 2:
                                        regex_fp = row[2]
                                    desc = last_comment

                                # Elements without description
                                else:
                                    regex = line

                                # Replace environment variables
                                regex = replaceEnvVars(regex)
                                # OS specific transforms
                                regex = transformOS(regex, os_platform)

                                # If false positive definition exists
                                regex_fp_comp = None
                                if 'regex_fp' in locals():
                                    # Replacements
                                    regex_fp = replaceEnvVars(regex_fp)
                                    regex_fp = transformOS(regex_fp, os_platform)
                                    # String regex as key - value is compiled regex of false positive values
                                    regex_fp_comp = re.compile(regex_fp)

                                # Create dictionary with IOC data
                                fioc = {'regex': re.compile(regex), 'score': score, 'description': desc, 'regex_fp': regex_fp_comp}
                                self.filename_iocs.append(fioc)

                            except Exception as e:
                                logger.log("ERROR", "Init", "Error reading line: %s" % line)
                                if logger.debug:
                                    traceback.print_exc()
                                    sys.exit(1)

        except Exception as e:
            if 'ioc_filename' in locals():
                logger.log("ERROR",  "Init", "Error reading IOC file: %s" % ioc_filename)
            else:
                logger.log("ERROR",  "Init", "Error reading files from IOC folder: %s" % ioc_directory)  
                logger.log("ERROR",  "Init", "Please make sure that you cloned the repo or downloaded the sub repository: "
                                             "See https://github.com/Neo23x0/Loki/issues/51")
            sys.exit(1)

    def initialize_yara_rules(self):

        yaraRules = ""
        dummy = ""
        rule_count = 0

        try:
            for yara_rule_directory in self.yara_rule_directories:
                if not os.path.exists(yara_rule_directory):
                    continue
                logger.log("INFO", "Init", "Processing YARA rules folder {0}".format(yara_rule_directory))
                for root, directories, files in os.walk(yara_rule_directory, onerror=walk_error, followlinks=False):
                    for file in files:
                        try:
                            # Full Path
                            yaraRuleFile = os.path.join(root, file)
                            # Skip hidden, backup or system related files
                            if file.startswith(".") or file.startswith("~") or file.startswith("_"):
                                continue

                            # Extension
                            extension = os.path.splitext(file)[1].lower()

                            # Skip all files that don't have *.yar or *.yara extensions
                            if extension != ".yar" and extension != ".yara":
                                continue

                            with open(yaraRuleFile, 'r') as yfile:
                                yara_rule_data = yfile.read()

                            # Test Compile
                            try:
                                compiledRules = yara.compile(source=yara_rule_data, externals={
                                    'filename': dummy,
                                    'filepath': dummy,
                                    'extension': dummy,
                                    'filetype': dummy,
                                    'md5': dummy,
                                    'owner': dummy,
                                })
                                logger.log("DEBUG", "Init", "Initializing Yara rule %s" % file)
                                rule_count += 1
                            except Exception as e:
                                logger.log("ERROR", "Init", "Error while initializing Yara rule %s ERROR: %s" % (file, sys.exc_info()[1]))
                                traceback.print_exc()
                                if logger.debug:
                                    sys.exit(1)
                                continue

                            # Add the rule
                            yaraRules += yara_rule_data

                        except Exception as e:
                            logger.log("ERROR", "Init", "Error reading signature file %s ERROR: %s" % (yaraRuleFile, sys.exc_info()[1]))
                            if logger.debug:
                                traceback.print_exc()
                                # sys.exit(1)

            # Compile
            try:
                logger.log("INFO", "Init", "Initializing all YARA rules at once (composed string of all rule files)")
                compiledRules = yara.compile(source=yaraRules, externals={
                    'filename': dummy,
                    'filepath': dummy,
                    'extension': dummy,
                    'filetype': dummy,
                    'md5': dummy,
                    'owner': dummy,
                })
                logger.log("INFO", "Init", "Initialized %d Yara rules" % rule_count)
            except Exception as e:
                traceback.print_exc()
                logger.log("ERROR", "Init", "Error during YARA rule compilation ERROR: %s - please fix the issue in the rule set" % sys.exc_info()[1])
                sys.exit(1)

            # Add as Lokis YARA rules
            self.yara_rules.append(compiledRules)

        except Exception as e:
            logger.log("ERROR", "Init", "Error reading signature folder /signatures/")
            if logger.debug:
                traceback.print_exc()
                sys.exit(1)

    def initialize_hash_iocs(self, ioc_directory, false_positive=False):
        HASH_WHITELIST = [# Empty file
                          int('d41d8cd98f00b204e9800998ecf8427e', 16),
                          int('da39a3ee5e6b4b0d3255bfef95601890afd80709', 16),
                          int('e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855', 16),
                          # One byte line break file (Unix) 0x0a
                          int('68b329da9893e34099c7d8ad5cb9c940', 16),
                          int('adc83b19e793491b1c6ea0fd8b46cd9f32e592fc', 16),
                          int('01ba4719c80b6fe911b091a7c05124b64eeece964e09c058ef8f9805daca546b', 16),
                          ]
        try:
            for ioc_filename in os.listdir(ioc_directory):
                if 'hash' in ioc_filename:
                    if false_positive and 'falsepositive' not in ioc_filename:
                        continue
                    with codecs.open(os.path.join(ioc_directory, ioc_filename), 'r', encoding='utf-8') as file:
                        for line in file:
                            try:
                                if re.search(r'^#', line) or re.search(r'^[\s]*$', line):
                                    continue
                                row = line.split(';')
                                hash = row[0].lower()
                                comment = row[1].rstrip(" ").rstrip("\n")
                                # Empty File Hash
                                if hash in HASH_WHITELIST:
                                    continue
                                # Else - check which type it is
                                if len(hash) == 32:
                                    self.hashes_md5[int(hash, 16)] = comment
                                if len(hash) == 40:
                                    self.hashes_sha1[int(hash, 16)] = comment
                                if len(hash) == 64:
                                    self.hashes_sha256[int(hash, 16)] = comment
                                if false_positive:
                                    self.false_hashes[int(hash, 16)] = comment
                            except Exception as e:
                                logger.log("ERROR", "Init", "Cannot read line: %s" % line)

                # Debug
                if logger.debug:
                    logger.log("DEBUG", "Init", "Initialized %s hash IOCs from file %s"
                               % (str(len(self.hashes_md5)+len(self.hashes_sha1)+len(self.hashes_sha256)), ioc_filename))


            # create sorted lists with just the integer values of the hashes for quick binary search 
            self.hashes_md5_list = list(self.hashes_md5.keys())
            self.hashes_md5_list.sort()
            self.hashes_sha1_list = list(self.hashes_sha1.keys())
            self.hashes_sha1_list.sort()
            self.hashes_sha256_list = list(self.hashes_sha256.keys())
            self.hashes_sha256_list.sort()

        except Exception as e:
            if logger.debug:
                traceback.print_exc()
                sys.exit(1)
            logger.log("ERROR", "Init", "Error reading Hash file: %s" % ioc_filename)

    def initialize_filetype_magics(self, filetype_magics_file):
        try:

            with open(filetype_magics_file, 'r') as config:
                lines = config.readlines()

            for line in lines:
                try:
                    if re.search(r'^#', line) or re.search(r'^[\s]*$', line) or ";" not in line:
                        continue

                    ( sig_raw, description ) = line.rstrip("\n").split(";")
                    sig = re.sub(r' ', '', sig_raw)

                    if len(sig) > self.max_filetype_magics:
                        self.max_filetype_magics = len(sig)

                    # print "%s - %s" % ( sig, description )
                    self.filetype_magics[sig] = description

                except Exception as e:
                    logger.log("ERROR", "Init", "Cannot read line: %s" % line)

        except Exception as e:
            if logger.debug:
                traceback.print_exc()
                sys.exit(1)
            logger.log("ERROR", "Init", "Error reading Hash file: %s" % filetype_magics_file)

    def initialize_excludes(self, excludes_file):
        try:
            excludes = []
            with open(excludes_file, 'r') as config:
                lines = config.read().splitlines()

            for line in lines:
                if re.search(r'^[\s]*#', line):
                    continue
                try:
                    # If the line contains something
                    if re.search(r'\w', line):
                        regex = re.compile(line, re.IGNORECASE)
                        excludes.append(regex)
                except Exception as e:
                    logger.log("ERROR", "Init", "Cannot compile regex: %s" % line)

            self.fullExcludes = excludes

        except Exception as e:
            if logger.debug:
                traceback.print_exc()
            logger.log("NOTICE", "Init", "Error reading excludes file: %s" % excludes_file)


    def get_file_data(self, filePath):
        fileData = b''
        try:
            # Read file complete
            with open(filePath, 'rb') as f:
                fileData = f.read()
        except Exception as e:
            if logger.debug:
                traceback.print_exc()
            logger.log("DEBUG", "FileScan", "Cannot open file %s (access denied)" % filePath)
        finally:
            return fileData


    def script_stats_analysis(self, data):
        """
        Doing a statistical analysis for scripts like PHP, JavaScript or PowerShell to
        detect obfuscated code
        :param data:
        :return: message, score
        """
        anomal_chars = [r'^', r'{', r'}', r'"', r',', r'<', r'>', ';']
        anomal_char_stats = {}
        char_stats = {"upper": 0, "lower": 0, "numbers": 0, "symbols": 0, "spaces": 0}
        anomalies = []
        c = Counter(data)
        anomaly_score = 0

        # Check the characters
        for char in c.most_common():
            if char[0] in anomal_chars:
                anomal_char_stats[char[0]] = char[1]
            if char[0].isupper():
                char_stats["upper"] += char[1]
            elif char[0].islower():
                char_stats["lower"] += char[1]
            elif char[0].isdigit():
                char_stats["numbers"] += char[1]
            elif char[0].isspace():
                char_stats["spaces"] += char[1]
            else:
                char_stats["symbols"] += char[1]
        # Totals
        char_stats["total"] = len(data)
        char_stats["alpha"] = char_stats["upper"] + char_stats["lower"]

        # Detect Anomalies
        if char_stats["alpha"] > 40 and char_stats["upper"] > (char_stats["lower"] * 0.9):
            anomalies.append("upper to lower ratio")
            anomaly_score += 20
        if char_stats["symbols"] > char_stats["alpha"]:
            anomalies.append("more symbols than alphanum chars")
            anomaly_score += 40
        for ac, count in anomal_char_stats.iteritems():
            if (count/char_stats["alpha"]) > 0.05:
                anomalies.append("symbol count of '%s' very high" % ac)
                anomaly_score += 40

        # Generate message
        message = "Anomaly detected ANOMALIES: '{0}'".format("', '".join(anomalies))
        if anomaly_score > 40:
            return message, anomaly_score

        return "", 0


def get_application_path():
    try:
        if getattr(sys, 'frozen', False):
            application_path = os.path.dirname(os.path.realpath(sys.executable))
        else:
            application_path = os.path.dirname(os.path.realpath(__file__))
        return application_path
    except Exception as e:
        print("Error while evaluation of application path")
        traceback.print_exc()
        if args.debug:
            sys.exit(1)


def is64bit():
    """
    Checks if the system has a 64bit processor architecture
    :return arch:
    """
    return platform.machine().endswith('64')


def processExists(pid):
    """
    Checks if a given process is running
    :param pid:
    :return:
    """
    return psutil.pid_exists(pid)


def updateLoki(sigsOnly):
    logger.log("INFO", "Update", "Starting separate updater process ...")
    pArgs = []


    if os.path.exists(os.path.join(get_application_path(), 'loki-upgrader.py')):
        pArgs.append(args.python)
        pArgs.append('loki-upgrader.py')
    else:
        logger.log("ERROR", "Update", "Cannot find neither thor-upgrader.exe nor thor-upgrader.py in the current working directory.")

    if sigsOnly:
        pArgs.append('--sigsonly')
        p = Popen(pArgs, shell=False)
        p.communicate()
    else:
        pArgs.append('--detached')
        Popen(pArgs, shell=False)


def walk_error(err):
    if "Error 3" in str(err):
        logging.error(str(err))
        print("Directory walk error")


# CTRL+C Handler --------------------------------------------------------------
def signal_handler(signal_name, frame):
    try:
        print("------------------------------------------------------------------------------\n")
        logger.log('INFO', 'Init', 'LOKI\'s work has been interrupted by a human. Returning to Asgard.')
    except Exception as e:
        print('LOKI\'s work has been interrupted by a human. Returning to Asgard.')
    sys.exit(0)

def main():
    """
    Argument parsing function
    :return:
    """

    # Parse Arguments
    parser = argparse.ArgumentParser(description='Loki - Simple IOC Scanner')
    parser.add_argument('-p', '--path', help='Path to scan', default='/', type=str)    
    parser.add_argument('-s', help='Maximum file size to check in KB (default 5000 KB)', metavar='kilobyte', default=5000)
    parser.add_argument('-l', help='Log file', metavar='log-file', default='')
    parser.add_argument('--rss', help='Remote syslog system', metavar='remote-loghost', default='')
    parser.add_argument('--rsp', help='Remote syslog port', metavar='remote-syslog-port', default=514)
    parser.add_argument('-a', help='Alert score', metavar='alert-level', default=100)
    parser.add_argument('-w', help='Warning score', metavar='warning-level', default=60)
    parser.add_argument('-n', help='Notice score', metavar='notice-level', default=40)
    parser.add_argument('--printall', action='store_true', help='Print all files that are scanned', default=False)
    parser.add_argument('--allreasons', action='store_true', help='Print all reasons that caused the score', default=False)
    parser.add_argument('--noprocscan', action='store_true', help='Skip the process scan', default=False)
    parser.add_argument('--nofilescan', action='store_true', help='Skip the file scan', default=False)
    parser.add_argument('--vulnchecks', action='store_true', help='Run the vulnerability checks', default=False)
    parser.add_argument('--nolevcheck', action='store_true', help='Skip the Levenshtein distance check', default=False)
    parser.add_argument('--scriptanalysis', action='store_true', help='Statistical analysis for scripts to detect obfuscated code (beta)', default=False)
    parser.add_argument('--rootkit', action='store_true', help='Skip the rootkit check', default=False)
    parser.add_argument('--noindicator', action='store_true', help='Do not show a progress indicator', default=False)
    parser.add_argument('--dontwait', action='store_true', help='Do not wait on exit', default=False)
    parser.add_argument('--intense', action='store_true', help='Intense scan mode (also scan unknown file types and all extensions)', default=False)
    parser.add_argument('--csv', action='store_true', help='Write CSV log format to STDOUT (machine processing)', default=False)
    parser.add_argument('--onlyrelevant', action='store_true', help='Only print warnings or alerts', default=False)
    parser.add_argument('--nolog', action='store_true', help='Don\'t write a local log file', default=False)
    parser.add_argument('--update', action='store_true', default=False, help='Update the signatures from the "signature-base" sub repository')
    parser.add_argument('--debug', action='store_true', default=False, help='Debug output')
    parser.add_argument('--maxworkingset', type=int, default=200, help='Maximum working set size of processes to scan (in MB, default 100 MB)')
    parser.add_argument('--syslogtcp', action='store_true', default=False, help='Use TCP instead of UDP for syslog logging')
    parser.add_argument('--logfolder', help='Folder to use for logging when log file is not specified', metavar='log-folder', default='')
    parser.add_argument('--nopesieve', action='store_true', help='Do not perform pe-sieve scans', default=False)
    parser.add_argument('--pesieveshellc', action='store_true', help='Perform pe-sieve shellcode scan', default=False)
    parser.add_argument('--python', action='store', help='Override default python path', default='python')
    parser.add_argument('--nolisten', action='store_true', help='Dot not show listening connections', default=False)
    parser.add_argument('--excludeprocess', action='append', help='Specify an executable name to exclude from scans, can be used multiple times', default=[])
    parser.add_argument('--force', action='store_true',
                        help='Force the scan on a certain folder (even if excluded with hard exclude in LOKI\'s code', default=False)
    parser.add_argument('--version', action='store_true', help='Shows welcome text and version of loki, then exit', default=False)
    parser.add_argument("-t", "--threads", help="Number of threads to use for scanning (default: 2 max should be 4)", type=int, default=2)
    parser.add_argument("--max-depth", help="Maximum directory depth to scan (default: unlimited)", type=int, default=None)
    parser.add_argument("--no-scan-clam", help="Disable ClamAV scanning", action="store_true")
    parser.add_argument("--memory-limit", help="Maximum memory limit for the script in GB (default: 2 GB)", type=int, default=5)
    parser.add_argument('--git-scan', action='store_true', help='Scan files changed in the last 7 days using git-whatchanged')
    args = parser.parse_args()

    if args.syslogtcp and not args.r:
        print('Syslog logging set to TCP with --syslogtcp, but syslog logging not enabled with -r')
        sys.exit(1)
    
    
		
    if args.nolog and (args.l or args.logfolder):
        print('The --logfolder and -l directives are not compatible with --nolog')
        sys.exit(1)
		
    filename = 'loki_%s_%s.log' % (getHostname(os_platform), datetime.datetime.now().strftime('%Y-%m-%d_%H-%M-%S'))
    if args.logfolder and args.l:
        print('Must specify either log folder with --logfolder, which uses the default filename, or log file with -l. Log file can be an absolute path')
        sys.exit(1)
    elif args.logfolder:
        args.logfolder = os.path.abspath(args.logfolder)
        args.l = os.path.join(args.logfolder, filename)
    elif not args.l:
        args.l = filename

    if args.nopesieve and args.pesieveshellc:
        print('The --pesieveshellc directive was specified, but pe-sieve scanning was disabled with --nopesieve')
        sys.exit(1)
        
    args.excludeprocess = [ x.lower() for x in args.excludeprocess ]
    
    return args

# MAIN ################################################################
if __name__ == '__main__':

    # Signal handler for CTRL+C
    signal_module.signal(signal_module.SIGINT, signal_handler)

    # Argument parsing
    args = main()

    # Remove old log file
    if os.path.exists(args.l):
        os.remove(args.l)

    # Logger
    LokiCustomFormatter = None
    logger = LokiLogger(args.nolog, args.l, getHostname(os_platform), args.rss, int(args.rsp), args.syslogtcp, args.csv, args.onlyrelevant, args.debug,
                        platform=os_platform, caller='main', customformatter=LokiCustomFormatter)

    # Show version
    if args.version:
        sys.exit(0)

    # Update
    if args.update:
        updateLoki(sigsOnly=False)
        sys.exit(0)

    logger.log("NOTICE", "Init", "Starting Loki Scan VERSION: {3} SYSTEM: {0} TIME: {1} PLATFORM: {2}".format(
        getHostname(os_platform), getSyslogTimestamp(), getPlatformFull(), logger.version))

    # Loki
    loki = Loki(args.intense, args.threads , args.memory_limit)

    # Check if admin
    isAdmin = False
    
    if os.geteuid() == 0:
        isAdmin = True
        logger.log("INFO", "Init", "Current user is root - very good")
    else:
        logger.log("NOTICE", "Init", "Program should be run as 'root' to ensure all access rights to process memory and file objects.")

    # Scan Path -------------------------------------------------------
    if not args.nofilescan:
        # Set default
        defaultPath = args.path
        defaultThreads = args.threads
        if (os_platform == "linux" or os_platform == "macos") and args.path == "C:\\":
            defaultPath = "/"
        # Linux & macOS
        else:
           loki.scan_path(defaultPath)

    if args.git_scan:
        # Get the list of changed files from git-whatchanged
        changed_files = Loki.get_changed_files_from_git()
        # Scan the changed files
        Loki.scan_path(changed_files)

    # Result ----------------------------------------------------------
    logger.log("NOTICE", "Results", "Results: {0} alerts, {1} warnings, {2} notices".format(logger.alerts, logger.warnings, logger.notices))
    if logger.alerts:
        logger.log("RESULT", "Results", "Indicators detected!")
        logger.log("RESULT", "Results", "Loki recommends checking the elements on virustotal.com or Google and triage with a "
                             "professional tool like THOR https://nextron-systems.com/thor in corporate networks.")
    elif logger.warnings:
        logger.log("RESULT", "Results", "Suspicious objects detected!")
        logger.log("RESULT", "Results", "Loki recommends a deeper analysis of the suspicious objects.")
    else:
        logger.log("RESULT", "Results", "SYSTEM SEEMS TO BE CLEAN.")

    logger.log("INFO", "Results", "Please report false positives via https://github.com/Neo23x0/signature-base")
    logger.log("NOTICE", "Results", "Finished LOKI Scan SYSTEM: %s TIME: %s" % (getHostname(os_platform), getSyslogTimestamp()))

sys.exit(0)