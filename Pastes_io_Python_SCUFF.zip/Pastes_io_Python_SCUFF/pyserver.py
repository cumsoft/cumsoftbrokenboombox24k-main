# -*- coding: utf-8 -*-
import json
import shutil
import os
import sys

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
                            QMetaObject, QObject, QPoint, QRect,
                            QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QAction, QBrush, QColor, QConicalGradient,
                           QCursor, QFont, QFontDatabase, QGradient,
                           QIcon, QImage, QKeySequence, QLinearGradient,
                           QPainter, QPalette, QPixmap, QRadialGradient,
                           QTransform)
from PySide6.QtWidgets import (QApplication, QGridLayout, QHeaderView, QLabel,
                               QLineEdit, QMainWindow, QMenu, QMenuBar,
                               QPushButton, QSizePolicy, QStatusBar, QTableWidget,
                               QTableWidgetItem, QVBoxLayout, QWidget, QHBoxLayout, QFrame, QFileDialog)


class Ui_MainWindow(object):

    def select_server_jar(self):
        # Open a file dialog for selecting the Minecraft server JAR file
        file_dialog = QFileDialog()
        jar_file_path, _ = file_dialog.getOpenFileName(filter="JAR files (*.jar)")

        if jar_file_path:
            # Check if "ManagerSettings.json" exists
            if os.path.exists("ManagerSettings.json"):
                with open("ManagerSettings.json", "r") as json_file:
                    manager_settings = json.load(json_file)
            else:
                # If "ManagerSettings.json" does not exist, create it with default values
                manager_settings = {
                    "ram_gb": "4",
                    "server_jar": "server",
                    "server_dir": "server"
                }

            # Ensure the server directory exists
            os.makedirs(manager_settings["server_dir"], exist_ok=True)

            # Copy and rename the selected JAR file to "server.jar" in the specified directory
            shutil.copy(jar_file_path, manager_settings["server_dir"] + "/server.jar")

            # Update "ManagerSettings.json" with the new server JAR file
            manager_settings["server_jar"] = "server.jar"

            with open("ManagerSettings.json", "w") as json_file:
                json.dump(manager_settings, json_file, indent=4)

    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1126, 852)

        self.actionOpen_EULA = QAction(MainWindow)
        self.actionOpen_EULA.setObjectName(u"actionOpen_EULA")

        self.actionSelect_Server_jar = QAction(MainWindow)
        self.actionSelect_Server_jar.setObjectName(u"actionSelect_Server_jar")
        self.actionSelect_Server_jar.triggered.connect(self.select_server_jar)

        self.actionManage = QAction(MainWindow)
        self.actionManage.setObjectName(u"actionManage")

        self.actionDownload = QAction(MainWindow)
        self.actionDownload.setObjectName(u"actionDownload")

        self.actionserver_properties = QAction(MainWindow)
        self.actionserver_properties.setObjectName(u"actionserver_properties")

        self.actionops_json = QAction(MainWindow)
        self.actionops_json.setObjectName(u"actionops_json")

        self.actionbanned_players_json = QAction(MainWindow)
        self.actionbanned_players_json.setObjectName(u"actionbanned_players_json")

        self.actionbanned_ips_json = QAction(MainWindow)
        self.actionbanned_ips_json.setObjectName(u"actionbanned_ips_json")

        self.actioncommands_yml = QAction(MainWindow)
        self.actioncommands_yml.setObjectName(u"actioncommands_yml")

        self.actionOpen_config = QAction(MainWindow)
        self.actionOpen_config.setObjectName(u"actionOpen_config")

        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.gridLayoutWidget = QWidget(self.centralwidget)
        self.gridLayoutWidget.setObjectName(u"gridLayoutWidget")
        self.gridLayoutWidget.setGeometry(QRect(10, 20, 1101, 771))
        self.gridLayout = QGridLayout(self.gridLayoutWidget)
        self.gridLayout.setObjectName(u"gridLayout")
        self.gridLayout.setContentsMargins(0, 0, 0, 0)

        ###############################
        self.label = QLabel(self.gridLayoutWidget)
        self.label.setObjectName(u"label")

        self.Label_online = QLabel("Online")
        self.Label_online.setAlignment(Qt.AlignRight)  # Align the label to the right

        # Create a QHBoxLayout for the labels
        self.labelLayout = QHBoxLayout()
        self.labelLayout.addWidget(self.label)  # Add the server IP address label
        self.labelLayout.addWidget(self.Label_online)  # Add the "Online:" label

        # Add the label layout to the grid layout
        self.gridLayout.addLayout(self.labelLayout, 0, 0)
        ###############################

        self.Button_Send_Command = QPushButton(self.gridLayoutWidget)
        self.Button_Send_Command.setObjectName(u"Button_Send_Command")

        self.Line_Server_Console_Input = QLineEdit(self.gridLayoutWidget)
        self.Line_Server_Console_Input.setObjectName(u"Line_Server_Console_Input")

        self.Table_Server_Console = QTableWidget(self.gridLayoutWidget)
        self.Table_Server_Console.setObjectName(u"Table_Server_Console")

        self.gridLayout.addWidget(self.Table_Server_Console, 2, 0, 1, 1)

        # Create a QHBoxLayout for the buttons
        self.buttonLayout = QHBoxLayout()
        self.buttonLayout.setSpacing(10)  # Set spacing between widgets in the layout

        # Then add the buttons
        self.Button_Start_Server = QPushButton("Start Server")
        self.buttonLayout.addWidget(self.Button_Start_Server)

        self.Button_Restart_Server = QPushButton("Restart Server")
        self.buttonLayout.addWidget(self.Button_Restart_Server)

        self.Button_StopServer = QPushButton("Stop Server")
        self.buttonLayout.addWidget(self.Button_StopServer)

        self.Button_Kill_Server = QPushButton("Kill Server")
        self.buttonLayout.addWidget(self.Button_Kill_Server)

        # Add the button layout to the grid layout
        self.gridLayout.addLayout(self.buttonLayout, 1, 0)  # Adjusted the row index to 1

        # Create a QHBoxLayout for the input field and the button
        self.inputLayout = QHBoxLayout()
        self.inputLayout.setSpacing(10)  # Set spacing between widgets in the layout

        self.inputLayout.addWidget(self.Line_Server_Console_Input)
        self.inputLayout.addWidget(self.Button_Send_Command)

        # Add the input layout to the grid layout
        self.gridLayout.addLayout(self.inputLayout, 3, 0)  # Adjusted the row index to 3

        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 1126, 22))
        self.menuGeneral = QMenu(self.menubar)
        self.menuGeneral.setObjectName(u"menuGeneral")
        self.menuProperties = QMenu(self.menubar)
        self.menuProperties.setObjectName(u"menuProperties")
        self.menuPlugins = QMenu(self.menubar)
        self.menuPlugins.setObjectName(u"menuPlugins")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.menubar.addAction(self.menuGeneral.menuAction())
        self.menubar.addAction(self.menuProperties.menuAction())
        self.menubar.addAction(self.menuPlugins.menuAction())
        self.menuGeneral.addAction(self.actionOpen_config)
        self.menuGeneral.addSeparator()
        self.menuGeneral.addAction(self.actionOpen_EULA)
        self.menuGeneral.addAction(self.actionSelect_Server_jar)
        self.menuProperties.addAction(self.actionserver_properties)
        self.menuProperties.addAction(self.actionops_json)
        self.menuProperties.addSeparator()
        self.menuProperties.addAction(self.actionbanned_players_json)
        self.menuProperties.addAction(self.actionbanned_ips_json)
        self.menuPlugins.addAction(self.actionManage)
        self.menuPlugins.addAction(self.actionDownload)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)

    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.actionOpen_EULA.setText(QCoreApplication.translate("MainWindow", u"Open EULA", None))
        self.actionSelect_Server_jar.setText(QCoreApplication.translate("MainWindow", u"Select Server JAR", None))
        self.actionManage.setText(QCoreApplication.translate("MainWindow", u"Manage", None))
        self.actionDownload.setText(QCoreApplication.translate("MainWindow", u"Download", None))
        self.actionserver_properties.setText(QCoreApplication.translate("MainWindow", u"Server Setings", None))
        self.actionops_json.setText(QCoreApplication.translate("MainWindow", u"Operators", None))
        self.actionbanned_players_json.setText(QCoreApplication.translate("MainWindow", u"Banned Players", None))
        self.actionbanned_ips_json.setText(QCoreApplication.translate("MainWindow", u"Banned IPs", None))
        self.actioncommands_yml.setText(QCoreApplication.translate("MainWindow", u"commands.yml", None))
        self.actionOpen_config.setText(QCoreApplication.translate("MainWindow", u"Open manager config", None))
        self.Label_online.setText(QCoreApplication.translate("MainWindow", u"Online:", None))
        self.Button_Send_Command.setText(QCoreApplication.translate("MainWindow", u"Send Command", None))
        self.label.setText(QCoreApplication.translate("MainWindow", u"Serves IP Adress: 127.0.0.1:25565", None))
        self.Button_Start_Server.setText(QCoreApplication.translate("MainWindow", u"Start Server", None))
        self.Button_Restart_Server.setText(QCoreApplication.translate("MainWindow", u"Restart Server", None))
        self.Button_StopServer.setText(QCoreApplication.translate("MainWindow", u"Stop Server", None))
        self.Button_Kill_Server.setText(QCoreApplication.translate("MainWindow", u"Kill Server", None))
        self.menuGeneral.setTitle(QCoreApplication.translate("MainWindow", u"General", None))
        self.menuProperties.setTitle(QCoreApplication.translate("MainWindow", u"Properties", None))
        self.menuPlugins.setTitle(QCoreApplication.translate("MainWindow", u"Plugins", None))
    # retranslateUi


if __name__ == "__main__":
    app = QApplication(sys.argv)
    MainWindow = QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec())