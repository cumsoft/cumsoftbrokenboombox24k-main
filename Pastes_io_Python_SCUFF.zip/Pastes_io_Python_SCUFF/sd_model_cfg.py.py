# The model dict is used for webUI only

model_dict = {
    'Stable Diffusion 1.5': '/home/ubuntu/stable-diffusion-webui/models/Stable-diffusion/_base/_v1-5-pruned.ckpt',
    'revAnimated_v11': '/home/ubuntu/stable-diffusion-webui/models/Stable-diffusion/_general/revAnimated_v11.safetensors',
    'realisticVisionV20_v20': '/home/ubuntu/stable-diffusion-webui/models/Stable-diffusion/_general/realisticVisionV20_v20.safetensors',
    'aZovyaRPGArtistTools_v3': '/home/ubuntu/stable-diffusion-webui/models/Stable-diffusion/_general/aZovyaRPGArtistTools_v3.safetensors',
    'samdoesarts_style_ckpt': '/home/ubuntu/stable-diffusion-webui/models/Stable-diffusion/zzz/samdoesarts_style.ckpt',
    'samdoesarts_merged_lora': '/home/ubuntu/stable-diffusion-webui/models/Lora/samdoesartsSamYang_offsetRightFilesize.safetensors',
    'samyang_lora': '/home/ubuntu/stable-diffusion-webui/models/Lora/samdoesartsSamYang_offsetRightFilesize.safetensors'
}