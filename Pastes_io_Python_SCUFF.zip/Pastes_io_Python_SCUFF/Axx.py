# Copyright (c) OpenMMLab. All rights reserved.
import os

# from chatbot import Chatbot, Session
# from chat_template import InternLMXComposer7B
from lmdeploy_vl.chatbot import Chatbot, Session
from lmdeploy_vl.chat_template import InternLMXComposer7B
import numpy as np


tritonserver_addr = '10.140.0.65:33432'

chatbot = Chatbot(tritonserver_addr)
decorator = InternLMXComposer7B()

# query1 = 'Who is in the picture?'
# answer1 = 'Albert Einstein is in the picture.'

# messages = [
#     {
#         'role': 'user',
#         'content': [
#             {'type': 'text', 'text': query1},
#             {
#                 'type': 'image_url',
#                 'image_url': {
#                     'url': ''
#                 },
#             },
#         ],
#     },
#     {'role': 'assistant', 'content': answer1}
# ]

# history_prompt = decorator.messages2prompt(messages, sequence_start=True)
# emb = np.load('ayst.npy')
sess = Session(0)
info = 'meta instruction\nYou are an AI assistant whose name is 浦语.\n- 浦语 is a conversational language model that is developed by Shanghai AI Laboratory (上海人工智能实验室). It is designed to be helpful, honest, and harmless.\n- 浦语 can understand and communicate fluently in the language chosen by the user such as English and 中文.\nconversation\n <|User|>: 10+9<TOKENS_UNUSED_0> <|Bot|>:  19<TOKENS_UNUSED_1>'
sess.histories = info
# sess.history_image_embs = [emb]
chatbot.session = sess
chatbot.resume(0)

query2 = '再加9'
status, res, n_token = chatbot.infer(
    0,
    query2,
    image_embs=None,
    request_output_len=512)

print(res)