class Color:
    LIGHT_GREEN = "c0ffc0"
    DARK_GREEN = "00c000"
    LIGHT_YELLOW = "ffffc0"
    DARK_YELLOW = "c0c000"
    LIGHT_RED = "ffc0c0"
    DARK_RED = "c00000"
    LIGHT_BLUE = "c0c0ff"
    DARK_BLUE = "0000c0"
    WHITE = "ffffff"
    BLACK = "000000"
 
 
COLOR_TO_MOVEMENT = {
    Color.LIGHT_GREEN: lambda x: (x[0] - 1, x[1]),
    Color.DARK_GREEN: lambda x: (x[0] + 1, x[1]),
    Color.LIGHT_YELLOW: lambda x: (x[0], x[1] - 1),
    Color.DARK_YELLOW: lambda x: (x[0], x[1] + 1),
    Color.LIGHT_RED: lambda x: (x[0] + 1, x[1]),
    Color.DARK_RED: lambda x: (x[0] - 1, x[1]),
    Color.LIGHT_BLUE: lambda x: (x[0], x[1] + 1),
    Color.DARK_BLUE: lambda x: (x[0], x[1] - 1),
    Color.WHITE: lambda x: x
}
 
 
def is_color_black(color: str) -> bool:
    return color == Color.BLACK
 
 
def calculate_final_vector(position_vector: tuple[int, int],
                           colors: list[str]) -> tuple[int, int]:
    for raw_color in colors:
        color = raw_color.lower()
        if is_color_black(color):
            break
 
        if color in COLOR_TO_MOVEMENT:
            update_position_function = COLOR_TO_MOVEMENT[color]
            position_vector = update_position_function(position_vector)
 
    return position_vector
 
 
if __name__ == '__main__':
    assert calculate_final_vector(
        (1, 1), ['00C000', 'C0FFC0', 'C00000', 'FFFFFF', 'C0C000']
    ) == (0, 2)
    assert calculate_final_vector((0, 0), ['00c000', 'c0c000']) == (1, 1)