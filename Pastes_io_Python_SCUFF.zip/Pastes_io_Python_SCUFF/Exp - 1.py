List = []
print("Blank List:")
print(List)
print(" ")

List = [29, 30, 40]
print("List of numbers:")
print(List)
print(" ")

List = ["Criteria", "Polo", "Swift"]
print("List of car names:")
print(List)
print(" ")

name = ["Jagadeesh", "Grau", "ravi", "Pradeep"]
roll_no = [20, 17, 23, 18]
print(name)
print(name[0], name[1])
print(name[1:3])
print(name + roll_no)
print(roll_no[2:])
print(" ")

marks = (98, 70, 89, 30)
roll_no = ('001', '002', '003')
days = ('mon', 'tues', 'wed')
month = ('Jan', ('feb', 'mar'))
tup = (1, "a", "string", 5+10)
print("Tuple")
print(marks[2])
print(marks[1:])
print(len(days))
print(len(month))
print(tup)
print(" ")

book = {}
print("Empty Dictionary:")
print(book)
print(" ")

phone = {1: "Realme",
         2: "OPPO",
         3: "iPhone"}
print("List of phone brand names:")
print(phone)
print(" ")

employee = {'001': 'abc',
            '002': 'def',
            '003': 'ghi'}
print("The employee details are:")
print(employee)
print(" ")

days = dict([(1, 'Jan'),
             (2, 'Feb')])
print("Dictionary with each item as pairs:")
print(days)
print(" ")

Set1 = set()
Set2 = set()

for i in range(1, 6):
    Set1.add(i)

for i in range(3, 8):
    Set2.add(i)

print("Set1 = ", Set1)
print("Set2 = ", Set2)
print("\n")