import sys
import time
import os
%matplotlib inline
import matplotlib.pyplot as plt
from toy_exchange_client import ExchangeClient, BID_SIDE, ASK_SIDE, Order
from IPython.display import clear_output

BUY=BID_SIDE
SELL=ASK_SIDE

# Addresses for the test and real exchange
TEST_EXCHANGE="http://api.test-toy-exchange.svc.cluster.local:5000"
REAL_EXCHANGE="http://api.toy-exchange.svc.cluster.local:5000"

BADGE="team9" # TODO: this is the username we have given to you
SECRET="philosophical-horse-204" # TODO: Change this to the password we have given to you
EXCHANGE = REAL_EXCHANGE # TODO: Change me to REAL_EXCHANGE when you're ready

client = ExchangeClient(
        badge=BADGE,
        secret=SECRET,
        exchange_url=EXCHANGE
        )

# Below code are used to plot a graph of current price for a product
# Modify it to suit your need
last_tops = []
def plot_market_state(top_result):
    global last_tops
    
    last_tops.append(top_result)
    last_tops = last_tops[-10:]
    
    reversed_indexes = range(len(last_tops), 0, -1)
    timescale = list(map(lambda x: f't-{x}', reversed_indexes))
    
    ask, = plt.plot(timescale,list(map(lambda top: top['ask'] , last_tops)), label='ASK')
    bid, = plt.plot(timescale,list(map(lambda top: top['bid'] , last_tops)), label='BID')
    last_trade, = plt.plot(timescale,list(map(lambda top: top['last_trade'] , last_tops)), label='Last Trade')
    
    plt.legend(handles=[ask, bid, last_trade])
    plt.show()
    
# These flags control what the output is during each iteration
print_feed = True
print_positions = True
plot_feed = True # Turn this on for graph plotting

# buys_price = {"DOUGH" : 0, "SAUCE" : 0}
# sells_price = {"DOUGH" : 0, "SAUCE" : 0}

def trade_loop():
    clear_output(wait=True) # This clears the output so we don't spam the log
    sauce_top = client.top("SAUCE")
    dough_top = client.top("DOUGH")
    pizza_top = client.top("PIZZA")
    calzone_top = client.top("CALZONE")
    
    # intialising variables
    sauce_ask = sauce_top["ask"]
    sauce_bid = sauce_top["bid"]
    dough_ask = dough_top["ask"]
    dough_bid = dough_top["bid"]
    pizza_ask = pizza_top["ask"]
    pizza_bid = pizza_top["bid"]
    calzone_ask = calzone_top["ask"]
    calzone_bid = calzone_top["bid"]
    
    if sauce_top["ask"] == None or sauce_top["bid"] == None:
        width_sauce = 0
    else:
        width_sauce = sauce_top["ask"] - sauce_top["bid"]
    
    if dough_top["ask"] == None or dough_top["bid"] == None:
        width_dough = 0
    else:
        width_dough = dough_top["ask"] - dough_top["bid"]
        
    #if dough_top["ask"] == None or dough_top["ask"] == None or d:
    #     width_dough = 0
    
    quantity = 20
    prof = 0.05
    width = 1.5
    
    print()
    print(width_sauce)
    print()
    
    if width_sauce > width:
        client.quote("SAUCE", BUY, sauce_bid + prof, quantity)
        client.quote("SAUCE", SELL, sauce_ask - prof, quantity)
   
        
    if width_dough > width:
        client.quote("DOUGH", BUY, dough_bid + prof, quantity)
        client.quote("DOUGH", SELL, dough_ask - prof, quantity)
        
    

    
    
    
#     # if sauce + dough < pizza, purchase sauce + dough, sell pizza
#     if (sauce_ask != None or dough_ask != None or pizza_bid != None)and (sauce_ask + dough_ask < pizza_bid):
#         if (client.positions() == {}):
#             limiting = min(dough_top["ask_qty"], sauce_top["ask_qty"])
#         else:    
#             limiting = min(dough_top["ask_qty"], sauce_top["ask_qty"], 1000 - abs(client.positions()["DOUGH"]["position"]), 1000 - abs(client.positions()["SAUCE"]["position"])) 
#         client.hit("SAUCE", BUY, sauce_ask, limiting)
#         client.hit("DOUGH", BUY, dough_ask, limiting)
#         client.hit("PIZZA", SELL, pizza_bid, limiting)
        
#     if (dough_bid != None or sauce_bid != None or pizza_ask != None)and (pizza_ask < sauce_bid + dough_bid):
#         if (client.positions() == {}):
#             limiting = min(dough_top["bid_qty"], sauce_top["bid_qty"])
#         else:   
#             limiting = min(dough_top["bid_qty"], sauce_top["bid_qty"], 1000 - abs(client.positions()["PIZZA"]["position"]))
#         client.hit("SAUCE", SELL, sauce_bid, limiting)
#         client.hit("DOUGH", SELL, dough_bid, limiting)
#         client.hit("PIZZA", BUY, pizza_ask, limiting)
        
#     if (sauce_ask != None or dough_ask != None or calzone_bid != None)and (sauce_ask + dough_ask < calzone_bid):
#         if (client.positions() == {}):
#             limiting = min(dough_top["ask_qty"] / 2, sauce_top["ask_qty"])
#         else:
#             limiting = min(dough_top["ask_qty"] / 2, sauce_top["ask_qty"], 1000 - abs(client.positions()["DOUGH"]["position"]) / 2, 1000 - abs(client.positions()["SAUCE"]["position"])) 
#         client.hit("SAUCE", BUY, sauce_ask, limiting)
#         client.hit("DOUGH", BUY, dough_ask, 2 * limiting)
#         client.hit("CALZONE", SELL, calzone_bid, limiting)
        
#     if (dough_bid != None or sauce_bid != None or calzone_ask != None)and (calzone_ask < sauce_bid + dough_bid):
#         if (client.positions() == {}):
#             limiting = min(dough_top["bid_qty"] / 2, sauce_top["bid_qty"])
#         else:
#             limiting = min(dough_top["bid_qty"] / 2, sauce_top["bid_qty"], 1000 - abs(client.positions()["CALZONE"]["position"]))
#         client.hit("SAUCE", SELL, sauce_bid, limiting)
#         client.hit("DOUGH", SELL, dough_bid, 2 * limiting)
#         client.hit("CALZONE", BUY, calzone_ask, limiting)
    
    
    
    
    # client.hit("SAUCE", SELL, sauce_bid, 20)
    # client.hit("DOUGH", 
    
    # client.trades().groupby('').agg('
    
    if print_feed:
        print("Top Bid/Offer for SAUCE:")
        print(sauce_top)
        print("Top Bid/Offer for DOUGH:")
        print(dough_top)
        print("Top Bid/Offer for PIZZA:")
        print(pizza_top)
        print("Top Bid/Offer for CALZONE:")
        print(calzone_top)
    
    if print_positions:
        print()
        print("Positions:")
        print(client.positions())
    
    if plot_feed:
        plot_market_state(sauce_top)
        plot_market_state(dough_top)

        
client.run(trade_loop)