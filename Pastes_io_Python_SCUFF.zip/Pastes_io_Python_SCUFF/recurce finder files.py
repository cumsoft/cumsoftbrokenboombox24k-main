import os
import random

BASE_DIR = os.path.dirname(__file__)
TARGETS = ['mp4', 'avi', 'mov']
SAVE_DIR = '.__DATA__'
FILTERS = [SAVE_DIR]
IGNORE_DUPLICATE_FILES = True

if not os.path.exists(SAVE_DIR):
    os.mkdir(SAVE_DIR)


def check_file_in_filters(file_name: str):
    if file_name in FILTERS:
        return True
    return False


def copy_file(file: str, file_name: str):
    with open(file, mode='rb') as f_in, open(f'{BASE_DIR}\\{SAVE_DIR}\\{file_name}', mode='ab') as f_out:
        for line in f_in:
            f_out.write(line)


def get_file_extension(file_name: str):
    return file_name[file_name.rfind('.')+1:]


def search(path=BASE_DIR):
    try:
        if os.path.isdir(path):
            lst_dir = os.listdir(path)
        else:
            return
    except PermissionError as _:
        return

    for file_name in lst_dir:
        if check_file_in_filters(file_name):
            continue

        if os.path.isdir(f'{path}\\{file_name}'):
            search(f'{path}\\{file_name}')
        else:
            print(f'Checking file: {path}\\{file_name}')
            if get_file_extension(file_name) in TARGETS:

                if os.path.exists(f'{BASE_DIR}\\{SAVE_DIR}\\{file_name}'):
                    if IGNORE_DUPLICATE_FILES:
                        continue
                    else:
                        file_name = f'{file_name}_{str(random.random())}'

                print('Coping...')
                copy_file(f'{path}\\{file_name}', file_name)
                print(f'{path}\\{file_name} copied!')
            else:
                print('Not suitable!')


search()
print('Done.')