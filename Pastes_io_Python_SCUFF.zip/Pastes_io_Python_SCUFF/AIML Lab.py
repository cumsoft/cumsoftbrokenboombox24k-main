Q2.

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error

# Step a: Read and display top 10 samples of the dataset
data = pd.read_csv("insurance.csv")
print("Top 10 samples of the dataset:")
print(data.head(10))

# Step b: Display the features and label
print("\nFeatures (Independent variables):")
print(data.drop(columns=['charges']).columns.tolist())
print("\nLabel (Dependent variable):")
print("charges")

# Step c: Remove missing value samples
data.dropna(inplace=True)

# Step d: Normalize the feature set
scaler = MinMaxScaler()
data_normalized = data.copy()
data_normalized[data_normalized.columns[:-1]] = scaler.fit_transform(data_normalized[data_normalized.columns[:-1]])

# Step e: Split data into training and testing sets
X = data_normalized.drop(columns=['charges'])
y = data_normalized['charges']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Step f: Train the regression model using built-in library
model = LinearRegression()
model.fit(X_train, y_train)

# Evaluate the model with test data
y_pred = model.predict(X_test)
testing_error = mean_squared_error(y_test, y_pred)
print("\nTesting Error:", testing_error)



Q3.

import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix

# Step 1: Load the Iris dataset
iris = load_iris()
X = iris.data
y = iris.target

# Step 2: Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Step 3: Standardize features by removing the mean and scaling to unit variance
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Step 4: Train the Logistic Regression model
model = LogisticRegression()
model.fit(X_train_scaled, y_train)

# Step 5: Make predictions on the testing set
y_pred = model.predict(X_test_scaled)

# Step 6: Evaluate the model
accuracy = accuracy_score(y_test, y_pred)
print("Accuracy:", accuracy)

conf_matrix = confusion_matrix(y_test, y_pred)
print("Confusion Matrix:")
print(conf_matrix)

# Step 7: Visualize the decision boundaries (2D visualization for simplicity)
# We'll use only the first two features for visualization
X_train_2d = X_train_scaled[:, :2]

# Fit the model on only 2 features
model_2d = LogisticRegression()
model_2d.fit(X_train_2d, y_train)

# Plot decision boundaries
x_min, x_max = X_train_2d[:, 0].min() - 1, X_train_2d[:, 0].max() + 1
y_min, y_max = X_train_2d[:, 1].min() - 1, X_train_2d[:, 1].max() + 1
xx, yy = np.meshgrid(np.arange(x_min, x_max, 0.1), np.arange(y_min, y_max, 0.1))
Z = model_2d.predict(np.c_[xx.ravel(), yy.ravel()])
Z = Z.reshape(xx.shape)

plt.contourf(xx, yy, Z, alpha=0.4)
plt.scatter(X_train_2d[:, 0], X_train_2d[:, 1], c=y_train, marker='o', edgecolor='k')
plt.title('Logistic Regression Decision Boundaries (2D)')
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.show()