def merge(a, b, c):
    i = j = k = 0
    m = len(a)
    n = len(b)
    while i < m and j < n:
        if a[i] < b[j]:
            c[k] = a[i]
            i += 1
        else:
            c[k] = b[j]
            j += 1
        k += 1

    for num in a[i::]:
        c[k] = num
        k += 1
    for num in b[j::]:
        c[k] = num
        k += 1



def mergesort(arr):
    length = len(arr)
    if length > 1:
        middle = length // 2
        L = arr[:middle]
        R = arr[middle:]
        mergesort(L)
        mergesort(R)
        merge(L, R, arr)


arr = [12, 11, 13, 5, 6, 7]
       
mergesort(arr)

print(arr)