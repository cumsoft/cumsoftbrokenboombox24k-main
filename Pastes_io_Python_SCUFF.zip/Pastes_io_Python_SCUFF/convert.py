import os
import click
import csv


def __convert_to_anki_format(row):
    word, _, definition, sentence, _ = row
    cloze = f'{{{{c1::{word}::{definition}}}}}'
    return {
        'cloze': sentence.replace('_____', cloze),
        'word': word
    }


def __write_anki_file(filename, anki_cards):
    with open(filename, 'w', encoding='utf-8') as out_file:
        for card in anki_cards:
            cloze, word = card['cloze'], card['word']
            out_file.write(f'{cloze}\t{word}\n')       


@click.command()
@click.argument('csv_file', type=click.File('r', encoding='utf-8'))
def convert(csv_file):
    csv_data = csv.reader(csv_file)
    next(csv_data, None) # skip header

    anki_cards = []
    for row in csv_data:
        anki_cards.append(__convert_to_anki_format(row))
    
    filename = f'{os.path.splitext(csv_file.name)[0]}_anki.txt'
    __write_anki_file(filename, anki_cards)


if __name__ == '__main__':
    convert()