from time import sleep
from random import randint
print("TRANSACTION LOG")
l1 = [[], [], []]
while True:
    from datetime import datetime
    from datetime import date
    today = date.today()
    now = datetime.now()
    current_time = now.strftime("%H:%M:%S")
    print("Transaction took place at ", current_time , "," , today) 
    print('''=====================================================================================================================
Welcome to BestBank''')
    sleep(1.5)
    a = int(input('''1. Create an account
2. Manage existing account
'''))
    sleep(1)
    if a == 1:
        b = input("Kindly enter the name of the holder of the account:  ")
        sleep(1)
        l1[0].append(b)
        d = input('''Our privacy policy requires that every account has a PIN.
Kindly create a PIN with four characters
(Note that the PIN can have letters, numbers and symbols): 
''')
        sleep(1)
        while len(d) != 4:
            d = input('''Your PIN is not valid.
Kindly create a pin with four characters
''')
            sleep(1)
        l1[2].append(d)
        c = float(input('''Our policy requires you deposit an amount for the account to be activated.
Kindly enter the amount you wish to deposit(In GH₵):
'''))
        while c < 0:
            c = float(input('''The amount you entered is not a valid amount.
Kindly enter an amount you wish to deposit
'''))
            sleep(1)
        sleep(1)
        l = round(c, 2)
        l1[1].append(str(l))
        print('''Your account has been successfully created.
=====================================================================================================================       

''')
        sleep(1)
    elif a == 2:
        b = int(input('''Please select an action:
1. Withdraw money
2. Deposit money
3. Check balance
'''))
        sleep(1)
        if b == 1:
            c = input('''Kindly enter the name you used to register the account
(Note that it has to be the same name else the system will not recognize it)
''')
            sleep(1)
            while c not in l1[0]:
                m = int(input('''Name not found in our database
1. Change name
2. Exit
'''))
                if m == 1:
                    c = input('''Kindly enter the name you used to register the account
(Note that it has to be the same name else the system will not recognize it)
''')
                    sleep(1)
                elif m == 2:
                    print('''Redirecting
=====================================================================================================================
                    
                    ''')
                    sleep(1)
                    break
            for i in range(len(l1[0])):
                if l1[0][i] == c:
                    d = input('Enter your PIN: ')
                    sleep(1)
                    while l1[2][i] != d:
                        k = int(input('''Incorrect PIN. 
1. Try another PIN
2. Exit
'''))
                        sleep(1)
                        if k == 1:
                            d = input('Enter your PIN: ')
                            sleep(1)
                            continue
                        elif k == 2:
                            print('''Redirecting
=====================================================================================================================
                    
                    ''')
                            sleep(1)
                            break
                    if l1[2][i] == d:
                        e = float(input('Kindly enter the amount you wish to withdraw(In GH₵): '))
                        sleep(1)
                        if float(l1[1][i]) >= e:
                            f = float(l1[1][i]) - e
                            g = round(f, 2)
                            h = round(e, 2)
                            l1[1].pop(i)
                            l1[1].insert(i, str(g))
                            print('''Thank you for banking with us.
You withdrew GH₵ ''' + str(h) + ''' and the amount remaining is GH₵ ''' + str(g) + '''
=====================================================================================================================

''')
                    
                            sleep(1)
                        else:
                            print("Insufficient funds. You have GH₵ " + l1[1][i] + ''' in your account
=====================================================================================================================

''')
        elif b == 2:
            c = input('''Kindly enter the name you used to register the account
(Note that it has to be the same name else the system will not recognize it)
''')
            sleep(1)
            while c not in l1[0]:
                m = int(input('''Name not found in our database
1. Change name
2. Exit
'''))
                if m == 1:
                    c = input('''Kindly enter the name you used to register the account
(Note that it has to be the same name else the system will not recognize it)
''')
                    sleep(1)
                elif m == 2:
                    print('''Redirecting
=====================================================================================================================
                    
                    ''')
                    sleep(1)
                    break
            for i in range(len(l1[0])): 
                if l1[0][i] == c:
                    d = input('Enter your PIN: ')
                    sleep(1)
                    while l1[2][i] != str(d):
                        k = int(input('''Incorrect PIN. 
1. Try another PIN
2. Exit
'''))
                        sleep(1)
                        if k == 1:
                            d = input('Enter your PIN: ')
                            sleep(1)
                            continue
                        elif k == 2:
                            print('''Redirecting
=====================================================================================================================
                    
                    ''')
                            sleep(1)
                            break
                    if l1[2][i] == str(d):
                        e = float(input('Kindly enter the amount you wish to deposit(In GH₵): '))
                        sleep(1)
                        f = float(l1[1][i]) + e
                        g = round(f, 2)
                        h = round(e, 2)
                        l1[1].pop(i)
                        l1[1].insert(i, str(g))
                        print('''Thank you for banking with us.
You deposited GH₵ ''' + str(h) + ''' and the amount is now GH₵ ''' + str(g) + '''
=====================================================================================================================

''')
        elif b == 3:
            c = input('''Kindly enter the name you used to register the account
(Note that it has to be the same name else the system will not recognize it)
''')
            sleep(1)
            while c not in l1[0]:
                m = int(input('''Name not found in our database
1. Change name
2. Exit
'''))
                if m == 1:
                    c = input('''Kindly enter the name you used to register the account
(Note that it has to be the same name else the system will not recognize it)
''')
                    sleep(1)
                elif m == 2:
                    print('''Redirecting
=====================================================================================================================
                    
                    ''')
                    sleep(1)
                    break
            for i in range(len(l1[0])): 
                if l1[0][i] == c:
                    d = input('Enter your PIN: ')
                    sleep(1)
                    while l1[2][i] != str(d):
                            k = int(input('''Incorrect PIN. 
1. Try another PIN
2. Exit
'''))
                            sleep(1)
                            if k == 1:
                                d = input('Enter your PIN: ')
                                sleep(1)
                                continue
                            elif k == 2:
                                print('''Redirecting
=====================================================================================================================
                    
                    ''')
                            sleep(1)
                            break
                    if l1[2][i] == str(d):
                        y = randint(10000000, 99999999)  
                        print('''
--------------------------------------------------------------------------------------------
RECEIPT ID: ''' + str(y) + '''
NAME OF ACCOUNT HOLDER: ''' + l1[0][i] + '''
Your account balance is GH₵''' + l1[1][i] + '''
--------------------------------------------------------------------------------------------

''')
        else:
            print('''Unrecognized action
            
''')
            continue
    else:
        print('''Unrecognized action
        
''')
        continue