from pymongo import MongoClient

# Create a client to connect to MongoDB
client = MongoClient('localhost', 27017)

# Connect to a database
db = client['sample_database']

# Connect to a collection
collection = db['sample_collection']

# Insert multiple documents into the collection
data = [
    {"name": "John", "age": 30, "city": "New York"},
    {"name": "Jane", "age": 25, "city": "Boston"},
    {"name": "Doe", "age": 28, "city": "Chicago"},
    {"name": "Anna", "age": 22, "city": "New York"}
]
collection.insert_many(data)

# Query examples:

# 1. Retrieve all documents
print("\nAll Documents:")
for item in collection.find():
    print(item)

# 2. Retrieve a single document
print("\nSingle Document:")
single_doc = collection.find_one({"name": "John"})
print(single_doc)

# 3. Retrieve documents with conditions
print("\nDocuments with age > 25:")
for item in collection.find({"age": {"$gt": 25}}):
    print(item)

# 4. Retrieve documents with specific fields
print("\nDocuments with only name and age fields:")
for item in collection.find({}, {"_id": 0, "name": 1, "age": 1}):
    print(item)

# 5. Sort documents (1 for ascending, -1 for descending)
print("\nDocuments sorted by age in ascending order:")
for item in collection.find().sort("age", 1):
    print(item)

# 6. Limit the number of returned documents
print("\nLimit to 2 documents:")
for item in collection.find().limit(2):
    print(item)

# 7. Count documents
count = collection.count_documents({"city": "New York"})
print(f"\nNumber of people from New York: {count}")

# Cleanup: Drop the sample collection to not leave test data
db.drop_collection('sample_collection')

# Close the connection
client.close()