import requests


def fetch(uid, limit):
    hehe = []
    api = "https://www.iesdouyin.com/web/api/v2/aweme/post/?aid=1128&_signature=PDHVOQAAXMfFyj02QEpGaDwx1S&dytk=&count=30&max_cursor=0&sec_uid="+uid
    
    while True:
        res = requests.get(api, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36", "Referer": "https://www.douyin.com/", "Cookie": ""}).json()
        videos = res["aweme_list"]
        
        for video in videos:
            aweme_id = video["aweme_id"]
            caption = video["desc"]
            print(aweme_id)
            if len(hehe) < limit:
                hehe.append(aweme_id)
        
        more = res["has_more"]
        if not more or len(hehe) >= limit:
            break
        cursor = res["max_cursor"]
        api = api + "&cursor=" + str(cursor)
    
    print(len(hehe))


uid = "MS4wLjABAAAACirq2YgCDHFt4JJLwl1l5Hj4WpThkGSm8uKQJY7a2hU"

fetch(uid, 50)