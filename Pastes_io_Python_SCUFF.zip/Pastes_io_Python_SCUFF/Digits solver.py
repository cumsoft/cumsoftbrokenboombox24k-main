def find_expression(numbers, target):
    operations = ['+', '-', '*', '/']
    def helper(numbers, target, expression):
        if len(numbers) == 1:
            if numbers[0] == target:
                return expression + ' = ' + str(target)
            else:
                return None
        for i in range(len(numbers)):
            for j in range(i+1, len(numbers)):
                for op in operations:
                    if op == '/' and numbers[j] == 0:
                        continue # skip division by zero
                    if op == '-' and numbers[i] < numbers[j]:
                        continue # skip negative results
                    if op == '/' and numbers[i] % numbers[j] != 0:
                        continue # skip non-whole division
                    new_numbers = numbers[:i] + [eval(str(numbers[i])+op+str(numbers[j]))] + numbers[j+1:]
                    new_expression = '(' + str(numbers[i]) + ' ' + op + ' ' + str(numbers[j]) + ')'
                    result = helper(new_numbers, target, expression + ' ' + new_expression)
                    if result:
                        return result
        return None
    return helper(numbers, target, '')




numbers = [3,5,7,13,20,25]
target = 495
result = find_expression(numbers, target)
if result:
    print(result)
else:
    print('No expression found')