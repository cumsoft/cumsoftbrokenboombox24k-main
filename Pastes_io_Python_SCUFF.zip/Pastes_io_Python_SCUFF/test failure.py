pytest tests/server/ -vv
=================================================================================================================================== test session starts ===================================================================================================================================
platform linux -- Python 3.10.6, pytest-7.2.0, pluggy-1.0.0 -- /home/keceli/venvs/balsam/bin/python
cachedir: .pytest_cache
rootdir: /home/keceli/soft/keceli_balsam, configfile: setup.cfg
plugins: cov-4.0.0, mock-3.10.0, anyio-3.6.2
collected 66 items                                                                                                                                                                                                                                                                        

tests/server/test_apps.py::test_created_app_in_list_view PASSED                                                                                                                                                                                                                     [  1%]
tests/server/test_apps.py::test_filter_apps_by_site PASSED                                                                                                                                                                                                                          [  3%]
tests/server/test_apps.py::test_cannot_create_duplicate PASSED                                                                                                                                                                                                                      [  4%]
tests/server/test_apps.py::test_cannot_update_duplicate PASSED                                                                                                                                                                                                                      [  6%]
tests/server/test_apps.py::test_delete_app PASSED                                                                                                                                                                                                                                   [  7%]
tests/server/test_apps.py::test_no_shared_app PASSED                                                                                                                                                                                                                                [  9%]
tests/server/test_apps.py::test_cannot_add_app_to_other_user_site PASSED                                                                                                                                                                                                            [ 10%]
tests/server/test_auth.py::test_unauth_user_cannot_view_sites PASSED                                                                                                                                                                                                                [ 12%]
tests/server/test_auth.py::test_register PASSED                                                                                                                                                                                                                                     [ 13%]
tests/server/test_auth.py::test_auth_user_can_view_sites PASSED                                                                                                                                                                                                                     [ 15%]
tests/server/test_batchjobs.py::test_can_create_batchjob PASSED                                                                                                                                                                                                                     [ 16%]
tests/server/test_batchjobs.py::test_list_batchjobs_spanning_sites PASSED                                                                                                                                                                                                           [ 18%]
tests/server/test_batchjobs.py::test_filter_by_site PASSED                                                                                                                                                                                                                          [ 19%]
tests/server/test_batchjobs.py::test_filter_by_time_range PASSED                                                                                                                                                                                                                    [ 21%]
tests/server/test_batchjobs.py::test_json_tags_filter_list PASSED                                                                                                                                                                                                                   [ 22%]
tests/server/test_batchjobs.py::test_detail_view PASSED                                                                                                                                                                                                                             [ 24%]
tests/server/test_batchjobs.py::test_update_to_invalid_state PASSED                                                                                                                                                                                                                 [ 25%]
tests/server/test_batchjobs.py::test_update_valid PASSED                                                                                                                                                                                                                            [ 27%]
tests/server/test_batchjobs.py::test_bulk_status_update_batch_jobs PASSED                                                                                                                                                                                                           [ 28%]
tests/server/test_batchjobs.py::test_delete_running_batchjob PASSED                                                                                                                                                                                                                 [ 30%]
tests/server/test_batchjobs.py::test_delete_api_endpoint PASSED                                                                                                                                                                                                                     [ 31%]
tests/server/test_batchjobs.py::test_no_shared_batchjobs_in_list_view PASSED                                                                                                                                                                                                        [ 33%]
tests/server/test_batchjobs.py::test_permission_in_detail_view PASSED                                                                                                                                                                                                               [ 34%]
tests/server/test_batchjobs.py::test_bulk_update_cannot_affect_other_users_batchjobs PASSED                                                                                                                                                                                         [ 36%]
tests/server/test_jobs.py::test_add_jobs PASSED                                                                                                                                                                                                                                     [ 37%]
tests/server/test_jobs.py::test_child_with_two_parents_state_update PASSED                                                                                                                                                                                                          [ 39%]
tests/server/test_jobs.py::test_parent_with_two_children_state_update PASSED                                                                                                                                                                                                        [ 40%]
tests/server/test_jobs.py::test_add_job_without_transfers_is_STAGED_IN PASSED                                                                                                                                                                                                       [ 42%]
tests/server/test_jobs.py::test_bulk_put PASSED                                                                                                                                                                                                                                     [ 43%]
tests/server/test_jobs.py::test_bulk_patch PASSED                                                                                                                                                                                                                                   [ 45%]
tests/server/test_jobs.py::test_acquire_for_launch PASSED                                                                                                                                                                                                                           [ 46%]
tests/server/test_jobs.py::test_update_to_running_does_not_release_lock FAILED                                                                                                                                                                                                      [ 48%]

======================================================================================================================================== FAILURES =========================================================================================================================================
______________________________________________________________________________________________________________________ test_update_to_running_does_not_release_lock _______________________________________________________________________________________________________________________

auth_client = <tests.server.util.BalsamTestClient object at 0x7f07c3daf6a0>, job_dict = <function job_dict.<locals>._job_dict at 0x7f07c3dcfa30>, create_session = <function create_session.<locals>._create_session at 0x7f07c3dcc820>
db_session = <sqlalchemy.orm.session.Session object at 0x7f07c3daf220>

    def test_update_to_running_does_not_release_lock(auth_client, job_dict, create_session, db_session):
        jobs = auth_client.bulk_post("/jobs/", [job_dict(transfers={}) for _ in range(10)])
    
        # Mark jobs PREPROCESSED
        ids = [j["id"] for j in jobs]
        app_ids = {jobs[0]["app_id"]}
        auth_client.bulk_put("/jobs/", {"state": "PREPROCESSED"}, id=ids)
    
        session = create_session()
        # Launcher1 acquires all of them
        acquired = auth_client.post(
            f"/sessions/{session.id}",
            max_wall_time_min=120,
            filter_tags={},
            max_num_jobs=100,
            max_nodes_per_job=32,
            app_ids=app_ids,
            check=status.HTTP_200_OK,
        )
    
        # Behind the scenes, the acquired jobs are locked:
        all_jobs = db_session.query(models.Job).all()
        print(f"there are {len(all_jobs)} total jobs having sess ids of:", set(j.session_id for j in all_jobs))
        for job in db_session.query(models.Job).all():
>           assert job.session_id == session.id
E           assert None == 191
E            +  where None = <balsam.server.models.tables.Job object at 0x7f07c3c369e0>.session_id
E            +  and   191 = <balsam.server.models.tables.Session object at 0x7f07c3c06b30>.id

tests/server/test_jobs.py:298: AssertionError
---------------------------------------------------------------------------------------------------------------------------------- Captured stdout setup ----------------------------------------------------------------------------------------------------------------------------------
user_from_token has identified the user: user33e16e9b-e058-451d-9764-cced49456740
user_from_token has identified the user: user33e16e9b-e058-451d-9764-cced49456740
---------------------------------------------------------------------------------------------------------------------------------- Captured stderr setup ----------------------------------------------------------------------------------------------------------------------------------
2022-12-19 14:57:32.899 | 797473 | INFO | balsam.server.utils.timer:47] TIMER: balsam.server.auth.password_login.login Wall: 0.185464 CPU: 0.185249
2022-12-19 14:57:32.913 | 797473 | INFO | balsam.server.utils.timer:47] TIMER: balsam.server.routers.sites.create Wall: 0.012096 CPU: 0.003493
2022-12-19 14:57:32.921 | 797473 | INFO | balsam.server.utils.timer:47] TIMER: balsam.server.routers.apps.create Wall: 0.005533 CPU: 0.003702
----------------------------------------------------------------------------------------------------------------------------------- Captured log setup ------------------------------------------------------------------------------------------------------------------------------------
INFO     balsam.server.utils.timer:timer.py:47 TIMER: balsam.server.auth.password_login.login Wall: 0.185464 CPU: 0.185249
INFO     balsam.server.utils.timer:timer.py:47 TIMER: balsam.server.routers.sites.create Wall: 0.012096 CPU: 0.003493
INFO     balsam.server.utils.timer:timer.py:47 TIMER: balsam.server.routers.apps.create Wall: 0.005533 CPU: 0.003702
---------------------------------------------------------------------------------------------------------------------------------- Captured stdout call -----------------------------------------------------------------------------------------------------------------------------------
user_from_token has identified the user: user33e16e9b-e058-451d-9764-cced49456740
user_from_token has identified the user: user33e16e9b-e058-451d-9764-cced49456740
user_from_token has identified the user: user33e16e9b-e058-451d-9764-cced49456740
there are 13 total jobs having sess ids of: {None, 191}
---------------------------------------------------------------------------------------------------------------------------------- Captured stderr call -----------------------------------------------------------------------------------------------------------------------------------
2022-12-19 14:57:32.932 | 797473 | INFO | balsam.server.utils.timer:47] TIMER: balsam.server.routers.jobs.bulk_create Wall: 0.006843 CPU: 0.004425
2022-12-19 14:57:32.942 | 797473 | INFO | balsam.server.utils.timer:47] TIMER: balsam.server.routers.jobs.query_update Wall: 0.007079 CPU: 0.002760
2022-12-19 14:57:32.952 | 797473 | INFO | balsam.server.utils.timer:47] TIMER: balsam.server.routers.sessions.acquire Wall: 0.005148 CPU: 0.002930
------------------------------------------------------------------------------------------------------------------------------------ Captured log call ------------------------------------------------------------------------------------------------------------------------------------
INFO     balsam.server.utils.timer:timer.py:47 TIMER: balsam.server.routers.jobs.bulk_create Wall: 0.006843 CPU: 0.004425
INFO     balsam.server.utils.timer:timer.py:47 TIMER: balsam.server.routers.jobs.query_update Wall: 0.007079 CPU: 0.002760
INFO     balsam.server.utils.timer:timer.py:47 TIMER: balsam.server.routers.sessions.acquire Wall: 0.005148 CPU: 0.002930
================================================================================================================================= short test summary info =================================================================================================================================
FAILED tests/server/test_jobs.py::test_update_to_running_does_not_release_lock - assert None == 191
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
============================================================================================================================== 1 failed, 31 passed in 15.63s ==============================================================================================================================