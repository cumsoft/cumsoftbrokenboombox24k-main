# track each digits and display duplicates in the next iterations

import time

num = 1 # starting number

def func(x):
    return x*2 # multiplying number

delay = 0.05
digits = 40

digit_arr = [' ']*digits

while True:
    num_str = f'{num:{digits}d}'

    result_str = ''
    for i, c in enumerate(num_str):
        if digit_arr[i] == c:
            result_str += c #'█'
        else:
            result_str += ' '
            digit_arr[i] = c
    
    print(result_str+'|')

    num = func(num)
    num %= 10**digits

    time.sleep(delay)