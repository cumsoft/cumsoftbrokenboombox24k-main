#Szyfrowanie
a=input("podaj napis do zaszyfrowania(szyfr cezara)")
napis=""
for x in a.lower():
    if ord(x)<=118:
        napis=napis+chr(ord(x)+4)
    if ord(x)>118:
        napis=napis+chr(ord(x)-(122-96)+4)
print(napis)
# Deszyfrowanie
b=input("podaj napisz do deszyfrowania(szyfr cezara)")
napis=""
for x in b.lower():
    if ord(x)>100:
        napis=napis+chr(ord(x)-4)
    if ord(x)<=100:
        napis=napis+chr(ord(x)+26-4)
print(napis)