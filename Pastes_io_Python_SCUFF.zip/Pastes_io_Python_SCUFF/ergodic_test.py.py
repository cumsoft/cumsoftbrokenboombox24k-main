#!/usr/bin/python

#
#   Inspired by:    https://ergodicityeconomics.com/2023/07/28/the-infamous-coin-toss/
#   September 23, 2023
#

from    __future__  import  print_function


import random
import sys


C_note      = 100.0                     # the $$$s we start each run with - from our hypothetical, imaginary, deep-pocket banker, I guess


def do_run(n) :
    m       = C_note                    # give the us a C note to start. It probably came from the government. They don't break legs if they are not paid back.
    pt      = 1.0                       # what chunk of our dough we will bet the next flip
    for i  in range(n) :
        bm  = m * pt                    # how much of dough we will bet, this flip
        if random.random() >= 0.5 :     # flip a coin
            m  += bm * .5               # we win
            pt  = 1.0                   # yeah, next flip, put it all on the line. We're ***, baby, ***!
        else    :
            m  -= bm * .4               # dang, take us down to 60% of dough we put on the line - which, biggest-case, is less money than we could have won, but worse than the inverse of what we win, per flip
            pt  = 0.125                 # note: bet only this chunk of our money next flip - the smaller the number, the harder it is for us to go bust, but the harder it is for us to break the bank
        if  m < 0.005  :                # note: make this half-cent amount negative to never go bust completely
            return(0.0)
        pass
    return(m)


def do_lotsa_runs(c, fc) :
    t       = 0.0                       # what our money situation is, over all.
    zc      = 0                         # how many times we went "bankrupt"
    nc      = 0                         # how many plays we started in the hole - in hock and needing to borrow another 100 bucks
    for i  in range(c)  :
        if  t   < 0.0   :
            nc += 1                     # bump how many times our super-player was starting a run while over-all losing
        r   = do_run(fc)
        t  -= C_note                    # take the C note out of our wallet
        t  += r                         # but add in what we ended up with on the table
        if  r   < 0.005 :               # did this run leave that C note to less than a rounded penny? (we don't look for zero here because do_run() may or may not tap out at under a rounded penny)
            zc += 1                     #   then keep the "bankrupty" count going
        # print("%6u %12.2f %14.2f" % ( i + 1, r, t, ))
    return(t, zc, nc)


if  __name__ == '__main__' :
    c   = 10000                         # how many runs to do
    fc  =   850                         # how many coins to flip per run
    if  len(sys.argv) > 1 :
        c   = int(sys.argv[1])
    if  len(sys.argv) > 2 :
        fc  = int(sys.argv[2])

    t, zc, nc   = do_lotsa_runs(c, fc)
    print("Total $%.2f,   $%.2f per run with %u bankruptcies and %u in-hock runs" % ( t, t / c, zc, nc, ))


# eof