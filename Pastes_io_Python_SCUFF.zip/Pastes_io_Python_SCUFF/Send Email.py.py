import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
 
_from = ""
_to = ""
_password = r""
 
msg = MIMEMultipart("alternative")
msg["Subject"] = "Assunto"
msg["From"]= _from
msg["To"] = _to
 
html = "<html><body><p>Hello World!</p></body></html>"
html_parsing = MIMEText(html, "html")
msg.attach(html_parsing)
 
s = smtplib.SMTP_SSL("host")
# s.set_debuglevel(1)
s.login(_from, _password)
s.sendmail(_from, _to, msg.as_string())
s.quit()