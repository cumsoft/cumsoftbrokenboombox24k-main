#### Exemplo 1
#### Classe simples apenas com a operação
#### isso aqui poderia ter mais atributos e até mais metodos
#### como é uma boa pratica nao manter a conexão aberta e usar apenas durante alguma operação,
#### usar with - as é algo bem util, pois abre e fecha a conexão pra vc automaticamente
#### o retorno False quando a operação não funciona também pode ajudar muito

import sqlalchemy as db
import pandas as pd

class Db:
    def __init__(self, dialect:str, driver:str, user:str, password:str, host:str, port:(str or int), base_name:str) -> None:
        self.eng = db.create_engine(f'{dialect}+{driver}://{user}:{password}@{host}:{port}/{base_name}').connect()


    def _select(self, table_name:str, fields:str='*', conditions:str='') -> pd.DataFrame:
        with self.eng.connect() as conn:
            ResultProxy = conn.execute(f"select {fields} from {table_name} where D_E_L_E_T_='' {f'AND {conditions}' if conditions != '' else ''}")
            return ResultProxy.fetchall()


#### Exemplo 2
#### embora não siga a boa pratica de conexão que comentei,  tem coisas interessantes, como esses decoradores
#### que, contratualmente, são a forma mais correta de acessarem os atributos fora da classe
import sqlalchemy as sql

class Db:
    def __init__(self, dialect:str, driver:str, user:str, password:str, host:str, port:(str or int), base:str):
        """This class is used to connect to the database and execute queries.
        """
        self._source:str = f'{dialect}+{driver}://{user}:{password}@{host}:{port}/{base}'
        self._eng:sql = sql.create_engine(self._source)
        self._conn:sql = self._connect()


    @property
    def eng(self) -> sql:
        """This method is used to return the engine.

        Returns:
            sql: The engine.
        """
        return self._eng


    @property
    def conn(self) -> sql:
        """This method is used to return the connection.

        Returns:
            sql: The connection.
        """
        return self._conn


    def _connect(self) -> (bool or sql):
        """This method is used to connect to the database.
        Returns False if the connection fails.

        Returns:
            bool or sql: The connection.
        """
        try:
            return self._eng.connect()
        except Exception as e:
            print(e)
            return False
            
### Exemplo 3
### estará incompleto pois contém trechos de codigos sensíveis a empresa (como requisições)
#### aqui sinto falta de passagem de parametros pro banco

import sqlalchemy as db

from datetime import datetime, timedelta

class Db:
    def __init__(self):
        self.source:str = ''
        self.conn = self._connect()
        self.start_date:datetime.datetime
        self.end_date:datetime.datetime = datetime.now()
        self.query:str = ''
        self.res:object = ''


    def _connect(self):
        print(f' [{datetime.now()}] >> Conectando com o banco')
        try:
            eng = db.create_engine(self.source)
            print(f' [{datetime.now()}] >>> Conectado com sucesso')
            return eng.connect()
        except Exception as e:
            print(f' [{datetime.now()}] >>> {e}')


    def execute_query(self):
        pass


    def get_res(self):
        return self.res