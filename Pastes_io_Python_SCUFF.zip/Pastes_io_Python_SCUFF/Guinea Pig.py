amount_of_food = float(input()) * 1000
amount_of_hay = float(input()) * 1000
amount_of_cover = float(input()) * 1000
weight_of_pigs = float(input()) * 1000
consumables = True
days = 30

while True:
    days -= 1
    amount_of_food -= 300
    if amount_of_food <= 0:
        consumables = False
        break
    if days % 2 == 0:
        amount_of_hay -= amount_of_food * 0.05
        if amount_of_hay <= 0:
            consumables = False
            break
    if days % 3 == 0:
        amount_of_cover -= weight_of_pigs / 3
        if amount_of_cover <= 0:
            consumables = False
            break
    if days == 0:
        break

if not consumables:
    print("Merry must go to the pet store!")
else:
    print(f"Everything is fine! Puppy is happy! Food: {amount_of_food / 1000:.2f}, Hay: {amount_of_hay / 1000:.2f}, Cover: {amount_of_cover / 1000:.2f}.")