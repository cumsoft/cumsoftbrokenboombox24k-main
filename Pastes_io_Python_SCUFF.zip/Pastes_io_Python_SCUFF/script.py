import time
from qbittorrentapi import Client, APIConnectionError

processed_torrents = set()

def resume_torrent(client, torrent):
    torrent_name = torrent['name']
    torrent_hash = torrent['hash']
    print(f"Resuming torrent: {torrent_name} (Hash: {torrent_hash})")
    client.torrents_resume(torrent_hashes=[torrent_hash])

def monitor_qbittorrent():
    qbittorrent_url = 'http://localhost:12345/'  # Change this to your qBittorrent Web UI URL
    qbittorrent_username = 'hello'  # Change this to your qBittorrent username
    qbittorrent_password = 'hello1234'  # Change this to your qBittorrent password

    while True:
        try:
            client = Client(host=qbittorrent_url, username=qbittorrent_username, password=qbittorrent_password)
            torrents = client.torrents.info()
            for torrent in torrents:
                if 'bhdauto' in torrent['tags'] and torrent['hash'] not in processed_torrents:
                    time.sleep(30)  # Wait for 30 seconds
                    resume_torrent(client, torrent)
                    processed_torrents.add(torrent['hash'])

            time.sleep(5)  # Adjust the interval as needed

        except APIConnectionError as e:
            # Handle 403 error (login failure)
            print(f"Failed to connect to qBittorrent API: {e}")
            print("Retrying in 10 seconds...")
            time.sleep(10)

if __name__ == "__main__":
    monitor_qbittorrent()