import random
import math

# Generate a random 4-digit number and label it as "MICHAEL"
MICHAEL = random.randint(1000, 9999)

# Calculate the sum of all digits in MICHAEL
digit_sum = sum(int(digit) for digit in str(MICHAEL))

# Calculate the square root of MICHAEL
sqrt_MICHAEL = math.sqrt(MICHAEL)

# Calculate RALF
RALF = digit_sum / sqrt_MICHAEL

# Calculate JAKE
JAKE = sqrt_MICHAEL / digit_sum

# Calculate the product of RALF and JAKE
result = RALF * JAKE

# Display the values and result
print("MICHAEL:", MICHAEL)
print("Sum of digits in MICHAEL:", digit_sum)
print("Square root of MICHAEL:", sqrt_MICHAEL)
print("RALF:", RALF)
print("JAKE:", JAKE)
print("RALF * JAKE:", result)