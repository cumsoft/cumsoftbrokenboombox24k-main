class SegmentTree:
    def __init__(self, L, R):
        self.left = None
        self.right = None
        self.val = 0
        self.L = L
        self.R = R
    
    def build(L, R):
        if L == R:
            return SegmentTree(L, R)
        
        M = (L + R) // 2
        root = SegmentTree(L, R)
        root.left = SegmentTree.build(L, M)
        root.right = SegmentTree.build(M + 1, R)

        return root
    
    def update(self, action, L, R):
        if L == self.L and R == self.R:
            if action == 'add':
                self.val += 1
            elif action == 'remove':
                self.val -= 1
            return
        
        M = (self.L + self.R) // 2
        if L > M:
            self.right.update(action, L, R)
        elif R <= M:
            self.left.update(action, L, R)
        else:
            self.left.update(action, L, M)
            self.right.update(action, M + 1, R)

        self.val = max(self.left.val, self.right.val)



def countMaxIntersectingRectangles(rectangles): 
    segments = []
    x1Min, x2Max = float('inf'), float('-inf')

    for rectangle in rectangles:
        x1, y1, x2, y2 = rectangle
        opening_segment = (y1, x1, x2, 'open')
        closing_segment = (y2, x1, x2, 'close')
        x1Min = min(x1Min, x1)
        x2Max = max(x2Max, x2)
        segments.append(opening_segment)
        segments.append(closing_segment)
    
    segments.sort()
    segmentTree = SegmentTree.build(x1Min, x2Max)

    maxIntersecting = float('-inf')

    for segment in segments: 
        y, x1, x2, event = segment
        if event == 'open':
            segmentTree.update('add', x1, x2)
            maxIntersecting = max(maxIntersecting, segmentTree.val)
        else:
            segmentTree.update('remove', x1, x2)
    return maxIntersecting


# 3 intersecting
rectangles = [[1,1,4,5], [-2,-1,3,3], [1,2,2,3], [-5,1,-4,2]]

max = countMaxIntersectingRectangles(rectangles)
print(max)