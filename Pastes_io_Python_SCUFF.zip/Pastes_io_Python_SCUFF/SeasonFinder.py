def get_season(month, day):
    # Dictionary mapping month to (start_day, end_day) for each season
    seasons = {
        'Spring': ('March', 20, 'June', 20),
        'Summer': ('June', 21, 'September', 21),
        'Autumn': ('September', 22, 'December', 20),
        'Winter': ('December', 21, 'March', 19)
    }
    
    # List of months for validation
    months = ['January', 'February', 'March', 'April', 'May', 'June', 
              'July', 'August', 'September', 'October', 'November', 'December']
    
    # Days in each month for validation
    days_in_month = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    
    # Check if the input month is valid
    if month not in months:
        return 'Invalid'
    
    # Check if the input day is valid
    month_index = months.index(month)
    if day < 1 or day > days_in_month[month_index]:
        return 'Invalid'
    
    # Function to check if the date is within a season's range
    def in_season(start_month, start_day, end_month, end_day):
        start_index = months.index(start_month)
        end_index = months.index(end_month)
        if start_index <= month_index <= end_index:
            if (month == start_month and day >= start_day) or (month == end_month and day <= end_day):
                return True
            elif start_month != end_month and start_index < month_index < end_index:
                return True
        return False
    
    # Determine the season
    for season, (start_month, start_day, end_month, end_day) in seasons.items():
        if in_season(start_month, start_day, end_month, end_day):
            return season
    
    # If date is not in any season range, it must be Winter
    return 'Winter'

# usage:
month = input('Enter the month: ')
try:
    day = int(input('Enter the day: '))
    print(get_season(month, day))
except ValueError:
    print('Invalid')