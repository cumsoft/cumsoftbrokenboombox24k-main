import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler, LabelEncoder
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error

# Step a: Read and display top 10 samples of the dataset
data = pd.read_csv("insurance.csv")
print("Top 10 samples of the dataset:")
print(data.head(10))

# Step b: Display the features and label
print("\nFeatures (Independent variables):")
print(data.drop(columns=['charges']).columns.tolist())
print("\nLabel (Dependent variable):")
print("charges")

# Step c: Remove missing value samples from the dataset if any
data.dropna(inplace=True)

# Step d: Encode categorical columns and normalize the feature set
categorical_columns = ['***', 'smoker', 'region']
numeric_columns = data.select_dtypes(include=[np.number]).columns

# Label encode categorical columns
label_encoders = {}
for col in categorical_columns:
    label_encoders[col] = LabelEncoder()
    data[col] = label_encoders[col].fit_transform(data[col])

# Normalize the feature set
scaler = MinMaxScaler()
data[numeric_columns] = scaler.fit_transform(data[numeric_columns])

# Step e: Randomly select 80% of the total samples for training and remaining for testing
X = data.drop(columns=['charges'])
y = data['charges']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Step f: Train the regression model using built-in library
model = LinearRegression()
model.fit(X_train, y_train)

# Evaluate the model with test data
y_pred = model.predict(X_test)
testing_error = mean_squared_error(y_test, y_pred)
print("\nTesting Error:", testing_error)