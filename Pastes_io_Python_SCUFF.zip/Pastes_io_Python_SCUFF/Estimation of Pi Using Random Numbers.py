import random
import matplotlib.pyplot as plt


def estimate_pi(n):
    
    num_point_circle = 0
    num_point_total = 0
    num_point_outside = 0
    
    plt.figure(figsize=(10,10))
    
    for _ in range(n):
        x = random.uniform(-1,1)
        y = random.uniform(-1,1)
        distance = x**2 + y**2
        if distance <= 1:
            num_point_circle += 1
            plt.scatter(x, y, color='b')
        else:
            num_point_outside += 1
            plt.scatter(x,y, color='r')
        num_point_total += 1
        
    circle = plt.Circle((0, 0), 1,fill=False)
    plt.gca().add_patch(circle)
    plt.show()
        
    return 4 * num_point_circle/num_point_total


print(estimate_pi(1000))