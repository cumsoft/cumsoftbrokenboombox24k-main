response = openai.ChatCompletion.create(
            model="gpt-4-0613",
            messages=[
                {"role": "system", "content": "You are a state-of-the-art intelligence agency people profiler AI (in short: IAPPAI). You read content written and posted by an individual on the internet and then you analyze that individual's personality based on their submitted content."},
                {"role": "user", "content": f"please analyse this person by their tweets and save the analysis. {texts_combined}"},
            ],
            functions=[
                {
                    "name": "save_analysis",
                    "description": "saves the current analysis",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "error": {
                                "type": "string",
                                "description": "error message if there is an error. empty string if there is no error.",
                            },
                            "analysis": {
                                "type": "string",
                                "description": "result of the analysis on the person's character and personality. 500 words or less.",
                            },
                            "obvious_biases": {
                                "type": "string",
                                "description": "obvious biases that the person has.",
                            },
                            "peculiarities": {
                                "type": "string",
                                "description": "peculiarities that the person has.",
                            },
                            "predicted_political_affiliation": {
                                "type": "string",
                                "description": "predicted political affiliation of the person. Affiliation name only or empty string if there is no prediction",
                            },
                            "predicted_religious_affiliation": {
                                "type": "string",
                                "description": "predicted religious affiliation of the person. Religion name only empty string if there is no prediction.",
                            },
                            "criticisms": {
                                "type": "array",
                                "items": {
                                    "type": "string",
                                    "description": "a criticism of the person's character or behavior.",
                                },
                            },
                            "interests": {
                                "type": "array",
                                "items": {
                                    "type": "string",
                                    "description": "a subject of interest for this person.",
                                },
                            },
                            "known_personal_facts": {
                                "type": "array",
                                "items": {
                                    "type": "string",
                                    "description": "a fact about this person.",
                                },
                            },
                            "occupations": {
                                "type": "array",
                                "items": {
                                    "type": "string",
                                    "description": "an activity that could be considered an occupation in which this individual partakes in.",
                                },
                            },
                        },
                        "required": ["error", "analysis", "obvious_biases", "peculiarities", "predicted_political_affiliation", 
                                    "predicted_religious_affiliation", "criticisms", 
                                    "interests", "known_personal_facts"],
                    },
                },
            ],
        )