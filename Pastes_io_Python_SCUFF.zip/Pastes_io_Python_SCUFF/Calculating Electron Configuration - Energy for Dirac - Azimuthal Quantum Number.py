import openpyxl
from openpyxl.styles import Alignment

class ElectronConfigurationCalculator:
    def __init__(self):
        self.periodic_table = {
            'H': {'atomic_number': 1, 'atomic_mass': 1.008},
            'He': {'atomic_number': 2, 'atomic_mass': 4.0026},
            'Li': {'atomic_number': 3, 'atomic_mass': 6.94},
            'Be': {'atomic_number': 4, 'atomic_mass': 9.0122},
            # ... continue with the rest of the elements
        }
        self.output_filename = "electron_configurations.xlsx"

    def calculate_quantum_numbers(self, n, electron_count):
        # Here, you would perform more complex calculations to determine the quantum numbers
        l = 0  # Placeholder for demonstration purposes
        return n, l, electron_count

    def calculate_electron_configuration(self, atomic_number):
        electron_config = f"{atomic_number}s{atomic_number}"
        energy_dirac = -atomic_number * 2
        energy_analytical = -atomic_number * 1.5
        diff = energy_dirac - energy_analytical

        return electron_config, energy_dirac, energy_analytical, diff

    def write_to_excel(self):
        workbook = openpyxl.Workbook()
        sheet = workbook.active
        sheet.title = "Electron Configurations"

        headers = ["Element", "Atomic Number", "Atomic Mass", "Electron Configuration",
                   "Energy for Dirac", "NR (Analytical)", "Diff",
                   "Principal Quantum Number (n)", "Azimuthal Quantum Number (l)",
                   "Magnetic Quantum Number (m_l)", "Spin Quantum Number (s)"]

        for col_num, header in enumerate(headers, 1):
            col_letter = openpyxl.utils.get_column_letter(col_num)
            sheet[f"{col_letter}1"] = header

        for row_num, (element_symbol, data) in enumerate(self.periodic_table.items(), 2):
            atomic_number = data['atomic_number']
            atomic_mass = data['atomic_mass']

            electron_config, energy_dirac, energy_analytical, diff = self.calculate_electron_configuration(atomic_number)
            quantum_numbers = [self.calculate_quantum_numbers(1, 2)]

            row_data = [element_symbol, atomic_number, atomic_mass, electron_config,
                        energy_dirac, energy_analytical, diff]

            for n, l, electrons in quantum_numbers:
                azimuthal_str = f"s, p, d, f within an energy level"
                magnetic_str = ", ".join([str(-l + i) for i in range(2 * l + 1)])
                spin_str = "±1/2"

                row_data.extend([n, l, azimuthal_str, magnetic_str, spin_str])

            for col_num, cell_value in enumerate(row_data, 1):
                col_letter = openpyxl.utils.get_column_letter(col_num)
                cell = sheet[f"{col_letter}{row_num}"]
                cell.value = cell_value
                cell.alignment = Alignment(horizontal="center")

        workbook.save(self.output_filename)
        print(f"Data written to {self.output_filename}")

    def main(self):
        self.write_to_excel()


if __name__ == "__main__":
    calculator = ElectronConfigurationCalculator()
    calculator.main()