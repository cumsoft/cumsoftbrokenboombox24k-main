from random import choices, randint, shuffle

# 加载单词文件
words_list = open('./words_alpha.txt').read().split()
print('#words_list:', len(words_list))
print('sample:', ', '.join(choices(words_list, k=5)))

# 生成 {单词长度 => [单词列表]} 的字典，缩短搜寻范围
WORDS_LEN_MAP = {}
for word in words_list:
    WORDS_LEN_MAP.setdefault(len(word), []).append(word)

def phrase_shorten(phrase, fetchone=True, randomize=False):
    matches = []
    target_len = len(phrase.split())
    words_pool = WORDS_LEN_MAP[target_len]
    if randomize:
        shuffle(words_pool)
    for word in WORDS_LEN_MAP[target_len]:
        if all([c in w for c, w in zip(word, phrase.lower().split())]):
            matches.append(word.upper())
            if fetchone:
                break

    return matches


phrases = [
    'Alabama Power Production Landscape Enterprise',
    'Locus Webnar River Hippo Enterprise Rev',
    *[
        ' '.join(word.title() for word in choices(words_list, k=randint(5, 15)))
        for _ in range(8)
    ]
]
for i, phrase in enumerate(phrases, 1):
    print(f'#{i}')
    phrase_shortened = phrase_shorten(phrase, True, True)
    print('{} => {}'.format(
        phrase,
        phrase_shortened[0] if phrase_shortened else '(not found)'
    ))
    print()