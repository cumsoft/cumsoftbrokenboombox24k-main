# Project by: Elvis Aboagye Asante 

# Title: COMPANION 2.0

import random

def chatbot():

    user = input("May I know your name, friend? : ")

    print(f"Hello,{user}, I'm Companion. I'm a chatbot designed by A-Tech to assist students to both study and have fun with some mini games")

    print("How can I assist you today?")

    while True:

        def game1():

            while True:

                weapon = input("Choose your weapon[rock,paper,scissors]  ")

                comp=random.choice(("rock","paper","scissors"))

                if weapon==comp:

                    print("It's a draw!")

                elif (weapon=="rock" and comp=="scissors") or (weapon=="scissors"and comp=="paper"):

                    print(f"You win!Computer chose {comp}")

                else:

                    print(f"Computer wins. Computer chose {comp}")

                again = input("Do you want to play again?[Y/N]")

                if again == "Y":

                    continue

                elif again == "N":

                    break

        def game2():

            while True:

                player = int(input("Guess the number. Hint: 1-10  "))

                comp= random.randint(1, 10)

                if comp == player:

                    print("Great guessing! You got that right")

                else:

                    print(f"Not quite. The number is {comp}")

                again = input("Do you want to play again?[Y/N]")

                if again == "Y":

                    continue 

                elif again == "N":

                    break

        def calc():

            while True:

                print("You're using Companion Basic calculator")

                print("What operation do you want to perform")

                print("1: Sum")

                print("2: Product")

                print("3: Difference ")

                print("4: Quotient")

                print("5: Exponential")

                learner = input("(1-5):  ")

                if learner=="1":

                    print("Type your two numbers to add")

                    a = int(input("a: "))

                    b = int(input("b: "))

                    print(f"Sum of {a} and {b} is", a+b)

                elif learner=="2":

                    print("Type your two numbers to multiply")

                    a = int(input("a: "))

                    b = int(input("b: "))

                    print(f"Product of {a} and {b}  is", a*b)

                elif learner == "3":

                    print("Type your two numbers to subtract")

                    a = int(input("a: "))

                    b = int(input("b: "))

                    print( f"Difference of {a} and {b} is", a-b)

                elif learner == "4":

                    print("Type your two numbers to divide")

                    a = int(input("a: "))

                    b = int(input("b: "))

                    print(f"Quotient of {a} and {b} is", a/b,"or", a//b)

                elif learner == "5":

                    a = int(input("Type your base number: "))

                    b = int(input("Type the exponent: "))

                    print("Answer is",  a**b)

                else:

                    print("Invalid option ")

                    break 

                    

                again=input("Do you want to solve some more? [Y/N]")

                if again == "Y":

                    continue

                elif again == "N":

                    break

        

        print("Select your option")

        print("1: Go to Mathrena ")

        print("2: Play a game")

        print("3: Tips for studying.")

        choice = input("(1-3):")

        if choice == "2":

            print("What game do you want us to play?")

            print("1: Rock, paper, scissors.")

            print("2: Number guessing game ")

            game = input("(1-2):")

            if game == "1":

                game1()

            elif game == "2":

                game2()

            else:

                print("Invalid option")

                break

        elif choice == "1":

            print("Welcome to Mathrena")

            print("What do you want to do?")

            print("1: Learn math tricks ")

            

            print("2: Calculator ")

            ans = input("(1-2): ")

            if ans == "2":

                calc()

            elif ans == "1":

                print("1: Divisibility tricks")

                print("2: Multiplication tricks")

                trick = input("(1-2): ")

                if trick == "1":

                    print("Divisibility rule for which number:")

                    div = input("(1-11): " )

                    if div == "1":

                        print("Every number is divisible by 1. Divisibility rule for 1 does not have any condition. Any number divided by 1 will give the number itself, irrespective of how large the number is. For example, 3 is divisible by 1 and 3000 is also divisible by 1 completely.")

                    elif div =="2":

                        print("If a number is even or a number whose last digit is an even number i.e.  2,4,6,8 including 0, it is always completely divisible by 2.Example: 508 is an even number and is divisible by 2 but 509 is not an even number, hence it is not divisible by 2. Procedure to check whether 508 is divisible by 2 or not is as follows:Consider the number 508. Just take the last digit 8 and divide it by 2. If the last digit 8 is divisible by 2 then the number 508 is also divisible by 2.")

                    elif div == "3":

                        print("Divisibility rule for 3 states that a number is completely divisible by 3 if the sum of its digits is divisible by 3.Consider a number, 308. To check whether 308 is divisible by 3 or not, take sum of the digits (i.e. 3+0+8= 11). Now check whether the sum is divisible by 3 or not. If the sum is a multiple of 3, then the original number is also divisible by 3. Here, since 11 is not divisible by 3, 308 is also not divisible by 3.Similarly, 516 is divisible by 3 completely as the sum of its digits i.e. 5+1+6=12, is a multiple of 3.")

                    elif div =="4":

                        print("If the last two digits of a number are divisible by 4, then that number is a multiple of 4 and is divisible by 4 completely.Example: Take the number 2308. Consider the last two digits i.e.  08. As 08 is divisible by 4, the original number 2308 is also divisible by 4.")

                    elif div =="5":

                        print("Numbers, which last with digits, 0 or 5 are always divisible by 5.Example: 10, 10000, 10000005, 595, 396524850, etc.")

                    elif div =="6":

                        print("Numbers which are divisible by both 2 and 3 are divisible by 6. That is, if the last digit of the given number is even and the sum of its digits is a multiple of 3, then the given number is also a multiple of 6.Example: 630, the number is divisible by 2 as the last digit is 0.The sum of digits is 6+3+0 = 9, which is also divisible by 3.Hence, 630 is divisible by 6.")

                    elif div =="7":

                        print("The rule for divisibility by 7 is a bit complicated which can be understood by the steps given below:Divisibility rule of 7. Example: Is 1073 divisible by 7? From the rule stated remove 3 from the number and double it, which becomes 6. Remaining number becomes 107, so 107-6 = 101. Repeating the process one more time, we have 1 x 2 = 2. Remaining number 10  – 2 = 8. As 8 is not divisible by 7, hence the number 1073 is not divisible by 7.")

                    elif div =="8":

                        print("If the last three digits of a number are divisible by 8, then the number is completely divisible by 8.Example: Take number 24344. Consider the last two digits i.e.  344. As 344 is divisible by 8, the original number 24344 is also divisible by 8.")

                    elif div =="9":

                        print("The rule for divisibility by 9 is similar to divisibility rule for 3. That is, if the sum of digits of the number is divisible by 9, then the number itself is divisible by 9. Example: Consider 78532, as the sum of its digits (7+8+5+3+2) is 25, which is not divisible by 9, hence 78532 is not divisible by 9.")

                    elif div =="10":

                        print("Divisibility rule for 10 states that any number whose last digit is 0, is divisible by 10. Example: 10, 20, 30, 1000, 5000, 60000, etc")

                    elif div == "11":

                        print("If the difference of the sum of alternative digits of a number is divisible by 11, then that number is divisible by 11 completely. i.e., Sum of digits in odd places – Sum of digits in even places = 0 or a multiple of 11. In order to check whether a number like 2143 is divisible by 11, below is the following procedure. Group the alternative digits i.e. digits which are in odd places together and digits in even places together. Here 24 and 13 are two groups. Take the sum of the digits of each group i.e. 2+4=6 and 1+3= 4 Now find the difference of the sums; 6-4=2. If the difference is divisible by 11, then the original number is also divisible by 11. Here 2 is the difference which is not divisible by 11. Therefore, 2143 is not divisible by 11. A few more conditions are there to test the divisibility of a number by 11. They are explained here with the help of examples: If the number of digits of a number is even, then add the first digit and subtract the last digit from the rest of the number. Example: 3784.Number of digits = 4. Now, 78 + 3 – 4 = 77 = 7 × 11. Thus, 3784 is divisible by 11. If the number of digits of a number is odd, then subtract the first and the last digits from the rest of the number. Example: 82907. Number of digits = 5. Now, 290 – 8 – 7 = 275 × 11. Thus, 82907 is divisible by 11. Form the groups of two digits from the right end digit to the left end of the number and add the resultant groups. If the sum is a multiple of 11, then the number is divisible by 11. Example: 3774 := 37 + 74 = 111 := 1 + 11 = 12. 3774 is not divisible by 11. 253 := 2 + 53 = 55 = 5 × 11. 253 is divisible by 11. Subtract the last digit of the number from the rest of the number. If the resultant value is a multiple of 11, then the original number will be divisible by 11. Example: 9647. 9647 := 964 – 7 = 957. 957 := 95 – 7 = 88 = 8 × 11. Thus, 9647 is divisible by 11.")

                    else:

                        print("Invalid option")

                elif trick =="2":

                    print("Here are some multiplication tricks  to multiply in creative ways.                                                              \n1: The Rule of 9s.The Rule of 9s. First up, we have got our friends, the Nines. The Nines are like your friend who always has a slightly plausible conspiracy theory. They both have odd patterns, but it is probably just a coincidence. If you look at the answer column left side, you will see that descending the column, the numbers are in order up to 10. Then, jump to the right column and ascend, and the numbers also ascend. Ignore your friend. The universe is not trying to tell you something with this pattern.                                                                       \n2: Butterfly Method Next, we jump into the butterfly method. As you would expect, this is a method of cross-multiplication  for adding and subtracting fractions. First, multiply the left-to-right diagonal, then multiple the right-to-left diagonal. These two numbers go in the butterfly antenna. Subtract them, and you have got your numerator. Multiply the two denominators, and that brings you the denominator for the solution. Do not forget to reduce your answer!                                                                   \n3: Double-digit Round. This technique is useful for multiplying two double-digit numbers. First, think of a nice, round number to which both of our numbers are closest. Take 92 x 98, for example. Both are close to 100, so we subtract them from 100 to get 8 and 2. Add those together to get 10, and this is your difference! Subtract 10 from 100 to get 90, which is the first part of our answer. Remember 8 and 2? Multiply these to get 16. Therefore, our answer is 9016. Clever, right?                                                                 \n4: Remember The Twins. For the next one, remember that all multiplication facts have an identical twin. So, if you forget 8×2, you might remember that 2×8 is 16. We like this one because it cuts the table in half!                                                                 \n5: Add a Zero for 10s. Let us speak with another dear friend Mr.10. 10s only response is to put a zero after it. 10 x 2 = 20.                                                                       \n6: 11s Repeat until 6. Alright, we have hit 10. let us jump forward to the oddest number, 11. Of course, 11 has the repeating digits up to 11×9. 11×4=44.           You can try your hands on questions involving these and confirm with the Companion Basic Calculator")

                c = input("Go to Basic Calculator? [Y/N]: ")

                if c== "Y":

                    calc()

        elif choice=="3":

            print("Here are some effective learning methods:Studying effectively involves adopting strategies that optimize your learning and retention of information. Here are some tips to help you study effectively:                                           \n1. Set clear goals: Determine what you want to achieve through your study session. Setting specific goals will help you stay focused and motivated.                   ,\n 2. Create a study schedule: Plan dedicated study time in your daily or weekly schedule. Establish a routine that works best for you and stick to it.                                          ,\n3. Find a suitable study environment: Choose a quiet and comfortable place to study where you can minimize distractions. This could be a library, a quiet room at home, or a café.                                            \n 4. Break it down: Divide your study material into smaller, manageable chunks. Breaking down the content will make it easier to grasp and retain information effectively.                                                  \n5. Use active learning techniques: Engage with the material actively rather than passively reading or listening. Take notes, ask questions, summarize information in your own words, and teach it to someone else. This promotes understanding and memory retention.                                                                  \n6. Utilize different study methods: Experiment with various study techniques such as flashcards, mind maps, diagrams, or summarizing key points. Find out which methods work best for you and incorporate them into your study routine.                                                                 \n7. Practice retrieval: Instead of simply reviewing notes, actively test yourself by recalling information. Practice answering questions or explaining concepts without referring to your materials. This helps reinforce learning and identify areas that need further review.                                                                            \n8. Take breaks: Break your study sessions into manageable blocks of time, typically 25-30 minutes, and take short breaks in between. This technique, known as the Pomodoro Technique, helps maintain focus and prevents mental fatigue.                                                                            \n9. Stay organized: Keep your study materials and notes well-organized. This will save you time and frustration when you need to review or revise the information later.                                                               \n 10. Stay motivated and manage stress: Find ways to stay motivated, such as setting rewards for achieving study goals or finding study buddies for accountability. Manage stress through regular exercise, proper sleep, and taking breaks to relax and recharge.                                                                 \n11. Seek understanding, not just memorization: Instead of focusing solely on memorizing facts, aim to understand the underlying concepts and principles. This will enable you to apply your knowledge to different situations and solve problems effectively.                                                                \n12. Review and revise: Regularly review and revise previously learned material to reinforce your understanding and prevent forgetting. Spaced repetition techniques, such as reviewing material at increasing intervals, can be effective for long-term retention.Remember, effective studying is a personalized process, so it's important to experiment with different techniques and find what works best for you. Additionally, maintaining a healthy lifestyle with proper nutrition, exercise, and sleep will contribute to your overall cognitive function and ability to study effectively.")

                    

                

                    

        else:

            print("Invalid option")

            break 

        start = input(" Do you need any other assistance?[Y/N]")

        if start=="Y":

            print(f"Welcome back {user}   ")

            continue 

        elif start == "N":

            print(f"Goodbye, {user}. Hope to hear from you again :) ")

            break

            

        

                 

chatbot()