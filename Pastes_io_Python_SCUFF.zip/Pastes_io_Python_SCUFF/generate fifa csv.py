import pandas as pd
import random

# Generate a fictional FIFA dataset
def generate_fifa_data(num_players=100):
    data = {'Name': [], 'Age': [], 'Position': [], 'Overall': [], 'Rating': [],
            'Acceleration': [], 'Shooting': [], 'Passing': [], 'Dribbling': [], 'Defending': []}

    positions = ['Forward', 'Midfielder', 'Defender', 'Goalkeeper']

    for _ in range(num_players):
        data['Name'].append(f'Player{_ + 1}')
        data['Age'].append(random.randint(18, 35))
        data['Position'].append(random.choice(positions))
        data['Overall'].append(random.randint(70, 90))
        data['Rating'].append(random.randint(70, 90))
        data['Acceleration'].append(random.randint(50, 90))
        data['Shooting'].append(random.randint(50, 90))
        data['Passing'].append(random.randint(50, 90))
        data['Dribbling'].append(random.randint(50, 90))
        data['Defending'].append(random.randint(50, 90))

    return pd.DataFrame(data)

# Save the generated dataset to CSV
fifa_dataset = generate_fifa_data()
fifa_dataset.to_csv('fifa_dataset.csv', index=False)