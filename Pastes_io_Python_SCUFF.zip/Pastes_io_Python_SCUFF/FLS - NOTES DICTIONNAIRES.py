#! 1. Les types des structure de données
id = 1
name = "John Smith"
user = "johnsmith"
email = "johnsmith@gmail.com"
actif = False
addresse_ville = "Ottawa"
addresse_pays = "Canada"

#? Il faudra répéter ces variables pour chaque personne 


personne = [1, "John Smith", 
            "johnsmith", "johnsmith@gmail.com", 
            False, "Ottawa", "Canada"] 

#? Manque d'organisation! Que faire si nous ajoutons un nouvel attribut?


personne = {
    "id": 1,
    "name": "John Smith",
    "user": "johnsmith",
    "email": "johnsmith@gmail.com",
    "actif": False,
    "addresse":{
        "ville": "Ottawa", 
        "pays": "Canada"
    }
}
#* Les dictionnaires essaient de résoudre ces problèmes ! 







#! 2. Les listes

#* attribuer des valeurs
ecole_l = ["Uottawa", 1848]
ecole_l = list(('Uottawa', 1848))
ecole_l = []
ecole_l.append("Carleton")
ecole_l.append(1848)


ecole_l[0] #* Retourne "Carleton"
ecole_l[0] = "Uottawa" #* Modifie valeur
ecole_l[2] = "GeeGees" #! IndexError: Out of Range. Indice 2 existe pas!
ecole_l.append("GeeGees") #* Ordre est important! Placé à la fin

ecole_l #* Retourne tout le dictionaire
"""
["Uottawa", 1848, "GeeGees"]
"""
len(ecole_l) 
#* Retourne 3, peuvent avoir des valeurs répéter. MAIS JAMAIS indice répété.



#! Les dictionaires
ecole_d = {
    "nom": "Uottawa",
    "annee_creer": 1848
} 
#* Noter que c'est plus claire de quoi est quoi
ecole_d = dict(nom = "Carleton", annee_creer = 1848)
ecole_d = dict()
ecole_d.update({"nom": "Carleton"})
ecole_d.update({"annee_creer": 1848})


ecole_d["nom"] #* Retourne "Carleton"
ecole_d.get("nom") #* Retourne "Carleton"
ecole_d[0] #! KeyError: Clé existe pas! Pas de numeros! Pas de Ordre!
ecole_d.update({"nom": "Uottawa"})
ecole_d["mascotte"] = "Geegees" #* N'importe pas que mascotte n'existait pas!

ecole_d #* Retourne tout le dictionaire
"""
{
    "nom": "Uottawa",
    "annee_creer": 1848,
    "mascotte": "Geegees"
} 
"""
len(ecole_d) 
#* Retourne 3, peuvent avoir des valeurs répéter. MAIS JAMAIS clé répété.







#! 3. Conditionelles
ecole_l = ["Uottawa", 1848]

if ecole_l[1] != 1848:
    print("Date incorrecte " + ecole_l.pop(1) + " changé")



ecole_d = {
    "nom": "Uottawa",
    "annee_creer": 1000
} 

if "annee_creer" in ecole_d: #* verifie si cet cle est dedans le dictionnaire
    valeur = ecole_d["annee_creer"]
    if valeur != 1848:
        del ecole_d["annee_creer"]
        print("Date incorrecte " + valeur +" changé")







#! 4. Pour eviter les référence, toujour ajouter .copy() --> ecole_copy = ecole_d.copy().keys()
#* Retourne la référence d'un liste avec clé(s) chaînes 
ecole_d.keys() 
# ["nom", "annee_creer"]

#* Retourne la référence d'un liste avec valeur(s) chaînes 
ecole_d.values() 
# ["Uottawa", 1848]

#* Retourne la référence d'un tuple avec les éléments 
ecole_d.items() 
# [("nom", "Uottawa"),("annee_creer", 1848)]


#! Boucles
#* On peut utiliser les liste de keys/values/items
ecole_d = {
    "nom": "Uottawa",
    "annee_creer": 1000
} 

for x in ecole_d.keys():
  print(x)
"""
nom
annee_creer 
"""

for y in ecole_d.values():
  print(y)
"""
Uottawa
1000
"""

for x in ecole_d:
    y = ecole_d[x]
    print(x,y)
    
for x, y in ecole_d.items():
  print(x, y)
"""
nom Uottawa
annee_creer 1000
"""


#TODO: Éliminer toutes les clés dont la clé est égale à la valeur (clé==valeur)

auto = {
  "marque": "BMW",
  "modèle": "X3",
  "année": 2022,
  "Luxe": "Luxe"
}

for x, y in auto.copy().items():
    if  x   ==    y:
        del auto[x]
        
print(auto)
"""
auto = {
  "marque": "BMW",
  "modèle": "X3",
  "année": 2022,
}
"""