#!/usr/bin/env python3
"""
The task is to implement an elevator driver.
Elevator moves between floors (up & down). There are button for each floor in the
elevator cabin (no buttons to open/close the doors). On each floor there are
2 buttons UP & DOWN (1 button for the highest floor DOWN and 1 for the lowest UP).
The elevator should move according to the floors selected by users,
but no user should have priority and each user should be able to go to the desired
floor (i.e. if there is 25 floors in the building, users on each floor should have
the same priority; also there should be no possibility to stop the elevator from
moving to users that are not inside of the cabin e.g. by moving between 2nd & 3rd
floor endlessly).
The elevator should work in an optimized way (completing all the existing requests 
in the shortest overall time)
Implementation notes:
- Start updating the template code in Elevator class (see comments) if you need
  additional methods - implement it after Elevator.__init__
- If elevator is not moving get_current_direction returns DIRECTION_NONE
- get_current_floor called from on_before_floor returns the floor number that was
  before the floor for which on_before_floor is called (i.e. if the elevator goes up
  after the 2nd floor, and on_before_floor is called for the 3rd floor,
  get_current_floor will return 2)
- move_up & move_down functions starts movement and are not discrete (i.e. if
  move_up is called you should explicitly provide stop conditions and stop the
  elevator - it doesn't move the elevator up by one floor).
- Docstrings and comments in your code are appreciated.
"""
DIRECTION_DOWN, DIRECTION_NONE, DIRECTION_UP = -1, 0, 1


class HardwareElevator():
    """This is the hardware elevator (engine) which provides an interface
    for the main business logic programmed in Elevator.
    This class cannot and MUST NOT be changed.
    """

    def move_up(self):
        self.current_direction = DIRECTION_UP
        pass

    def move_down(self):
        self.current_direction = DIRECTION_DOWN
        pass

    def stop_and_open_doors(self):
        self.current_direction = DIRECTION_NONE
        pass

    def set_doors_closed_callback(self, callback):
        """Set a function to be called when the doors automatically close.
        """
        pass

    def set_before_floor_callback(self, callback):
        """Set a function to be called when the elevator is about to arrive
        to a floor.
        NOTE: self.get_current_floor() will return at this moment not the
        floor the elevator is about to arrive to.
        """
        pass

    def set_floor_button_callback(self, callback):
        """Set a function to be called when someone presses a button on a floor.
        The callback is passed the floor number and the desired direction.
        """
        pass

    def set_cabin_button_callback(self, callback):
        """Set a function to be called when someone presses a button inside the
        cabin.
        The callback is passed the desired floor number.
        """
        pass

    def get_current_floor(self):
        return self.current_floor

    def get_current_direction(self):
        """Return the direction in which the elevator is currently moving.
        When the elevator is stopped on a floor, the direction is None.
        """
        return self.current_direction


class Elevator():
    def __init__(self):
        self.elevator = HardwareElevator()
        self.elevator.set_doors_closed_callback(self.on_doors_closed)
        self.elevator.set_before_floor_callback(self.on_before_floor)
        self.elevator.set_floor_button_callback(self.on_floor_button_pressed)
        self.elevator.set_cabin_button_callback(self.on_cabin_button_pressed)

        self.queue: list[int] = []
        self.return_queue: list[int] = []

    def insert_to_queue(self, floor: int, queue: list[int]):
        if abs(floor) not in [abs(x) for x in queue]:
            queue.append(floor)
            queue.sort()

    def button_press_handler(self, floor: int, direction: int | None = None):
        elevator_direction = self.elevator.get_current_direction()
        current_floor = self.elevator.get_current_floor()

        if not self.queue:
            self.queue.insert(floor)
            return

        if elevator_direction == DIRECTION_NONE:
            elevator_direction = DIRECTION_UP if self.queue[0] > 0 else DIRECTION_DOWN

        dir_floor = floor * (direction or elevator_direction)
        dir_cur_floor = current_floor * elevator_direction

        if dir_floor == dir_cur_floor:
            self.elevator.stop_and_open_doors()
        elif dir_floor > dir_cur_floor:
            self.insert_to_queue(floor, self.queue)
        else:
            self.insert_to_queue(floor, self.return_queue)

    def on_doors_closed(self):
        """This callback is called when the doors automatically close"""
        if not self.queue:
            pass
        current_floor = self.elevator.get_current_floor()
        next_floor = abs(self.queue[0])
        if next_floor > current_floor:
            self.elevator.move_up()
        elif next_floor < current_floor:
            self.elevator.move_down()

    def on_before_floor(self):
        """This callback is called when the elevator is about to arrive
        to a floor."""
        prev_floor = self.elevator.get_current_floor()
        direction = self.elevator.get_current_direction()
        next_floor = prev_floor + direction
        next_in_queue = abs(self.queue[0])
        if next_floor == next_in_queue:
            self.queue.pop(0)
            if not self.queue and self.return_queue:
                self.queue, self.return_queue = self.return_queue, self.queue
            self.elevator.stop_and_open_doors()

    def on_floor_button_pressed(self, floor: int, direction: int):
        """This callback is called when someone presses a button on a floor"""
        self.button_press_handler(floor, direction)

    def on_cabin_button_pressed(self, floor: int):
        """This callback is called when someone presses a button inside the
        cabin."""
        self.button_press_handler(floor)