random 

def get_player_choice():
	while True:
		player_choice = input("Choose rock (r), paper (p) or scissors (s): ") 
		if player_choice in ['r', 'p', 's']:
			return player_choice 
		else:
			print("Invalid choice. Please try again")

def get_computer_choice():
	choices = ['r', 'p', 's']
	return random.choice
	
def determine_winner(player_choice, computer_choice):
	if player_choice == computer_choice:
		return "Tie!" 
	elif (player_choice == 'r' and computer_choice == 's') or \
	       (player_choice == 'p' and computer_choice == 'r') or\
	       (player_choice == 's' and computer_choice == 'p'):
	    return "You win!"
	else:
	    return "Computer wins"
    	
def play_again():
	while True:
		play_again=input("Do you want to play again? (y/n): ")
		if play_again == 'y':
			return True
		elif play_again == 'n':
			return False
		else:
			print("Invalid input. Please enter 'y' or 'n'.")
			

def play_game():
	print("Let's play Rock, Paper, Scissors!")
	while True:
		player_choice = get_player_choice()
		computer_choice = get_computer_choice()
		print(f"You chose: {player_choice}")
		print(f"Computer chose: {computer_choice}")
		print(determine_winner(player_choice, computer_choice))
		if not play_again():
			break
			
play_game()