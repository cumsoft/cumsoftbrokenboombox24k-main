import nltk
from nltk.tokenize import word_tokenize
nltk.download('punkt')
nltk.download('averaged_perceptron_tagger')

script_text = """I am a *** confident girl.

I love myself unconditionally.

...."""

words_in_script_text = word_tokenize(script_text)
print(words_in_script_text)

tagged_output = nltk.pos_tag(words_in_script_text)
file_to_write = open("output.txt", 'w')
file_to_write.write(str(tagged_output))

print("all done!")