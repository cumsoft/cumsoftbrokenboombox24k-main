# IMPORTING STANDARD PACKAGES
import os
import logging

# IMPORTING THIRD PARTY PACKAGES
import sentry_sdk

from sentry_sdk.integrations.logging import LoggingIntegration

env_type = "local"
if env_type == "local":
   sentry_sdk.init(
      dsn=os.getenv("SENTRY_DNS"),
      traces_sample_rate=eval(os.getenv("SENTRY_TRACE_SAMPLE_RATE")),
      send_default_pii=True,
      integrations=[
         LoggingIntegration(
            level=logging.INFO,
            event_level=logging.ERROR
         ),
      ],
   )