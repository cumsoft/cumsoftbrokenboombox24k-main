import pymorphy2

morph = pymorphy2.MorphAnalyzer()

word_1 = ''
word_2 = 'похвалить'
word_3 = ''

res1 = []
res2 = []
res3 = []
#p1 = morph.parse(word_1)[0].inflect({'plur'}).word
p2 = morph.parse(word_2)[0].inflect({'plur', 'futr'}).word
p3 = morph.parse(word_2)[0].inflect({'plur'}).tag.tense




#res1.append(p1)
res2.append(p2)
res3.append(p3)
print(res2 + res3)