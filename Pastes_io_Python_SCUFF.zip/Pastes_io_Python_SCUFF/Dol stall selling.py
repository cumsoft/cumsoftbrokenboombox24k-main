from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities 
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.service import Service
import time
options = Options()
options.page_load_strategy='none'
driver = webdriver.Chrome(options=options)
options.add_experimental_option("detach", True)
capa = DesiredCapabilities.CHROME
capa["pageLoadStrategy"] = "none"
driver.get("file:///F:/Me/Degrees%20of%20Lewdity/Degrees%20of%20Lewdity%200.4.1.7.html")
time.sleep(15)

for n in range (1,201):
    try:
        WebDriverWait(driver, 0.5, poll_frequency=0.25).until(EC.presence_of_element_located((By.PARTIAL_LINK_TEXT, "Continue"))).click()
        continue
    except:
        pass
    try:
        WebDriverWait(driver, 0.5, poll_frequency=0.25).until(EC.presence_of_element_located((By.PARTIAL_LINK_TEXT, "Let them go"))).click()
        continue
    except:
        pass
    try:
        WebDriverWait(driver, 0.5, poll_frequency=0.25).until(EC.presence_of_element_located((By.PARTIAL_LINK_TEXT, "Push your most expensive stock"))).click()
        WebDriverWait(driver, 0.5, poll_frequency=0.25).until(EC.presence_of_element_located((By.PARTIAL_LINK_TEXT, "Ask for normal price"))).click()
        for r in range (1,10): 
            try: 
                WebDriverWait(driver, 0.5, poll_frequency=0.25).until(EC.presence_of_element_located((By.PARTIAL_LINK_TEXT, "Refuse to budge"))).click() 
            except:
                break
        continue
    except:
        pass
    try:
        WebDriverWait(driver, 0.5, poll_frequency=0.25).until(EC.text_to_be_present_in_element((By.XPATH, '//*[@id="passage-stall-sell"]'), 'better price'))
        for r in range (1,10): 
            try: 
                WebDriverWait(driver, 0.5, poll_frequency=0.25).until(EC.presence_of_element_located((By.PARTIAL_LINK_TEXT, "Refuse to budge"))).click() 
            except:
                break
        continue
    except:
        pass
    try:             
        WebDriverWait(driver, 0.5, poll_frequency=0.25).until(EC.text_to_be_present_in_element((By.XPATH, '//*[@id="passage-stall"]'), 'loiters nearby')) 
        driver.find_element(By.PARTIAL_LINK_TEXT, "Ignore").click()
        continue
    except:
        pass
    try:
        WebDriverWait(driver, 0.5, poll_frequency=0.25).until(EC.presence_of_element_located((By.PARTIAL_LINK_TEXT, "Ask for normal price"))).click()
        continue
    except:
        pass
    try: 
        WebDriverWait(driver, 0.5, poll_frequency=0.25).until(EC.text_to_be_present_in_element((By.XPATH, '//*[@id="passage-stall-sell"]'), 'walk away')) or WebDriverWait(driver,1).until(EC.text_to_be_present_in_element((By.XPATH, '//*[@id="passage-stall"]'), 'walk away'))
        WebDriverWait(driver, 0.5, poll_frequency=0.25).until(EC.presence_of_element_located((By.PARTIAL_LINK_TEXT, "them go"))).click()
        continue
    except:
        pass
    try:
        WebDriverWait(driver, 0.5, poll_frequency=0.25).until(EC.text_to_be_present_in_element((By.XPATH, '//*[@id="passage-stall"]'), 'Answer honestly'))
        WebDriverWait(driver, 0.5, poll_frequency=0.25).until(EC.presence_of_element_located((By.PARTIAL_LINK_TEXT, "Answer honestly"))).click()
        continue
    except:
        pass
    try:
        WebDriverWait(driver, 0.5, poll_frequency=0.25).until(EC.element_to_be_clickable((By.PARTIAL_LINK_TEXT, "Converse"))).click()
        continue
    except:
        pass
    try:
        WebDriverWait(driver, 0.5, poll_frequency=0.25).until(EC.presence_of_element_located((By.PARTIAL_LINK_TEXT, "Remain silent"))).click()
        continue
    except:
        pass
    try:
        WebDriverWait(driver, 0.5, poll_frequency=0.25).until(EC.presence_of_element_located((By.PARTIAL_LINK_TEXT, "Encourage them to buy something"))).click()
        continue
    except:
        pass
    try:
        WebDriverWait(driver, 0.5, poll_frequency=0.25).until(EC.text_to_be_present_in_element((By.XPATH, '//*[@id="passage-stall"]'), 'An official arrives'))
        print ("ended")
        time.sleep(1000)  
    except:
        pass