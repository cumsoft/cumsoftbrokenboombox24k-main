from rules import *
import os
import configparser
from pyrogram import Client, filters, InlineKeyboardButton, InlineKeyboardMarkup
import random
import asyncio

# Загружаем конфиг
config = configparser.ConfigParser()
config.read('config.ini')
name = str(config['account']['name'])
api_id = int(config['account']['api_id'])
api_hash = str(config['account']['api_hash'])
source_id = int(config['src']['source_id'])
target_id = int(config['src']['target_id'])

# Создаем клиент Telegram
if os.path.exists(f"{name}.session"):
    app = Client(name)
else:
    app = Client(name, api_id=api_id, api_hash=api_hash)

# Функция для форматирования сообщений
def format_message(message):
    # Удаляем ненужные тексты из сообщения
    message = message.replace("#Spot-exchange #BTC inflow total went above 500.0", "")
    message = message.replace("The current value is", "👉 Текущий объем:")
    message = message.replace("Resolution: block | Type: Repetition | Cool Down: 5min", "")
    message = message.replace("Live Chart | Manager Alerts | note:", "")
    
    # Форматируем текст
    message = message.strip()
    message = message.replace("\n\n", "\n")

    return message

# Функция для выбора рандомного рекламного сообщения
def get_advertisement_message():
    messages = [
        "🛎️ Не забываете, что разобраться в он-чейн можно самостоятельно на сайте [CryptoQuant](https://dataguide.cryptoquant.com/) и [GlassNode](https://academy.glassnode.com/), а можно в группе с верифицированным он-чейн аналитиком. Количество свободных мест и расписание, можно уточнить у администратора. Обучение проходит на русском языке в зуме. Подробности на сайта [ACTIV](https://activ.foundation/academy/?utm_source=Telegram&utm_medium=Social&utm_campaign=Feed1)",
        "🚀 Готовы начать зарабатывать на рынке криптовалют? Наша группа предлагает обучение он-чейн анализу, проводимое верифицированным специалистом CryptoQuant. Присоединяйтесь к нам и получите необходимые навыки для успешной торговли! Подробности [ACTIV](https://activ.foundation/academy/?utm_source=Telegram&utm_medium=Social&utm_campaign=Feed2)",
        "💰 Не хотите больше терять деньги на рынке криптовалют? Обучение он-чейн анализу от верифицированного специалиста поможет вам научиться читать графики и принимать правильные решения. Присоединяйтесь [ACTIV](https://activ.foundation/academy/?utm_source=Telegram&utm_medium=Social&utm_campaign
]
return random.choice(messages)
# Функция для постинга рекламного сообщения

async def post_advertisement():
# Выбираем случайное сообщение и форматируем его
message = get_advertisement_message()
message = format_message(message)

# Постим сообщение с кнопками голосования
keyboard = InlineKeyboardMarkup([
    [InlineKeyboardButton("🔴 0", callback_data="dislike"), InlineKeyboardButton("🟢 0", callback_data="like")]
])
sent_message = await app.send_message(target_id, message, reply_markup=keyboard)

# Анимация кнопок голосования
await animate_vote_buttons(sent_message)

# Нажимаем случайные кнопки голосования
await click_vote_buttons(sent_message)

# Функция для анимации кнопок голосования

async def animate_vote_buttons(message):
keyboard = message.reply_markup.inline_keyboard
while True:
for row in keyboard:
for button in row:
button_text = button.text
if button_text.startswith("🔴"):
button_text = "🔴🔴🔴"
else:
button_text = "🟢🟢🟢"
updated_button = InlineKeyboardButton(button_text, callback_data=button.callback_data)
row[row.index(button)] = updated_button
keyboard = InlineKeyboardMarkup(keyboard)
await app.edit_message_reply_markup(message.chat.id, message.message_id, reply_markup=keyboard)
await asyncio.sleep(0.5)

# Функция для нажатия случайных кнопок голосования

async def click_vote_buttons(message):
await asyncio.sleep(random.randint(180, 600)) # Ожидаем случайное время от 3 до 10 минут
keyboard = message.reply_markup.inline_keyboard
users_count = random.randint(10, 20) # Количество участников группы, участвующих в голосовании
votes_count = {"likes": 0, "dislikes": 0} # Количество голосов
for i in range(users_count):
user_id = random.randint(1, 1000)
if user_id % 2 == 0: # Случайно нажимаем на одну из кнопок
votes_count["likes"] += 1
else:
votes_count["dislikes"] += 1
# Обновляем кнопки голосования
keyboard = update_votes(keyboard, votes_count)
await app.edit_message_reply_markup(message.chat.id, message.message_id, reply_markup=keyboard)
await asyncio.sleep(1)

# Функция для получения текущего количества голосов из кнопок голосования

def get_votes(markup):
likes_count = int(markup.inline_keyboard[0][1].text.split()[0])
dislikes_count = int(markup.inline_keyboard[0][0].text.split()[0])
return {"likes": [], "dislikes": [], "likes_count": likes_count, "dislikes_count": dislikes_count}

def update_votes(markup, votes):
likes_button = markup.inline_keyboard[0][1]
dislikes_button = markup.inline_keyboard[0][0]
likes_button_text = f"🟢 {votes['likes_count']}"
dislikes_button_text = f"🔴 {votes['dislikes_count']}"
likes_button.callback_data = f"like {','.join(str(v) for v in votes['likes'])}"
dislikes_button.callback_data = f"dislike {','.join(str(v) for v in votes['dislikes'])}"
likes_button.text = likes_button_text
dislikes_button.text = dislikes_button_text
return InlineKeyboardMarkup([[dislikes_button, likes_button]])

# Функция для обработки событий голосования

async def on_vote_callback_query(_, query):
user_id = query.from_user.id
callback_data = query.data.split()
message = query.message
# Проверяем, что голосование идет по нужному сообщению
if message.chat.id != target_id:
    return

# Получаем текущее количество голосов
votes = get_votes(message.reply_markup)

# Если пользователь уже проголосовал, не обрабатываем его голос
if user_id in votes["likes"] or user_id in votes["dislikes"]:
    return

# Обновляем количество голосов и кнопки голосования
if callback_data[0] == "like":
    votes["likes"].append(user_id)
    votes["likes_count"] += 1
elif callback_data[0] == "dislike":
    votes["dislikes"].append(user_id)
    votes["dislikes_count"] += 1
keyboard = update_votes(message.reply_markup, votes)
await app.edit_message_reply_markup(message.chat.id, message.message_id, reply_markup=keyboard)

# Запускаем бота

if name == 'main':
app.run()