import os
import PIL
import pytesseract

from tkinter import *
from tkinter import ttk
from tkinter.messagebox import showerror
from tkcalendar import Calendar, DateEntry
    

class OCRWindow:

    def __init__(self, title: str) -> None:
        self.tk_window = Tk()
        
        self.employee_name: StringVar = StringVar()
        self.employee_company: StringVar = StringVar()
        self.ocr_text: StringVar = StringVar()
        self.sign_date: StringVar = StringVar()
        self.protocole_type: StringVar = StringVar()
        self.file_path: StringVar =  StringVar()

        self.margin_size = 15
        self.entry_size = 50

        self.tk_window.title("PFRO OCR")
        self.tk_window.resizable(False, False)
        self.tk_window.configure(padx=self.margin_size, pady=self.margin_size)

    def open_document(self, file_path: str):
        os.startfile(file_path)

    def ocr_document(self, file_path, ocr_text_entry: Text):

        allowed_extensions = (".ppt", ".pdf", ".png")
        filename, file_extension = os.path.splitext(file_path)

        if not file_extension in allowed_extensions:
            showerror("Błąd pliku", "Plik posiada niewłaściwe rozszerzenie")
            return 
        
        text = ""

        if file_extension == ".png":
            text += self.ocr_image(file_path)
        elif file_extension == ".ppt":
            text += self.ocr_powerpoint(file_path)
        
        ocr_text_entry.configure(state=NORMAL)
        ocr_text_entry.delete('1.0', END)
        ocr_text_entry.insert('1.0', text)
        ocr_text_entry.configure(state=DISABLED)
        
    def ocr_image(self, file_path) -> str:
        return pytesseract.image_to_string(PIL.Image.open(file_path), lang='pol')

    def ocr_powerpoint(self, file_path) -> str:
        pass


    def build(self) -> None:

        data_frame = Frame(self.tk_window)
        data_frame.grid(column=0, row=0, sticky=(W,S,N))

        ttk.Label(master=data_frame, text="Imię i nazwisko").grid(column=0, row=0, sticky=(W))
        employee_name_entry = Entry(data_frame, textvariable=self.employee_name, width=50)
        employee_name_entry.grid(column=0, row=1, sticky=(W))
        employee_name_entry.grid_configure(pady=(0, self.margin_size))

        ttk.Label(master=data_frame, text="Spółka").grid(column=0, row=2, sticky=(W))
        employee_company_entry = Entry(data_frame, textvariable=self.employee_company, width=self.entry_size)
        employee_company_entry.grid(column=0, row=3, sticky=(W))
        employee_company_entry.grid_configure(pady=(0, self.margin_size))

        frame_1 = Frame(data_frame)
        frame_1.grid(column=0, row=5, sticky=(N,E,S,W))
        frame_1.grid_configure(pady=(0, self.margin_size))


        ttk.Label(master=frame_1, text="Data podpisania").grid(column=0, row=0, sticky=(W))
        date_entry = DateEntry(frame_1, textvarialbe=self.sign_date, 
                               locale='pl_PL', date_pattern='dd-mm-yyyy', width=int((self.entry_size-3)/2)-2)
        date_entry.grid(column=0, row=1, sticky=(W), padx=(0, self.margin_size))


        ttk.Label(master=frame_1, text="Typ protokołu").grid(column=1, row=0, sticky=(W))
        types=("Odbiór", "Wydanie",)
        protocole_type_entry = ttk.OptionMenu(frame_1, self.protocole_type, types[0], *types)
        protocole_type_entry.grid(column=1, row=1, sticky=(W), padx=(0, self.margin_size))


        ocr_text_frame = Frame(self.tk_window)
        ocr_text_frame.grid(column=2, row=0, sticky=(W), padx=(self.margin_size, 0))

        ttk.Label(master=ocr_text_frame, text="Text OCR").grid(column=0, row=0, sticky=(W))

        scroll_bar_y = Scrollbar(ocr_text_frame, orient=VERTICAL)
        scroll_bar_y.grid(column=1, row=1, sticky=(N,S))

        scroll_bar_x = Scrollbar(ocr_text_frame, orient=HORIZONTAL)
        scroll_bar_x.grid(column=0, row=2, sticky=(W,E))

        ocr_text_entry = Text(ocr_text_frame, width=50, wrap="none", yscrollcommand=scroll_bar_y.set, xscrollcommand=scroll_bar_x.set)
        ocr_text_entry.grid(column=0, row=1, sticky=(W))
        ocr_text_entry.insert('1.0', "Hello\nWorld!")
        ocr_text_entry.configure(state=DISABLED)

        scroll_bar_y.config(command=ocr_text_entry.yview)
        scroll_bar_x.config(command=ocr_text_entry.xview)

        ocr_button_frame = Frame(ocr_text_frame)
        ocr_button_frame.grid(column=0, row=3, sticky=(W,E,N,S))

        skan_file_button = Button(ocr_button_frame, text="Podgląd pliku", command=lambda: self.open_document(self.file_path.get()))
        skan_file_button.grid(column=0, row=0)

        skan_file_button = Button(ocr_button_frame, text="Skanuj plik", command=lambda: self.ocr_document(str(self.file_path.get()), ocr_text_entry))
        skan_file_button.grid(column=1, row=0)

        footer_frame = Frame(self.tk_window)
        footer_frame.grid(column=0, row=1, sticky=(W,E,N,S))

        ttk.Label(master=footer_frame, text="Plik: "+self.file_path.get()).grid(column=0, row=0, sticky=(W))

    def open(self):
        self.file_path.set("C:\\Users\\Gabriel\\Desktop\\lol.png")
        self.build()
        self.tk_window.mainloop()

    def close(self):
        self.tk_window.destroy()


pytesseract.pytesseract.tesseract_cmd = 'C:\\Users\\Gabriel\\AppData\\Local\\Programs\\Tesseract-OCR\\tesseract.exe'
window = OCRWindow("OCR PFRO")
window.open()