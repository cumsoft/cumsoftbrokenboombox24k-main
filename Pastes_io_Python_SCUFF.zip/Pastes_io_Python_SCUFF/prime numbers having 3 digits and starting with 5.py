# Function to check if a number is prime
def is_prime(n):
    if n <= 1:
        return False
    if n == 2 or n == 3:
        return True
    if n % 2 == 0:
        return False
    for i in range(3, int(n**0.5) + 1, 2):
        if n % i == 0:
            return False
    return True

# Function to display all prime numbers with 3 digits starting with 5
def display_prime_numbers():
    for num in range(500, 1000):
        if str(num).startswith('5') and is_prime(num):
            print(num)

# Calling the function
display_prime_numbers()