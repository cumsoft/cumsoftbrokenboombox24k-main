import aiohttp
import asyncio
import json
import html
import re

async def scrape_copypastas():
    headers = {
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/109.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Alt-Used': 'copypastatext.com',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'cross-site',
    }

    page = 1
    valid_sections = 0
    scraped_data = {}

    async with aiohttp.ClientSession(headers=headers) as session:
        while True:
            tasks = []
            for i in range(5):
                url = f"https://copypastatext.com/wp-json/wp/v2/posts?page={page}&per_page=100"
                task = asyncio.ensure_future(scrape_page(session, url))
                tasks.append(task)
                page += 1
            results = await asyncio.gather(*tasks)
            if all(not result[0] for result in results):
                break

            for success, response_json in results:
                if success:
                    for post in response_json:
                        title = html.unescape(post["title"]["rendered"])
                        content = html.unescape(post["content"]["rendered"])
                        pastas = re.findall('<code>(.*?)</code>', content, re.DOTALL)
                        if pastas:
                            scraped_data[valid_sections] = {
                                "title": title,
                                "pastas": pastas
                            }
                            valid_sections += 1

    formatted_data = json.dumps(scraped_data, indent=4, ensure_ascii=False)
    with open("copypastas.json", "w") as file:
        file.write(formatted_data)
    print(formatted_data)

async def scrape_page(session, url):
    response = await session.get(url)
    response_json = await response.json()
    return response.ok, response_json

if __name__ == "__main__":
    asyncio.run(scrape_copypastas())