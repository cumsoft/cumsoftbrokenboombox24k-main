import itertools

def is_antimagic(square):
    n = len(square)
    target_sum = sum(range(1, n*n + 1)) // (2*n + 2)

    # Check row sums
    for row in square:
        if sum(row) != target_sum:
            return False

    # Check column sums
    for col in range(n):
        if sum(square[row][col] for row in range(n)) != target_sum:
            return False

    # Check diagonal sums
    if sum(square[i][i] for i in range(n)) != target_sum:
        return False
    if sum(square[i][n-i-1] for i in range(n)) != target_sum:
        return False

    return True

def generate_antimagic_squares():
    numbers = range(1, 17)  # Numbers 1 to 16
    permutations = itertools.permutations(numbers)

    squares = []
    for perm in permutations:
        square = [perm[i:i+4] for i in range(0, 16, 4)]
        if is_antimagic(square):
            squares.append(square)

    return squares

# Generate and print all antimagic squares
antimagic_squares = generate_antimagic_squares()
for square in antimagic_squares:
    for row in square:
        print(row)
    print()