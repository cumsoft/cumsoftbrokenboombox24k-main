def removeElement(a,index):
  for i in range(index+1,len(a)):
    a[i-1]= a[i]
  a[len(a)-1]=0
  return a

# Test 02: Discard Cards
def discardCards(cards,number):
  # TO DO
  idx=0
  while idx<len(cards):
      if cards[idx]==number:
        cards = removeElement(cards,idx)
        idx=0 #after removing one element, start searching from the beginning again as the index position will not be the same as before
      idx+=1

  return cards