import string

key = input("Enter key: ").upper()
pt = input("Enter plaintext: ").upper()
ch = int(input("1. Encrypt\n2. Decrypt\nChoose: "))

def check():
    exists_in_list = False
    for nested_list in my_2d_list:
        if 'three' in nested_list:
            exists_in_list = True
            print(nested_list)
            break

if ch == 1:
    mat = [[0 for j in range(5)] for i in range(5)]
    alphabet = list(string.ascii_uppercase)
    keybets = list(dict.fromkeys(key))
    keyleft = len(keybets)
    alphaleft = len(alphabet)

    for i in range(5):
        for j in range(5):
            if keyleft > 0:
                if keybets[0] in mat:
                    continue
                elif keybets[0] == "J":
                    mat[i][j] = "I"
                    keyleft -= 1
                else:
                    mat[i][j] = keybets[0]
                keybets.remove(keybets[0])
                keyleft -= 1

            else:
                if alphaleft > 0:
                    if alphabet[0] in mat:
                        continue
                    elif alphabet[0] == "J":
                        mat[i][j] = "I"
                        alphaleft -= 1
                    else:
                        mat[i][j] = alphabet[0]
                        alphabet.remove(alphabet[0])
                        alphaleft -= 1

            print(mat)