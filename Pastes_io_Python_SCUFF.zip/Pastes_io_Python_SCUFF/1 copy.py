import pandas as pd
import os
import csv
import time
import getpass

def get_windows_username():
    
    username = getpass.getuser()
    return username

def load_files_into_dataframes(directory):
    files = ['Delivery Plan.csv', 'LQUA-Coverage.txt', 'RESB-Coverage.csv']
    dataframes = {}

    specified_columns = {
        'Delivery Plan.csv': ['Delivery_Plan_Material', 'Delivery_Plan_Vendor_Name', 'Delivery_Plan_Quantity', 'Delivery_Plan_Delivery_Date'],
        'LQUA-Coverage.txt': ['Plnt', 'Material', 'Typ', 'StorageBin', 'Stock', 'PutawayStk', 'Pick qty', 'Avail.stck',
                              'Sp.Stck No'],
        'RESB-Coverage.csv': ['RESB_Plant', 'RESB_Material', 'RESB_WO_ITM', 'RESB_Quantity', 'RESB_ReqmtsDate',
                              'RESB_WBS_Element', 'RESB_Effectivity', 'RESB_Work_Center', 'RESB_MPS_Date','RESB_Production_Line','RESB_Logis_Flow','RESB_Vendor']
    }

    for file_name in files:
        file_path = os.path.join(directory, file_name)

        if file_name == 'LQUA-Coverage.txt':
            # Read the LQUA file and skip the first 3 rows
            try:
                df = pd.read_csv(file_path, delimiter='\t', header=0, encoding='utf-8', skiprows=3)
            except UnicodeDecodeError:
                df = pd.read_csv(file_path, delimiter='\t', header=0, encoding='ISO-8859-1', skiprows=3)
        else:
            # Adjust the delimiter based on the file extension
            delimiter_char = ',' if file_name.endswith('.csv') else '\t'

            try:
                df = pd.read_csv(file_path, delimiter=delimiter_char, header=0, encoding='utf-8')
            except UnicodeDecodeError:
                df = pd.read_csv(file_path, delimiter=delimiter_char, header=0, encoding='ISO-8859-1')

        df.columns = df.columns.str.strip()
        columns_to_keep = specified_columns[file_name]
        df = df[columns_to_keep]
        dataframes[file_name] = df

    return dataframes


def process_and_sort_resb(df_resb):
    df_resb['RESB_ReqmtsDate'] = pd.to_datetime(df_resb['RESB_ReqmtsDate'], format = '%d/%m/%Y')
    df_resb['RESB_Quantity'] = df_resb['RESB_Quantity'].astype(float)
    df_resb.sort_values(by=['RESB_Material', 'RESB_ReqmtsDate', 'RESB_WO_ITM'], inplace=True, ascending=[True, True, True])
    df_resb.reset_index(drop=True, inplace=True)


def process_lqua_coverage(df_lqua):
    for col in ['Stock', 'PutawayStk', 'Pick qty', 'Avail.stck']:
        df_lqua[col] = df_lqua[col].str.replace('.', '').str.replace(',', '.').astype(float)


def process_and_sort_delivery_plan(df_delivery):
    df_delivery['Delivery_Plan_Delivery_Date'] = pd.to_datetime(df_delivery['Delivery_Plan_Delivery_Date'], errors='coerce')
    df_delivery['Delivery_Plan_Quantity'] = df_delivery['Delivery_Plan_Quantity'].astype(float)
    df_delivery.sort_values(by=['Delivery_Plan_Material', 'Delivery_Plan_Delivery_Date', 'Delivery_Plan_Vendor_Name'], inplace=True)
    df_delivery.reset_index(drop=True, inplace=True)



def allocate_stock(resb_row, lqua_df, df_delivery):
    material_rows = lqua_df[lqua_df['Material'] == resb_row['RESB_Material']].copy()
    delivery_rows = df_delivery[df_delivery['Delivery_Plan_Material'] == resb_row['RESB_Material']]
    remaining_qty = resb_row['RESB_Quantity']

    # Handle NaT or NaN values in remaining_qty
    if pd.isna(remaining_qty):
        remaining_qty = 0

    # Create a custom sort order for Typ
    sort_order = {'999': 2, 'TSG': 1}
    material_rows.loc[:, 'SortOrder'] = material_rows['Typ'].map(sort_order).fillna(0)

    # Sort material_rows based on SortOrder, then drop the SortOrder column
    material_rows = material_rows.sort_values(by='SortOrder', ascending=True).drop(columns=['SortOrder'])

    output_rows = []

    for index, material_row in material_rows.iterrows():
        if remaining_qty > 0:
            allocation = min(remaining_qty, material_row['Avail.stck'])
            remaining_qty -= allocation
            lqua_df.at[index, 'Avail.stck'] -= allocation
            if allocation > 0:
                output_row = resb_row.copy()
                output_row['RESB_Quantity'] = allocation  # Adjust the RESB_Quantity based on allocation
                output_row['Allocated Typ'] = material_row['Typ']
                output_row['Allocated StorageBin'] = material_row['StorageBin']
                if material_row['Typ'] == '999':
                    output_row['Coverage Status'] = "Blocked Stock - Lost Material"
                elif material_row['Typ'] == 'TSG':
                    output_row['Coverage Status'] = "Blocked Stock - Quality Material"
                elif material_row['Typ'] == '916':
                    output_row['Coverage Status'] = "Investigate - Bad Stock"
                elif material_row['Typ'] == '922':
                    output_row['Coverage Status'] = "Investigate - Bad Stock"
                else:
                    output_row['Coverage Status'] = "Available"
                output_rows.append(output_row)

    for index, delivery_row in delivery_rows.iterrows():
        if remaining_qty > 0:
            allocation = min(remaining_qty, delivery_row['Delivery_Plan_Quantity'])
            remaining_qty -= allocation
            df_delivery.at[index, 'Delivery_Plan_Quantity'] -= allocation
            if allocation > 0:
                output_row = resb_row.copy()
                output_row['RESB_Quantity'] = allocation
                output_row['Allocated Typ'] = "Delivery"
                output_row['Allocated StorageBin'] = delivery_row['Delivery_Plan_Vendor_Name']

                # Check if the Delivery Date is NaT
                if pd.isna(delivery_row['Delivery_Plan_Delivery_Date']):
                    output_row['Delivery Date Status'] = "Invalid Date"
                else:
                    output_row['Delivery Date Status'] = delivery_row['Delivery_Plan_Delivery_Date'].strftime('%d/%m/%Y')

                delivery_date = delivery_row['Delivery_Plan_Delivery_Date']
                requirement_date = pd.to_datetime(resb_row['RESB_ReqmtsDate'])
                if delivery_date < pd.Timestamp.today():
                    output_row['Coverage Status'] = "Delivery Date in the Past"
                elif delivery_date > requirement_date:
                    output_row['Coverage Status'] = "Bad Delivery Date"                   
                else:
                    output_row['Coverage Status'] = "Good Delivery Date"
                output_rows.append(output_row)

    if remaining_qty > 0:
        output_row = resb_row.copy()
        output_row['Allocated Typ'] = "None"
        output_row['Allocated StorageBin'] = "None"
        output_row['RESB_Quantity'] = remaining_qty  # Use the remaining quantity
        output_row['Coverage Status'] = "No Coverage"
        output_rows.append(output_row)

    return output_rows


def main():
    start_time = time.time()
    directory = r'C:\Users\201006840\OneDrive - Alstom\Static Reports\Brugge Coverage Report'
    dfs = load_files_into_dataframes(directory)
    process_and_sort_resb(dfs['RESB-Coverage.csv'])
    process_lqua_coverage(dfs['LQUA-Coverage.txt'])
    process_and_sort_delivery_plan(dfs['Delivery Plan.csv'])

    output_rows = []
    for index, resb_row in dfs['RESB-Coverage.csv'].iterrows():
        output_rows.extend(allocate_stock(resb_row, dfs['LQUA-Coverage.txt'], dfs['Delivery Plan.csv']))

    output_df = pd.DataFrame(output_rows)

    # Generate an index for each unique 'RESB_WO_ITM'
    output_df['Index'] = output_df.groupby('RESB_WO_ITM').cumcount() + 1
    cols = ['Index'] + [col for col in output_df if col != 'Index']
    output_df = output_df[cols]

    # Convert all non-string columns to string
    output_df = output_df.astype(str)

    output_file_path = os.path.join(directory, 'Coverage Report.xlsx')
    writer = pd.ExcelWriter(output_file_path, engine='xlsxwriter')
    output_df.to_excel(writer, sheet_name='Coverage Report', index=False)
    writer._save()
    end_time = time.time()  # Record the end time
    elapsed_time = end_time - start_time 
    print(f"Finished. It took {elapsed_time:.2f} seconds to run.")
if __name__ == "__main__":
    main()