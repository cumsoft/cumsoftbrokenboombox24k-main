@auth.route("/reset_password")
def reset_password():
    if verify_secret_reset_string(request.args):
        email = request.args.get("email")
        secret_reset_string = request.args.get("secret_reset_string")
        return render_template("reset_password.html", email=email, secret_reset_string=secret_reset_string)
    else:
        abort(404)

@auth.route("/reset_password", methods=["POST"])
def reset_password_post():
    if verify_secret_reset_string(request.form):
        new_password = request.form.get("new_password")
        confirm_password = request.form.get("confirm_password")
        if safe_str_cmp(new_password, confirm_password):
            email = request.form.get("email")
            user = User.query.filter_by(email=email).first()
            user.password = generate_password_hash(new_password, method="sha256")
            db.session.commit()
            flash('Reset successful.')
            return render_template("login.html")

        else:
            email = request.form.get("email")
            secret_reset_string = request.form.get("secret_reset_string")
            flash("The passwords must match")
            return render_template("reset_password.html", email=email, secret_reset_String=secret_reset_string)

    else:
        abort(404)