contacts = {} # initiating dictionary
def addContact():
    print("============== Add new contact ================")
    name = input("Enter your name: ")
    phone_number = int(input("Enter your phone number: "))
    email_id = input("Enter your email id: ")
    if validateMail(email_id):
            contacts[name] = {"Phone Number": phone_number, "Email ID": email_id}
            print()
            print("Contact Saved Successfully..")
    else:
        print('----X----')
        print("Enter Valid Mail Address")
        add_contact()
    
def validateMail(email):
    if '@' not in email:
        return False
    username, domain = email.split('@')
    if '.' not in domain:
        return False
    return True
def viewContacts():
    print("================= Here are your contacts====================")
    print(contacts)
    for name, info in contacts.items():
        print(f"Name: {name}")
        print(f"Phone Number: {info['Phone Number']}")
        print(f"Email ID: {info['Email ID']}")
        print()

def searchContact():
    searchName = input("Enter the name of the contact you want to search for: ")
    print("=========== Finding contact for "+searchName+" ===========")
    if searchName in contacts:
        print(f"Name: {searchName}")
        print(f"Phone Number: {contacts[searchName]['Phone Number']}")
        print(f"Email ID: {contacts[searchName]['Email ID']}")
    else:
        print(f"No contact found with the name {searchName}")

while True:
    print()
    print("=============== Welcome to Aryan's Phonebook =================")
    print()
    print("1. Add Contact")
    print("2. View Contacts")
    print("3. Search Contact")
    print("4. Exit")
    print()
    choice = input("Enter your choice: ")
    print()
    if choice == "1":
        addContact()
    elif choice == "2":
        viewContacts()
    elif choice == "3":
        searchContact()
    elif choice == "4":
        print ("Thanks for using Phonebook. See you again!")
        break
    else:
        print()
        print("Invalid choice. Please try again. ")