import random
import time

def find_indices(array, item_compare):
    return [idx for idx, value in enumerate(array) if value == item_compare]

def IsInteger(test):
    try:
        int(test)
        return True
    except ValueError:
        return False

def Homepage():
    global Score
    global Turn
    Score=0
    Turn=0
    Progress=input("Input what you want to do (Play,Settings,History,Quit): ").strip().lower()
    if Progress=="settings":
        Settings()
    elif Progress=="play":
        Play()
    elif Progress=="history":
        History()
    elif Progress=="quit":
        Score=0
        Turn=0
        print("Thank you for playing!!!")
    else:
        print("Invalid Input")
        Homepage()

def Settings():
    global Length
    global Range
    Length=input("Time: ")
    if IsInteger(Length)==True:
        Length=int(Length)
    else:
        print("Invalid Input")
        Settings()
    Range=input("Range of values: ")
    if IsInteger(Range)==True:
        Range=int(Range)
    else:
        print("Invalid Input")
        Settings()
    Homepage()
    
def History():
    veiw=input("Would you like to see the highest overall average or the highest average for a range (Overall,Range,Back): ").strip().lower()
    if veiw=="overall":
        print("The highest average is",round(max(Record),2)," correct equations per second with time used of",Times[Record.index(max(Record))],"and a the range of values", Scope[Record.index(max(Record))])
        History()
    elif veiw=="range":
        search=input("What range would you like to see?: ")
        if IsInteger(search)==True:
            lis=find_indices(Scope,int(search))
            Value=[]
            if len(lis)!=0:
                for x in range(0,len(lis)):
                    Value.append(Record[lis[x]])
                print("The highest average for the range of",search, "is",round(max(Value),2))
            else:
                print("No games have been played with that range")
            History()
        else:
            print("Invalid input")
            History()
    elif veiw=="back" or veiw=="quit":
        Homepage()
    else:
        print("Invalid input")
        History()

def Play():
    global Start_Time
    global quit
    global Length
    global Temp
    Answer=0
    Start_Time=time.time()
    print("Game starting (input 'quit' to stop game)")
    print("You have", Length, "seconds to solve equations using numbers from 1 to", Range)
    print(3)
    time.sleep(1)
    print(2)
    time.sleep(1)
    print(1)
    time.sleep(1)
    print("Go!")
    FirstLevelEquations(Range)
    if quit==False:
        print("The score is",Score,"and The turns taken is",Turn, "in a time of",Length)
        Record.append(Score/Length)
        Times.append(Length)
        Scope.append(Range)
    else:
        quit=False
        print("Game quitted")
    Homepage()

def Input_Section(Eval):
    global Start_Time
    global Turn
    global Score 
    global Range
    global Length
    global quit
    Input=input("=").strip().lower()
    if IsInteger(Input)==True:
        if int(Input)==Eval:
            print("Correct")
            Track_Time=time.time()
            Score+=1
            Turn+=1
            if Track_Time-Start_Time<Length:
                FirstLevelEquations(Range)
        else:
            print("Failure the answer was ",Eval)
            Track_Time=time.time()
            Turn+=1
            if Track_Time-Start_Time<Length:
                FirstLevelEquations(Range)
    elif Input=="quit":
        Score=0
        Turn=0
        quit=True
    else:
        print("Invalid input, try again")
        Input_Section(Eval)
    
class Math(object):
    def __init__(self, num_f, num_s, operator):
        self.num_f=num_f
        self.num_s=num_s
        self.operator=operator
    
    def Check_Divide(self):
        global Answer
        if self.num_f%self.num_s==0:
            Determiner=random.randint(0,1)
            if Determiner==0:
                self.operator="/"
    
    def Display_f(self):
        print(self.num_f,self.operator,self.num_s)
    
    def Basic_Computation(self):
        global Answer
        if self.operator=="/":
            Answer=self.num_f/self.num_s
        elif self.operator=="*":
            Answer=self.num_f*self.num_s
        elif self.operator=="+":
            Answer=self.num_f+self.num_s
        elif self.operator=="-":
            Answer=self.num_f-self.num_s
        Input_Section(Answer)

def FirstLevelEquations(range):
    Problem=Math(random.randint(1,range),random.randint(1,range),Operations[random.randint(0, 2)])
    Problem.Check_Divide()
    Problem.Display_f()
    Problem.Basic_Computation()

Length=30
Range=12
Record=[0]
Times=[0]
Scope=[0]
Operations=["*","+","-"]
Score=0
Answer=0
Turn=0
quit=False
Start_Time=time.time()

Homepage()