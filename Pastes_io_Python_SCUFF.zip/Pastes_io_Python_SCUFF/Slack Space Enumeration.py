import pytsk3
import subprocess
import re

def get_slack_space(file_entry):
    """
    Calculate and return the slack space for a given file.
    """
    file_info = file_entry.info.meta
    file_size = file_info.size
    slack_size = file_entry.info.fs_info.block_size - (file_size % file_entry.info.fs_info.block_size)
    return slack_size if slack_size != file_entry.info.fs_info.block_size else 0

def read_slack_space(fs_info, file_path):
    """
    Read and display the slack space of a given file in an image.
    """
    file_entry = fs_info.open(file_path)

    slack_size = get_slack_space(file_entry)
    if slack_size > 0:
        file_offset = file_entry.info.meta.size
        fs_info.img_info.seek(file_offset)
        slack_data = fs_info.img_info.read(slack_size)
        print(f"Slack Space Data for {file_path}:")
        print(slack_data)
    else:
        print(f"No slack space available for {file_path}")

def find_ntfs_partitions():
    """Find NTFS partitions on the system."""
    try:
        output = subprocess.check_output(['lsblk', '-f']).decode('utf-8')
        # Regex to find NTFS partitions
        partitions = re.findall(r'(\S+).*ntfs', output, re.IGNORECASE)
        return [f"/dev/{partition}" for partition in partitions]
    except subprocess.CalledProcessError:
        return []

def main():
    ntfs_partitions = find_ntfs_partitions()

    if ntfs_partitions:
        print(f"Found NTFS partitions: {ntfs_partitions}")
        for partition in ntfs_partitions:
            # Mount the partition in read-only mode
            mount_point = f"/mnt/{partition.split('/')[-1]}"
            subprocess.call(['sudo', 'mount', '-o', 'ro', partition, mount_point])
            
            # Scan for slack space in a specified file (Example: /path/to/file)
            file_path = "path/to/file"
            try:
                img = pytsk3.Img_Info(f"filesystem:{mount_point}")
                fs_info = pytsk3.FS_Info(img)
                read_slack_space(fs_info, file_path)
            finally:
                # Unmount the partition after analysis
                subprocess.call(['sudo', 'umount', mount_point])
    else:
        print("No NTFS partitions found.")

if __name__ == "__main__":
    main()