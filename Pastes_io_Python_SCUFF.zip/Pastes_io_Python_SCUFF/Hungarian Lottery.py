import random


def lotto_valasztas():
    valasz = ""
    while valasz not in ["1", "2", "3"]:
        valasz = input("Lottó választás:\nÖtöslottó: 1\nHatoslottó: 2\nHeteslottó: 3\n")
    return int(valasz)


def meg_egy_jatek():
    valasz = ""
    while valasz.lower() not in ["i", "n"]:
        valasz = input("Még egy játék? (i/n)\n")
    return valasz == "i"


legnagyobb_huzhato_szam = {5: 90, 6: 45, 7: 35}

while True:
    jatek = lotto_valasztas() + 4   #1 => 5 etc.
    szamok = [x for x in range(1, legnagyobb_huzhato_szam[jatek] + 1)]
    huzott_szamok = random.sample(szamok, k=jatek)
    print(sorted(huzott_szamok))
    if not meg_egy_jatek():
        break