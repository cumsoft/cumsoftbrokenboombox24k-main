import _io
from collections import defaultdict

aas = [
        "A",
        "C",
        "D",
        "E",
        "F",
        "G",
        "H",
        "I",
        "K",
        "L",
        "M",
        "N",
        "P",
        "Q",
        "R",
        "S",
        "T",
        "V",
        "W",
        "Y"
    ]


def check_content(line: str):

    for symbol in line:
        if symbol in aas or symbol == "-":
            return True
        else:
            return False


def display_sequences(sequences: dict):
    for idx, sequence in enumerate(sequences.keys()):
        print(f"{idx + 1}. {sequence}")


def display_content(sequence: str):
    aa_dict = defaultdict(int)

    for aa in sequence:
        aa_dict[aa] += 1

    aa_content = {}

    for k, v in aa_dict.items():
        aa_content[k] = v/len(sequence)

    for k, v in aa_content.items():
        print(f"{k}: {v}")


def read_fasta(lines: list[str]):
    seq_dict = defaultdict(str)

    for line in lines:
        try:
            if line.startswith(">"):
                current_accession = line.split()[0][1:]
            else:
                line = line.replace("\n", "")
                if not check_content(line):
                    raise ValueError
                seq_dict[current_accession] += line
        except UnboundLocalError:
            continue
        except ValueError:
            print("Invalid symbol in file")
            return

    return dict(seq_dict)


if __name__ == '__main__':
    options = ["y", "n"]

    print("load sequences with breaks? [y, n]:")
    while True:
        breaks = input("")

        if breaks in options:
            break
        else:
            print("choose between y or n")

    with open("../PF00061-seed.fasta") as f:
        lines = f.readlines()

    match breaks:
        case "y":
            pass
        case "n":
            lines = [line.replace("-", "") for line in lines]

    sequences = read_fasta(lines)

    if len(sequences) < 1:
        raise ValueError("there must be at least 1 sequence in file")

    display_sequences(sequences)

    if breaks == "n":
        print(f"Chose number of sequence to display content [1-{len(sequences)}]:")
        while True:
            n = int(input("")) - 1

            if n in range(0, len(sequences)):
                break
            else:
                print("chose sequence in valid range")

        seq = list(sequences.values())[n - 1]

        display_content(seq)