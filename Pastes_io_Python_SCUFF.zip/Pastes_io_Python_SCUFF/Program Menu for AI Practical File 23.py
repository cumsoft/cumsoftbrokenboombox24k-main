import os, json

os.system("")
esc = "\x1b"
lineLength = os.get_terminal_size().columns

print()
print(f"{esc}[0;93mWelcome to{esc}[0m".center(lineLength))
print(f"{esc}[1;92mPranit Anil Kharche's{esc}[1;36m AI Practical File{esc}[0m 2023".center(lineLength + 6))
print()

programs = json.load(open("questions.json"))

while True:
    programValue = input(f"{esc}[93m>>{esc}[0m Please Enter the Practical Program you want to run (1 - {len(programs)} / list / exit): ")
    print()

    if programValue == "exit": exit(-1)

    programNum = (int(programValue)) if programValue != "list" else "list"

    strPrograms = "\n".join(map(
        (
            lambda p:
                f"{p.get('number')}.{' ' * (max(map(lambda p: len(str(p.get('number'))) + 1, programs)) - len(str(p.get('number'))))}{esc}[38;5;75m{p.get('title')}{esc}[0m"
        ), programs
    ))

    if programValue == "list": print(f"Available programs:\n{strPrograms}\n") # Sunglasses

    elif programNum <= len(programs) and programNum > 0:
        program = programs[programNum - 1]
        programFile = f"Question{programNum}.py"

        if not os.path.isfile(f"{os.getcwd()}\{programFile}"):
            print(f"{esc}[1;91mERROR{esc}[0m: Unable to find program file at:\n\t{programFile}")
            break

        else: print(f"{esc}[105m FOUND {esc}[0m: The filepath of the program was found.")
        print(f"{esc}[1;92mFILENAME{esc}[0m: {programFile}")

        print(f"{esc}[1;92mRUNNING{esc}[0m: Running practical program `{esc}[93m{program.get('number')}. {program.get('title')}{esc}[0m`", end="\n\n")

        print((f" {esc}[1;95m{program.get('title')}"[0:lineLength - 4] + f"{esc}[0m ").center(lineLength - 2, "-"), end="\n\n")

        os.system(f"python {programFile}")
        print(f"\n\nThe program finished executing.\n")

    else:
        print(f"{esc}[1;91mERROR{esc}[0m: The provided program number is invalid.")
        break