import numpy as np
 
b = [1,3,4,5,9]
n = 11
A = [0] * n
for i in range(n): 
    A[i] = [0] * n
 
 
for i in range(n):
    for j in range (n):
        if (i==j):
            A[i][j]=0
        elif ((i-j)%11 in b):
            A[i][j] = 1
        else: 
            A[i][j] = -1 
 
 
E = [0] * n
for i in range(n): 
    E[i] = [0] * n
 
for i in range(n):
    for j in range (n):
        if (i==j):
            E[i][j]=A[i][j]-1
        else:
            E[i][j]=A[i][j]
 
 
m = 12
H = [0] * m
for i in range(m): 
    H[i] = [0] * m
 
for i in range (m):
    for j in range (m):
        if (i == 0 or j == 0):
            H[i][j] = 1
        else:
            H[i][j] = E[i-1][j-1]
 
 
print(H)
 
 
 
x = np.array([10, 0, 6, -8, -2, 9, 6, 10, 3, -10, 7, 9])
k = np.array([1, 3, 5, 7, 9, 9, 6, 10, 3, -10, 7, 9])