class HakunaMatata:

    def check(self, number):
        if number % 5 == 0 and number % 7 == 0:
            return "Hakuna Matata"
        elif number % 5 == 0:
            return "Hakuna"
        elif number % 7 == 0:
            return "Matata"
        else:
            return "Invalid"


my_tester = HakunaMatata()
n = int(input("No. of Inputs: "))
while n:
    x = int(input())
    print(my_tester.check(x))
    n -= 1