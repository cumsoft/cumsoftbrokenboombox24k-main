import nltk
from nltk.corpus import brown
import matplotlib.pyplot as plt

# Load the Brown Corpus from NLTK
nltk.download('brown')
words = brown.words()

# Create a frequency distribution of the words
freq_dist = nltk.FreqDist(words)

# Get the top 20 most common words and their frequencies
top_words = freq_dist.most_common(20)
x_values = [word[0] for word in top_words]
y_values = [word[1] for word in top_words]

# Create a bar chart of the top 20 most common words
plt.bar(x_values, y_values)
plt.xticks(rotation=45, ha='right')
plt.xlabel('Words')
plt.ylabel('Frequency')
plt.title('Top 20 Most Common Words in the English Language')
plt.show()