import time
import random
import keyboard

# Initialize game variables
red_light_duration = random.uniform(2, 5)
green_light_duration = random.uniform(2, 5)
player_moving = False
player_eliminated = False

# Define the function that checks if the player is moving during red light
def check_player_movement():
    global player_eliminated
    if not player_moving:
        player_eliminated = True

# Start the game loop
while True:
    # Set the light to red
    print("RED LIGHT")
    keyboard.wait('space')  # wait for the space key to be pressed
    start_time = time.time()  # get the current time
    player_moving = False  # reset the player movement flag
    player_eliminated = False  # reset the player eliminated flag
    # Wait for the red light to turn green
    while time.time() - start_time < red_light_duration:
        check_player_movement()  # check if the player is moving
        time.sleep(0.1)  # wait for 0.1 seconds

    # Set the light to green
    print("GREEN LIGHT")
    start_time = time.time()  # get the current time
    # Wait for the green light to turn red
    while time.time() - start_time < green_light_duration:
        check_player_movement()  # check if the player is moving
        time.sleep(0.1)  # wait for 0.1 seconds

    # If the player was eliminated during the red light, end the game
    if player_eliminated:
        print("PLAYER ELIMINATED")
        break