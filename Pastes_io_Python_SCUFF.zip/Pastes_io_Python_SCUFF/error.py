distilled_params,
        )

..\..\..\..\Anaconda3\envs\py\lib\site-packages\sqlalchemy\engine\base.py:1124:
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <sqlalchemy.engine.base.Connection object at 0x0000029134CAD0C0>
dialect = <sqlalchemy.dialects.sqlite.pysqlite.SQLiteDialect_pysqlite object at 0x0000029134B79B70>
constructor = <bound method DefaultExecutionContext._init_compiled of <class 'sqlalchemy.dialects.sqlite.base.SQLiteExecutionContext'>>       
statement = 'INSERT INTO user (username, hashed_password, email, registration_confirmation_email, profile_pic_name) VALUES (?, ?, ?, ?, ?)'   
parameters = ('fkpr[kfkuh', b'$2b$12$QbQcOjUBost/DN0O2stxIu2avgOY7pHYcFl98d9oQNfvQhYXnCyna', 'nmyles@mail.com', 0, None)
args = (<sqlalchemy.dialects.sqlite.base.SQLiteCompiler object at 0x0000029134B36A10>, [{'email': 'nmyles@mail.com', 'hashed_... b'$2b$12$QbQcOjUBost/DN0O2stxIu2avgOY7pHYcFl98d9oQNfvQhYXnCyna', 'profile_pic_name': None, 'username': 'fkpr[kfkuh'}])
conn = <sqlalchemy.pool.base._ConnectionFairy object at 0x0000029134B251E0>
context = <sqlalchemy.dialects.sqlite.base.SQLiteExecutionContext object at 0x0000029134CAE170>

    def _execute_context(
        self, dialect, constructor, statement, parameters, *args
    ):
        """Create an :class:`.ExecutionContext` and execute, returning
        a :class:`_engine.ResultProxy`.

        """

        try:
            try:
                conn = self.__connection
            except AttributeError:
                # escape "except AttributeError" before revalidating
                # to prevent misleading stacktraces in Py3K
                conn = None
            if conn is None:
                conn = self._revalidate_connection()

            context = constructor(dialect, self, conn, *args)
        except BaseException as e:
            self._handle_dbapi_exception(
                e, util.text_type(statement), parameters, None, None
            )

        if context.compiled:
            context.pre_exec()

        cursor, statement, parameters = (
            context.cursor,
            context.statement,
            context.parameters,
        )

        if not context.executemany:
            parameters = parameters[0]

        if self._has_events or self.engine._has_events:
            for fn in self.dispatch.before_cursor_execute:
                statement, parameters = fn(
                    self,
                    cursor,
                    statement,
                    parameters,
                    context,
                    context.executemany,
                )

        if self._echo:
            self.engine.logger.info(statement)
            if not self.engine.hide_parameters:
                self.engine.logger.info(
                    "%r",
                    sql_util._repr_params(
                        parameters, batches=10, ismulti=context.executemany
                    ),
                )
            else:
                self.engine.logger.info(
                    "[SQL parameters hidden due to hide_parameters=True]"
                )

        evt_handled = False
        try:
            if context.executemany:
                if self.dialect._has_events:
                    for fn in self.dialect.dispatch.do_executemany:
                        if fn(cursor, statement, parameters, context):
                            evt_handled = True
                            break
                if not evt_handled:
                    self.dialect.do_executemany(
                        cursor, statement, parameters, context
                    )
            elif not parameters and context.no_parameters:
                if self.dialect._has_events:
                    for fn in self.dialect.dispatch.do_execute_no_params:
                        if fn(cursor, statement, context):
                            evt_handled = True
                            break
                if not evt_handled:
                    self.dialect.do_execute_no_params(
                        cursor, statement, context
                    )
            else:
                if self.dialect._has_events:
                    for fn in self.dialect.dispatch.do_execute:
                        if fn(cursor, statement, parameters, context):
                            evt_handled = True
                            break
                if not evt_handled:
                    self.dialect.do_execute(
                        cursor, statement, parameters, context
                    )

            if self._has_events or self.engine._has_events:
                self.dispatch.after_cursor_execute(
                    self,
                    cursor,
                    statement,
                    parameters,
                    context,
                    context.executemany,
                )

            if context.compiled:
                context.post_exec()

            if context.is_crud or context.is_text:
                result = context._setup_crud_result_proxy()
            else:
                result = context.get_result_proxy()
                if result._metadata is None:
                    result._soft_close()

            if context.should_autocommit and self._root.__transaction is None:
                self._root._commit_impl(autocommit=True)

            # for "connectionless" execution, we have to close this
            # Connection after the statement is complete.
            if self.should_close_with_result:
                # ResultProxy already exhausted rows / has no rows.
                # close us now
                if result._soft_closed:
                    self.close()
                else:
                    # ResultProxy will close this Connection when no more
                    # rows to fetch.
                    result._autoclose_connection = True

        except BaseException as e:
>           self._handle_dbapi_exception(
                e, statement, parameters, cursor, context
            )

..\..\..\..\Anaconda3\envs\py\lib\site-packages\sqlalchemy\engine\base.py:1316:
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <sqlalchemy.engine.base.Connection object at 0x0000029134CAD0C0>, e = IntegrityError('UNIQUE constraint failed: user.username')        
statement = 'INSERT INTO user (username, hashed_password, email, registration_confirmation_email, profile_pic_name) VALUES (?, ?, ?, ?, ?)'   
parameters = ('fkpr[kfkuh', b'$2b$12$QbQcOjUBost/DN0O2stxIu2avgOY7pHYcFl98d9oQNfvQhYXnCyna', 'nmyles@mail.com', 0, None)
cursor = <sqlite3.Cursor object at 0x0000029134B2A5C0>
context = <sqlalchemy.dialects.sqlite.base.SQLiteExecutionContext object at 0x0000029134CAE170>

    def _handle_dbapi_exception(
        self, e, statement, parameters, cursor, context
    ):
        exc_info = sys.exc_info()

        if context and context.exception is None:
            context.exception = e

        is_exit_exception = not isinstance(e, Exception)

        if not self._is_disconnect:
            self._is_disconnect = (
                isinstance(e, self.dialect.dbapi.Error)
                and not self.closed
                and self.dialect.is_disconnect(
                    e,
                    self.__connection if not self.invalidated else None,
                    cursor,
                )
            ) or (is_exit_exception and not self.closed)

            if context:
                context.is_disconnect = self._is_disconnect

        invalidate_pool_on_disconnect = not is_exit_exception

        if self._reentrant_error:
            util.raise_(
                exc.DBAPIError.instance(
                    statement,
                    parameters,
                    e,
                    self.dialect.dbapi.Error,
                    hide_parameters=self.engine.hide_parameters,
                    dialect=self.dialect,
                    ismulti=context.executemany
                    if context is not None
                    else None,
                ),
                with_traceback=exc_info[2],
                from_=e,
            )
        self._reentrant_error = True
        try:
            # non-DBAPI error - if we already got a context,
            # or there's no string statement, don't wrap it
            should_wrap = isinstance(e, self.dialect.dbapi.Error) or (
                statement is not None
                and context is None
                and not is_exit_exception
            )

            if should_wrap:
                sqlalchemy_exception = exc.DBAPIError.instance(
                    statement,
                    parameters,
                    e,
                    self.dialect.dbapi.Error,
                    hide_parameters=self.engine.hide_parameters,
                    connection_invalidated=self._is_disconnect,
                    dialect=self.dialect,
                    ismulti=context.executemany
                    if context is not None
                    else None,
                )
            else:
                sqlalchemy_exception = None

            newraise = None

            if (
                self._has_events or self.engine._has_events
            ) and not self._execution_options.get(
                "skip_user_error_events", False
            ):
                # legacy dbapi_error event
                if should_wrap and context:
                    self.dispatch.dbapi_error(
                        self, cursor, statement, parameters, context, e
                    )

                # new handle_error event
                ctx = ExceptionContextImpl(
                    e,
                    sqlalchemy_exception,
                    self.engine,
                    self,
                    cursor,
                    statement,
                    parameters,
                    context,
                    self._is_disconnect,
                    invalidate_pool_on_disconnect,
                )

                for fn in self.dispatch.handle_error:
                    try:
                        # handler returns an exception;
                        # call next handler in a chain
                        per_fn = fn(ctx)
                        if per_fn is not None:
                            ctx.chained_exception = newraise = per_fn
                    except Exception as _raised:
                        # handler raises an exception - stop processing
                        newraise = _raised
                        break

                if self._is_disconnect != ctx.is_disconnect:
                    self._is_disconnect = ctx.is_disconnect
                    if sqlalchemy_exception:
                        sqlalchemy_exception.connection_invalidated = (
                            ctx.is_disconnect
                        )

                # set up potentially user-defined value for
                # invalidate pool.
                invalidate_pool_on_disconnect = (
                    ctx.invalidate_pool_on_disconnect
                )

            if should_wrap and context:
                context.handle_dbapi_exception(e)

            if not self._is_disconnect:
                if cursor:
                    self._safe_close_cursor(cursor)
                with util.safe_reraise(warn_only=True):
                    self._autorollback()

            if newraise:
                util.raise_(newraise, with_traceback=exc_info[2], from_=e)
            elif should_wrap:
>               util.raise_(
                    sqlalchemy_exception, with_traceback=exc_info[2], from_=e
                )

..\..\..\..\Anaconda3\envs\py\lib\site-packages\sqlalchemy\engine\base.py:1510:
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

    def raise_(
        exception, with_traceback=None, replace_context=None, from_=False
    ):
        r"""implement "raise" with cause support.

        :param exception: exception to raise
        :param with_traceback: will call exception.with_traceback()
        :param replace_context: an as-yet-unsupported feature.  This is
         an exception object which we are "replacing", e.g., it's our
         "cause" but we don't want it printed.    Basically just what
         ``__suppress_context__`` does but we don't want to suppress
         the enclosing context, if any.  So for now we make it the
         cause.
        :param from\_: the cause.  this actually sets the cause and doesn't
         hope to hide it someday.

        """
        if with_traceback is not None:
            exception = exception.with_traceback(with_traceback)

        if from_ is not False:
            exception.__cause__ = from_
        elif replace_context is not None:
            # no good solution here, we would like to have the exception
            # have only the context of replace_context.__context__ so that the
            # intermediary exception does not change, but we can't figure
            # that out.
            exception.__cause__ = replace_context

        try:
>           raise exception

..\..\..\..\Anaconda3\envs\py\lib\site-packages\sqlalchemy\util\compat.py:182:
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <sqlalchemy.engine.base.Connection object at 0x0000029134CAD0C0>
dialect = <sqlalchemy.dialects.sqlite.pysqlite.SQLiteDialect_pysqlite object at 0x0000029134B79B70>
constructor = <bound method DefaultExecutionContext._init_compiled of <class 'sqlalchemy.dialects.sqlite.base.SQLiteExecutionContext'>>       
statement = 'INSERT INTO user (username, hashed_password, email, registration_confirmation_email, profile_pic_name) VALUES (?, ?, ?, ?, ?)'   
parameters = ('fkpr[kfkuh', b'$2b$12$QbQcOjUBost/DN0O2stxIu2avgOY7pHYcFl98d9oQNfvQhYXnCyna', 'nmyles@mail.com', 0, None)
args = (<sqlalchemy.dialects.sqlite.base.SQLiteCompiler object at 0x0000029134B36A10>, [{'email': 'nmyles@mail.com', 'hashed_... b'$2b$12$QbQcOjUBost/DN0O2stxIu2avgOY7pHYcFl98d9oQNfvQhYXnCyna', 'profile_pic_name': None, 'username': 'fkpr[kfkuh'}])
conn = <sqlalchemy.pool.base._ConnectionFairy object at 0x0000029134B251E0>
context = <sqlalchemy.dialects.sqlite.base.SQLiteExecutionContext object at 0x0000029134CAE170>

    def _execute_context(
        self, dialect, constructor, statement, parameters, *args
    ):
        """Create an :class:`.ExecutionContext` and execute, returning
        a :class:`_engine.ResultProxy`.

        """

        try:
            try:
                conn = self.__connection
            except AttributeError:
                # escape "except AttributeError" before revalidating
                # to prevent misleading stacktraces in Py3K
                conn = None
            if conn is None:
                conn = self._revalidate_connection()

            context = constructor(dialect, self, conn, *args)
        except BaseException as e:
            self._handle_dbapi_exception(
                e, util.text_type(statement), parameters, None, None
            )

        if context.compiled:
            context.pre_exec()

        cursor, statement, parameters = (
            context.cursor,
            context.statement,
            context.parameters,
        )

        if not context.executemany:
            parameters = parameters[0]

        if self._has_events or self.engine._has_events:
            for fn in self.dispatch.before_cursor_execute:
                statement, parameters = fn(
                    self,
                    cursor,
                    statement,
                    parameters,
                    context,
                    context.executemany,
                )

        if self._echo:
            self.engine.logger.info(statement)
            if not self.engine.hide_parameters:
                self.engine.logger.info(
                    "%r",
                    sql_util._repr_params(
                        parameters, batches=10, ismulti=context.executemany
                    ),
                )
            else:
                self.engine.logger.info(
                    "[SQL parameters hidden due to hide_parameters=True]"
                )

        evt_handled = False
        try:
            if context.executemany:
                if self.dialect._has_events:
                    for fn in self.dialect.dispatch.do_executemany:
                        if fn(cursor, statement, parameters, context):
                            evt_handled = True
                            break
                if not evt_handled:
                    self.dialect.do_executemany(
                        cursor, statement, parameters, context
                    )
            elif not parameters and context.no_parameters:
                if self.dialect._has_events:
                    for fn in self.dialect.dispatch.do_execute_no_params:
                        if fn(cursor, statement, context):
                            evt_handled = True
                            break
                if not evt_handled:
                    self.dialect.do_execute_no_params(
                        cursor, statement, context
                    )
            else:
                if self.dialect._has_events:
                    for fn in self.dialect.dispatch.do_execute:
                        if fn(cursor, statement, parameters, context):
                            evt_handled = True
                            break
                if not evt_handled:
>                   self.dialect.do_execute(
                        cursor, statement, parameters, context
                    )

..\..\..\..\Anaconda3\envs\py\lib\site-packages\sqlalchemy\engine\base.py:1276:
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <sqlalchemy.dialects.sqlite.pysqlite.SQLiteDialect_pysqlite object at 0x0000029134B79B70>
cursor = <sqlite3.Cursor object at 0x0000029134B2A5C0>
statement = 'INSERT INTO user (username, hashed_password, email, registration_confirmation_email, profile_pic_name) VALUES (?, ?, ?, ?, ?)'   
parameters = ('fkpr[kfkuh', b'$2b$12$QbQcOjUBost/DN0O2stxIu2avgOY7pHYcFl98d9oQNfvQhYXnCyna', 'nmyles@mail.com', 0, None)
context = <sqlalchemy.dialects.sqlite.base.SQLiteExecutionContext object at 0x0000029134CAE170>

    def do_execute(self, cursor, statement, parameters, context=None):
>       cursor.execute(statement, parameters)
E       sqlalchemy.exc.IntegrityError: (sqlite3.IntegrityError) UNIQUE constraint failed: user.username
E       [SQL: INSERT INTO user (username, hashed_password, email, registration_confirmation_email, profile_pic_name) VALUES (?, ?, ?, ?, ?)]  
E       [parameters: ('fkpr[kfkuh', b'$2b$12$QbQcOjUBost/DN0O2stxIu2avgOY7pHYcFl98d9oQNfvQhYXnCyna', 'nmyles@mail.com', 0, None)]
E       (Background on this error at: http://sqlalche.me/e/13/gkpj)

..\..\..\..\Anaconda3\envs\py\lib\site-packages\sqlalchemy\engine\default.py:608: IntegrityError

During handling of the above exception, another exception occurred:

client = <FlaskClient <Flask 'app'>>, new_user = <User 'fkpr[kfkuh'>

    def test_verified_email(client, new_user):
        '''
        GIVEN a Flask application configured for testing
        WHEN the "/verified_email<token>" request is (GET) Also test the token is created and verified. email is sent
        THEN check that a token works.
        '''


        response = client.get("/verified_email<token>", follow_redirects=True)
        assert response.status_code == 200
        with app.test_request_context():

            # if the new_user is already added delete the user
            # This is try is if an error occurs in the try below.
            # Else the new_user is eventually added outside the try

            # Why does this work?
            #Is this to convulted?
            try:
                db.session.add(new_user)
                db.session.commit()
            except exc.IntegrityError:
                # will this work without rollback ? no
>               db.session.delete(new_user)

app\tests\functional\test_routes.py:143:
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <sqlalchemy.orm.scoping.scoped_session object at 0x0000029133078100>, args = (<User 'fkpr[kfkuh'>,), kwargs = {}

    def do(self, *args, **kwargs):
>       return getattr(self.registry(), name)(*args, **kwargs)

..\..\..\..\Anaconda3\envs\py\lib\site-packages\sqlalchemy\orm\scoping.py:163:
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <sqlalchemy.orm.session.SignallingSession object at 0x0000029134B79F30>, instance = <User 'fkpr[kfkuh'>

    def delete(self, instance):
        """Mark an instance as deleted.

        The database delete operation occurs upon ``flush()``.

        """
        if self._warn_on_events:
            self._flush_warning("Session.delete()")

        try:
            state = attributes.instance_state(instance)
        except exc.NO_STATE as err:
            util.raise_(
                exc.UnmappedInstanceError(instance),
                replace_context=err,
            )

>       self._delete_impl(state, instance, head=True)

..\..\..\..\Anaconda3\envs\py\lib\site-packages\sqlalchemy\orm\session.py:2061:
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <sqlalchemy.orm.session.SignallingSession object at 0x0000029134B79F30>
state = <sqlalchemy.orm.state.InstanceState object at 0x0000029134B377F0>, obj = <User 'fkpr[kfkuh'>, head = True

    def _delete_impl(self, state, obj, head):

        if state.key is None:
            if head:
>               raise sa_exc.InvalidRequestError(
                    "Instance '%s' is not persisted" % state_str(state)
                )
E               sqlalchemy.exc.InvalidRequestError: Instance '<User at 0x29134b37820>' is not persisted

..\..\..\..\Anaconda3\envs\py\lib\site-packages\sqlalchemy\orm\session.py:2067: InvalidRequestError

During handling of the above exception, another exception occurred:

client = <FlaskClient <Flask 'app'>>, new_user = <User 'fkpr[kfkuh'>

    def test_verified_email(client, new_user):
        '''
        GIVEN a Flask application configured for testing
        WHEN the "/verified_email<token>" request is (GET) Also test the token is created and verified. email is sent
        THEN check that a token works.
        '''


        response = client.get("/verified_email<token>", follow_redirects=True)
        assert response.status_code == 200
        with app.test_request_context():

            # if the new_user is already added delete the user
            # This is try is if an error occurs in the try below.
            # Else the new_user is eventually added outside the try

            # Why does this work?
            #Is this to convulted?
            try:
                db.session.add(new_user)
                db.session.commit()
            except exc.IntegrityError:
                # will this work without rollback ? no
                db.session.delete(new_user)
                db.session.commit()
            finally:
                try:
>                   user = User.query.filter_by(username=new_user.username).first()

app\tests\functional\test_routes.py:147:
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <flask_sqlalchemy.BaseQuery object at 0x000002913340A290>

    def first(self):
        """Return the first result of this ``Query`` or
        None if the result doesn't contain any row.

        first() applies a limit of one within the generated SQL, so that
        only one primary entity row is generated on the server side
        (note this may consist of multiple result rows if join-loaded
        collections are present).

        Calling :meth:`_query.Query.first`
        results in an execution of the underlying
        query.

        .. seealso::

            :meth:`_query.Query.one`

            :meth:`_query.Query.one_or_none`

        """
        if self._statement is not None:
            ret = list(self)[0:1]
        else:
>           ret = list(self[0:1])

..\..\..\..\Anaconda3\envs\py\lib\site-packages\sqlalchemy\orm\query.py:3429:
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <flask_sqlalchemy.BaseQuery object at 0x000002913340A290>, item = slice(0, 1, None)

    def __getitem__(self, item):
        if isinstance(item, slice):
            start, stop, step = util.decode_slice(item)

            if (
                isinstance(stop, int)
                and isinstance(start, int)
                and stop - start <= 0
            ):
                return []

            # perhaps we should execute a count() here so that we
            # can still use LIMIT/OFFSET ?
            elif (isinstance(start, int) and start < 0) or (
                isinstance(stop, int) and stop < 0
            ):
                return list(self)[item]

            res = self.slice(start, stop)
            if step is not None:
                return list(res)[None : None : item.step]
            else:
>               return list(res)

..\..\..\..\Anaconda3\envs\py\lib\site-packages\sqlalchemy\orm\query.py:3203:
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <flask_sqlalchemy.BaseQuery object at 0x0000029134CADF60>

    def __iter__(self):
        context = self._compile_context()
        context.statement.use_labels = True
        if self._autoflush and not self._populate_existing:
            self.session._autoflush()
>       return self._execute_and_instances(context)

..\..\..\..\Anaconda3\envs\py\lib\site-packages\sqlalchemy\orm\query.py:3535:
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <flask_sqlalchemy.BaseQuery object at 0x0000029134CADF60>
querycontext = <sqlalchemy.orm.query.QueryContext object at 0x0000029134A4D340>

    def _execute_and_instances(self, querycontext):
>       conn = self._get_bind_args(
            querycontext, self._connection_from_session, close_with_result=True
        )

..\..\..\..\Anaconda3\envs\py\lib\site-packages\sqlalchemy\orm\query.py:3556:
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <flask_sqlalchemy.BaseQuery object at 0x0000029134CADF60>
querycontext = <sqlalchemy.orm.query.QueryContext object at 0x0000029134A4D340>
fn = <bound method Query._connection_from_session of <flask_sqlalchemy.BaseQuery object at 0x0000029134CADF60>>
kw = {'close_with_result': True}

    def _get_bind_args(self, querycontext, fn, **kw):
>       return fn(
            mapper=self._bind_mapper(), clause=querycontext.statement, **kw
        )

..\..\..\..\Anaconda3\envs\py\lib\site-packages\sqlalchemy\orm\query.py:3571:
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <flask_sqlalchemy.BaseQuery object at 0x0000029134CADF60>
kw = {'clause': <sqlalchemy.sql.selectable.Select at 0x29134cae3b0; Select object>, 'close_with_result': True, 'mapper': <Mapper at 0x291344450f0; User>}

    def _connection_from_session(self, **kw):
>       conn = self.session.connection(**kw)

..\..\..\..\Anaconda3\envs\py\lib\site-packages\sqlalchemy\orm\query.py:3550:
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <sqlalchemy.orm.session.SignallingSession object at 0x0000029134B79F30>, mapper = <Mapper at 0x291344450f0; User>
clause = <sqlalchemy.sql.selectable.Select at 0x29134cae3b0; Select object>
bind = Engine(sqlite:///C:\Users\nmyle\OneDrive\Desktop\flaskcodeusethis\flaskblog2\app\app.db), close_with_result = True
execution_options = None, kw = {}

    def connection(
        self,
        mapper=None,
        clause=None,
        bind=None,
        close_with_result=False,
        execution_options=None,
        **kw
    ):
        r"""Return a :class:`_engine.Connection` object corresponding to this
        :class:`.Session` object's transactional state.

        If this :class:`.Session` is configured with ``autocommit=False``,
        either the :class:`_engine.Connection` corresponding to the current
        transaction is returned, or if no transaction is in progress, a new
        one is begun and the :class:`_engine.Connection`
        returned (note that no
        transactional state is established with the DBAPI until the first
        SQL statement is emitted).

        Alternatively, if this :class:`.Session` is configured with
        ``autocommit=True``, an ad-hoc :class:`_engine.Connection` is returned
        using :meth:`_engine.Engine.connect` on the underlying
        :class:`_engine.Engine`.

        Ambiguity in multi-bind or unbound :class:`.Session` objects can be
        resolved through any of the optional keyword arguments.   This
        ultimately makes usage of the :meth:`.get_bind` method for resolution.

        :param bind:
          Optional :class:`_engine.Engine` to be used as the bind.  If
          this engine is already involved in an ongoing transaction,
          that connection will be used.  This argument takes precedence
          over ``mapper``, ``clause``.

        :param mapper:
          Optional :func:`.mapper` mapped class, used to identify
          the appropriate bind.  This argument takes precedence over
          ``clause``.

        :param clause:
            A :class:`_expression.ClauseElement` (i.e.
            :func:`_expression.select`,
            :func:`_expression.text`,
            etc.) which will be used to locate a bind, if a bind
            cannot otherwise be identified.

        :param close_with_result: Passed to :meth:`_engine.Engine.connect`,
          indicating the :class:`_engine.Connection` should be considered
          "single use", automatically closing when the first result set is
          closed.  This flag only has an effect if this :class:`.Session` is
          configured with ``autocommit=True`` and does not already have a
          transaction in progress.

        :param execution_options: a dictionary of execution options that will
         be passed to :meth:`_engine.Connection.execution_options`, **when the
         connection is first procured only**.   If the connection is already
         present within the :class:`.Session`, a warning is emitted and
         the arguments are ignored.

         .. versionadded:: 0.9.9

         .. seealso::

            :ref:`session_transaction_isolation`

        :param \**kw:
          Additional keyword arguments are sent to :meth:`get_bind`,
          allowing additional arguments to be passed to custom
          implementations of :meth:`get_bind`.

        """
        if bind is None:
            bind = self.get_bind(mapper, clause=clause, **kw)

>       return self._connection_for_bind(
            bind,
            close_with_result=close_with_result,
            execution_options=execution_options,
        )

..\..\..\..\Anaconda3\envs\py\lib\site-packages\sqlalchemy\orm\session.py:1142:
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <sqlalchemy.orm.session.SignallingSession object at 0x0000029134B79F30>
engine = Engine(sqlite:///C:\Users\nmyle\OneDrive\Desktop\flaskcodeusethis\flaskblog2\app\app.db), execution_options = None
kw = {'close_with_result': True}

    def _connection_for_bind(self, engine, execution_options=None, **kw):
        if self.transaction is not None:
>           return self.transaction._connection_for_bind(
                engine, execution_options
            )

..\..\..\..\Anaconda3\envs\py\lib\site-packages\sqlalchemy\orm\session.py:1150: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <sqlalchemy.orm.session.SessionTransaction object at 0x0000029134B354B0>
bind = Engine(sqlite:///C:\Users\nmyle\OneDrive\Desktop\flaskcodeusethis\flaskblog2\app\app.db), execution_options = None

    def _connection_for_bind(self, bind, execution_options):
>       self._assert_active()

..\..\..\..\Anaconda3\envs\py\lib\site-packages\sqlalchemy\orm\session.py:409:
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <sqlalchemy.orm.session.SessionTransaction object at 0x0000029134B354B0>, prepared_ok = False, rollback_ok = False, deactive_ok = False
closed_msg = 'This transaction is closed'

    def _assert_active(
        self,
        prepared_ok=False,
        rollback_ok=False,
        deactive_ok=False,
        closed_msg="This transaction is closed",
    ):
        if self._state is COMMITTED:
            raise sa_exc.InvalidRequestError(
                "This session is in 'committed' state; no further "
                "SQL can be emitted within this transaction."
            )
        elif self._state is PREPARED:
            if not prepared_ok:
                raise sa_exc.InvalidRequestError(
                    "This session is in 'prepared' state; no further "
                    "SQL can be emitted within this transaction."
                )
        elif self._state is DEACTIVE:
            if not deactive_ok and not rollback_ok:
                if self._rollback_exception:
>                   raise sa_exc.InvalidRequestError(
                        "This Session's transaction has been rolled back "
                        "due to a previous exception during flush."
                        " To begin a new transaction with this Session, "
                        "first issue Session.rollback()."
                        " Original exception was: %s"
                        % self._rollback_exception,
                        code="7s2a",
E                       sqlalchemy.exc.InvalidRequestError: This Session's transaction has been rolled back due to a previous exception during flush. To begin a new transaction with this Session, first issue Session.rollback(). Original exception was: (sqlite3.IntegrityError) UNIQUE constraint failed: user.username
E                       [SQL: INSERT INTO user (username, hashed_password, email, registration_confirmation_email, profile_pic_name) VALUES (?, ?, ?, ?, ?)]
E                       [parameters: ('fkpr[kfkuh', b'$2b$12$QbQcOjUBost/DN0O2stxIu2avgOY7pHYcFl98d9oQNfvQhYXnCyna', 'nmyles@mail.com', 0, None)]
E                       (Background on this error at: http://sqlalche.me/e/13/gkpj) (Background on this error at: http://sqlalche.me/e/13/7s2a)

..\..\..\..\Anaconda3\envs\py\lib\site-packages\sqlalchemy\orm\session.py:289: InvalidRequestError

During handling of the above exception, another exception occurred:

client = <FlaskClient <Flask 'app'>>, new_user = <User 'fkpr[kfkuh'>

    def test_verified_email(client, new_user):
        '''
        GIVEN a Flask application configured for testing
        WHEN the "/verified_email<token>" request is (GET) Also test the token is created and verified. email is sent
        THEN check that a token works.
        '''


        response = client.get("/verified_email<token>", follow_redirects=True)
        assert response.status_code == 200
        with app.test_request_context():

            # if the new_user is already added delete the user
            # This is try is if an error occurs in the try below.
            # Else the new_user is eventually added outside the try

            # Why does this work?
            #Is this to convulted?
            try:
                db.session.add(new_user)
                db.session.commit()
            except exc.IntegrityError:
                # will this work without rollback ? no
                db.session.delete(new_user)
                db.session.commit()
            finally:
                try:
                    user = User.query.filter_by(username=new_user.username).first()
                    token = user.create_token()

                    assert token != None # assert user?
                    user = User.verify_token(token)
                    assert user != None


                    assert user.registration_confirmation_email == False

                    # test the line below with user and new_user while deleting
                    new_user = User(registration_confirmation_email=True)
                    db.session.add(new_user)
                    db.session.commit()

                    user = User.query.filter_by(username=new_user.username).first()
                    assert user.registration_confirmation_email == True

                finally:
                    # this will also work with db.session.rollback()
>                   db.session.delete(new_user)

app\tests\functional\test_routes.py:167:
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
..\..\..\..\Anaconda3\envs\py\lib\site-packages\sqlalchemy\orm\scoping.py:163: in do
    return getattr(self.registry(), name)(*args, **kwargs)
..\..\..\..\Anaconda3\envs\py\lib\site-packages\sqlalchemy\orm\session.py:2061: in delete
    self._delete_impl(state, instance, head=True)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <sqlalchemy.orm.session.SignallingSession object at 0x0000029134B79F30>
state = <sqlalchemy.orm.state.InstanceState object at 0x0000029134B377F0>, obj = <User 'fkpr[kfkuh'>, head = True

    def _delete_impl(self, state, obj, head):

        if state.key is None:
            if head:
>               raise sa_exc.InvalidRequestError(
                    "Instance '%s' is not persisted" % state_str(state)
                )
E               sqlalchemy.exc.InvalidRequestError: Instance '<User at 0x29134b37820>' is not persisted

..\..\..\..\Anaconda3\envs\py\lib\site-packages\sqlalchemy\orm\session.py:2067: InvalidRequestError
_________________________________________________________ test_password_characters __________________________________________________________

make_password_contains_a_capital = True, make_password_contains_a_number = True, make_password_contains_special_character = True
user_already_exists = False

    def test_password_characters(make_password_contains_a_capital, make_password_contains_a_number,
        make_password_contains_special_character, user_already_exists):




        # Use plaintext password
        # new user should not fail at all of the asserts below
        assert make_password_contains_a_capital == True
        assert make_password_contains_a_number == True
        assert make_password_contains_special_character == True
>       assert user_already_exists == True
E       assert False == True

app\tests\unit\test_functions.py:12: AssertionError
________________________________________________________ test_new_user_with_fixture _________________________________________________________ 

new_user = <User 'fkpr[kfkuh'>, plaintext_password = 'pojkp[kjpj[pj'

    def test_new_user_with_fixture(new_user,  plaintext_password = 'pojkp[kjpj[pj'):
        # testing_hashed_password = hashed_password
        # assert new_user.id == 5
        # assert new_user.id == 0


>       new_user = User.query.filter_by(username=new_user.username).first()

app\tests\unit\test_models.py:11:
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
..\..\..\..\Anaconda3\envs\py\lib\site-packages\sqlalchemy\orm\query.py:3429: in first
    ret = list(self[0:1])
..\..\..\..\Anaconda3\envs\py\lib\site-packages\sqlalchemy\orm\query.py:3203: in __getitem__
    return list(res)
..\..\..\..\Anaconda3\envs\py\lib\site-packages\sqlalchemy\orm\query.py:3535: in __iter__
    return self._execute_and_instances(context)
..\..\..\..\Anaconda3\envs\py\lib\site-packages\sqlalchemy\orm\query.py:3556: in _execute_and_instances
    conn = self._get_bind_args(
..\..\..\..\Anaconda3\envs\py\lib\site-packages\sqlalchemy\orm\query.py:3571: in _get_bind_args
    return fn(
..\..\..\..\Anaconda3\envs\py\lib\site-packages\sqlalchemy\orm\query.py:3550: in _connection_from_session
    conn = self.session.connection(**kw)
..\..\..\..\Anaconda3\envs\py\lib\site-packages\sqlalchemy\orm\session.py:1142: in connection
    return self._connection_for_bind(
..\..\..\..\Anaconda3\envs\py\lib\site-packages\sqlalchemy\orm\session.py:1150: in _connection_for_bind
    return self.transaction._connection_for_bind(
..\..\..\..\Anaconda3\envs\py\lib\site-packages\sqlalchemy\orm\session.py:409: in _connection_for_bind
    self._assert_active()
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <sqlalchemy.orm.session.SessionTransaction object at 0x0000029134B354B0>, prepared_ok = False, rollback_ok = False, deactive_ok = False
closed_msg = 'This transaction is closed'

    def _assert_active(
        self,
        prepared_ok=False,
        rollback_ok=False,
        deactive_ok=False,
        closed_msg="This transaction is closed",
    ):
        if self._state is COMMITTED:
            raise sa_exc.InvalidRequestError(
                "This session is in 'committed' state; no further "
                "SQL can be emitted within this transaction."
            )
        elif self._state is PREPARED:
            if not prepared_ok:
                raise sa_exc.InvalidRequestError(
                    "This session is in 'prepared' state; no further "
                    "SQL can be emitted within this transaction."
                )
        elif self._state is DEACTIVE:
            if not deactive_ok and not rollback_ok:
                if self._rollback_exception:
>                   raise sa_exc.InvalidRequestError(
                        "This Session's transaction has been rolled back "
                        "due to a previous exception during flush."
                        " To begin a new transaction with this Session, "
                        "first issue Session.rollback()."
                        " Original exception was: %s"
                        % self._rollback_exception,
                        code="7s2a",
E                       sqlalchemy.exc.InvalidRequestError: This Session's transaction has been rolled back due to a previous exception during flush. To begin a new transaction with this Session, first issue Session.rollback(). Original exception was: (sqlite3.IntegrityError) UNIQUE constraint failed: user.username
E                       [SQL: INSERT INTO user (username, hashed_password, email, registration_confirmation_email, profile_pic_name) VALUES (?, ?, ?, ?, ?)]
E                       [parameters: ('fkpr[kfkuh', b'$2b$12$QbQcOjUBost/DN0O2stxIu2avgOY7pHYcFl98d9oQNfvQhYXnCyna', 'nmyles@mail.com', 0, None)]
E                       (Background on this error at: http://sqlalche.me/e/13/gkpj) (Background on this error at: http://sqlalche.me/e/13/7s2a)

..\..\..\..\Anaconda3\envs\py\lib\site-packages\sqlalchemy\orm\session.py:289: InvalidRequestError
============================================================= warnings summary ============================================================== 
app\__init__.py:87
  C:\Users\nmyle\OneDrive\Desktop\flaskcodeusethis\flaskblog2\app\__init__.py:87: UserWarning: The name 'userinfo' is already registered for this blueprint. Use 'name=' to provide a unique name. This will become an error in Flask 2.1.
    app.register_blueprint(userinfo)

app\__init__.py:88
  C:\Users\nmyle\OneDrive\Desktop\flaskcodeusethis\flaskblog2\app\__init__.py:88: UserWarning: The name 'postinfo' is already registered for this blueprint. Use 'name=' to provide a unique name. This will become an error in Flask 2.1.
    app.register_blueprint(postinfo)

app\__init__.py:89
  C:\Users\nmyle\OneDrive\Desktop\flaskcodeusethis\flaskblog2\app\__init__.py:89: UserWarning: The name 'mail' is already registered for this blueprint. Use 'name=' to provide a unique name. This will become an error in Flask 2.1.
    app.register_blueprint(mail)

app\__init__.py:90
  C:\Users\nmyle\OneDrive\Desktop\flaskcodeusethis\flaskblog2\app\__init__.py:90: UserWarning: The name 'payment' is already registered for this blueprint. Use 'name=' to provide a unique name. This will become an error in Flask 2.1.
    app.register_blueprint(payment)

app/tests/functional/test_routes.py::test_verified_email
  C:\Users\nmyle\Anaconda3\envs\py\lib\site-packages\itsdangerous\jws.py:201: DeprecationWarning: JWS support is deprecated and will be removed in ItsDangerous 2.1. Use a dedicated JWS/JWT library such as authlib.
    super().__init__(secret_key, **kwargs)

-- Docs: https://docs.pytest.org/en/stable/how-to/capture-warnings.html
========================================================== short test summary info ========================================================== 
FAILED app/tests/functional/test_routes.py::test_verified_email - sqlalchemy.exc.InvalidRequestError: Instance '<User at 0x29134b37820>' is...
FAILED app/tests/unit/test_functions.py::test_password_characters - assert False == True
FAILED app/tests/unit/test_models.py::test_new_user_with_fixture - sqlalchemy.exc.InvalidRequestError: This Session's transaction has been ...