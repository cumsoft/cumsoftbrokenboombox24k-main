import numpy as np
import pandas as pd

## In case of unknown 'party' during training
a) discard samples
b) data injection 
c) and others... 

def calculate_probabilities(df, size):
    """ Conditional probabilities are stored in dictionaries """
    df_dict = {}
    for col_name in df.columns[1:]:
        df_dict[col_name] = {'y': 0, 'n': 0, '?': 0}
        for item in df[col_name]:  ## [y,y,n,?,n,n,n,y,...] - column for some policy, for some party
            df_dict[col_name][item] += 1

	# Now, df_dict[col_name] stores number of votes per type, e.g. {'y': 190, 'n': 124, "?": 3}
	# df_dict = {'handicapped-infants': {'y': 190, 'n': 124, "?": 3}, 'feature': {...}}
	
	## No Laplace smoothing, get probabilities by dividing on size:
	## {'y': 190/317, 'n': 124/317, ...} ## (!!) probs sum to 1!

	## Laplace smoothing 
	## It could be case that {"y": 314, "?": 3, "n": 0 (!)}
	## Problem is: zero-probability for 'n'!!

	## {'y': 191/320, 'n': 125/320, '?': 1/320}  # escape zero-prob 

    for col_name in df.columns[1:]:
        for item in df_dict[col_name]:
            df_dict[col_name][item] = (df_dict[col_name][item] + 1) / (size + 3)

    return df_dict

# Bayes rule
# post_prob = prior x likelihood / norm-factor
# in log-space: log(pos_prob) = log(prob) + log(likelihood) - log(norm-factor)

def train_naive_bayes(train_df):
    """ Training of Naive Bayes Classifier """
    size = train_df["party"].shape[0]  ## number of samples 

    prior_republican = (train_df["party"] == "republican").sum(axis=0) / size  ## relative number of republicans, [0-1]
    prior_democrat = (train_df["party"] == "democrat").sum(axis=0) / size  ## relative number of democrats, [0-1]
    prior = [prior_republican, prior_democrat]  # e.g. [0.8, 0.2]

    republican_df = train_df.loc[train_df["party"] == "republican"]  ## all 'republican' samples
    democrat_df = train_df.loc[train_df["party"] == "democrat"]  ## all 'democrat' samples

    republican_size = republican_df.shape[0]  ##
    democrat_size = democrat_df.shape[0]  ## 

    republican_dict = calculate_probabilities(republican_df, republican_size)
	## republican_dict = {'feature1' : {'y': prob, 'n': prob, '?': prob}, ... }

    democrat_dict = calculate_probabilities(democrat_df, democrat_size)
	## ... 

    vote_list = [republican_dict, democrat_dict]  ## in Bayes: likelihood p(x_i | C_k), k=1,2,3

    return prior, vote_list


def test_naive_bayes(test_data, prior, vote_list):
    """ Testing of Naive Bayes Classifier """
    max_score = 0
    answer = 0

    for index in range(len(prior)):  ## always 2
        score = np.log(prior[index])  ## log-prob of prior 
        for i, col_name in enumerate(vote_list[index].keys()):  ## col_name in ['handicapped-infants', ...]
            score += np.log(vote_list[index][col_name][test_data[i]])  ## test_data[i] is y,n,? for current policy
        if index == 0:
            max_score = score
        elif score > max_score:
            max_score = score
            answer = index
    return "republican" if answer == 0 else "democrat"  ## stupid way to compare scores...


def main():
    names_columns = ["party", "handicapped-infants", "water-project-cost-sharing",
                     "adoption-of-the-budget-resolution", "physician-fee-freeze",
                     "el-salvador-aid", "religious-groups-in-schools", "anti-satellite-test-ban",
                     "aid-to-nicaraguan-contras", "mx-missile", "immigration",
                     "synfuels-corporation-cutback", "education-spending", "superfund-right-to-sue",
                     "crime", "duty-free-exports", "export-administration-act-south-africa"]

    df = pd.read_csv("house-votes-84.data", names=names_columns)

    accuracy = 0
    list_df = []  ## 435 CV (44, 44, 44, 44, 44, 43, 43, 43, 43, 43), binning 
    df_remainder = df
    
    while len(list_df) < 10:
        if len(list_df) < 5:
            df_chunk = df_remainder.sample(n=44)
        else:
            df_chunk = df_remainder.sample(n=43)
        df_remainder = df_remainder.drop(df_chunk.index)
        list_df.append(df_chunk)

    for index, test in enumerate(list_df):  ## (0, chunk_1), (1, chunk_2), ... (9, chunk_10)
        test_df = test  ## cross-evaluation on test
        train_df = pd.concat(list_df[:index] + list_df[index+1:])
        prior, vote_list = train_naive_bayes(train_df)

        turn_accuracy = 0  # for the current choice of 'test'
        for row in range(test_df.shape[0]):
            if test_df.iloc[row]["party"] == test_naive_bayes(test_df.iloc[row].drop("party"), prior, vote_list):
                turn_accuracy += 1

        print('Accuracy on turn', index, "-->", turn_accuracy / test_df.shape[0])
        accuracy += turn_accuracy / test_df.shape[0]  ## mean of all cross-evaluation runs, i.e. avg over 10 
    print("Total accuracy is: ", accuracy / 10)


if __name__ == "__main__":
    main()