# Udayveer's Calculator
def calculate(a, b, formula):
  if formula == '+':
    return a + b
  elif formula == '-':
    return a - b
  elif formula == '*':
    return a * b
  elif formula == '/':
    return a / b
print('Choose Any Random Number!')
a = float(input())
print('Choose A Second Number!')
b = float(input())
print('Do You Want To * / - or + ?')
# If You Don't Know Meaning Of The Symbols, Heres The Meaning Of Them! In Python.
print('The * Means Multiplication, The - Means Subtraction, The + Means Addition And The / Means Division.')
formula = input()
Answer = calculate(a, b, formula)
print(Answer)