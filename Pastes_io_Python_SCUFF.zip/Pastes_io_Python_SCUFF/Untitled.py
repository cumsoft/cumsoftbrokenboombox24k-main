import pandas
import seaborn
 
data = pandas.read_csv('support_data.csv')
 
# названия сегментов и интервалов
segments_old = ['Segment 0', 'Segment 1', 'Segment 2']
segments_new = ['Потенциальные клиенты', 'Обычные клиенты', 'VIP-клиенты']
intervals = ['До внедрения роботов', 'После внедрения роботов']
 
intervals_column = list(data['interval'])
segments_column = list(data['segment'])
score_column = list(data['score'])
 
# средние оценки
mean_scores = []
 
for i in segments_old:
    sum_before = 0
    len_before = 0
    sum_ater = 0
    len_after = 0
    for index in range(len(data)):
        if segments_column[index] == i:
            if data['interval'][index] == 'До внедрения роботов':
                sum_before += data['score'][index]
                len_before = len_before + 1
            else:
                sum_ater += data['score'][index]
                len_after = len_after + 1
    vv = [sum_before / len_before, sum_ater / len_after]
    mean_scores.append(vv)  
print(mean_scores)
seaborn.heatmap(mean_scores, xticklabels=intervals, yticklabels=segments_new, annot=True, cmap='RdYlGn')