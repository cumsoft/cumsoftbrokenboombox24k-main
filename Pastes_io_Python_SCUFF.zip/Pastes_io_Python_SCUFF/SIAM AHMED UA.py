def getUA():
    dalv=random.choice(["2.1.0","1.6.0"])
    andv=random.randint(7,15)
    device="SM-G2830 ES"
    b2=f"{random.randint(100000,999999)}.{str(random.randint(1,999)).zfill(3)}"
    screen=[random.choice(["1.6","2.5","3","2.0"]),random.choice(["1080","720","1980"]),random.randint(1200,4800)]
    scrn="{"+f"density={screen[0]},width={screen[1]},height={screen[2]}"+"}"
    Build=random.choice("SPQOPMJLIR")+random.choice(string.ascii_uppercase)+random.choice(string.ascii_uppercase)+random.choice(string.digits)+random.choice(string.ascii_uppercase)
    #f"SQ1A.{random.randint(100000,999999)}.{str(random.randint(1,51)).zfill(3)}.{random.choice('ABCD')}1"
    app="katana"#random.choice(["katana","orca"])
    return f"Dalvik/2.1.0 (Linux; U; Android {andv}; {device} Build/{Build}) [FBAN/FB4A;FBAV/40806.0.0.13.115;FBBV/41127812106;FBRV/0;FBPN/com.facebook.{app};FBLC/bn_BD;FBMF/Apple;FBBD/iPhone;FBDV/{device};FBSV/{andv};FBCA/armeabi-v7a:armeabi;FBDM/{scrn};FB_FW/1;]"