# FF match grouper
# Ilpo Kantonen 26 August 2023

from csv import reader

def read_matchlist(fname_p='') -> list:
    if fname_p == '':
        return None
    filename = fname_p
    tempkits = []
    try:
        with open(filename, 'r') as read_obj:
            csv_reader = reader(read_obj)
            ekarivi = True   # Ohita ensimmäinen header-rivi mätsilistasta
            for m in csv_reader:
                if ekarivi == False:
                   tempkits.append(m)
                else:
                    ekarivi = False
    except (IOError, OSError) as err:
        print(err)
        return []
    finally:
        if read_obj is not None:
            read_obj.close()
    return tempkits

def sama_nimi(eka,toka) -> bool:
    if len(eka) != len(toka):
        return False
    for i in range(len(eka)):
        if eka[i] != toka[i]:
            return False
    return True

if __name__ == '__main__':
    PATH = '/path/to/matchlistfiles/'
    t_matchit = read_matchlist(PATH + 'Terttu.csv')
    j_matchit = read_matchlist(PATH + 'Jorma.csv')

    samoja = 0
    for a in t_matchit:
        for b in j_matchit:
            if sama_nimi(a[0], b[0]):
                samoja += 1

    print('Tertulla', len(t_matchit), 'ja Jormalla', len(j_matchit), 'ja yhteisiä FF-mätsejä', samoja, 'mätsiä.')