import random,string

def genUA():

    

    #Android Versi

    andv= random.randint(3,15)

    

    #device name

    device=f"SM-N{random.randint(100,999)}{random.choice(string.ascii_uppercase)}"

    #build

    build=f"SP1A.{random.randint(100000,999999)}.{random.randint(100,999)}"

    #Chrome Version

    chrmv=f"{random.randint(20,115)}.0.{random.randint(1000,9999)}.{random.randint(100,999)}"

    

    #Facebook App Version

    FBAV=f"{random.randint(50,420)}.0.0.{random.randint(10,99)}.{random.randint(100,999)}"

    

    ua=f"Mozilla/5.0 (Linux; Android {andv}; {device} Build/{build}; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/{chrmv} Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/{FBAV};]"

    

    return ua

    

#for printing the ua

print(genUA())