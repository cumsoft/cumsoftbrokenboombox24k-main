import re
import math

class LispInterpreter:
    def __init__(self):
        self.global_env = {
            '+': lambda *args: sum(args),
            '-': lambda *args: args[0] - sum(args[1:]),
            '*': lambda *args: math.prod(args),
            '/': lambda *args: args[0] / math.prod(args[1:]),
            'mod': lambda a, b: a % b,
            'sqrt': lambda x: math.sqrt(x),
            'define': self.define,
            'if': self.if_expr,
            'lambda': self.lambda_expr
        }

    def tokenize(self, program):
        return program.replace('(', ' ( ').replace(')', ' ) ').split()

    def parse(self, tokens):
        if len(tokens) == 0:
            raise SyntaxError("Unexpected EOF")

        token = tokens.pop(0)

        if token == '(':
            parsed_expr = []
            while tokens[0] != ')':
                parsed_expr.append(self.parse(tokens))
            tokens.pop(0)  # Pop off ')'
            return parsed_expr
        elif token == ')':
            raise SyntaxError("Unexpected )")
        else:
            return self.atom(token)

    def atom(self, token):
        try:
            return int(token)
        except ValueError:
            try:
                return float(token)
            except ValueError:
                return token

    def eval_expr(self, expr, environment):
        if isinstance(expr, str):  # variable reference
            return environment.get(expr, expr)
        elif not isinstance(expr, list):  # constant literal
            return expr
        elif expr[0] in self.global_env:  # built-in function call
            func = self.global_env[expr[0]]
            args = [self.eval_expr(arg, environment) for arg in expr[1:]]
            return func(*args)
        elif expr[0] == 'if':  # conditional expression
            return self.if_expr(expr, environment)
        elif expr[0] == 'define':  # variable/function definition
            return self.define(expr, environment)
        elif expr[0] == 'lambda':  # function definition
            return self.lambda_expr(expr, environment)
        else:  # user-defined function call
            func = self.eval_expr(expr[0], environment)
            args = [self.eval_expr(arg, environment) for arg in expr[1:]]
            return func(*args)

    def define(self, expr, environment):
        _, variable, value = expr
        environment[variable] = self.eval_expr(value, environment)

    def if_expr(self, expr, environment):
        _, condition, true_expr, false_expr = expr
        if self.eval_expr(condition, environment):
            return self.eval_expr(true_expr, environment)
        else:
            return self.eval_expr(false_expr, environment)

    def lambda_expr(self, expr, environment):
        _, parameters, body = expr
        return lambda *args: self.eval_expr(body, dict(zip(parameters, args)))

    def interpret(self, program):
        tokens = self.tokenize(program)
        ast = self.parse(tokens)
        return self.eval_expr(ast, self.global_env)

    def repl(self):
        print("Welcome to the Lisp Interpreter. Type '(exit)' to exit.")
        while True:
            try:
                user_input = input(">>> ")
                if user_input.lower() == "(exit)":
                    break
                result = self.interpret(user_input)
                print(result)
            except (SyntaxError, TypeError, NameError) as e:
                print(f"Error: {e}")

if __name__ == "__main__":
    interpreter = LispInterpreter()
    interpreter.repl()