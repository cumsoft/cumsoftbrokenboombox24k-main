from tabnanny import verbose
from unittest.util import _MAX_LENGTH
from django.db import models
 
# Create your models here.
 
class Category(models.Model):
    title = models.CharField(max_length=50)
    parrent = models.ForeignKey('Category',on_delete=models.DO_NOTHING,verbose_name='parrent',blank=True,null=True)
 
 
class Article(models.Model):
    name = models.CharField('Article',max_length=80)
    link = models.CharField('Link',max_length=500)
 
 
class Comment(models.CharField):
    by = models.CharField("By",max_length=60)
    article = models.ForeignKey('Article',on_delete=models.DO_NOTHING,verbose_name='article')
    comment = models.ForeignKey('Comment',on_delete=models.DO_NOTHING,verbose_name='comment')