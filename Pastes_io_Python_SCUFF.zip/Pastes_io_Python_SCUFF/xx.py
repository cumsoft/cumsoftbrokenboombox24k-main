# coding: utf-8
import csv

INPUT_FILE = 'report.csv'

def process(limit, columns=[], input_lines=[]):
    """Process data"""
    fh = open(INPUT_FILE)
    input = {}
    cnt = 0
    if not input_lines:
        input_lines.extend(csv.reader(fh))

    for l in input_lines:
        tid = l[0]
        amount = l[1]
        category = l[2]
        try:
            amount = float(amount)
        except Exception:
            try:
                amount = int(amount)
            except ValueError:
                amount = None
        cnt += 1
        if category not in input.keys():
            input[category] = []
        input[category] += (tid, amount, category)

    for category, rows in input.items():
        batch = 1
        output = []
        headers = []
        for row in rows:
            if 'tid' in columns:
                headers.append('tid')
                output.append(row[0])
            if 'category' in columns:
                headers.append('category')
                output.append(row[2])
            if 'amount' in columns:
                headers.append('amount')
                output.append(row[1])

            if cnt > limit:
                cnt = 0
                batch += 1
                output[0:0] = [headers]
                w = open(category + '_' + batch + '.csv', 'a')
                writer = csv.writer(w)
                [writer.writerow(o) for o in output if o[2] != None]
                w.close()
                output[:] = []
    fh.close()
    pass

process(100, ['tid', 'amount'])