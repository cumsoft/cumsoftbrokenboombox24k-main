from pywinauto import Application
import pyautogui
import sys
import subprocess
import win32gui
import win32com.client
import psutil
import time
import pygetwindow as gw



def sap_force_login():
    path = r"C:\Program Files (x86)\SAP\FrontEnd\SAPgui\saplogon.exe"
    subprocess.Popen(path)
    time.sleep(3)

    SapGuiAuto = win32com.client.GetObject('SAPGUI')
    if not type(SapGuiAuto) == win32com.client.CDispatch:
        sys.exit()

    application = SapGuiAuto.GetScriptingEngine
    if not type(application) == win32com.client.CDispatch:
        SapGuiAuto = None
        sys.exit()

    connection = application.OpenConnection("4 GSI ERP - Production [PC1]", True)
    if not type(connection) == win32com.client.CDispatch:
        application = None
        SapGuiAuto = None
        sys.exit()

    # Assuming one session per connection for simplicity
    session = connection.Children(0)
    if not type(session) == win32com.client.CDispatch:
        connection = None
        application = None
        SapGuiAuto = None
        sys.exit()

    try:
        session.findById("wnd[1]/usr/radMULTI_LOGON_OPT1").Select()
        session.findById("wnd[1]").sendVKey(0)
    except win32com.client.pywintypes.com_error as e:
        return None

    return session


def kill_process(process_name):
    try:
        result = subprocess.run(['taskkill', '/f', '/im', process_name], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if result.returncode != 0:
            raise Exception(result.stderr.decode('utf-8').strip())
    except Exception:
        pass    

def find_sap_windows(title):
    def window_enum_callback(hwnd, results):
        if win32gui.GetWindowText(hwnd).startswith(title):
            results.append(hwnd)
    
    results = []
    win32gui.EnumWindows(window_enum_callback, results)
    return results
def get_existing_sap_sessions(window_title):
    hwnds = find_sap_windows(window_title)
    
    open_sessions = []
    
    if hwnds:
        SapGuiAuto = win32com.client.GetObject("SAPGUI")
        if not type(SapGuiAuto) == win32com.client.CDispatch:
            return None

        application = SapGuiAuto.GetScriptingEngine
        if not type(application) == win32com.client.CDispatch:
            return None
        
        for connection in application.Children:
            for session in connection.Children:
                open_sessions.append(session)
        
    return open_sessions


def open_extra_sessions(session, required_sessions, max_sessions=6): ##### update max sessions here
    current_sessions = len(get_existing_sap_sessions("SAP Easy Access"))
    sessions_to_open = min(max_sessions - current_sessions, required_sessions - current_sessions)
    for _ in range(sessions_to_open):
        session.findById("wnd[0]/tbar[0]/okcd").text = "/o"
        session.findById("wnd[0]").sendVKey(0)
        session.findById("wnd[1]").sendVKey(5)
        time.sleep(2)
        
def create_sessions(session):
    for i in range(4):
        try:
            session.findById("wnd[0]/tbar[0]/okcd").text = "/o"
            session.findById("wnd[0]").sendVKey(0)
            session.findById("wnd[1]").sendVKey(5)
        except Exception:
            # Print the error message and exit the function
            print("Error found! Exiting the function...")
            return




def kill_errors():
    errors_found = False  # Flag to track if errors were found

    while True:
        for window in gw.getAllWindows():
            if window.title == 'SAP GUI for Windows 770' or window.title == 'Error':
                window.close()
                errors_found = True
                print("SAP Error window closed...")
                time.sleep(2)    
        if not errors_found:
            print("No errors found")
            break  # Exit the function if no errors were found

        # Reset the flag for the next iteration
        errors_found = False

def count_process_instances(process_name):
    count = 0
    for proc in psutil.process_iter(['name']):
        try:
            if process_name.lower() in proc.info['name'].lower():
                count += 1
        except (psutil.NoSuchProcess ,psutil.AccessDenied ,psutil.ZombieProcess):
            pass
    return count;

if __name__ == "__main__":
    window_title = "SAP Easy Access"

    print(f"Found {count_process_instances('SAPMonitorGSI.exe')} SAPMonitorGSI.exe instances running...")
    if count_process_instances('SAPMonitorGSI.exe') > 2:
         print("Already running, exiting the program...")
         time.sleep(3)
         sys.exit(0)  

    while True:
        print("Checking for errors...")            
        kill_errors()
        time.sleep(5)
        print("Checking for errors again...")            
        kill_errors()        
        sessions = get_existing_sap_sessions(window_title)

        if not sessions:
            print("No sessions found, opening new sessions...")
            session = sap_force_login()
            time.sleep(2)
            kill_errors()
            create_sessions(session)
            sessions = get_existing_sap_sessions(window_title)  # Update sessions after creating new sessions

        session_count = len(sessions)
        print(f"Found {session_count} open SAP session(s)")

        if session_count < 6:
            required_sessions = 6  # you want total 6 sessions open
            print(f"Opening new sessions...")
            # Since session should be of type 'SapGui.ScriptingCtrl.1' (based on your script), 
            # you can use the last session from the list of sessions for the session parameter
            open_extra_sessions(sessions[-1], required_sessions)
        print("Next check in 30mins..")
        time.sleep(150)  # wait for 1hr seconds