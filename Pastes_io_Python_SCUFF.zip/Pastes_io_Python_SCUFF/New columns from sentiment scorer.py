import pandas as pd
import numpy as np
from random import random

# Setting up a dataframe and functions that resemble (I assume) what you currently have.
# Meaning, you don't need this part, assuming you're returning a tuple of scores in your
# real function.
def get_sentiment(text: str) -> tuple[float, float, float]:
    """Dummy function representing your sentiment scorer

    Args:
        text: text to be analyzed

    Returns:
        tuple: (negative score, neutral score, positive score)
    """
    # Actual sentiment calculation happens here.
    negative_score = random()
    neutral_score = random()
    positive_score = random()

    return (negative_score, neutral_score, positive_score)

## Dummy dataframe representing your actual dataframe with text.
orig_df = pd.DataFrame('Stuff', index=np.arange(100), columns=['Text'])

# Okay, this is the stuff you should actually add to your code
## Apply your sentiment scorer to each row of the text column. 
## Returns a pandas Series whose rows are the tuples returned by the function
sent_rows = orig_df['Text'].apply(get_sentiment)

## Split up each tuple into three new columns, converting it into a dataframe that we can merge with orig_df.
## (This seems weird [and it is weird], but the pd.Series() function applied to a tuple cell splits it up into 
## separate columns.
sent_df = sent_rows.apply(pd.Series)

## Now add new columns to the dataframe and assign our sentiment scores to them
new_df = pd.concat((orig_df, sent_df), axis=1)

## Update column names (preserving original column names)
new_df.columns = (*orig_df.columns, 'Neg_Senti', 'Neut_Senti', 'Pos_Senti')