class TreeNode:
    def __init__(self, type_val, class_val=None, freq_val=None, att_val=None, forks_val=0):
        self.is_subtree = int(type_val)
        self.branch_count = int(forks_val)
        self.fallback_to = class_val
        self.split_by = att_val
        if self.is_subtree:
            self.children = dict()
        else:
            self.children = None
    def add_child(self, key, value):
        self.children[key] = value

def get_node(file):
    assert (line := file.readline())
    kvs = dict()
    for t in line.split():
        k,v = t.split('=')
        v = v.strip('"')
        kvs[k + '_val'] = v
    node = TreeNode(**kvs)
    if node.is_subtree:
        get_node(file)
        node.add_child(0, get_node(file))
        node.add_child(1, get_node(file))
    return node

def get_tree(path):
    with open(path, 'rt') as file:
        assert file.readline().startswith('id=')
        assert file.readline().startswith('entries=')
        tree = get_node(file)
    return tree

def print_node(node, pref=''):
    if node.is_subtree:
        print(f'{pref}if {node.split_by}:')
        print_node(node.children[1], pref+'  ')
        print(f'{pref}else:')
        print_node(node.children[0], pref+'  ')
    else:
        print(f'{pref}return {repr(node.fallback_to)}')

tree = get_tree('0.tree')
print_node(tree)