# Importation de la classe FastAPI du module fastapi.
# FastAPI est une bibliothèque moderne et rapide (haute performance) pour la création d'API
# avec Python 3.6+ basée sur les annotations de type standard Python.

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from sql import get_cursor


# On crée un modèle de données avec Pydantic.
# C'est une classe qui hérite de la classe BaseModel.
# Chaque attribut de la classe est un champ de données.
# Cette classe modèle un item quelconque qui va nous servir d'exemple.
class Item(BaseModel):
    id: int | None = Field(primary_key=True, default=None)
    name: str
    description: str
    price: float

    class Config:
        populate_by_name = (
            True  # Autorise à peupler le modèle avec les noms des attributs
        )


# Création d'une instance de la classe FastAPI.
# C'est l'application principale ou l'entrée de votre projet.
app = FastAPI()


# Définition d'une route ou d'un chemin avec la méthode GET à la racine ("/").
# async et await sont utilisés pour la programmation asynchrone en Python,
# ce qui permet d'améliorer les performances de votre application.
# La fonction root() est une opération de lecture qui renvoie un dictionnaire.
@app.get("/")
async def root():
    return {"message": "Hello World"}


# Définition d'une autre route avec la méthode GET à "/hello/{name}".
# "{name}" est un paramètre de chemin qui est passé à la fonction say_hello().
# La fonction say_hello() prend "name" comme argument et renvoie un message personnalisé.
@app.get("/hello/{name}")
async def say_hello(name: str):
    return {"message": f"Hello {name}"}


# Définition d'une autre route avec la méthode GET à "/items/".
@app.get("/items/")
async def get_all_items():
    with get_cursor() as cursor:
        cursor.execute("SELECT id, name, description, price FROM _items")
        columns = [desc[0] for desc in cursor.description]
        items = cursor.fetchall()
        return [Item(**dict(zip(columns, item))) for item in items]


# Définition d'une autre route avec la méthode GET à "/items/{item_id}".
@app.get("/items/{item_id}")
async def get_item(item_id: int):
    with get_cursor() as cursor:
        cursor.execute(
            "SELECT * FROM _items WHERE id = %s", (item_id,)
        )
        columns = [desc[0] for desc in cursor.description]
        item = cursor.fetchone()
        if item is None:
            raise HTTPException(status_code=404, detail="Item not found")

        data = dict(zip(columns, item))
        return Item(**data)


# Définition d'une autre route avec la méthode POST à "/items/".
# La fonction create_item() prend un objet de type Item comme argument.
# Cet objet est validé par Pydantic et renvoyé.
@app.post("/items/")
async def create_item(item: Item):
    with get_cursor() as cursor:
        cursor.execute(
            "INSERT INTO _items (name, description, price) VALUES (%s, %s, %s) RETURNING id",
            (item.name, item.description, item.price),
        )
        item.id = cursor.fetchone()[0]
    return item


# Définition d'une autre route avec la méthode DELETE à "/items/{item_id}".
@app.delete("/items/{item_id}")
async def delete_item(item_id: str):
    with get_cursor() as cursor:
        cursor.execute(
            "DELETE FROM _items WHERE id = %s RETURNING id",
            (item_id,),
        )
        deleted_id = cursor.fetchone()
        if deleted_id is None:
            raise HTTPException(status_code=404, detail="Item not found")
    return {"message": f"Item {deleted_id[0]} successfully deleted"}


# Définition d'une autre route avec la méthode PUT à "/items/{item_id}".
@app.put("/items/{item_id}")
async def update_item(item_id: str, item: Item):
    with get_cursor() as cursor:
        cursor.execute(
            "UPDATE _items SET name = %s, description = %s, price = %s WHERE id = %s RETURNING id",
            (item.name, item.description, item.price, item_id),
        )
        updated_id = cursor.fetchone()
        if updated_id is None:
            raise HTTPException(status_code=404, detail="Item not found")
    item.id = updated_id[0]
    return item