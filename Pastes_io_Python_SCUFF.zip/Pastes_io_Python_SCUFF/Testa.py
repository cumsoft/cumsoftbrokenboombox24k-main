import tkinter as tk
from tkinter import ttk


class MainWindow(tk.Tk):
    def __init__(self):
        super().__init__()

        # Define a list of people
        self.people = ["Alice", "Bob", "Carol"]

        # Create a frame to hold the list of people and their state buttons
        self.people_frame = tk.Frame(self)
        self.people_frame.pack()

        # Create a label for the list of people
        self.people_label = tk.Label(self.people_frame, text="People:")
        self.people_label.pack()

        # Create a listbox to display the list of people
        self.people_listbox = tk.Listbox(self.people_frame, height=len(self.people))
        for person in self.people:
            self.people_listbox.insert("end", person)
        self.people_listbox.pack()

        # Create a frame to hold the state buttons for each person
        self.state_frame = tk.Frame(self.people_frame)
        self.state_frame.pack()

        # Create a label for the state buttons
        self.state_label = tk.Label(self.state_frame, text="State:")
        self.state_label.pack()

        # Create a radio button for each state
        self.wfo_radiobutton = tk.Radiobutton(self.state_frame, text="WFO", value="WFO")
        self.wfo_radiobutton.pack()

        self.wfh_radiobutton = tk.Radiobutton(self.state_frame, text="WFH", value="WFH")
        self.wfh_radiobutton.pack()

        self.na_radiobutton = tk.Radiobutton(self.state_frame, text="N/A", value="N/A")
        self.na_radiobutton.pack()

        # Create a button to copy the selected state to the clipboard
        self.copy_button = tk.Button(self, text="Copy to Clipboard", command=self.copy_state_to_clipboard)
        self.copy_button.pack()

        # Bind the selection of a person in the listbox to the enablement of the state buttons
        self.people_listbox.bind("<<ListboxSelect>>", self.on_person_selected)

        # Disable the state buttons initially
        self.wfo_radiobutton.config(state="disabled")
        self.wfh_radiobutton.config(state="disabled")
        self.na_radiobutton.config(state="disabled")

    def on_person_selected(self, event):
        # Get the selected person from the listbox
        selected_person = self.people_listbox.get(self.people_listbox.curselection())

        # Enable the state buttons
        self.wfo_radiobutton.config(state="normal")
        self.wfh_radiobutton.config(state="normal")
        self.na_radiobutton.config(state="normal")

    def copy_state_to_clipboard(self):
        # Get the selected person from the listbox
        selected_person = self.people_listbox.get(self.people_listbox.curselection())

        # Get the selected state
        selected_state = self.wfo_radiobutton.get() if self.wfo_radiobutton.get() else (
            self.wfh_radiobutton.get() if self.wfh_radiobutton.get() else self.na_radiobutton.get()
        )

        # Ignore N/A state people
        if selected_state == "N/A":
            return

        # Copy the state to the clipboard
        self.clipboard_clear()
        self.clipboard_append(f"{selected_person}: {selected_state}")


if __name__ == "__main__":
    app = MainWindow()
    app.mainloop()