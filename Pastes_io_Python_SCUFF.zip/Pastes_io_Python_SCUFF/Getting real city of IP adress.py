import requests
 
ip = '127.0.0.1'
url = 'http://ip-api.com/json/' + ip
 
response = requests.get(url).json()
city = response['city']