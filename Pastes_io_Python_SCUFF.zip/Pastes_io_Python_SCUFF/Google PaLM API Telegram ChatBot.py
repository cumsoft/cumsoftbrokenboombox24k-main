from telegram.ext import Updater, CommandHandler, MessageHandler, Filters
import os
import requests
import google.generativeai as palm

# Configure the API
palm.configure(api_key='Your_Google_PaLM_API_Key)

# Initialize a memory log
memory_log = ""

def update_memory_log(new_message):
    global memory_log
    memory_log = (memory_log + new_message)[-3000:]

def start(update, context):
    update.message.reply_text("Ahoy there! I'm the DeFi Raider, here to assist ye on yer DeFi adventures!")

def help_command(update, context):
    update.message.reply_text("Ye can use the following commands, matey:\n"
                              "/start - To start a conversation with me\n"
                              "/help - To get help\n"
                              "/chat - To chat with me\n"
                              "/joke - To hear a joke from me\n"
                              "/coininfo {coin_id} - To get information about a specific coin")

def chat(update, context):
    global memory_log
    if context.args:
        persona_prefix = "Respond as the swashbuckling DeFi rebel pirate The DeFi Raider: "
        new_message = " ".join(context.args)
        update_memory_log(new_message)
        prompt = persona_prefix + "Recalling recent conversations: " + memory_log + " answer my new question: " + new_message
        response = palm.chat(messages=[prompt], temperature=0.45, top_k=40, top_p=0.95)
        update_memory_log(response.last)
        update.message.reply_text(response.last)
    else:
        update.message.reply_text("Ye need to provide a message to chat, matey!")

def joke(update, context):
    global memory_log
    persona_prefix = "Respond as the swashbuckling DeFi rebel pirate The DeFi Raider with a joke: "
    new_message = "Tell me a joke"
    update_memory_log(new_message)
    prompt = persona_prefix + "Recalling recent conversations: " + memory_log  + new_message
    response = palm.generate_text(prompt=prompt, temperature=0.35, top_k=40, top_p=0.95)
    update_memory_log(response.result)
    update.message.reply_text(response.result)



def get_coin_data(coin_id):
    response = requests.get(f"https://api.coingecko.com/api/v3/coins/{coin_id}?localization=false&tickers=false&market_data=true&community_data=true&developer_data=true&sparkline=false")
    if response.status_code == 200:
        return response.json()
    else:
        return None

def coin_info(update, context):
    if context.args:
        coin_id = context.args[0].lower()  # Convert the coin_id to lowercase
        data = get_coin_data(coin_id)
        if data:
            metrics = [
                "id",
                "symbol",
                "market_data.price_change_percentage_24h",
                "market_data.price_change_percentage_30d",
                "market_data.price_change_percentage_1y",
                "market_data.market_cap_change_percentage_24h",
                "market_data.market_cap_change_percentage_30d",
                "market_data.market_cap_change_percentage_1y",
                "market_data.total_volume_change_percentage_24h",
                "market_data.total_volume_change_percentage_30d",
                "market_data.total_volume_change_percentage_1y",
                "asset_platform_id",
                "block_time_in_minutes",
                "hashing_algorithm",
                "localization.en",
                "community_data.twitter_screen_name",
                "community_data.telegram_channel_identifier",
                "community_data.subreddit_url",
                "public_interest_stats.country_origin",
                "sentiment_votes.up_percentage",
                "sentiment_votes.down_percentage",
                "public_interest_stats.watchlist_count",
                "market_data.market_cap_rank",
                "coingecko_rank",
                "coingecko_score",
                "developer_data.developer_score",
                "community_data.community_score",
                "liquidity_score",
                "public_interest_stats.alexa_rank",
                "public_interest_stats.public_interest_score",
                "market_data.total_value_locked",
                "market_data.mcap_to_tvl_ratio",
                "market_data.fdv_to_tvl_ratio",
                "market_data.roi",
                "market_data.market_cap_rank",
                "market_data.market_cap_change_percentage_in_usd",
                "market_data.price_change_percentage_24h",
                "market_data.price_change_percentage_30d",
                "market_data.price_change_percentage_1y",
                "market_data.total_supply",
                "market_data.max_supply",
                "market_data.circulating_supply",
                "developer_data.stars",
                "public_interest_stats.alexa_rank",
            ]

            msg = f"Data for {data['name']} (ID: {coin_id}):\n"
            for metric in metrics:
                keys = metric.split(".")
                value = data
                for key in keys:
                    if key in value:
                        value = value[key]
                    else:
                        value = "N/A"
                        break
                msg += f"{keys[-1]}: {value}\n"
            
            # Getting the opinion from the Google Generative AI
            prompt = f"What's your opinion on this coin based on the given data here, {msg}"
            response = palm.generate_text(prompt=prompt, temperature=0.45, top_k=40, top_p=0.95)
            msg += f"\nGoogle AI's opinion: {response.result}"

            # Sending the response in chunks if it's too large
            for i in range(0, len(msg), 4096):
                update.message.reply_text(msg[i:i+4096])
        else:
            update.message.reply_text(f"No data found for {coin_id}")
    else:
        update.message.reply_text("Ye need to provide a coin ID, matey!")




def main():
    # Replace 'YOUR_API_KEY_HERE' with your actual API key
    updater = Updater("Your_Telegram_Bot_Token", use_context=True)

    dp = updater.dispatcher

    dp.add_handler(CommandHandler("start", start))
    dp.add_handler(CommandHandler("help", help_command))
    dp.add_handler(CommandHandler("chat", chat, pass_args=True))
    dp.add_handler(CommandHandler("joke", joke))
    dp.add_handler(CommandHandler("coininfo", coin_info, pass_args=True))

    # Start the bot
    updater.start_polling()

    # Run the bot until the user sends a signal with Ctrl-C
    updater.idle()

if __name__ == "__main__":
    main()
#By ₿obbie Ð.Ł. Nigmatic
#Always Free, Always Open Source
#Optional Donations to Buy Me a Coffee:
#BTC: bc1q5uc7fzha63x37gq3x4ul7l70j5phzurmtcqtzf

#LTC: ltc1quuw4a308wtd767uek8mq7wya22l76d4u8l5vnq

#Doge: D9R5dW55CgFUUyQsyvbkZeHWRrE3tpzyRx

#KCC/KCS: 0x8D7bda2D58e3B17E0f21a609195018452024A497