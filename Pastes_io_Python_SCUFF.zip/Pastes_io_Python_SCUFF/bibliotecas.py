#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Usando la biblioteca time y la funcion time.sleep() hacer un script que pida
# una cantidad de tiempo e imprima una cuenta regresiva hasta terminar
# con la onomatopeya de una explosión:
# ej
# >> Ingrese una cantidad de segundos: 5
# >> 5
# >> 4
# >> 3
# >> 2
# >> 1
# >> ¡BOOOOMMM!!!
 
import time
 
tiempo = int(input("Ingrese una cantidad de segundos: "))
for f in range(tiempo,0,-1):
     print(f)
     time.sleep(1)
 
print("¡BOOOOMMM!")
 
# Script que simula el lanzamiento de dos dados
import random
 
while True:
    print("\nLanzamiento de dados:")
    print(f"Primer dado: {random.randint(1,6)}  Segundo dado: {random.randint(1,6)}")
    opcion = input("Presione cualquier tecla para continuar (o 'x' para salir): ")
    if opcion.lower() == "x":
        print("Hasta luego...")
        break