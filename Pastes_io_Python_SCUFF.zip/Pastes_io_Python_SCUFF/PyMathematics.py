# Welcome To Yuvi's Easy Mathematics!
Number1 = float(input("Type In The Number You Want To Change; "))
Number2 = float(input("Type In The Second Number; "))

print("Available Operations Are; + , - , * , /.")
print("If You Don't Know What These Mean, + Is Addition - Is Subtraction * Is Multiplication / Is Division.")
select = input("Select Operations; ")

if select == "+":
    print(Number1, "+", Number2, "=", Number1 + Number2)

elif select == "-":
    print(Number1, "-", Number2, "=", Number1 - Number2)

elif select == "*":
    print(Number1, "*", Number2, "=", Number1 * Number2)

elif select == "/":
    print(Number1, "/", Number2, "=", Number1 / Number2)
# More Mathematics Coming Soon!
else:
    print("Invalid Operation Or Operation Is Not Supported Yet")