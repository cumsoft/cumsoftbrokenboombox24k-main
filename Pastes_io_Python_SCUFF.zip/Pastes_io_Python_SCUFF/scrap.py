import asyncio
import datetime
import logging
import time
 
import json
 
                    # Global variables
        VISITED_PAGES = set()
        MAX_DEPTH = 5  # Set the maximum depth of the recursion
        GO_TO_EXTERNAL = False  # Whether to follow external links
        EXTERNAL_DOMAINS = ['example.com', 'help.kuna.io', 'sample.com']  # Allowed external domains
        MAX_PAGES = 100  # Set the maximum total pages processed
        all_data = []
        MAX_LINKS_ON_PAGE = 20
        FORBIDDEN_SUB_URLS = ['help.kuna.io/ru/']
 
        async def scrape_page(page, depth=0, pages_processed=0):
            if depth > MAX_DEPTH or pages_processed >= MAX_PAGES:
                return pages_processed
 
            url = page.url
            if url in VISITED_PAGES:
                return pages_processed
            VISITED_PAGES.add(url)
 
            # Get all links on the page
            link_elements = await page.query_selector_all('a')
            links = [await page.evaluate('(el) => el.href', link) for link in link_elements]
            processed_links_on_page = 0
            for link in links:
                if pages_processed >= MAX_PAGES:
                    break
 
                # Ignore visited pages or external links (if not allowed)
                if link in VISITED_PAGES or (
                        not GO_TO_EXTERNAL and not any(domain in link for domain in EXTERNAL_DOMAINS)) or (
                        any(domain in link for domain in FORBIDDEN_SUB_URLS)
                ):
                    continue
                processed_links_on_page += 1
                if processed_links_on_page > MAX_LINKS_ON_PAGE:
                   break
 
                try:
                    # Open a new page for each link
                    new_page = await page.context.new_page()
                    await new_page.goto(link)
 
                    # Extract the page title, header and visible text
                    title = await new_page.title()
                    header = await new_page.eval_on_selector('header', '(el) => el.innerText')
                    content = await new_page.evaluate('''() => {
                        let text = '';
                        let nodes = document.querySelector('section[data-testid="main-content"]').getElementsByTagName('*');
                        for (let node of nodes) {
                            if (node.innerText && node.offsetWidth !== 0 && node.offsetHeight !== 0) {
                                text += node.innerText + '\\n';
                            }
                        }
                        return text;
                    }''')
 
                    content = cut_string_until_substr(content, "Did this answer your question")
                    # Create a dictionary of the data
                    page_data = {
                        'url': link,
                        'page_title': title,
                        'page_header': header,
                        'page_content': content
                    }
 
                    # Append the data to the all_data list
                    all_data.append(page_data)
                    logging.info(f"Data added for {link}")
                    # Recursively scrape linked pages
                    pages_processed = await scrape_page(new_page, depth + 1, pages_processed + 1)
                    VISITED_PAGES.add(link)
 
                    await new_page.close()
 
                except Exception as e:
                    logging.error(f"Error occurred while processing {link}: {e}")
                    continue
 
            return pages_processed
 
        start_url = "https://help.kuna.io/en/"
        await self.page.goto(start_url)
 
        total_pages_processed = await scrape_page(self.page)
        logging.info(f"Total pages processed: {total_pages_processed}")
 
        # Once all pages have been processed, write the data to the JSON file
        with open('scraped_data.json', 'w') as f:
            json.dump(all_data, f, indent=4)  # Using an indent for pretty-printing