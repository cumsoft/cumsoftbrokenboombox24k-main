import time
import random
from machine import SoftI2C, Pin
from lcd_api import LcdApi
from pico_i2c_lcd import I2cLcd

i2c = SoftI2C(sda=Pin(0), scl=Pin(1), freq=400000)
i2c_addr = i2c.scan()[0]
lcd = I2cLcd(i2c, i2c_addr, 2, 16)
lcd.clear()
while True:
    lcd.move_to(0,0)
    random_num = random.uniform(0,360)
    if random_num <= 90:
        lcd.putstr("North Easterly")
        lcd.move_to(0,1)
        lcd.putstr(str(random_num))
    elif random_num > 90 and random_num <= 180:
        lcd.putstr("North Westerly")
        lcd.move_to(0,1)
        lcd.putstr(str(random_num))
    elif random_num > 180 and random_num <= 270:
        lcd.putstr("South Westerly")
        lcd.move_to(0,1)
        lcd.putstr(str(random_num))
    else:
        lcd.putstr("South Easterly")
        lcd.move_to(0,1)
        lcd.putstr(str(random_num))

    time.sleep(2)
    lcd.clear()