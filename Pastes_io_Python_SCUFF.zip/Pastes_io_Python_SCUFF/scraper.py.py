import csv
import requests
from lxml import html
import operator as op


def print_if_matches(word_list, conversation, designation):
    paras = conversation.get("message")
    for p in paras:
        matched_words = []
        for w in word_list:
            if p and op.contains(p, w[0]):
                matched_words.append(w[0])

        if len(matched_words) > 0:
            print("========match=======")
            print("participant_name - ", conversation["participant"])
            print("participant_designation - ", designation)
            print("message - ", p)
            print("matched_words - ", matched_words)

    # for w in word_list:
    #     if conversation.get("message") and op.contains(conversation.get("message"), w[0]):
    #         matched_word.append(w[0])

    # if len(matched_word) > 0:
    #     print("========match=======")
    #     print("participant_name - ", conversation["participant"])
    #     print("participant_designation - ", designation)
    #     print("message - ", conversation["message"])
    #     print("matched_words - ", matched_word)


if __name__ == "__main__":
    word_list = []
    with open('initial.csv', newline='') as csvfile:
        csv_reader = csv.reader(csvfile, delimiter=',', quotechar='|')
        for row in csv_reader:
            word_list.append(row)

    page = requests.get('https://seekingalpha.com/article/4549108-microsoft-corporation-msft-q1-2023-earnings-call-transcript')

    # print(page.content)
    tree = html.fromstring(page.content)

    # company info section
    company_tree = tree.cssselect("span[data-test-id=post-primary-tickers]")
    for c in company_tree:
        a_tags = c.cssselect("a")
        for a in a_tags:
            print("company_name - ", a.text)

    # quarter and year info section
    transcript_tree = tree.cssselect("h1[data-test-id=post-title]")
    for c in transcript_tree:
        print("quarter&year - ", c.text.split(") ")[1][0:7])

    main_body = tree.cssselect("div[data-test-id=content-container]")

    company_participants = []
    conference_participants = []
    conversations = []

    temp_dict = {}
    for m in main_body:
        paragraphs = m.cssselect("p")

        is_company_participants_section = False
        is_conference_participants = False
        is_conversation_sec = False

        for p in paragraphs:
            if len(p) > 0 and p[0].text == "Company Participants":
                is_company_participants_section = True
                continue
            if len(p) > 0 and p[0].text == "Conference Call Participants":
                is_conference_participants = True
                is_company_participants_section = False
                continue
            if len(p) > 0 and p[0].text == "Operator":
                is_conference_participants = False
                is_company_participants_section = False
                is_conversation_sec = True

            if len(p) > 0 and p[0].text == "Question-and-Answer Session":
                break

            if is_company_participants_section:
                company_participants.append(p.text)
            if is_conference_participants:
                conference_participants.append(p.text)

            if is_conversation_sec:
                if p.text is None and len(p) > 0:
                    temp_dict = dict()
                    temp_dict["participant"] = p[0].text
                    temp_dict["message"] = []
                    conversations.append(temp_dict)
                    continue
                if len(conversations) > 0:
                    conversations[len(conversations) - 1]["message"].append(p.text)

    print("company_participants - ", company_participants)
    print("company_participants_count - ", len(company_participants))
    print("conference_participants - ", conference_participants)
    print("conference_participants_count - ", len(conference_participants))

    designation = dict()
    # build participant and designation dict
    for p in conference_participants:
        designation[p.split(" - ")[0].strip()] = p.split(" - ")[1]
    for p in company_participants:
        designation[p.split(" - ")[0].strip()] = p.split(" - ")[1]

    print("====== conversation ====")
    for c in conversations:
        print_if_matches(word_list, c, designation.get(c.get("participant").strip()))

    qa = []
    for m in main_body:
        paragraphs = m.cssselect("p")

        is_qa = False
        for p in paragraphs:
            if len(p) > 0 and p[0].text == "Question-and-Answer Session":
                is_qa = True
                continue

            if is_qa:
                if p.text is None and len(p) > 0:
                    temp_dict = dict()
                    temp_dict["participant"] = p[0][0].text if len(p[0]) > 0 else p[0].text
                    temp_dict["message"] = []
                    qa.append(temp_dict)
                    continue
                if len(qa) > 0:
                    qa[len(qa) - 1]["message"].append(p.text)

    print("===== questions and answers ====")
    for c in qa:
        print_if_matches(word_list, c, designation.get(c["participant"].strip()))