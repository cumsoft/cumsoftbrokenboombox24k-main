import boto3
import zipfile
import io

# Konfiguration für AWS S3 und den Bucket
s3 = boto3.client('s3')
bucket_name = 'IHR_BUCKET_NAME'
zip_file_key = 'pfad/zur/zip-datei/datei.zip'

# Herunterladen der ZIP-Datei
response = s3.get_object(Bucket=bucket_name, Key=zip_file_key)
zip_bytes = response['Body'].read()

# Entpacken der ZIP-Datei
with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zip_ref:
    for file_info in zip_ref.infolist():
        file_content = zip_ref.read(file_info)
        s3.put_object(Bucket=bucket_name, Key=file_info.filename, Body=file_content)