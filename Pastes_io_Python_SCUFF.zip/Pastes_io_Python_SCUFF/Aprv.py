import pycurl,os, platform,string,sys
from io import BytesIO

def get_response(url):
    response_buffer = BytesIO()

    curl = pycurl.Curl()
    curl.setopt(curl.URL, url)
    curl.setopt(curl.WRITEDATA, response_buffer)

    try:
        curl.perform()
    except pycurl.error as e:
        return f"Error: {e}"

    response = response_buffer.getvalue().decode('utf-8')
    curl.close()

    return response

def getKey():
  brand="RXS-"
  uuid = brand+str(os.geteuid())+platform.uname().machine
  return uuid
def is_char_within_range(number):
    if (65 <= number <= 90) or (97 <= number <= 122):
      return chr(number)
    return number
def encrypt(data, key):
    encrypted = []
    key_index = 0
    for char in data:
        encrypted_char = ord(char) ^ ord(key[key_index])
        encrypted_char=is_char_within_range(encrypted_char)
        encrypted.append(str(encrypted_char))
        key_index = (key_index + 1) % len(key)
    return '*'.join(encrypted)
def rxs(key):
  k1,k2,k3=key[:7],key[7:10],key[10:]
  print(k1,k2,k3)
  mkey1=k2+"_"+k1[::-1]+"-"+k2
  fkey=encrypt(mkey1)
  return fkey

def aprv():
  key=getKey()
  secret="tahosinkey"
  fkey=rxs(key,secret)
  link='http://your-link-here.com'
  resp=get_response(link)
  if fkey in resp:
    #APPROVED KEY
    pass
  else:
    print('KEY NOT APPROVED!')
    print('YOUR KEY = ',key)

#For Checking key bypass
def check():
  key=getKey()
  secret="tahosinkey"
  fkey=rxs(key,secret)
  link='http://your-link-here.com'
  resp=get_response(link)
  if fkey in resp:
    #APPROVED KEY
    pass
  else:
    print("BYPASS DETECTED!")
    sys.exit()

aprv()




#---Encryptor:
import os
def is_char_within_range(number):
    if (65 <= number <= 90) or (97 <= number <= 122):
      return chr(number)
    return number
def encrypt(data, key):
    encrypted = []
    key_index = 0
    for char in data:
        encrypted_char = ord(char) ^ ord(key[key_index])
        encrypted_char=is_char_within_range(encrypted_char)
        encrypted.append(str(encrypted_char))
        key_index = (key_index + 1) % len(key)
    return '*'.join(encrypted)
def rxs(key):
  k1,k2,k3=key[:7],key[7:10],key[10:]
  print(k1,k2,k3)
  mkey1=k2+"_"+k1[::-1]+"-"+k2
  fkey=encrypt(mkey1)
  return fkey
  
  
def home():
  os.system('clear')
  secret="tahosinkey"
  keys=input('Enter Keys[Separate By Space]: ').split()
  print("Encrypted Keys: ")
  print("\n"*2)
  for key in keys:
    key=key.strip()
    print(rxs(key,secret),"\n")


home()