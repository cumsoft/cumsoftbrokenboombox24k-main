def _hash(self, key: str, inserting: bool = False) -> int:
        """
        Hash function to preform lookup of a passed key. Uses probing and double hashing.
        :param key: str The key being used to preform lookup
        :param inserting: bool Whether we are performing an insert
        :return: int value of bin hashed from the key
        """

        # Helper function in attempt to clean up my code
        def get_bin_idx(i: int) -> int:
            return (self._hash_1(key=key) + i * self._hash_2(key=key)) % self.capacity

        itt = 0

        current_node = None

        while self.table[get_bin_idx(itt)] is not None:
            current_node = self.table[get_bin_idx(itt)]
            if not inserting and current_node.key == key:
                return get_bin_idx(itt)
            elif inserting and (current_node.deleted or current_node.key == key):
                return get_bin_idx(itt)
            itt += 1

        return get_bin_idx(itt)

    def _insert(self, key: str, value: T) -> None:
        """
        Insert or update a value into the table at computed hash index
        :param key: The key of the node we're looking to delete
        :param value: The value of the node to insert or update if the node already exists
        :return: None
        """
        node_idx = self._hash(key, inserting=True)

        # if a Node exists and that key is the key passed, update that nodes value with value passed
        if self.table[node_idx] and self.table[node_idx].key == key:
            self.table[node_idx].value = value
        # else if a node exists, create a new node at the given index
        else:
            self.table[node_idx] = HashNode(key, value)
            self.size += 1

        if self.size >= self.capacity / 2:
            self._grow()