y = fused_angle - x_angle
    S = P[0, 0] + R_angle
    K = np.array([P[0, 0] / S, P[1, 0] / S])
    x_angle += K[0] * y
    x_bias += K[1] * y
    P -= K.reshape((2, 1)) @ np.array([[P[0, 0], P[0, 1]], [P[1, 0], P[1, 1]]])

    # Print the filtered angle
    print("Filtered Angle: ", x_angle)

    # Delay for the desired update rate
    time.sleep(dt)