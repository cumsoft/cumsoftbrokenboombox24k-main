import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
from sqlalchemy import create_engine
import datetime
import fitz

engine = create_engine('sqlite:///your_database.db')
# Sample student data
grades_data = pd.DataFrame({
    'Student Name': ['Parth Yadav', 'Alice', 'Bob', 'Charlie'],
    'Math': [90, 85, 92, 88],
    'Science': [88, 90, 91, 85],
    'History': [78, 75, 82, 90],
})

# Sample skills data
skills_data = pd.DataFrame({
    'Student Name': ['Parth Yadav', 'Alice', 'Bob', 'Charlie'],
    'Coding': [89, 75, 80, 70],
    'Communication': [90, 85, 78, 90],
    'Leadership': [92, 70, 85, 75],
})

# Sample attendance data
attendance_data = pd.DataFrame({
    'Student Name': ['Parth Yadav', 'Alice', 'Bob', 'Charlie'],
    'Attendance Percentage': [95, 92, 98, 94],
}, index=['May', 'June', 'July', 'August'])

# Function to assign points based on marks
def assign_points(marks):
    if marks > 60:
        return 10
    else:
        return 0

# Add a "Points" column to the grades data
grades_data['Points'] = grades_data['Math'].apply(assign_points) + grades_data['Science'].apply(assign_points) + grades_data['History'].apply(assign_points)

# Calculate the total points rewarded for Parth Yadav
parth_yadav_total_points = grades_data[grades_data['Student Name'] == 'Parth Yadav']['Points'].sum()

# Streamlit App
st.title("Class X Student Dashboard")

# Sidebar for navigation
st.sidebar.title("Overall Ability")
st.sidebar.image('eps.jpeg',  use_column_width=True)

# Create an expander for Class X
class_x_expander = st.sidebar.expander("Class X")

# Sections in the expander
selected_section = class_x_expander.radio("Select a Section", ["Grade","User Profile", "Homework", "Group chat", "Class Points"])

# Display grade, skills, and attendance content combined in one tab
if selected_section == "Grade":
   st.subheader(f"Grades, Skills, and Attendance for Parth Yadav")

# Display student grades and points in a data table
   st.subheader("Grades:")
   st.table(grades_data[grades_data['Student Name'] == 'Parth Yadav'])

# Create a bar chart using Matplotlib for grades
   fig, ax = plt.subplots(figsize=(8, 6))
   subjects = grades_data.columns[1:4]  # Exclude the 'Points' column
   parth_yadav_grades = grades_data[grades_data['Student Name'] == 'Parth Yadav'].values[0][1:4]
   ax.bar(subjects, parth_yadav_grades, label="Grades", alpha=0.7)

# Display points
   ax.annotate(f'Points: {parth_yadav_total_points}', xy=(0.5, 0.5), xytext=(0.2, 0.8),
            textcoords='axes fraction', arrowprops=dict(facecolor='black', shrink=0.05),
            fontsize=12, ha='center')

   ax.set_xlabel("Subjects")
   ax.set_ylabel("Grades")
   ax.set_title(f"Grades for Parth Yadav")

# Display skills in a data table
   st.subheader("Skills:")
   st.table(skills_data[skills_data['Student Name'] == 'Parth Yadav'])

# Create a pie chart using Matplotlib for skills
   fig2, ax2 = plt.subplots(figsize=(8, 6))
   labels = skills_data.columns[1:]
   sizes = skills_data[skills_data['Student Name'] == 'Parth Yadav'].values[0][1:]
   ax2.pie(sizes, labels=labels, autopct='%1.1f%%', startangle=90)
   ax2.axis('equal')  # Equal aspect ratio ensures the pie chart is circular.
   ax2.set_title(f"Skills for Parth Yadav")

# Display attendance in a data table
   st.subheader("Attendance (May to August):")
   st.table(attendance_data[attendance_data.index.isin(['May', 'June', 'July', 'August'])])

# Create a linear graph using Matplotlib for attendance
   fig3, ax3 = plt.subplots(figsize=(8, 6))
   dates = range(1, len(attendance_data) + 1)
   percentages = attendance_data['Attendance Percentage'].tolist()
   ax3.plot(dates, percentages, marker='o', linestyle='-')
   ax3.set_xlabel("Months")
   ax3.set_ylabel("Attendance Percentage")
   ax3.set_title(f"Attendance for Parth Yadav (May to August)")
   ax3.axhline(y=89, color='red', linestyle='--', label='None')
   ax3.legend()

   st.pyplot(fig)
   st.pyplot(fig2)
   st.pyplot(fig3)

    # Display content based on the selected section in the expander
if selected_section == "User Profile":
    st.subheader("Student Profile") 
    st.image('dp.png', caption='Student Photo', use_column_width=True)
     # Display "Student Profile" title
    
    # You can display student information here
    student_name = "Parth Yadav"
    student_roll_number = "23"
    student_age = 16
    student_gender = "Male"
    student_address = "123 Main Street, City, Country"
    student_email = "fermilyy3@gmail.com"
    student_phone = "+1 (123) 456-7890"

    # Display the student's personal details
    st.write(f"Name: {student_name}")
    st.write(f"Roll Number: {student_roll_number}")
    st.write(f"Age: {student_age}")
    st.write(f"Gender: {student_gender}")
    st.write(f"Address: {student_address}")
    st.write(f"Email: {student_email}")
    st.write(f"Phone: {student_phone}")

    # Display the student's profile image (replace 'student_image.jpg' with the actual image file path or URL)


    # You can add more details as needed
    # You can also include profile pictures or other visuals
    
    # Optionally, you can add buttons or links to edit the profile or change password

    # You can customize the formatting and layout as per your requirements
    # For example, you can use st.markdown to add more styling or formatting.
    
    # Example of adding an edit profile button
    if st.button("Edit Profile"):
        # Add code to handle editing the profile here
        st.write("Edit profile functionality coming soon!")

    # Example of adding a change password button
    if st.button("Change Password"):
        # Add code to handle changing the password here
        st.write("Change password functionality coming soon!")


    # Display user profile content here.
elif selected_section== "Homework":
    st.subheader("Homework")
    with st.expander("Subject"):
        pdf_file = open("Screenshot (61).png", "rb").read()
        if st.button("english"):
         st.image(pdf_file)
         st.download_button("Download  PDF", data=pdf_file, key="english.pdf")
    



elif selected_section == "Chat Group":
    st.subheader("Groups")
    
elif selected_section == "Class Points":
       st.subheader("Points")
       st.write("""You all are thinking what are Class Point. 
                well class point is point that you recived from school through this app.You will recivie class point from your
                good manner,disciplane and duty and more importantly you recivie these point from your special exam & according to the growth
                of your Overall Ability .Now you will think what is special exam.Well the special exam is a exam which based on your
                Skill,logical thinking in which you will recivive a task with a lot riddles and you have to solve the task.If you solve the task
                correctly then you will recivive a lot class Points.
                Now here a question rise about that why class point is important?
                The answer is why class point is important is because it will help you to increase your report card percentage as if you
                want to score higher percentage in your report card but you are not good in study so these class point which based on your skill and 
                talent will help you to increase your percentage.For example suppose child name Aryan score 69%  in his report card as he
                not good studies but he have talent in other field and yet he have gained some class point from his talent which he can used to increase
                his perecntage.

"""
                 )
       st.write("1 Class Point = 0.1%")   
       st.write("so if you gained 100 class Point then:")
       st.write("100 Class point=0.100%")
       st.write("mean rougly 10%")

Social_media=st.sidebar.header("School Media")
social_selection=Social_media.radio("...",["LINKs","Null"])
if social_selection=="Null":
     st.write(
    """
    st.image('download.png', use_column_width=False, caption="[![Facebook](https://www.facebook.com/school-page)](https://www.facebook.com/school-page)")

    st.image('download.jpg', use_column_width=False, caption="[![Twitter](https://www.twitter.com/school-page)](https://www.twitter.com/school-page)")

    st.image('download(1).png', use_column_width=False, caption="[![Instagram](https://www.instagram.com/school-page)](https://www.instagram.com/school-page)")
    """,
    unsafe_allow_html=True
)