import numpy as np
from uncertainties import unumpy as up
from uncertainties import ufloat
from uncertainties.umath import *
import matplotlib.pyplot as plt

m_pend = ufloat(0.2490, 0.00005)  # kg
m_proj = ufloat(0.0665, 0.00005)  # kg
l_pend = ufloat(0.282, 0.0005)  # m
d_vert = ufloat(0.830, 0.0005)


def pend_vi(angle):
    height = l_pend * (1 - up.cos((angle * np.pi)/180))
    in_sqrt_prod = 2*9.81*height
    mass_ratio = (m_pend + m_proj)/(m_proj)
    sqrt_res = in_sqrt_prod**(1/2)
    result = mass_ratio * sqrt_res
    return result


def launch_vi(rng):
    result = rng * (9.81/(2*d_vert))**(1/2)
    return result


def std(pop, avg):
    tt = 0
    for i in pop:
        tt += (i - avg)**2
    inter = (1/(len(pop) - 1)) * tt
    return inter**(1/2)


ang_array = [29.5, 28.0, 29.0, 29.0, 29.0, 29.0, 29.5]
ang_uncert_array = [0.25 for i in range(7)]
uang_array = up.uarray(ang_array, ang_uncert_array)

pend_vis = []
for ang in uang_array:
    vi = pend_vi(ang)
    pend_vis.append(vi)

tot = 0
for v in pend_vis:
    tot = tot+v
pend_vi_avg = tot/len(uang_array)
pend_vi_std = std(pend_vis, pend_vi_avg)

print(f'Pendulum Avg: {pend_vi_avg}')
print(f'Pendulum STD: {pend_vi_std}')


range_array = [1.459, 1.457, 1.459, 1.446, 1.463, 1.458, 1.459]
range_uncert_array = [0.0005 for i in range(7)]
urange_array = up.uarray(range_array, range_uncert_array)

launch_vis = []
for rng in urange_array:
    vi = launch_vi(rng)
    launch_vis.append(vi)
tot = 0
for v in launch_vis:
    tot = tot + v
launch_vi_avg = tot/len(urange_array)
launch_vi_std = std(launch_vis, launch_vi_avg)

print(f'Launch Avg: {launch_vi_avg}')
print(f'Launch STD: {launch_vi_std}')

plt.figure(0)
pend_graph = plt.errorbar(x=ang_array,
                          y=up.nominal_values(pend_vis),
                          yerr=up.std_devs(pend_vis),
                          fmt=".k",
                          elinewidth=1,
                          capsize=3,
                          capthick=1)
plt.xlabel("Angle (\u00b0)")
plt.ylabel("Initial Velocity (m/s)")


plt.figure(1)
launch_graph = plt.errorbar(x=range_array,
                            y=up.nominal_values(launch_vis),
                            yerr=up.std_devs(launch_vis),
                            fmt=".k",
                            elinewidth=1,
                            capsize=3,
                            capthick=1)
plt.xlabel("Horizontal Distance (m)")
plt.ylabel("Initial Velocity (m/s)")