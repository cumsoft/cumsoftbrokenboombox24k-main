""" Test Mqtt with open server """
import paho.mqtt.client as mqtt
import time

THE_TOPIC = "$SYS/#" #Topic to suscribe ...on moquitto

address ="test.mosquitto.org" #The public broker address
port =1883 # port

def on_message(client, userdata, message):
	""" Called when a message has been received on a topic 
	that the client subscribes to and the message does not match 
	an existing topic filter callback. 
	Use message_callback_add() to define a callback that will be called 
	for specific topic filters. on_message will serve as fallback when none matched."""
	
	#print(message.topic+" "+str(message.payload))
	
	print("message received " ,str(message.payload.decode("utf-8")))
	print("message topic=",message.topic)
	print("message qos=",message.qos)
	print("message retain flag=",message.retain,end="\n \n")

def on_connect(client,userdata,flags,rc):
	""" When the client receives a CONNACK message from the broker 
	in response to the connect it generates an on_connect() callback. """

	print ("Connected to ",client._host,"port :",client._port)
	print ("Flags ",flags , "Returned code ", str (rc))

	# Subscribing in on_connect() means that if we lose the connection and
	# reconnect then subscriptions will be renewed.
	client.subscribe(THE_TOPIC,qos=0)

def on_subscribe(client, userdata, mid, granted_qos):
	""" Called when the broker responds to a subscribe request. """
	print ("on_subscribe userdata ",userdata)
	print ("on_subscribe mid ",mid)	
	print ("on_subscribe granted_qos ",userdata)	

def on_disconnect(client, userdata, rc):
	""" Called when the client disconnects from the broker. """
	print ( "on_disconnect userdata",userdata)
	print ( "on_disconnect rc",rc)	
""" Client """	

def on_publish(client, userdata, mid):
	"""
	Called when a message that was to be sent using the publish()
	call has completed transmission to the broker. 
	For messages with QoS levels 1 and 2, 
	this means that the appropriate handshakes have completed. 
	For QoS 0, this simply means that the message has left the client. 
	The mid variable matches the mid variable returned 
	from the corresponding publish() call, to allow outgoing messages
	to be tracked.

	This callback is important because even if the publish() 
	call returns success, 
	it does not always mean that the message has been sent.
	"""
	print ("on_publish ",userdata," , mid ",mid)

client =mqtt.Client ("Icarvs",
						clean_session=True,
						userdata=None,
						protocol=mqtt.MQTTv311,
						transport="tcp")

""" calls backs"""
client.on_message=on_message #Attach function to callback

client.on_connect=on_connect #Attach function to callback

client.on_subscribe=on_subscribe  #Attach function to callback

client.on_publish=on_publish #Attach function to callback

client.on_disconnect=on_disconnect #Attach function to callback

""" login & pwd """
client.username_pw_set(None, password=None) #Login & Pwd 

""" Connect """
client.connect (address,port,keepalive=60) #Connet to broker (host, port,keepalive, bind_address="")

#time.sleep (5)
#client.loop_start() #start the loop

client.loop_forever()