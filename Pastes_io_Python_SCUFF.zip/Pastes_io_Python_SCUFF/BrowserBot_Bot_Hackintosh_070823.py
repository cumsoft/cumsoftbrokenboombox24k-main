from __future__ import unicode_literals

import codecs
import urllib
import urllib.request
from pafy import new
from pyscreenshot import FailedBackendError
from lxml import etree
from bs4 import BeautifulSoup, SoupStrainer
import requests
import fnmatch
import json
from win32api import GetSystemMetrics
import math
import os.path
import sys
import time as t
import tkinter as tk

import discord
from discord import FFmpegPCMAudio
from discord.ext import commands
from discord.ext.commands import CommandNotFound
from dotenv import load_dotenv

import autoscroll
import chrome
from WinManager import *

os.system("taskkill /f /im AutoHotkey.exe /T")
loop = asyncio.get_event_loop()
load_dotenv()
root = tk.Tk()
root.withdraw()

bot = commands.Bot(command_prefix='.', help_command=None, case_insensitive=True)
TOKEN = os.getenv('DISCORD_TOKEN')
HomeDir = r'C:\Users\Serbz\Desktop\9.py'
VarDir = HomeDir + r'\VariableVariables'
LogDir = HomeDir + r'\Logs'
StaticVarDir = HomeDir + r'\StaticVars'
SoundDir = HomeDir + r'\Sound'
ChromeDir = HomeDir + r'\Chrome'
ScriptDir = HomeDir + r'\SkrippitySkripz'
ImgDir = HomeDir + r'\ImageSearch'
SerbzDir = HomeDir + r'\SerbzDir'
ahk = AHK(executable_path=r"C:\\Program Files\\AutoHotkey\\AutoHotkeyU64.exe")

ProxyLog, spotifySession, AutoScroll, IsAdmin, IsMod, pyautogui.FAILSAFE, \
ignoreView, netflixSession, restoreAnnoyingChrome, automatedAnnoyingChrome, blockedListKnown = False, False, False, \
                                                                                               False, False, False, False, False, False, False, False
altSysChanArray, nfVals, optsArray, blockedListArray = [], [], [], []
bypass = None
nameStr, msgStr, SerbziText = "", "", ""
ready, g_counter, SpotifyScrollDivCounter, chrome_w, chrome_h, CommandActive = 0, 0, 0, 0, 0, 0
SpotifyScrollVar, namesi = -1, -1
songNumber, O_songNumber = 1, 1
CPos = [0, 0]
# spotifySession = []
if os.path.exists(VarDir + r"\ProxyBox.txt"):
    os.remove(VarDir + r"\ProxyBox.txt")
text_file = open(VarDir + r"\ProxyBox.txt", "w")
text_file.write("1")
text_file.close()

if os.path.exists(HomeDir + r"\VariableVariables\spotifyCoords.txt"):
    os.remove(HomeDir + r"\VariableVariables\spotifyCoords.txt")

ahk.run_script(
    "Run cmd.exe /c start "" /D " + ScriptDir + r"\Tools" + " \
        /W imgreadCoords.bat", blocking=False)
solidWhiteImage = open(HomeDir + r"\ImageSearch\Chrome\proxySolidWhiteScrn.png", "rb").read()
supressStart = True


##########################################################################
##########################################################################
@bot.event
async def on_ready():
    global ready, optsArray, chrome_w, chrome_h
    global myduckingHeadsetJustDied, restoreAnnoyingChrome, automatedAnnoyingChrome
    await focus("chrome")

    ######## GLOBALS ##########

    myduckingHeadsetJustDied = -1  # reset counter triggers on send message, nothing in it but leaving it.
    ######## FROM VARIABLES.TXT #########
    txtfile = open(HomeDir + r"\variables.txt", "r")
    vars = txtfile.read()
    txtfile.close()
    varsSplit = str(vars).split("\n")
    CurrentID = int(varsSplit[10])
    QuietMode = int(varsSplit[6])
    Serbz = await bot.fetch_user(int(varsSplit[2]))
    SerbzChannel = await Serbz.create_dm()
    sysChannel = await bot.fetch_channel(int(varsSplit[4]))
    CurrentChannel = await bot.fetch_channel(int(CurrentID))
    altSysChanArray = [str(varsSplit[14]), str(varsSplit[15])]
    altSysEnable = bool(varsSplit[12])
    strict = bool(varsSplit[17])
    devVal = int(str(varsSplit[19]))
    supressStart = bool(varsSplit[23])
    optsArray = [CurrentChannel, CurrentID, Serbz, SerbzChannel, sysChannel, QuietMode, altSysChanArray, altSysEnable,
                 strict, devVal, supressStart]
    #### LOCAL ####
    HardReset = bool(varsSplit[8])

    msg_str = ""

    await Messages("Beginning initialization.", CurrentChannel, sysChannel, None)
    msg_str = msg_str + "``` #-#-#-#-#-# Initialization #-#-#-#-#-# \n #-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#  \n"

    #############################################
    Logger.LogPrint(bot.user.id)
    Logger.LogPrint(discord.__version__)
    strgB = ""
    for guild in bot.guilds:
        strgB = strgB + "\n" + str(guild)
    msg_str = msg_str + '\n' + r"logged in as: " + str(
        bot.user.name) + '\n ------' + '\n Servers connected to:' + '\n #-#-#-#-#-#-#-#-#-#-#-#-#-' + strgB
    #############################################
    if (os.path.exists(VarDir + r"\prevURL.txt")):
        txtfile = open(VarDir + r"\prevURL.txt")
        URL = txtfile.read()
        txtfile.close()
        os.remove(VarDir + r"\prevURL.txt")
        msg_str = msg_str + "\nRestoring primary tab from restart: URL - " + str(URL)
        await chrome.ASYNChttp(str(URL))
    msg_str = msg_str + "\ninit. 20%"
    #############################################
    if HardReset == True:
        await focus("d")
        msg_str = msg_str + "\nimproper/hard reset flag TRUE."
        await discRestart()
        await asyncio.sleep(10)
    else:
        msg_str = msg_str + "\nimproper/hard reset flag FALSE."
    await Logger.ValuesUpdater(8, True)  # HardReset set back to true incase of crash
    DiscordWindow = await img2click(ImgDir + r"\Discord\profile.png", 2, 0, 0, 1600, 900)
    #############################################
    if DiscordWindow == False:
        msg_str = msg_str + "\nDiscord window not found. (re)starting discord."
        await discreset(None, True)
        await discRestart()
    else:
        msg_str = msg_str + "\nDiscord window found."
    await focus("d")
    discGotItBtn = await img2click(ImgDir + r"\Discord\GotItBtn.png", 2, 0, 0, 1600, 900)
    #############################################
    if discGotItBtn != "None,None":
        await img2click(ImgDir + r"\Discord\GotItBtn.png", None, 0, 0, 1600, 900)
    await focus("chrome")
    msg_str = msg_str + "\ninit. 40%"
    await ChromeInit1()

    msg_str = msg_str + "\nChrome Init 1"
    URL = await chrome.getURL(1, 1)
    #duckorCompleteduck = await ChromeInit2(URL)
    #############################################
    #if duckorCompleteduck == "duck":
    #    msg_str = msg_str + r"Chrome Init. pt2 error. resuming."
    #elif duckorCompleteduck == "Complete duck":
    #    msg_str = msg_str + "\nChrome Init 2"
    chrome.close_tab()
    msg_str = msg_str + "\ninit. 80%"
    #############################################
    #try:
    #     UseduckingTor = 1
    #    confirmTheBear = await img2click(HomeDir + r'\ImageSearch\Chrome\tunnelBear3.png', 2)
    #    msg_str = msg_str + "\ninit. 90%"
    #    if confirmTheBear == (None, None):
    #        Logger.LogPrint("Tunnel Bear not on. Not setting ready flag, no commands can be taken.")
    #        if supressStart != True:
    #            msg_str = msg_str + + "\nBackend initialization failed. (3), restarting(?)```"
    #        else:
    #            msg_str = "```== Supressed Start -- \n Backend initialization failed. (4), restarting(?) ```"
    #        await Messages(msg_str, None, sysChannel, None)
    #        await restart(None, True)
    #except:
    #     print("It won't")
#         pass
    #    if supressStart != True:
    #        msg_str = msg_str + "\nBackend initialization failed. (4), restarting(?) ```"
    #    else:
    #        msg_str = "```== Supressed Start -- \n Backend initialization failed. (4), restarting(?) ```"
    #    await Messages(msg_str, None, sysChannel, None)
    #    await restart(None, True)
    #    return
        #############################################
    if os.path.exists(VarDir + r"initAck.txt"):
        os.remove(VarDir + r"initAck.txt")
        txtfile = open(VarDir + r"initReset.txt")
        txtfile.write("1")
        txtfile.close()
    txtfile = open(VarDir + r"\initComplete.txt", "w")
    txtfile.write("1")
    txtfile.close()
    pyautogui.moveTo(1495, 1063, 0.1)  # to clear
    pyautogui.moveTo(1908, 1063, 1)  # leftover icons in sys tray .clickc 1495 1063 .imgread 1495,1063,1908,1060
    # ahk.run_script(r'send, {F11}')
    chrome_w, chrome_h = await chrome.getSize()
    if supressStart != True:
        msg_str = msg_str + "\ninit. 100% ```"
    else:
        msg_str = "``` -- Supressed Start -- \n Complete"
    await Messages(msg_str + "\ninit. 100% ```", CurrentChannel, sysChannel, None)
    ready = 1
    return


####################################################################################################################################################
##########################################################################
@bot.event
async def on_command_error(ctx, error):
    global optsArray
    sysChannel = optsArray[4]
    if isinstance(error, CommandNotFound):
        await ctx.send("command " + str(str(ctx.message.content).split(" ")[0]) + " not found.")
        return
    if isinstance(error, KeyError):
        return
    if isinstance(error, UnboundLocalError):
        return
    await Messages(str(error), None, sysChannel, None)
    await Messages("Error", None, sysChannel, None)
    raise error


##########################################################################
##########################################################################
@bot.event
async def on_message(message):
    global IsAdmin, IsMod
    global AutoScroll, ignoreView
    global nameStr, optsArray, MessageChanID
    global ProxyLog, CommandActive
    global SpotifyScrollVar
    global SpotifyScrollDivCounter, blockedListKnown, blockedListArray
    MessageChanID = str(message.channel.id)
    await asyncio.sleep(0.2)
    strict = optsArray[8]
    sysChannel = optsArray[4]
    ##########################################################################
    ##########################################################################
    if ready == 1:
        if os.path.exists(HomeDir + "\SerbzDir\_strict.txt"):
            strict = 1
        IsAdmin = False
        MessageChanID = str(message.channel.id)
        CurrentID = await Logger.GetChanID()
        nameStr = str(message.author.name) + "|" + str(message.author.discriminator)
        ##########################################################################
        try:
            chanName = str(message.channel.name) + ' ' + str(message.channel.id) + '|||' \
                       + str(message.guild.name) + ' ' + str(message.guild.id)
        except AttributeError:
            chanName = "DM-" + str(message.channel.id)
        response = chanName + '\n' + message.author.name + '|' + message.author.discriminator + '|' \
                   + '--|' + ' ' + message.content + '\n\n'
        ##########################################################################
        if ((message.content)[:1]) == '.':
            if message.content != '.join':
                if (MessageChanID != str(CurrentID)):
                    if message.author.id != 246892047284436992:
                        return
                if (str(message.content).lower()==".view"):
                    ignoreView = False
                    await picSend(message.channel)
                    ignoreView = True
                    return
                if ("DM-" in chanName):
                    return
                if Logger.Blacklist(message):
                    await Messages("blacklisted word in command - " + str(response), None, sysChannel, SerbzChannel)
                    return
                if CommandActive == 1 and str(message.content) != '.restart':
                    await Messages("Command currently active please wait.", message.channel, None, None)
                    return
                if AutoScroll:
                    AutoScroll = False
                    await autoscroll.counter(AutoScroll, None, 0)
                    pyautogui.click(button='middle')
                if strict:
                    await Messages(
                        "Strict/Dev flag set, massive re-write of browser bot is currently under way. Please try again at some other time.",
                        message.channel, None, None)
                    await Messages("Strict/Dev flag set, try later." + str(response), None, None, SerbzChannel)
                    return
            CommandActive = 1
            chrome.driver.maximize_window()
            urlChanged = await chrome.url_change("not so stringy", "string stuff")
            IsAdmin = False
            IsMod = False
            # !#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#
            await bot.process_commands(message)
            # !#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#!#
            if not chrome.VerifyURL():
                await Messages("URL Not Allowed, homepage loaded.", message.channel, None, None)
            URL = await chrome.getURL(1, 1)
            URL = ((str(URL.replace("http://www.", "")).replace("https://www.", "")).split("."))[0]
            urlChanged = await chrome.url_change(str(URL), "not so stringy")
            if urlChanged:
                await asyncio.sleep(2)
                try:
                    x, y = await coordImg(ctx=None,file=(HomeDir + r"\ImageSearch\BlockButton.png"))
                    await asyncio.sleep(1)
                    pyautogui.moveTo(x, y, 0.15)
                except:
                    pass
            ##########################################################################
            msg = (str(message.content)).split(" ")
            msg = msg[0]
            text_file = open(StaticVarDir + r'\IgnoredViewCommands.txt')
            text_fileSplit = str(text_file.read()).split("\n")
            counter = len(text_fileSplit)
            for key in text_fileSplit:
                counter = counter - 1
                if key in msg:
                    ignoreView = True
                    print(str(msg))
                    print(str(key))
                    break
                if counter <= 0:
                    print(str(key))
                    await picSend(message.channel)
                    break
            ##########################################################################
            if SpotifyScrollVar >= 0:
                URL = await chrome.getURL(1, 1)
                if 'spotify.com/search' not in URL:
                    SpotifyScrollVar = -1
                    SpotifyScrollDivCounter = 0
                    songNumber = None
            if ProxyLog == False:
                if solidWhiteImage == open(HomeDir + r"\ImageSearch\screenShot.png", "rb").read():
                    await proxyBox(message.channel)
                    await message.channel.send("Command interrupted, please perform again.")
            ##########################################################################
        CommandActive = 0
        return
    ##################


##########################################################################
##########################################################################
async def proxyBox(channel):
    global ProxyLog
    try:
        x, y = await img2search(HomeDir + r'\ImageSearch\Chrome\ProxySignIn.png')
        pyautogui.moveTo(x - 57, y - 31)
        pyautogui.click(button='left')
    except:
        await picSend(channel)
        return
    await channel.send("Annoying dumbsh*t box diversion success")
    return


@bot.command(name="math")
async def domath(ctx):
    stringy = str(ctx.message.content).split(" ")
    count = 0
    stringyString = ""
    stringyArray = []
    for each in stringy:
        if count != 0:
            try:
                stringyArray.insert(count, int(float(str(each))))
            except:
                stringyArray.insert(count, str(each))
                pass
        count = count + 1
    counter = 0
    value = 0
    for each in stringyArray:
        if counter == 0:
            value = each
        counter = counter + 1
        if str(each) == "+":
            value = value + stringyArray[counter + 1]
        elif str() == "-":
            value = value - stringyArray[counter + 1]
    await Messages(str(value), ctx, None, None)
    return


##########################################################################
##########################################################################
async def picSend(channel):
    global ignoreView, solidWhiteImage, ProxyLog, restoreAnnoyingChrome, automatedAnnoyingChrome
    if ignoreView == True:
        return
    await chrome.view()
    file = discord.File(HomeDir + r"\ImageSearch\screenShot.png")
    await asyncio.sleep(0.25)
    await channel.send(file=file, content=" ")
    return


##########################################################################
##########################################################################
async def AdminCheck(ctx, checkingMod=0):
    global optsArray
    SerbzChannel = optsArray[3]
    sysChannel = optsArray[4]
    text_file = open(StaticVarDir + r"\AdminList.txt")
    AdminListStr = text_file.read()
    AdminList = str(AdminListStr).split("\n")
    text_file.close()
    msg = str(ctx.message.content)
    ctxUserID = ctx.message.author.id
    for userID in AdminList:
        # await Messages(str(userID) + "\n" + str(ctxUserID), None, None, SerbzChannel, ctx.message)
        if str(userID) == str(ctxUserID):
            await Messages("```" + str(ctx.message.author.name) + "#" + str(ctx.message.author.discriminator) + " " \
                           + str(ctx.message.author.id) + " " + ' IS ADMIN' + " -- \'" + msg + "\'```",
                           None, sysChannel, None, ctx.message)
            return True
    if checkingMod == 0:
        await Messages("Permission denied.", ctx, None, None, ctx.message)
    await Messages(
        "``` --- || " + ctx.author.name + "#" + ctx.author.discriminator + ' \n --- || IS NOT ADMIN' + " -- \'" \
        + str(ctx.message.author.id) + " \n --- || " + msg + "\'```", None, sysChannel, None)
    return False


async def ModCheck(ctx):
    global IsAdmin
    global optsArray
    SerbzChannel = optsArray[3]
    sysChannel = optsArray[4]
    text_file = open(StaticVarDir + r"\ModList.txt")
    ModListStr = text_file.read()
    text_file.close()
    ModList = str(ModListStr).split("\n")
    IsAdmin = await AdminCheck(ctx, 1)
    if IsAdmin:
        return True
    msg = str(ctx.message.content)
    ctxUserID = ctx.message.author.id
    for userID in ModList:
        # await Messages(str(userID) + "\n" + str(ctxUserID), None, None, SerbzChannel, ctx.message)
        if str(userID) == str(ctxUserID):
            await Messages("```" + str(ctx.message.author.name) + "#" + str(ctx.message.author.discriminator) + " " \
                           + str(ctx.message.author.id) + " " + ' IS MOD' + " -- \'" + msg + "\'```",
                           None, sysChannel, None, ctx.message)
            return True
    await Messages("Permission denied.", ctx, None, None, ctx.message)
    await Messages("``` --- || " + ctx.author.name + "#" + ctx.author.discriminator + ' \n --- || IS NOT MOD' + " -- \'" \
                   + str(ctx.message.author.id) + " \n --- || " + msg + "\'```", None, sysChannel, None)
    return False

@bot.command(name="link")
async def linkref(ctx):
    URL = await chrome.getURL(line="NaN", var2=None)
    await ctx.send("<" + str(URL) + ">")
    return




@bot.command(name='addmod')
async def addmod(ctx):
    global IsAdmin, optsArray
    sysChannel = optsArray[4]
    IsAdmin = await AdminCheck(ctx)
    if not IsAdmin:
        return
    subcmds = str(ctx.message.content).split(" ")
    user2addname = subcmds[1]
    user2addid = subcmds[2]
    try:
        userIdCheck = await bot.fetch_user(int(str(user2addid)))
    except:
        await Messages(str(on_command_error) + "\n\n" + str(subcmds[2]) + "is not a number or user ID", ctx, None, None,
                       ctx.message)
        return
    await Messages(str(userIdCheck), ctx, sysChannel, None, ctx.message)
    text_file = open(HomeDir + r"\StaticVars\ModList.txt", "a")
    text_file.write("\n" + str(user2addname) + "\n" + str(user2addid))
    text_file.close()
    return


##########################################################################
##########################################################################
@bot.command(name="values")
async def values(ctx, bypass=False):
    global optsArray, MessageChanID, myduckingHeadsetJustDied, chrome_w, chrome_h
    IsAdmin = await AdminCheck(ctx)
    URL = await chrome.getURL("NaN")
    if IsAdmin == False and bypass == False:
        await Messages("Nope", ctx, None, None, ctx.message)
        return

    returnstr = "``` \n" + "--- || devVal: " + str(optsArray[9]) + "\n" + \
                "--- || Window Size: " "W: " + str(chrome_w) + " H: " + str(chrome_h) + \
                "\n--- || CurrentID: " + str(optsArray[1]) + "\n--- || strict: " + str(
        optsArray[8]) + "\n--- || sysChannel: " + str(optsArray[4]) + \
                str(optsArray[5]) + "\n--- || CurrentChannel: " + str(optsArray[0]) + "\n--- || MessageChanID: " + str(
        MessageChanID) + "\n--- || altSysEnable: " + str(optsArray[7]) + "\n--- || myduckingHeadsetJustDied: " + str(
        myduckingHeadsetJustDied) + "\n--- || altSysChanArray: " + str(optsArray[6]) + "\n--- || SerbzChannel: " + \
                str(optsArray[3]) + "\n--- || Current URL: " + str(URL) + "\n ```"
    if bypass == False:
        await Messages(returnstr, ctx, None, None, ctx.message)
    return


##########################################################################
##########################################################################
# noinspection PyTypeChecker
@bot.command(name='clickc')
async def clickc(ctx):
    global optsArray
    global IsMod
    CurrentID = optsArray[1]
    CurrentChannel = bot.get_channel(int(CurrentID))
    IsMod = await ModCheck(ctx)
    CurrentChannel = optsArray[0]

    if IsMod == False:
        await Messages("You must have Admin permissions to use this.", CurrentChannel, None, None, ctx.message)
        return
    sysChannel = optsArray[4]
    # URL = await chrome.getURL(1, 1)
    CoordsSplit = (str(ctx.message.content)[8:]).split(" ")
    # btn = 'left'
    X = int(CoordsSplit[0])
    Y = int(CoordsSplit[1])
    if Y < 100 or Y > 840:
        await Messages("I cannot click there.", ctx, None, None, ctx.message)
        return
    pyautogui.moveTo(int(X), int(Y), 0.15)
    pyautogui.click(button='left')
    await Messages("Clicked X " + str(X) + " Y " + str(Y), CurrentChannel, sysChannel,
                   None)  #########" with " + btn + " mouse button.", CurrentChannel, sysChannel, None)
    return


##########################################################################
########################################################################## 
# noinspection PyTypeChecker
@bot.command(name='whereami')
async def whereami(ctx):
    global SerbzChannel, CurrentChannel, CurrentID
    global sysChannel
    CurrentID = await Logger.GetChanID()
    CurrentChannel = bot.get_channel(int(CurrentID))
    channel = bot.get_channel(int(CurrentID))
    if ctx.message.author.name != 'Serbz' and ctx.message.author.discriminator != '0001':
        return
    URL = await chrome.getURL(1, 1)
    textInvite = await channel.create_invite()
    await Messages('Current ID     ' + str(CurrentID) + '     Channel Name    ' + CurrentChannel, None, sysChannel,
                   SerbzChannel)
    await Messages(textInvite, None, None, SerbzChannel, ctx.message)
    await Messages('Current URL' + str(URL), None, sysChannel, SerbzChannel, ctx.message)


##########################################################################
##########################################################################
@bot.command(name='reload')
async def reload(ctx):
    global myduckingHeadsetJustDied
    global chrome_w, chrome_h, optsArray
    myduckingHeadsetJustDied = -1  # reset counter triggers on send message, nothing in it but leaving it.
    ######## FROM VARIABLES.TXT #########
    text_file = open(HomeDir + r"\variables.txt", "r")
    vars = text_file.read()
    text_file.close()
    varsSplit = str(vars).split("\n")
    CurrentID = int(varsSplit[10])
    QuietMode = int(varsSplit[6])
    Serbz = await bot.fetch_user(int(varsSplit[2]))
    SerbzChannel = await Serbz.create_dm()
    sysChannel = await bot.fetch_channel(int(varsSplit[4]))
    CurrentChannel = await bot.fetch_channel(int(CurrentID))
    altSysChanArray = [str(varsSplit[14]), str(varsSplit[15])]
    altSysEnable = bool(str(varsSplit[12]))
    strict = bool(str(varsSplit[17]))
    devVal = int(str(varsSplit[19]))
    supressStart = bool(varsSplit[23])
    optsArray = [CurrentChannel, CurrentID, Serbz, SerbzChannel, sysChannel, QuietMode, altSysChanArray, altSysEnable,
                 strict, devVal, supressStart]
    ##
    chrome_w, chrome_h = await chrome.getSize()

    await ctx.send("Reloaded")
    await values(ctx)
    return


@bot.command(name='restart')
async def restart(ctx, Bypass=False):
    global optsArray
    sysChannel = optsArray[4]
    CurrentChannel = optsArray[0]
    SerbzChannel = optsArray[3]
    CurrentID = await Logger.GetChanID()
    CurrentChannel = bot.get_channel(int(CurrentID))
    if Bypass == False:
        IsAdmin = await AdminCheck(ctx)
        if IsAdmin == False:
            await Messages('You do not have permission to use this command.', ctx, None, None)
            return
    await Messages("``` -#-#-#-#-# Restarting. #-#-#-#-#- ```", CurrentChannel, sysChannel, None)
    MsgStr = "```\n"
    ahk.run_script("winset, AlwaysOnTop, off, A", blocking=False)
    await asyncio.sleep(0.25)
    os.system("taskkill /f /im Autohotkey.exe /T")
    os.system("taskkill /f /im Autohotkeyu64.exe/T")
    os.system("taskkill /f /im webdriver.exe /T")
    os.system("taskkill /f /im chromedriver.exe /T")
    os.system("taskkill /f /im webdriver.exe /T")
    os.system("taskkill /f /im firefox.exe /T")
    MsgStr = MsgStr + 'processes ended.\n'
    try:
        ##############################
        inputFile = open(HomeDir + r"\bot.py", "r")
        exportFile = open(HomeDir + r"\bot2.py", "w")
        for line in inputFile:
            new_line = line.replace('\t', '    ')
            exportFile.write(new_line)
        inputFile.close()
        exportFile.close()

        inputFile = open(HomeDir + r"\bot2.py", "r")
        exportFile = open(HomeDir + r"\bot.py", "w")
        for line in inputFile:
            exportFile.write(line)
        inputFile.close()
        exportFile.close()
        MsgStr = MsgStr + 'Updated and backed up self.\n'
        #############################
    except  PermissionError:
        MsgStr = MsgStr + 'bot.py permissions error exception.\n'
        await Messages(r'bot.py permissions error exception.', None, None, SerbzChannel)
        pass

    try:
        #############################
        inputFile = open(HomeDir + r"\WinManager.py", "r")
        exportFile = open(HomeDir + r"\WinManager2.py", "w")
        for line in inputFile:
            new_line = line.replace('\t', '    ')
            exportFile.write(new_line)
        inputFile.close()
        exportFile.close()

        inputFile = open(HomeDir + r"\WinManager2.py", "r")
        exportFile = open(HomeDir + r"\WinManager.py", "w")
        for line in inputFile:
            exportFile.write(line)
        inputFile.close()
        exportFile.close()
        MsgStr = MsgStr + 'Window management update/backup complete.\n'
        #############################
    except  PermissionError:
        MsgStr = MsgStr + 'Window.py permissions error exception.\n'
        await Messages('Window.py permissions error exception', None, None, SerbzChannel)
        pass

    try:
        #############################
        inputFile = open(HomeDir + r"\chrome.py", "r")
        exportFile = open(HomeDir + r"\chrome2.py", "w")
        for line in inputFile:
            new_line = line.replace('\t', '    ')
            exportFile.write(new_line)
        inputFile.close()
        exportFile.close()

        inputFile = open(HomeDir + r"\chrome2.py", "r")
        exportFile = open(HomeDir + r"\chrome.py", "w")
        for line in inputFile:
            exportFile.write(line)
        inputFile.close()
        exportFile.close()
        MsgStr = MsgStr + 'Chrome controller update/backup complete.\n'
        ##############################
    except  PermissionError:
        MsgStr = MsgStr + 'Chrome.py permissions error exception.\n'
        await Messages('Chrome.py permissions error exception.', None, None, SerbzChannel)
        pass
    try:
        ##############################
        inputFile = open(HomeDir + r"\Logger.py", "r")
        exportFile = open(HomeDir + r"\Logger2.py", "w")
        for line in inputFile:
            new_line = line.replace('\t', '    ')
            exportFile.write(new_line)
        inputFile.close()
        exportFile.close()

        inputFile = open(HomeDir + r"\Logger2.py", "r")
        exportFile = open(HomeDir + r"\Logger.py", "w")
        for line in inputFile:
            exportFile.write(line)
        inputFile.close()
        exportFile.close()
        aMsgStr = MsgStr + 'Logger update/backup complete.'
        #############################
    except  PermissionError:
        MsgStr = MsgStr + 'Logger.py permissions error exception.\n'
        await Messages('Logger.py permissions error exception.', None, None, SerbzChannel)
        pass
    if os.path.exists(HomeDir + r"\VariableVariables\spotifyCoords.txt"):
        os.remove(HomeDir + r"\VariableVariables\spotifyCoords.txt")
    ahk.run_script(
        "Run cmd.exe /c start "" /D " + ScriptDir + " \
        /W backup.bat", blocking=False)
    MsgStr = MsgStr + 'Backup started, blocking false \n'
    await Logger.ValuesUpdater(8, False)  # HardReset val
    MsgStr = MsgStr + 'HardReset flag state set false\nend ```'
    if supressStart is not True:
        await Messages(str(MsgStr), None, sysChannel, None)
    os.execv(sys.executable, ['python'] + sys.argv)
    SystemExit()
    sys.exit()


##########################################################################
##########################################################################
@bot.command(name='forward')
async def forward(ctx):
    global SerbzChannel
    global sysChannel
    chrome.forward()
    return


##########################################################################
##########################################################################
@bot.command(name='back')
async def back(ctx):
    chrome.back()
    return


##########################################################################
##########################################################################
@bot.command(name='discreset')
async def discreset(ctx, bypass=False):
    global nameStr, optsArray
    sysChannel, SerbzChannel = optsArray[4], optsArray[3]
    if bypass == False:
        if nameStr != r"Serbz|0001" and nameStr != r"Serbz|0002":
            await Messages("Negative.", ctx, sysChannel, SerbzChannel, ctx.message)
            return
        await Messages("Restarting the puppet's Discord...", None, sysChannel, SerbzChannel, ctx.message)
    await discRestart()
    return


##########################################################################
##########################################################################
@bot.command(name='readsearch')
async def readsearch(ctx):
    global optsArray
    sysChannel = optsArray[4]
    SerbzChannel = optsArray[3]
    chrome.new_tab()
    await asyncio.sleep(0.5)
    stringVal = str(ctx.message.content)
    await b_search(ctx)
    await asyncio.sleep(3)
    result = await readImage(167, 269, 822, 569, False, "chrome")
    await Messages(str(result), ctx, sysChannel, SerbzChannel, ctx.message)
    chrome.close_tab()
    return


##########################################################################
##########################################################################
@bot.command(name='click')
async def click(ctx):
    await focus("chrome")
    if len(ctx.message.content) <= 7:
        await chrome.clickm()
    else:
        ahk.run_script(r"winactivate, chrome")
        ahk.run_script(r"winactivate, ahk_exe chrome.exe")
        pyautogui.hotkey('ctrl', 'f')
        await asyncio.sleep(0.5)
        pyautogui.write(str(ctx.message.content)[7:], 0.15)
        await asyncio.sleep(0.5)
        pyautogui.hotkey('ctrl', 'return')
    return


##########################################################################
##########################################################################
@bot.command(name='find')
async def find(ctx):
    keycount = 0
    cmdsubstr = str(ctx.message.content)[6:]
    cmdsplit = str(ctx.message.content).split(" ")
    print(str(cmdsplit[1]))
    print(str(str(cmdsplit[1])[:1]))
    if str(str(cmdsplit[1])[:1]) == "-":
        if str(cmdsplit[1]) == "-next":
            keycount = int(2)
        elif str(cmdsplit[1]) == "-prev":
            keycount = int(1)
        try:
            count = int(cmdsplit[2])
        except IndexError:
            count = int(1)
        if keycount == 2:
            pyautogui.press('tab')
            pyautogui.press('tab')
            while count > 0:
                pyautogui.press('space')
                # await asyncio.sleep(1)
                count = int(count) - int(1)
            pyautogui.hotkey('shift', 'tab')
            # await asyncio.sleep(1)
            pyautogui.hotkey('shift', 'tab')
        elif keycount == 1:
            pyautogui.press('tab')
            while count > 0:
                pyautogui.press('space')
                # await asyncio.sleep(1)
                count = int(count) - int(1)
            pyautogui.hotkey('shift', 'tab')
    else:
        await focus("chrome")
        pyautogui.hotkey('ctrl', 'f')
        pyautogui.write(cmdsubstr)
    return


##########################################################################
##########################################################################
@bot.command(name='xclick')
async def xclick(ctx):
    global optsArray
    sysChannel = optsArray[4]
    SerbzChannel = optsArray[3]
    response = str(xclick(ctx.message.content[8:])) + "-"
    await Messages(response, None, sysChannel, SerbzChannel, ctx.message)
    return


##########################################################################
##########################################################################
@bot.command(name='ytsearch')
async def Bytsearch(ctx):
    response = "searching for" + ctx.message.content[9:] + " on youtube"
    await chrome.ytsearch(ctx.message.content[9:])
    await Messages(response, ctx, None, None, ctx.message)
    return


##########################################################################
##########################################################################
@bot.command(name='refresh')
async def refresh(ctx):
    global SpotifyScrollVar
    SpotifyScrollVar = -1
    chrome.refresh()
    await Messages("Refreshing webpage", ctx, None, None, ctx.message)
    return


##########################################################################
##########################################################################
@bot.command(name='playpause')
async def playpause(ctx):
    URL = await chrome.getURL(1, 1)
    if 'spotify' in str(URL):
        c5, y6 = await coordImg(ctx, HomeDir + r"\ImageSearch\Spotify\menu.png", "anything here")
        await clk(c5, y6)
        return
    chrome.playPause()
    return


##########################################################################
##########################################################################
@bot.command(name='tab')
async def tab(ctx):
    global AutoScroll
    sysChannel = optsArray[4]
    SerbzChannel = optsArray[3]
    numTab = str(ctx.message.content[5:])
    if (numTab == 'new'):
        chrome.new_tab()
    elif (numTab == 'close'):
        chrome.close_tab()
    else:
        numTab = int(ctx.message.content[5:])
        if (numTab == 'help' or numTab == 'info'):
            await Messages('Tab commands:', ctx, sysChannel, SerbzChannel, ctx.message)
            await Messages(' .tab new - Creates a new tab', ctx, sysChannel, SerbzChannel, ctx.message)
            await Messages(' .tab `# ` Activates one of the currently open tabs', ctx, sysChannel, SerbzChannel,
                           ctx.message)
            await Messages(
                '----- tab values decrease in order opened/closed not the order in which they are displayed.', ctx,
                sysChannel, SerbzChannel)
            await Messages('----- and under certain circumstances it may still be possible that tab '
                           '1 exists, tab 2 does not and tab 3 does.', ctx, sysChannel, SerbzChannel)
            await Messages(' .tab close - Closes the currently active tab, tab 1 may never be closed.', ctx, sysChannel,
                           SerbzChannel)
        elif (numTab):
            chrome.switch_tab(numTab)
        else:
            response = "Please enter a number, new, or close, refer to .tab \
            help for more information"
            await Messages(response, ctx, None, None, ctx.message)
            return


##########################################################################
##########################################################################
@bot.command(name='view')
async def view(ctx):
    await picSend(ctx.channel)
    return


##########################################################################
##########################################################################
@bot.command(name='video')
async def videoOnOff(ctx):
    global optsArray
    sysChannel = optsArray[4]
    await focus("d")
    x, y = await discVideoCheck()
    if x == -1 and y == -1:
        x, y = await discVideoCheck2()
        await Messages(r"not found once", None, sysChannel, None, ctx.message)
        if x == 0 and y == 0:
            await Messages(r"unable to turn video on.", None, sysChannel, None, ctx.message)
            await focus("chrome")
            return
    x1 = x - 55
    x2 = x + 55
    y1 = y - 15
    y2 = y + 15
    await clk(x, y)
    foobar = await colorSearch("d", HomeDir + r"\ImageSearch\Discord\discColorSearch.png", x1, y1, x2, y2)
    if foobar == True:
        await asyncio.sleep(1)
        pyautogui.move(0, -50, 1)
        await asyncio.sleep(0.5)
        pyautogui.click(button='left')
        return
    else:
        await Messages(r"not found once, but found the second, video is currently off. Turning on.", None, sysChannel,
                       None)
        await videoOnC(ctx)
        return


#######################################
async def videoOnC(ctx):
    global optsArray
    sysChannel = optsArray[4]
    chrome.switch_tab(1)
    title = await chrome.mainTabTitle()
    await focus("d")
    MsgStr = "``` \n"
    titleMsgStr = "-#-#-#-#-#-#-#-#- \n Video command: \n -#-#-#-#-#-#-#-#- \nTitle to search for:\n" + str(
        title) + "\n\n"
    try:
        x, y = pyautogui.locateCenterOnScreen(ImgDir + r"\Discord\goLive.png")
    except TypeError:
        await Messages("Error. Sleeping 3, trying again.", None, sysChannel, None, ctx.message)
        await asyncio.sleep(0.7)
        pyautogui.click(button='left')
        await asyncio.sleep(1)
        await videoOnC(ctx)
        await asyncio.sleep(0.5)
        return
    await asyncio.sleep(0.5)
    W = 200
    H = 45
    xC1 = [int(float(x)) - 150, int(float(x)) - 150 + W]
    xC2 = [xC1[0] - W, xC1[1] - W]
    yR2 = [int(float(y)) - 80, int(float(y)) - 80 + H]
    yR1 = [yR2[0] - 145, yR2[1] - 145]
    box1 = [xC1[0], yR2[0], xC1[1], yR2[1]]
    box2 = [xC2[0], yR2[0], xC2[1], yR2[1]]
    box3 = [xC1[0], yR1[0], xC1[1], yR1[1]]
    box4 = [xC2[0], yR1[0], xC2[1], yR1[1]]
    Boxes = [box1, box2, box3, box4]
    if int(x) > 0 and int(y) > 0:  # 970,691
        counter = -1
        title = str(title)[:20]
        for key in Boxes:
            await focus("d")
            counter = counter + 1
            search = await readImage(Boxes[counter][0], Boxes[counter][1],
                                     Boxes[counter][2], Boxes[counter][3], False, "d")
            MsgStr = MsgStr + "\nImage Read: " + str(search)
            if ((str(title) in str(search)) or (str(search) in str(title)) or
                    ((str(search)[5:15] in str(title)) and len(search) >= 5)):
                MsgStr = MsgStr + "Stream Window found"
                break
            if counter >= 3:
                await focus("d")
                await focus("d")
                await videoOnC(ctx)
                return
        x = int(Boxes[counter][0] + 85)
        y = int(Boxes[counter][1] - 45)
        MsgStr = MsgStr + "\nCoords: " + str(x) + "," + str(y) + "\n"
        await focus("d")
        await clk(x, y)
        await asyncio.sleep(9.5)
        await img2click(ImgDir + r"\Discord\discLive.png")
        await Messages(MsgStr + "\nComplete. \n ```", ctx, sysChannel, None, ctx.message)
        await focus("chrome")
        return


##########################################################################
##########################################################################
@bot.command(name='bsearch')
async def b_search(ctx):
    stringVal = str(ctx.message.content)
    chrome.bSearch(ctx, stringVal[9:])
    return


##########################################################################
##########################################################################
@bot.command(name='http')
async def http(ctx):
    global optsArray, MessageChanID
    CurrentID = await Logger.GetChanID()
    sysChannel = optsArray[4]
    SerbzChannel = optsArray[3]
    MessageChanID = str(ctx.message.channel.id)
    await focus("chrome")
    print(str(CurrentID) + '|' + str(MessageChanID) + '|' + str(ctx.message.content)[6:])
    response = await chrome.ASYNChttp(str(ctx.message.content)[6:])
    await Messages(str(ctx.message.author.name) + "#" + str(ctx.message.author.discriminator) + " | | | | | " + str(
        ctx.message.content), None, sysChannel, SerbzChannel)
    await Messages("Browsing to.. <" + str(response) + ">", ctx, None, SerbzChannel, ctx.message)
    return


##########################################################################
##########################################################################
@bot.command(name='fmovie')
async def fmovie(ctx):
    response = await chrome.fmovie(ctx.message.content[8:])
    await Messages(response, ctx, None, None, ctx.message)
    return


##########################################################################
##########################################################################
# noinspection PyTypeChecker
@bot.command(name='netflix')
async def netflix(ctx):
    global chrome_w, chrome_h
    await focus("chrome")
    devVal, SerbzChannel, sysChannel = optsArray[9], optsArray[3], optsArray[4]
    start1 = t.time()
    chrome_w, chrome_h = await chrome.getSize()
    msg_str = "starting with chrome window dimensions: \n W: " + str(chrome_w) + "\nH: " + str(chrome_h)
    msg_str1 = "\nNetFlix Command\n-#-#-#-#-#-#-#-#-#-#-\nStart time:" + str(start1)
    if len(ctx.message.content) <= 9:
        await chrome.ASYNChttp("https://netflix.com")
        return
    this_message = str(ctx.message.content[9:])
    split_string = this_message.split()
    string_builder = ""
    season = 1
    episode = 1
    percent = -1
    nf_back = -1
    nf_forward = -1
    for subStr in split_string:
        if subStr.startswith('-%'):
            percent = float(min(max(int(subStr.replace('-%', '')), 0), 100) / 100.0)
            await chrome.coordClick(x=35 + int(1455.0 * percent), y=800)
            await Messages("Set episode time to " + str(int(100 * percent)) + "%", ctx, None, None, ctx.message)
            return
        elif subStr.startswith('-back'):
            nf_back = int(subStr.replace('-back', ''))
            msg_str = msg_str + str("\n subStr starts with back")
        elif subStr.startswith('-forward'):
            nf_forward = int(subStr.replace('-forward', ''))
            msg_str = msg_str + str("\n subStr starts with forward")
        elif subStr.startswith('-s'):
            season = int(subStr.replace('-s', ''))
            msg_str = msg_str + str("\n subStr starts with -s")
        elif subStr.startswith('-e'):
            episode = int(subStr.replace('-e', ''))
            msg_str = msg_str + str("\n subStr starts with -e")
        else:
            string_builder = string_builder + subStr + ' '
    if nf_back > 0:
        pyautogui.press('left', presses=nf_back)
    elif nf_forward > 0:
        pyautogui.press('right', presses=nf_forward)
    else:
        this_message = string_builder[:-1]
        msg_str = msg_str + "\nCHnetflix1 sent param: " + str(this_message) + "\n" + "time: " + str(t.time()) + "\n"
        await chrome.CHnetflix1(ctx, this_message, season, episode)
        y1 = 115
        y2 = y1 + 40
        x_base = ((chrome_w - 850) / 2) - 20  # 403
        x1 = x_base + 640 - 38  # 1005
        x2 = x_base + 710  # 1113
        countduck = 0
        countf = 0
        offset = 0
        skiptry = False
        start2 = t.time()
        msg_str2 = "\n--------\nImage Searching start: " + str(start2)
        msg_str = msg_str + "\n -#-#-#-#- \n Img Search Begin \n -#-#-#-#- \n"
        while countf < 15:
            if countf == 0:
                offset = 40
            elif countf == 1:
                skiptry = True
            else:
                offset = 0
                skiptry = False
            if not skiptry:
                read_string = ""
                msg_str = msg_str + "\nwhile loop: " + str(countf) + " \n"
                try:
                    read_string = await readImage(int(float(x1)) + int(offset),
                                                  int(float(y1 + (40 * countf) + (offset * float(0.2)))),
                                                  int(float(x2)) + int(offset),
                                                  int(float(y2 + (40 * countf) + (offset * float(0.2)))), False,
                                                  "chrome")
                    msg_str = msg_str + "readString btn: " + str(read_string) + "\n" + str(
                        int(float(x1)) + int(offset)) + " " + \
                              str(int(float(y1 + (40 * countf) + (offset * float(0.2))))) + "\n" + str(
                        int(float(x2)) + int(offset)) + " " + str(
                        int(float(int(y2 + (40 * countf) + (offset * float(0.2))))))
                except FailedBackendError:
                    countduck = countduck + 1
                    await asyncio.sleep(countduck)
                    if os.path.exists(HomeDir + r'\ImageSearch\im' + "WM_readImage" + r'.png'):
                        os.remove(HomeDir + r'\ImageSearch\im' + "WM_readImage" + r'.png')
                    await Messages(
                        "all backends failed! FailedBackendError exception raised. - " + str(countduck) + " - " + str(
                            countf) + "\nAttempted to remove " \
                        + HomeDir + r'\ImageSearch\im' + "WM_readImage" + r'.png - ' + str(countduck), None, sysChannel,
                        None)
                    read_string = "duck"
                    pass
                if str(r'Season ' + str(season)) in str(read_string) and read_string != "":
                    end2 = t.time()
                    await clk(x1 + ((x2 - x1) / 2), y1 + ((y2 - y1) / 2) + (40 * countf))
                    break
                end2 = t.time()
            countf = countf + 1
    response = await chrome.CHnetflix2(ctx, this_message, season, episode)
    end1 = t.time()
    msg_str1 = msg_str1 + "\nEnd time: " + str(end1)
    msg_str2 = msg_str2 + "\n Image Searching End time: " + str(end2)
    msg_str3 = "\n" + msg_str1 + "\n" + msg_str2
    await Messages("\n" + response + "\n ```" + str(msg_str3) + "``` ```" + str(msg_str) + "```", ctx, None,
                   SerbzChannel)
    return
@bot.command(name="musicbotlist")
async def musicbotlist(ctx):
    response = "searching for " + ctx.message.content[14:] + " on youtube"
    chrome.ytsearch(ctx.message.content[14:] + " playlist")
    await Messages(response, ctx, None, None, ctx.message)
    await asyncio.sleep(3)
    ahk.run_script(r"winactivate, chrome")
    ahk.run_script(r"winactivate, ahk_exe chrome.exe")
    pyautogui.hotkey('ctrl', 'f')
    await asyncio.sleep(0.5)
    pyautogui.write("full playlist", 0.15)
    await asyncio.sleep(0.5)
    pyautogui.hotkey('ctrl', 'return')
    await asyncio.sleep(3)
    URL = await chrome.getURL(line="NaN", var2=None)
    await ctx.send("~addlist " + str(URL))
    return




@bot.command(name="st")
async def st(ctx):
    await searchtext(ctx)
    return
@bot.command(name='searchtext')
async def searchtext(ctx):
    start1 = t.time()
    await ctx.send("\nSearchText Command\n-#-#-#-#-#-#-#-#-#-#-\nStart time:" + str(start1))

    N_quadrants = []
    searchStringSpl = str(ctx.message.content).split(" ")
    # searchString = str(ctx.message.content)[12:]
    searchStringSpl.pop(0)
    searchString = ""
    counter = 0
    skip = 0
    click = False
    foc = "chrome"

    #for subStr in searchStringSpl:
    #    counter = counter + 1
    #    if subStr.startswith('-click'):
    #        click = True
    ##        return
     #   elif subStr.startswith('-focus'):
     #       try:
     #           focus = searchStringSpl[counter+1]
     ##       except IndexError:
      #          await ctx.send("No Focus specified")
      #          return
      #      break
      #  else:
      #      searchString = str(searchString).lower() + str(subStr).lower() + ' '

    for each in searchStringSpl:
        if str(each).lower() == '-click':
            click = True
            skip = 1
        if str(each).lower() == '-focus':
            try:
                foc = str(searchStringSpl[counter+1]).lower()
                break
            except IndexError:
                await ctx.send("No focus specified")
                pass
        if counter == 0:
            spaceStr = ""
        else:
            spaceStr = " "
        if skip != 1:
            searchString = searchString + spaceStr + str(each)
        else:
            skip = 0
        counter = counter + 1
    await ctx.send(str(searchString) + ".. Searching.")
    await focus(foc)
    print("Width =", GetSystemMetrics(0))
    print("Height =", GetSystemMetrics(1))
    half_height = GetSystemMetrics(1) / 2
    half_width = GetSystemMetrics(0) / 2

    #                       top left                                bottom left
    quadrants = [[0, 0, half_width, half_height], [0, half_height, half_width, (half_height * 2)-30],
                 #          top right                               bottom right
                 [half_width, 0, half_width * 2, half_height],
                 [half_width, half_height, half_width * 2, (half_height * 2)-30] ]
    counter = -1
    counter2 = 0
    found_quadrants = []
    Shift = 0
    counter3 = 0
    counter4 = 0
    colorBlind = False
    while counter < 10:
        counter = counter + 1
        if counter >= 4:
            counter = 0
            if counter2 == 0 and counter3 <= 3:
                if not colorBlind:
                    colorBlind = not colorBlind
                counter3 = counter3 + 1
                if counter3 == 2 or counter3 == 3:
                    Shift = 150
                    ShiftDir = 1
                    if counter3 == 3:
                        ShiftDir = -1
                    quadrants = [[0 + (ShiftDir*Shift), 0 + (Shift*ShiftDir), (Shift*ShiftDir) + (half_width * 2),
                                  (half_height * 2) + (ShiftDir*Shift)]]
            elif counter3 > 3 and counter2 == 0:
                await ctx.send("Can't find text.")
                return
            else:
                if counter2 <= 4 and counter4 <= 3 and counter2 != 0:
                    counter4 = counter4 + 1
                    if counter4 == 1:
                        inverse = 1
                        ShiftMult = 5
                    elif counter4 == 2:
                        inverse = -1
                        ShiftMult = 4
                    elif counter4 == 3:
                        inverse = 1
                        ShiftMult = 2
                    Shift = (30 * ShiftMult) * inverse
                    quadrants = [[found_quadrants[0] + Shift, found_quadrants[1] + int(float(Shift / 4)),
                                  found_quadrants[2] + Shift,
                                  found_quadrants[3] + int(float(Shift / 4))]]
                elif counter3 > 3 or counter4 > 3:
                    break
                else:
                    break
        if Shift != 150:
            try:
                text = await readImage(quadrants[counter], binary=colorBlind)
                textSpl = str(text).split("\n")
                text = ""
                for line in textSpl:
                    if not line.isspace():
                        text = text + line
                #await ctx.send(file=discord.File(HomeDir + r'\ImageSearch\im' + "WM_readImage" + r'.png'))
            except:
                pass
        if str(searchString).lower() in str(text).lower() or Shift == 150:
            if Shift != 150:
                counter2 = counter2 + 1
                found_quadrants = quadrants[counter]
                if os.path.exists(HomeDir + r'\ImageSearch\im' + "WM_readImageTextFound" + r'.png'):
                    os.remove(HomeDir + r'\ImageSearch\im' + "WM_readImageTextFound" + r'.png')
                os.rename(HomeDir + r'\ImageSearch\im' + "WM_readImage" + r'.png', HomeDir + r'\ImageSearch\im' + \
                          "WM_readImageTextFound" + r'.png')
                await ctx.send(file=discord.File(HomeDir + r'\ImageSearch\im' + "WM_readImageTextFound" + r'.png'),
                               content="WM_readImageTextFound\n"
                                       "" + str(searchString) + " - \n\n " + str(text))
            Shift = 0
            text = ""
            N_quadrants = [quadrants[counter][0], quadrants[counter][1], quadrants[counter][2], quadrants[counter][3]]
            quadrants = [
                # bottom right    #################### 0
                [((N_quadrants[2] - N_quadrants[0]) / 2) + N_quadrants[0],
                 ((N_quadrants[3] - N_quadrants[1]) / 2) + N_quadrants[1],
                 N_quadrants[2],
                 N_quadrants[3]],
                # Top Left ########################## 1
                [N_quadrants[0],
                 N_quadrants[1],
                 ((N_quadrants[2] - N_quadrants[0]) / 2) + N_quadrants[0],
                 ((N_quadrants[3] - N_quadrants[1]) / 2) + N_quadrants[1]],
                # bottom left           ############ 2
                [N_quadrants[0],
                 ((N_quadrants[3] - N_quadrants[1]) / 2) + N_quadrants[1],
                 ((N_quadrants[2] - N_quadrants[0]) / 2) + N_quadrants[0],
                 N_quadrants[3]],
                # Top right ######################## 3
                [((N_quadrants[2] - N_quadrants[0]) / 2) + N_quadrants[0],
                 N_quadrants[1],
                 N_quadrants[2],
                 ((N_quadrants[3] - N_quadrants[1]) / 2) + N_quadrants[1]]
            ]
            endCycleStr = ""
            counter = -1
    if counter2 >= 1:
        #found_quadrants
        counter = -1
        counter2 = 0
        counter3 = -1
        N_quadrants = [N_quadrants[0], N_quadrants[1], N_quadrants[2], N_quadrants[3]] #last found quadrants without trim
        searchStringF = ""
        textF = ""
        countersFailed = [0, 0, 0, 0]
        while counter < 6:
            print("--------WHILE1---------")
            print(str(counter))
            print(str(counter2))
            print(str(counter3))
            if counter3 == counter2:
                break
            else:
                counter = -1

            counter3 = counter2
            print("--------WHILE2---------")
            print(str(counter))
            print(str(counter2))
            print(str(counter3))
            for coord in N_quadrants:
                counter = counter + 1
                if countersFailed[counter] != 1:
                    if counter == 2 or counter == 3:
                        coord = coord - 25
                        if counter == 2:
                            quadrants = [N_quadrants[0], N_quadrants[1], coord, N_quadrants[3]]
                        else:
                            quadrants = [N_quadrants[0], N_quadrants[1], N_quadrants[2], coord]
                    else:
                        coord = coord + 25
                        if counter == 0:
                            quadrants = [coord, N_quadrants[1], N_quadrants[2], N_quadrants[3]]
                        else:
                            quadrants = [N_quadrants[0], coord, N_quadrants[2], N_quadrants[3]]

                    try:
                        text = await readImage(quadrants, binary=colorBlind)
                        textSpl = str(text).split("\n")
                        text = ""
                        for line in textSpl:
                            if not line.isspace():
                                text = text + line
                    except:
                        pass
                    print("--------FOR---------")
                    print(str(counter))
                    print(str(counter2))
                    print(str(counter3))
                    print(str(quadrants))
                    print(str(N_quadrants))
                    if str(searchString).lower() in str(text).lower():

                        try:
                            if os.path.exists(HomeDir + r'\ImageSearch\im' + "WM_readImageTextFound" + r'.png'):
                                os.remove(HomeDir + r'\ImageSearch\im' + "WM_readImageTextFound" + r'.png')
                            os.rename(HomeDir + r'\ImageSearch\im' + "WM_readImage" + r'.png',
                                      HomeDir + r'\ImageSearch\im' + \
                                      "WM_readImageTextFound" + r'.png')
                            await ctx.send(file=discord.File(HomeDir + r'\ImageSearch\im' + "WM_readImageTextFound" + r'.png'),
                                       content="WM_readImageTextFound\n"
                                               "" + str(searchString) + " - \n\n " + str(text))
                        except:
                            pass
                        searchStringF = searchString
                        textF = text
                        N_quadrants = quadrants
                        counter2 = counter2 + 1
                        print("--------FORMATCH---------")
                        print(str(counter))
                        print(str(counter2))
                        print(str(counter3))
                        print(str(quadrants))
                        print(str(N_quadrants))
                    else:
                        countersFailed[counter] = 1

        #counter = 0
        #counter4 = 0
        #while counter5 < 10:
        #    counter2 = counter2 + 1  # quadrant to trim
        #    if counter2 > 4:
        #        N_quadrants = quadrants
        #        break
        #    for quadrant in N_quadrants: #4 quadrants loop for each
        #        counter = counter + 1
        #        #if counter == 2 or counter == 4:
        #        #O_quadrant = quadrant - (mult)    # * counter) counter = counter + 1
        #        # bottom right    #################### 0
        #        mult3 = 7 * counter4
        #        mult = [0, 0, 0, 0]
        #        mult2 = [0, 0, 0, 0]
        #        mult[counter] = 7 #trim by 7
        #        mult2[counter2] = 1 #which quadrant are we trimming
        #        quadrants = [
        #        ((N_quadrants[2] - (N_quadrants[0]) / 2) + N_quadrants[0])*mult2[0] + mult[0] - mult3,
        #        ((N_quadrants[3] - (N_quadrants[1]) / 2) + N_quadrants[1])*mult2[1] + mult[1] - mult3,
        #        ((N_quadrants[2] - (N_quadrants[0]) / 2) + N_quadrants[1])*mult2[2] - mult[2] - mult3,
        #         ((N_quadrants[3] - (N_quadrants[1]) / 2) + N_quadrants[1])*mult2[3] - mult[3] - mult3
        #         ]
        #        text = await readImage(quadrants[counter], binary=colorBlind)
        #        textSpl = str(text).split("\n")
        #        text = ""
        #        for line in textSpl:
        #            if not line.isspace():
        #                text = text + line
        #        if str(searchString).lower() in str(text).lower() and counter2 <= 4:
        #            if counter == 4:
        #                counter = 0 #reset main counter if all read
        #                counter2 = 0
        #        elif counter == 5:
        #            counter4 = counter4 + 1 #mult3 permanent -7 pixel change if all read

        if counter2 >= 3 and click is True:
            x1, y1 = await img2click(HomeDir + r'\ImageSearch\im' + "WM_readImageTextFound" + r'.png', 2)
            await ctx.send(str(x1) + " " + str(y1))
            pyautogui.moveTo(x1,y1,0.15)
            pyautogui.click(button='left')
            await ctx.send("clicked.")
        end = t.time()
        timeDiff = -int(start1) + int(end)
        await ctx.send(file=discord.File(HomeDir + r'\ImageSearch\im' + "WM_readImageTextFound" + r'.png'),
                   content="WM_readImage\n"
                           "" + str(searchStringF) + " - \n\n " + str(textF) + "\n\n" + str(int(start1)) + "\n\n" + str(int(end)) + "\n\n" + str(int(timeDiff)))

    if counter2 == 0:
        await ctx.send("not found ended.")

    return


##########################################################################
##########################################################################
@bot.command(name='purpose')
async def purpose(ctx):
    response = "```I am an in development bot, that video streams a browser, and all of its users control " \
               "the browser through me."
    response2 = "I am currently fully functional, however, still in early development```"
    await Messages(response + "\n" + response2, ctx, None, None, ctx.message)
    return


##########################################################################
##########################################################################
@bot.command(name='loveme')
async def love_me(ctx):
    response = 'https://i.imgur.com/gezCyXv.png'
    await Messages(response, ctx, None, None, ctx.message)
    response = 'My heart is made of beep.. Also, ew'
    await Messages(response, ctx, None, None, ctx.message)
    return


@bot.command(name="cartoon")
async def cartoonlist(ctx):
    global optsArray
    sysChannel = optsArray[4]
    episode = 0
    msgContentSpl = str(ctx.message.content).split(" ")
    counter = 0
    season = 0
    searchString = ""
    for key in msgContentSpl:
        counter = counter + 1
        if counter != 1:
            if key.lower() == 'season':
                season = msgContentSpl[counter]
            if key.lower() == 'episode':
                episode = msgContentSpl[counter]
                break
            searchString = searchString + " " + key
    await Messages("Searching for: " + str((searchString.replace(" ", "-")).lower())[1:], ctx, None, None, ctx.message)
    sysChannel = optsArray[4]
    URL = "https://www.wcoforever.net/cartoon-list"
    page = requests.get(URL)
    data = page.text
    soup = BeautifulSoup(data, features="lxml")
    stringy = ""
    for link in soup.find_all('a'):
        if str((searchString.replace(" ", "-")).lower())[1:] in str(link).lower():
            stringy = stringy + "\n" + str(link.get('href'))
            if episode != 0:
                break
            if len(stringy) > 900:
                stringy2 = ""
                for each in str(stringy).split("\n"):
                    stringy2 = stringy2 + "<" + str(each) + ">\n"
                await Messages("" + str(stringy2) + "", ctx, None, None, ctx.message)
                stringy = ""
                season = 0
    if episode == 0:
        if stringy != "":
            stringy2 = ""
            for each in str(stringy).split("\n"):
                stringy2 = stringy2 + "<" + str(each) + ">\n"
            await Messages("" + str(stringy2) + "", ctx, None, None, ctx.message)
        return
    else:
        if season == 0:
            return
        else:
            await Messages(str(episode), ctx, None, None)
            URL = str(stringy)
            page = requests.get(URL)
            data = page.text
            soup = BeautifulSoup(data, features="lxml")
            for link in soup.find_all('a'):
                stringy = str(link.get('href'))
                stringySpl = stringy.split("-")
                counter = -1
                for words in stringySpl:
                    counter = counter + 1
                    await Messages(str(stringySpl[counter]), ctx, None, None)
                    try:
                        if words.lower() == 'episode' and str(stringySpl[counter + 1]) == str(episode):
                            await Messages("<" + str(stringy) + ">", ctx, None, None, ctx.message)
                            page = requests.get(stringy)
                            parsed = json.loads(page.content)
                            text_file = open(HomeDir + r"\HTML\cartoonRead.txt", "w")
                            text_file.write(parsed)
                            text_file.close()
                            return
                    except IndexError:
                        pass
            for link in soup.find_all('a'):
                if 'episode-' + str(episode) in str(link).lower():
                    stringy = str(link.get('href'))
                    await Messages(str(stringy), ctx, None, None, ctx.message)
                    return
    await Messages("Idk", ctx, None, None, ctx.message)
    return


##########################################################################
##########################################################################
@bot.command(name='join')
async def joinReq(ctx):
    global IsMod
    global ahk, optsArray, s
    global myduckingHeadsetJustDied
    sysChannel = optsArray[4]
    SerbzChannel = optsArray[3]
    myduckingHeadsetJustDied = 10
    MessageChanID = str(ctx.message.channel.id)
    CurrentID = await Logger.GetChanID()
    optsArray[1] = CurrentID
    IsMod = await ModCheck(ctx)
    if IsMod == False:
        await Messages('You do not have permission to use this command')  ### + str(ctx.message.author.name) + "#" + \
        return
    if (int(MessageChanID) is not int(CurrentID)):
        await Messages(
            "Join request received", ctx, None, None)
        await Messages("\n" + r"previous ID:" + str(CurrentID) + "\n" + r"new ID: " + str(ctx.message.channel.id),
                       None, sysChannel, None)
        await Logger.ValuesUpdater(10, str(ctx.message.channel.id))
    else:
        await Messages("Already listening to this channel, attempting to join voice", ctx, None, None, ctx.message)

    try:
        channelInvite = await ctx.message.author.voice.channel.create_invite(max_uses=1, unique=True, max_age=900)
    except:
        await Messages("Unable to join voice channel. Invite permissions required, cannot be a DM channel.", ctx, None,
                       SerbzChannel)
        return
    await joinDisc(channelInvite)
    await SerbzChannel.send(str(channelInvite))
    myduckingHeadsetJustDied = 10
    await Messages("Complete.", ctx, None, None, ctx.message)
    return


##########################################################################
##########################################################################
@bot.command(name='servers')
async def servers(ctx):
    global optsArray
    global IsAdmin
    sysChannel = optsArray[4]
    IsAdmin = await AdminCheck(ctx)
    if IsAdmin == False:
        await Messages('You do not have permission to use this command.', ctx, None, None, ctx.message)
        return
    response = '``` Servers connected to: \n'
    response2 = ""
    for guild in bot.guilds:
        response2 = response2 + "\n" + guild.name
    await Messages(str(response) + "\n" + str(response2) + "```", None, sysChannel, None, ctx.message)
    return


##########################################################################
##########################################################################
@bot.command(name='ytplay')
async def ytplay(ctx):
    global optsArray
    sysChannel = optsArray[4]
    CurrentID = optsArray[1]
    substrCtxMessage = str(ctx.message.content)[8:]
    # splitCtxMessage = str(ctx.message.content).split(" ")
    response = 'playing ' + substrCtxMessage + ' on youtube'
    music_name = ctx.message.content[8:]
    query_string = urllib.parse.urlencode({"search_query": music_name})
    formatUrl = urllib.request.urlopen("https://www.youtube.com/results?" + query_string)
    search_results = re.findall(r"watch\?v=(\S{11})", formatUrl.read().decode())
    # clip = requests.get("https://www.youtube.com/watch?v=" + "{}".format(search_results[0]))
    clip2 = "https://www.youtube.com/watch?v=" + "{}".format(search_results[0])
    await chrome.ASYNChttp(clip2)
    await asyncio.sleep(0.5)
    x, y = await coordImg(ctx, HomeDir + r'\ImageSearch\Chrome\forbackref.png',
                          "Remove this string if you want this function to click")
    x1 = x + (-46)
    y1 = y + (77)
    x2 = x + (421)
    y2 = y + (229)
    readString = await readImage(x1, y1, x2, y2, False, "chrome")
    if "unusual traffic" in str(readString).lower():
        await Messages("Youtube thinks the traffic we are sending is unusual.\nUsing old ytplay method.", ctx,
                       sysChannel, None)
        await Bytsearch(ctx)
        URL = await chrome.getURL(None, "NaN")
        await asyncio.sleep(2)
        await clk(541, 556)
        await asyncio.sleep(2)
        URL2 = await chrome.getURL(None, "NaN")
        if URL != URL2:
            await Messages("success probably.", ctx, sysChannel, None, ctx.message)
        else:
            await Messages("blame google.", ctx, sysChannel, None, ctx.message)
    if MessageChanID == CurrentID:
        await Messages(response, ctx, None, None, ctx.message)
    return


@bot.command(name="ytplay2")
async def ytplay2(ctx):
    global optsArray
    sysChannel = optsArray[4]
    CurrentID = optsArray[1]
    ProjectFFMPEG = HomeDir + r"\ffmpeg_release\ffmpeg-4.4-full_build\bin\ffmpeg.exe"
    ffmpeg_opts = {'before_options': '-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5', 'options': '-vn'}
    channel = ctx.author.voice.channel
    try:
        voice = await channel.connect()
    except:
        pass
    await Messages(str(voice), None, sysChannel, None, ctx.message)
    music_name = ctx.message.content[8:]
    query_string = urllib.parse.urlencode({"search_query": music_name})
    formatUrl = urllib.request.urlopen("https://www.youtube.com/results?" + query_string)
    search_results = re.findall(r"watch\?v=(\S{11})", formatUrl.read().decode())
    # for key in search_results:
    #    clip = etree.HTML(urllib.urlopen("http://www.youtube.com/watch?v=" + str(key)).read())
    #    await Messages(str(clip), None, sysChannel, None, ctx.message)
    clip2 = "https://www.youtube.com/watch?v=" + "{}".format(search_results[0])
    video = new(clip2)
    audio = video.getbestaudio().url
    voice.play(FFmpegPCMAudio(executable=ProjectFFMPEG, source=audio, **ffmpeg_opts))
    voice.is_playing()
    return


##########################################################################
##########################################################################
@bot.command(name='loop')
async def loop(ctx):
    global IsAdmin, optsArray
    CurrentID, sysChannel, SerbzChannel = optsArray[1], optsArray[4], optsArray[3]
    URL = await chrome.getURL(1, 1)
    await asyncio.sleep(1)
    if 'youtube.com/watch?v=' in URL:
        ahk.right_click(808, 523)
        await picSend(ctx.channel)
        await asyncio.sleep(1)
        ahk.click(823, 553)
        await Messages('Loop toggled', ctx, sysChannel, SerbzChannel, ctx.message)
        await picSend(ctx.channel)
    elif 'https://open.spotify.com/' in URL:
        c5, y6 = await coordImg(ctx, HomeDir + r"\ImageSearch\Spotify\menu.png", "anything here")
        c5 = c5 + (76)
        y6 = y6 + (2)
        await clk(c5, y6)
        await coordImg(ctx,
                       HomeDir + r"\ImageSearch\Spotify\loop.png")  # could do this or read page size and use logo as anchor
        await Messages("Loop toggled", ctx, None, None, ctx.message)

        await Messages('Page not supported by the loop command, youtube video only.', ctx, None, None, ctx.message)
    return


##########################################################################
##########################################################################   
@bot.command(name='fix')
async def fix(ctx):
    global IsMod
    global ahk
    splitMsg = str(ctx.message.content).split(" ")
    if splitMsg[1] == 'sound':
        response = 'attempting to perform audio fix'
        await Messages(response, ctx, None, None, ctx.message)
        ahk.run_script(
            r"run, cmd.exe /c start  "" /D " + ScriptDir + " /W startfixsound.bat",
            blocking=True)
        return
    elif splitMsg[1] == 'restore':
        IsMod = await ModCheck(ctx)
        if IsMod == False:
            response = 'You do not have permission to use this command.'
            await Messages(str(response), ctx, None, None, ctx.message)
            return
        else:
            pyautogui.moveTo(1569, 88, 0.15)
            pyautogui.click(button='left')
            pyautogui.moveTo(1567, 102, 0.15)
            pyautogui.click(button='left')
            return
    return


##########################################################################
##########################################################################C:\Windows\System32\cmd.exe /c python C:\Users\Administrator\PycharmProjects\pythonProject\bot.py
@bot.command(name='autoscroll')
async def autoScroll(ctx):
    global AutoScroll, chrome_w, chrome_h
    chrome_w, chrome_h = await chrome.getSize()
    subcmd = str(ctx.message.content).split(" ")
    try:
        subcmd = subcmd[1]
    except:
        subcmd = 1
        pass
    pyautogui.moveTo(chrome_w - 100, chrome_h - 100)
    pyautogui.click(button='middle')
    pyautogui.move(0, 20)
    AutoScroll = True
    await autoscroll.counter(AutoScroll, ctx, subcmd)
    return


@bot.command(name='type')
async def btype(ctx):
    pyautogui.write(str(ctx.message.content)[6:], 0.20)
    pyautogui.press('enter')
    pyautogui.press('return')
    return


##########################################################################
##########################################################################    
@bot.command(name='twitch')
async def tchat(ctx):
    global TwitchSession, optsArray
    SerbzChannel = optsArray[3]
    msgSplit = (ctx.message.content).split(" ")
    if msgSplit[1] == "chat":
        ahk.click(1410, 810)
        wordCounter = 0
        chatString = " "
        for words in msgSplit:
            wordCounter = wordCounter + 1
            if wordCounter > 2:
                chatString = chatString + " " + words
        ahk.type(str(chatString))
        pyautogui.press('enter')
        pyautogui.press('enter')
    elif msgSplit[1] == "follow":
        pyautogui.moveTo(978, 722, 1)
        pyautogui.click(button='left')
    elif msgSplit[1] == 'Channel':
        try:
            chanName = str(msgSplit[2])
        except:
            await Messages(r'Twitch command not recognized, unable to parse channel name.', ctx, None, SerbzChannel,
                           ctx.message)
            return
        await Messages('Browsing to ' + str(msgSplit[2]) + "\'s channel", ctx, None, None, ctx.message)
        chrome.http('http://twitch.tv/' + str(msgSplit[2]))
        return
    elif msgSplit[1] == 'Bonus':
        pyautogui.moveTo(1355, 872, 0.15)
        pyautogui.click(button='left')
        return
    elif msgSplit[1] == 'points':
        try:
            number = int(msgSplit[2])
        except:
            number = 0
            pass
        pyautogui.moveTo(1229, 861, 0.25)
        pyautogui.click(button='left')
        pyautogui.moveTo(1296, 871, 0.25)
        pyautogui.click(button='left')
        if number >= 1:
            Yc = 0
            while number > 3:
                number = number - 3
                Yc = Yc + 1
            Y = int(625 + (Yc * 150))
            X = int(1225 + (number * 100))
            await asyncio.sleep(0.5)
            pyautogui.moveTo(X, Y, 0.15)
            pyautogui.click(button='left')
            pyautogui.moveTo(1420, 805, 0.15)
            pyautogui.click(button='left')
            return
    elif msgSplit[1] == 'mute':
        pyautogui.moveTo(302, 668, 2)
        pyautogui.click(button='left')
        await Messages(r'Toggled Mute on twitch stream', ctx, None, None, ctx.message)
        return
    else:
        await Messages(r'Twitch command not recognized ' + str(ctx.message.content), ctx, None, SerbzChannel,
                       ctx.message)
    return


##########################################################################
##########################################################################
@bot.command(name='imgread')
async def readimg(ctx):
    global optsArray
    devVal = optsArray[9]
    splitCMD = str(ctx.message.content[9:]).split(",")
    try:
        click = bool(splitCMD[4])
    except:
        click = False
        pass
    response = await readImage(int(splitCMD[0]), int(splitCMD[1]), int(splitCMD[2]), int(splitCMD[3]), click)
    responseArray = str(response).split("\n")
    stringy = "```"
    for key in responseArray:
        if not (key == "" or key is None or not key or key == "\n" or key == " " or key == "    "
                or key == "  " or key == "   "):
            stringy = stringy + "\n" + key
    response = stringy
    await ctx.send(file=discord.File(
        HomeDir + r'\ImageSearch\im' + "WM_readImage" + r'.png'), content=response + r" ```")
    Bin = await readImgBin(int(splitCMD[0]), int(splitCMD[1]), int(splitCMD[2]), int(splitCMD[3]))
    stringy = "```"
    BinArray = str(Bin).split("\n")
    for key in BinArray:
        if not (key == "" or key is None or not key or key == "\n" or key == " " or key == "    "
                or key == "  " or key == "   "):
            stringy = stringy + "\n" + key
    Bin = stringy
    await ctx.send(file=discord.File(
        HomeDir + r'\ImageSearch\im' + "WM_readImageBin" + r'.png'), content=Bin + r" ```")

    return


##########################################################################
##########################################################################
@bot.command(name='temp')
async def tempFunc(ctx):
    try:
        x, y = await img2click(file=(HomeDir + r"\ImageSearch\temp.png"),var2=2,x1=0,y1=0,x2=1600,y2=950)
        pyautogui.moveTo(x , y, 0.15)
        await ctx.send("not failed? " + str(x) + " " + str(y))
    except:
        await ctx.send("failed.")
        pass
    return


##########################################################################
##########################################################################
@bot.command(name="marbles")
async def twitchMarbles(ctx):
    global optsArray
    sysChannel = optsArray[4]
    SerbzChannel = optsArray[3]
    await focus("chrome")
    await Messages("Retrieving files for marbles/giveaway streams please wait.", ctx, sysChannel, SerbzChannel,
                   ctx.message)
    chrome.new_tab()
    if os.path.exists(HomeDir + "\HTML\ezpz2.txt"):
        os.remove(HomeDir + "\HTML\ezpz2.txt")
    if os.path.exists(HomeDir + "\HTML\ezpz.txt"):
        os.remove(HomeDir + "\HTML\ezpz.txt")
    if os.path.exists(HomeDir + "\HTML\Old School RuneScape - Twitch.html"):
        os.remove(HomeDir + "\HTML\Old School RuneScape - Twitch.html")
    await chrome.ASYNChttp(r'https://www.twitch.tv/directory/game/Old%20School%20RuneScape')
    pyautogui.moveTo(920, 360, 0.15)
    pyautogui.click(button='middle')
    pyautogui.move(0, 100)
    counter = 0
    while counter <= 5:
        await asyncio.sleep(2)
        counter = counter + 1
    pyautogui.click(button='middle')
    await asyncio.sleep(1)
    pyautogui.moveTo(1161, 149, 0.15)
    await asyncio.sleep(1)
    pyautogui.click(button='right')
    pyautogui.move(-20, 0, 0.15)
    await asyncio.sleep(2)
    pyautogui.press('down', presses=3)
    pyautogui.press('return')  # ??
    await asyncio.sleep(2)
    pyautogui.press('return')
    # ahk.run_script(r"Send, {Enter}", blocking=True)
    # await asyncio.sleep(35)

    ahk.run_script(
        "Run cmd.exe /c start "" /D " + ScriptDir + " \
            /W twitchscrape.bat", blocking=True)
    # ahk.run_script(ScriptDir + r"\duckitSplitit.ahk",blocking=True)
    while not os.path.exists(HomeDir + "\HTML\ezpz.txt"):
        await asyncio.sleep(1)
    await Messages("Thank you for waiting!", ctx, sysChannel,
                   SerbzChannel)
    chrome.close_tab()
    pyautogui.moveTo(1662, 877, 0.15)
    pyautogui.click(button='left')
    with codecs.open(HomeDir + "\HTML\ezpz.txt", "r", encoding='UTF-8') as file_object:
        Streams = file_object.read()
        file_object.close()
        os.remove(HomeDir + "\HTML\Twitch.html")
        os.remove(HomeDir + "\HTML\ezpz.txt")
        if len(str(Streams)) > 1000:
            length = 0
            splStreams = str(Streams).split("\n")
            Streams = " "
            for line in splStreams:
                length = length + len(str(line))
                Streams = str(Streams) + str(line)
                if length > 1000:
                    await Messages(str(Streams) + "`\n", ctx, None, SerbzChannel)
                    length = 0
                    Streams = "-   "
        await Messages(str(Streams) + "`", ctx, None, SerbzChannel)

    return


##########################################################################
##########################################################################
@bot.command(name='mute')
async def mute(ctx):
    global IsMod
    IsMod = await ModCheck(ctx)
    if not IsMod:
        return
    await Messages("Toggling mute.", ctx, None, None, ctx.message)
    await discMute()
    return


@bot.command(name='cmd')
async def cmd(ctx):
    # global optsArray, IsAdmin
    # IsAdmin = AdminCheck(ctx)
    # if not IsAdmin:
    #    return
    if not (ctx.author.id == 246892047284436992):
        await ctx.send("Permission denied")
        return
    sysChannel = optsArray[4]
    cmdStr = str(ctx.message.content)[5:]
    ahk.run_script(
        r"run, cmd.exe /c " + cmdStr,
        blocking=False)
    await Messages("running run, cmd.exe /c " + cmdStr, None, sysChannel, None, ctx.message)
    return


##########################################################################
##########################################################################
@bot.command(name="fullscreen")
async def fullscreen(ctx):
    await focus("chrome")
    pyautogui.press('f')
    return


##########################################################################
##########################################################################
@bot.command(name="scroll")
async def scroll(ctx):
    global CPos
    mult = 0
    times = 0
    CPos[0] = await chrome.scrollPos()
    await focus("chrome")
    subcmd = str(ctx.message.content).split(" ")
    Logger.LogPrint(str(subcmd[1]))
    URL = await chrome.getURL(1, 1)
    if "spotify.com/search" in URL:
        scrollLen = 1000  # 294,252 326,811
        await spotifyScroll(scrollLen)
        return
    else:
        scrollLen = 450
    try:
        times = subcmd[2]
        times = int(times)
    except:
        times = 1
        pass
    if str(subcmd[1]) == "down":
        mult = -1 * (times)
    elif str(subcmd[1]) == "up":
        mult = 1 * (times)
    elif str(subcmd[1]) == "top":
        pyautogui.moveTo(1540, 450, 0.15)
        pyautogui.scroll(scrollLen * 999)
        CPos[1] = await chrome.scrollPos()
        return
    pyautogui.moveTo(1540, 450, 0.15)
    pyautogui.scroll(scrollLen * int(mult))
    CPos[1] = await chrome.scrollPos()
    return


##########################################################################
##########################################################################
@bot.command(name="scrollpos")
async def BscrollPos(ctx):
    global optsArray
    sysChannel = optsArray[4]
    sPos = await chrome.scrollPos()
    await Messages(str(sPos), ctx, sysChannel, None, ctx.message)
    return


##########################################################################
##########################################################################


@bot.command(name="tts")
async def tts(ctx):
    ProjectFFMPEG = HomeDir + r"\_Audio\ffmpeg_release\ffmpeg-4.4-full_build\bin\ffmpeg.exe"
    stringy3 = ""
    stringy = ctx.message.content[5:]
    voices = ["david-attenborough", "arnold-schwarzenegger", #"mitch-mcconnel",
              "bob-barker", "bill-gates", "bill-clinton", "bill-nye", "homer-simpson",
              "peter-griffin", "gilbert-gottfried"]
    stringy2 = voices[random.randint(0, len(voices) - 1)]
    next = 0
    for each in ctx.message.content.split(" "):
        if next == 0 and each != f"{commandPrefix}tts":
            stringy3 = stringy3 + each + " "
        if next == 1:
            stringy2 = each
        if each == r"//":
            next = 1
            stringy = stringy3[:-3]
    #await messageHandler(ctx=ctx, lines=[f" @#F Processing: \n @#V Please wait. Processing text to speach may take a moment.", " @#F Voice Selected: " + \
    #                                     f" \n @#V {stringy2}", f" @#F Text: @#V {stringy}"])
    file = loop.run_until_complete(asyncio.ensure_future(
        tts_api.save_to_file(stringy2, stringy, HomeDir + r"\temp.wav")))
    if "504" in file['status'] or "500" in file['status']:
        loop.create_task(messageHandler(ctx=ctx, lines=[" @#F Failure: @#V try again."]))
    audio = HomeDir + r"\temp.wav"
    voice = None
    channel = await getChannel(ctx)
    voice = await getVoice(ctx, channel)
    try:
        if not voice.is_connected():
            try:
                await voice.connect()
            except:
                try:
                    await channel.connect()
                except:
                    pass
                pass
    except:
        pass
    await asyncio.sleep(1)
    voice.play(discord.FFmpegPCMAudio(audio, executable=ProjectFFMPEG))
    while voice.is_playing():
        await asyncio.sleep(0.1)
    return



#this command is shit
@bot.command(name='serbzi')
async def serbzi(ctx, SerbziText=""):
    #global SerbziText
    await chrome.ASYNChttp("http://www.vo.codes/")
    await asyncio.sleep(0.75)
    stringB = ""
    if SerbziText == "":
        textspl = str(ctx.message.content).split(" ")
        counter = -1
        for key in textspl:
            counter = counter + 1
        counter2 = 0
        while counter2 < counter:
            counter2 = counter2 + 1
            stringB = str(stringB) + " " + str(textspl[counter2])
        SerbziText = str(stringB)
        await coordImg(ctx, HomeDir + r'\ImageSearch\Vocodes\vo.codes1.png')
        x, y = await coordImg(ctx, HomeDir + r'\ImageSearch\Vocodes\vo.codesLogo.png',
                              "Remove this string if you want this function to click")
    x1 = x + (275)
    y1 = y + (53)
    await clk(x1, y1)
    x1 = x + (10)
    y1 = y + (106)
    await clk(x1, y1)
    x1 = x + (398)
    y1 = y + (117)
    await clk(x1, y1)
    x1 = x + (178)
    y1 = y + (286)
    pyautogui.moveTo(x1, y1, 0.15)
    pyautogui.scroll(999 * 450)
    x1 = x + (67)
    y1 = y + (392)
    await clk(x1, y1)
    x1 = x + (556)
    y1 = y + (284)
    pyautogui.moveTo(x1, y1, 0.15)
    pyautogui.scroll(-999 * 450)
    x, y = await coordImg(ctx, HomeDir + r'\ImageSearch\Vocodes\vo.codes2.png',
                          "Remove this string if you want this function to click")
    x1 = x + (-79)
    y1 = y + (-167)
    await clk(x1, y1)
    pyautogui.write(SerbziText, 0.05)
    SerbziText = ""
    await clk(x, y)
    await Messages("Waiting to infer voice.", ctx, None, None, ctx.message)
    await asyncio.sleep(1)
    x1 = x + (-175)
    y1 = y + (-241)
    x2 = x + (125)
    y2 = y + (-201)
    readString = await readImgBin(x1, y1, x2, y2)
    await ctx.send(file=discord.File(HomeDir + r'\ImageSearch\im' + "WM_readImage3" + r'.png'), content=" ")
    await asyncio.sleep(30)
    return


##########################################################################
##########################################################################  
@bot.command(name="sp")
async def sp(ctx):
    await spotify(ctx, True)
    return


##########################################################################
##########################################################################  

async def coordImg(ctx, file, toClickorNotToClick=None, x1=0, y1=0, x2=1600, y2=950):
    global msgStr
    xif, yif = 0, 0
    # pyautogui.moveTo(5, 5, 0.25)
    # x1, y1 = pyautogui.position()
    if toClickorNotToClick is not None:
        toClickorNotToClick = 2
    await img2click(file, toClickorNotToClick, int(float(x1)), int(float(y1)),
                    int(float(x2)), int(float(y2)))
    # await asyncio.sleep(0.5)
    x3, y3 = pyautogui.position()
    xif = int(float(x3))
    yif = int(float(y3))
    # await asyncio.sleep(0.5)
    try:
        if toClickorNotToClick == None:
            msgStr = str(msgStr) + "\nClicked "
        msgStr = str(msgStr) + "coords - \nx: " + str(x3) + "\ny: " + str(y3)
    except TypeError:
        if ctx is not None:
            await Messages(str(msgStr) + "\nnope", ctx, None, None, ctx.message)
    return int(xif), int(yif)


@bot.command(name="disconnectvoice")
async def dc_voice(ctx):
    for x in bot.voice_clients:
        if (x.guild == ctx.message.guild):
            return await x.disconnect()
    return


##########################################################################
##########################################################################
@bot.command(name="spotify")
async def spotify(ctx, var=False):
    global ahk, CommandActive
    global root
    global SpotifyScrollVar
    global SpotifyScrollDivCounter
    global sysChannel
    global SerbzChannel, devVal
    global sAX, sAY, sIX, sIY, sIY2, sIY1, sIX1, sIX2, songNumber, msgStr, spotifySession
    vY1, vX1, c5, zX1, zY1, y6 = 0, 0, 0, 0, 0, 0
    CommandActive = 1
    await focus("chrome")
    msgStr = "``` " + msgStr
    msgcontent = str(ctx.message.content)
    ### 160 x 50 ### ^^^
    if var is not False:
        msgcontent = msgcontent[3:]
        msgcontent = ".spotify" + msgcontent
    if len(msgcontent) <= 9:
        await chrome.ASYNChttp(r'https://open.spotify.com')
    URL = await chrome.getURL(1, 1)
    if 'open.spotify.com' not in str(URL):
        await chrome.ASYNChttp(r'https://open.spotify.com')
    await asyncio.sleep(1)
    if spotifySession == False or not os.path.exists(HomeDir + r"\VariableVariables\spotifyCoords.txt"):
        await Messages("Acquiring coordinates for spotify for this session.", ctx, None, None)
        await asyncio.sleep(1)
        sAX, sAY = await coordImg(ctx, HomeDir + r"\ImageSearch\Spotify\Logo.png", "AnythingHere")
        sIX, sIY = await coordImg(ctx, HomeDir + r"\ImageSearch\Spotify\installApp.PNG", "anything here")
        c5, y6 = await coordImg(ctx, HomeDir + r"\ImageSearch\Spotify\menu.png", "anything here")
        vX1, vY1 = await coordImg(ctx, HomeDir + r"\ImageSearch\Spotify\buttonsVol.png", "anything")
        zX1, zY1 = await coordImg(ctx, HomeDir + r"\ImageSearch\Spotify\A_LikedSongs.png", "anything")
        # vX2, vY2 = await coordImg(ctx, HomeDir + r"\ImageSearch\Spotify\fullscreen.png", "anything")
        text_file = open(HomeDir + r"\VariableVariables\spotifyCoords.txt", "w")

        ###########----------0----------------1----------------2------------------3-------------4------------5-
        text_file.write(str(sAX) + "|" + str(sAY) + "|" + str(sIX) + "|" + str(sIY) + "|" + str(c5) + "|" + str(y6)
                        + str(zX1) + "|" + str(zY1) + "|" + str(vX1) + "|" + str(vY1))
        #############################=====------6---------------7-----------------8-----------------9
        text_file.close()  #######################  + "|"  "|" + str(vY2) + "|" + str(vX2) + "|" + str(vY2) + "|"
        spotifySession = True
        await Messages("Complete.", ctx, sysChannel, None)
    elif spotifySession == True:
        text_file = open(HomeDir + r"\VariableVariables\spotifyCoords.txt", "r")
        coordsPreSpl = text_file.read()
        text_file.close()
        Coords = str(coordsPreSpl).split("|")
        for key in Coords:
            if int(key) == 5:
                spotifySession == False
                await Messages("Problem with spotify session coordinates, will re-acquire. Flagged.", None, sysChannel,
                               None)
                os.remove(HomeDir + r"\VariableVariables\spotifyCoords.txt")
                break
        sAX = int(Coords[0])
        sAY = int(Coords[1])
        sIX = int(Coords[2])
        sIY = int(Coords[3])
        c5 = int(Coords[4])
        y6 = int(Coords[5])
        vX1 = int(Coords[8])
        vY1 = int(Coords[9])
        # vX2 = int(Coords[8])
        # vY2 = int(Coords[9])
        zX1 = int(Coords[6])
        zY1 = int(Coords[7])
        await Messages("``` \n" + \
                       "spotify session values: \n" + \
                       "----------------------- \n" + \
                       " --| sAX " + str(Coords[0]) + \
                       "\n --| sAY " + str(Coords[1]) + \
                       "\n --| vX1 " + str(Coords[8]) + \
                       "\n --| vY1 " + str(Coords[9]) + \
                       "\n --| zY1 " + str(Coords[7]) + \
                       "\n --| zX1 " + str(Coords[6]) + \
                       "\n --| sIX " + str(Coords[2]) + \
                       "\n --| sIY " + str(Coords[3]) + \
                       "\n --| c5 " + str(Coords[4]) + \
                       "\n --| y6 " + str(Coords[5]) + "\n ```", None, sysChannel, None)
        #####                       "\n --| vX2 " + str(Coords[8]) + \
        #####               "\n --| vY2 " + str(Coords[9]) + \

    if vY1 < 500:
        await Messages("Problem with spotify session coordinates, will re-acquire. Flagged.", None, sysChannel,
                       None)
        os.remove(HomeDir + r"\VariableVariables\spotifyCoords.txt")
    sIX1 = sIX - 80  # 112,141 precision
    sIY1 = sIY - 25  # 112 282
    sIX2 = sIX + 80  # 261,279 311,319
    sIY2 = sIY + 25
    subcmdsplit = msgcontent[9:].split(" ")
    if str(subcmdsplit[0])[:3] == 'vol':  ####################################VOL
        volume = int(subcmdsplit[1])
        volume = float(volume / 100) * 80
        y = vY1
        x = (vX1 + math.floor(volume)) + 55
        pyautogui.moveTo(x, y, 0.2)
        pyautogui.click(button='left')
        CommandActive = 0
        msgStr = ""
        return
    ################
    if subcmdsplit[0] == 'next':
        c5 = c5 + (48)
        y6 = y6 + (-3)
        await clk(c5, y6)
        await Messages("Clicking for next song.", ctx, None, None)
        CommandActive = 0
        msgStr = ""
        return
    ################
    elif str(subcmdsplit[0])[:7] == 'restart' or str(subcmdsplit[0])[:4] == 'prev':
        c5 = c5 + (-46)
        y6 = y6
        await clk(c5, y6)
        if str(subcmdsplit[0])[:4] == 'prev':
            pyautogui.click(button='left')
        await Messages("Clicking for previous song.", ctx, None, None)
        CommandActive = 0
        msgStr = ""
        return
    ################
    elif subcmdsplit[0] == 'search':
        SpotifyScrollVar = -1
        SpotifyScrollDivCounter = 0
        searchterm = msgcontent[15:]
        searchterm2 = re.sub(r"\s", "%20", searchterm)
        await chrome.ASYNChttp(r"https://open.spotify.com/search/" + str(searchterm2) + r"/tracks")
        await Messages("Showing song search results for: " + str(searchterm), ctx, None, None)
        pyautogui.moveTo(846, 479, 0, 2)  # ~#!$~$$!#!#!!~#~#~~USE CHROME.GETSIZE FOR THIS + coordImg FOR WINDOW LOC
        CommandActive = 0
        msgStr = ""
        return
    ################
    elif subcmdsplit[0] == 'song':
        pressesNum = 0
        posVar = 0
        pressesKey = None
        X = int(float(sAX)) + 170  ####102, sAX
        Y = int(float(sAY)) + 160  # + (32 * (int(selection) - 1)) ###  143 sAY
        O_songNumber = songNumber
        try:
            songNumber = int(str(subcmdsplit[1]))
        except TypeError:
            await Messages(r"please enter a number", ctx, None, None)
            await Messages(" " + msgStr + " ```", ctx, sysChannel, None)
            msgStr = ""
            songNumber = 1
            pass
        await asyncio.sleep(0.2)
        pyautogui.moveTo(X, Y, 0.15)
        pyautogui.click(button='middle')
        pyautogui.click(button='middle')
        pyautogui.moveTo(0, 0, 0.15)
        if O_songNumber is None:
            pyautogui.scroll(75 * SpotifyScrollDivCounter)
        else:
            pressesNum = (O_songNumber - songNumber)
            if pressesNum > 0:
                pressesKey = 'up'
            elif pressesNum < 0:
                pressesNum = pressesNum * (-1)
                pressesKey = 'down'
            else:
                pressesKey = None
        if pressesKey is not None:
            await asyncio.sleep(0.2)
            pyautogui.press(str(pressesKey), presses=int(pressesNum), interval=0.15)
        try:
            option = subcmdsplit[2]
        except IndexError:
            pyautogui.press('return')
            CommandActive = 0
            await Messages(" " + msgStr + " ```", None, sysChannel, None)
            CommandActive = 0
            msgStr = ""
            return
        x2 = 0
        y2 = 0
        x2, y2 = await coordImg(ctx, HomeDir + r"\ImageSearch\Spotify\selectedSongSearch.png", "I like turtles")
        msgStr = "```\nx2, y2:  " + str(x2) + " " + str(y2)
        pyautogui.moveTo(x2, y2, 0.1)
        pyautogui.click(button='right')
        if option == "add":  ### in str(string).lower() or "queue" in str(string).lower():
            await asyncio.sleep(3)
            pyautogui.press('right', presses=4)
            await asyncio.sleep(0.25)
            pyautogui.press('enter')
            await asyncio.sleep(0.25)
            pyautogui.press('down', presses=7)
            await asyncio.sleep(0.25)
            pyautogui.press('right')
            await asyncio.sleep(0.25)
            pyautogui.press('down', presses=int(subcmdsplit[3]))
            await asyncio.sleep(0.25)
            pyautogui.press('enter')
            await asyncio.sleep(0.25)
            pyautogui.press('left', presses=4)
            CommandActive = 0
            await Messages(" " + msgStr + " ```", None, sysChannel, None)
            msgStr = ""
            return
    elif subcmdsplit[0] == 'home':
        x1 = sAX + (-30)
        y1 = sAY + (61)
        await clk(x1, y1)
        await Messages("Returned to the spotify home screen", ctx, None, None)
        CommandActive = 0
        msgStr = ""
        return
    elif subcmdsplit[0] == 'playlist':
        ######### several of these combine using len()
        try:
            selection = int(subcmdsplit[1])
        except:
            await Messages("Please use .spotify playlist 1-10", ctx, None, None)
            CommandActive = 0
            msgStr = ""
            return
        if int(selection) <= 0 or int(selection) > 10:
            await Messages("Please use .spotify playlist 1-10", ctx, None, None)
            CommandActive = 0
            msgStr = ""
            return
        X = zX1 - 40
        Y = int(float(zY1)) + 56 + (32 * (int(selection) - 1))
        if ((X > sIX1 and X < sIX2) and (Y > sIY1 and Y < sIY2)):
            await Messages("Unable to click that currently", ctx, None, None)
            CommandActive = 0
            msgStr = ""
            return
        await clk(X, Y)
        X = sAX + 293 - 106
        Y = sAY + 524 - 176
        await asyncio.sleep(1)
        await clk(X, Y)
        await asyncio.sleep(0.3)
        pyautogui.moveTo(5, 5, 0.2)
        # await clk(X1,Y1)
        await Messages("Playlist #" + str(selection) + " played.", ctx, None, None)
        CommandActive = 0
        msgStr = ""
        return
        #########
    elif subcmdsplit[0] == 'shuffle':
        c5 = c5 + (-83)
        y6 = y6 + (11)
        await clk(c5, y6)
        await coordImg(ctx, HomeDir + r"\ImageSearch\Spotify\shuffle.png")
        await Messages("Shuffle toggled", ctx, None, None)
        CommandActive = 0
        msgStr = ""
        return
        #########
    elif subcmdsplit[0] == 'loop':
        await loop(ctx)
        CommandActive = 0
        msgStr = ""
        return
    else:
        await Messages("The available spotify commands are:", ctx, None, None)
        await Messages("spotify home/song/search/prev/next/playlist", ctx, None, None)
        await Messages("The .playpause command is compatible with spotify.", ctx, None, None)
        CommandActive = 0
        msgStr = ""
        return
    #global spotifySession, chrome_w, chrome_h
    #await values(ctx, True)
    #if spotifySession == False:
    #    var = True
    #await Messages("Spotify Commands are currently under reconstruction. Thank you.", ctx, None, None, ctx.message)
    # x_sp_ppbtn, y_sp_ppbtn = await coordImg(ctx, HomeDir + r"\ImageSearch\Spotify\
    # x_sp_logo, y_sp_logo = await coordImg(ctx, HomeDir + r"\ImageSearch\Spotify\spotifyPlayPause.png")
    # readString = await readImage(x1, y1, x2, y2, False, "chrome")
    return


##########################################################################
##########################################################################
@bot.command(name='help')
async def help(ctx):
    global optsArray
    SerbzChannel = optsArray[4]

    commandList = ["spotify",
                   "twitch",
                   "netflix",
                   "tab",
                   "find",
                   "click"]
    try:
        subcmd = str(ctx.message.content).split(" ")
        for values in commandList:
            if (str(subcmd[1]) == str(values)):
                text_file = open(HomeDir + "\Commands\\" + values + ".txt", "r")
                response = text_file.read()
                text_file.close()
                await Messages(response, ctx, None, None, ctx.message)
                return
    except IndexError:
        pass
    await Messages(" ``` \
                    \n\n -- CMDS -- \
                    \n\n.oauth - prints the oauth 2 link to add the bot to your server. \
                    \n\n.join - Usable by the bot's admin list to have it join a text/voice channel. \
                    \n\n.purpose - lol \
                    \n\n.loop - Global loop toggle command. \
                    \n\n.fullscreen - Global Full Screen toggle command \
                    \n\n.playpause - Global play/pause toggle command \
                    \n\n.video [on/off] \
                    \n\n.view - ... \
                    \n\n.mute - Mute's the bots audio \
                    \``` \ ", ctx, None, None)
    await Messages("```\n\n.ytsearch [something to search on youtube] \
                    \n\n.ytplay [anything on youtube] - Instantly plays\
                    \n\n.netflix [Something to watch] [-s# -e#] \
                    \n\n.spotify/sp [next/prev/song 1-10 [add 1-10]/playlist 1-10/shuffle/loop(.loop works too)] \
                    \n\n.twitch [follow/chat [some message]/points [optional: 1-6]/mute] - see .help twtich for mor information.\
                    \n\n.marbles - retreives all twitch streams on OSRS browse page with terms giveaway or marble \
                    \n\n.fmovie [Something to watch] \
                    \n\n.http [Anything or anywhere] \
                    \n\n.bsearch [Something to search (google)] \
                    \n\n.tab [new/1-9999/close] - 1-9999 will just select an already open in tab \
                    \n\n.refresh - refreshes the web page \``` \ ", ctx, None, None)

    await Messages(" ``` \
                    \n\n.scroll [up/down] - This makes the bot turn into a transformer and blow up... It scrolls. \
                    \n\n.autoscroll [1-9999] - Pages to scroll down, canceled by any command \
                    \n\n.find [Anything/-next 1-9999/-prev 1-9999] \
                    \n\n.click [nothing (clicks selection with find)/something (clicks first find result)] \
                    \n\n.type [Something To Type] \
                    \n\n.back - Goes back \
                    \n\n.forward - Goes back too... it doesn't. \
                    \n\n-- Debug/Admin -- \
                    \n\n.scrollpos \
                    \n\n.servers \
                    \n\n.fix [sound/restore] \
                    \n\n.xclick [some xpath term] \
                    \n\n.restart \
                    \n\n.whereami \
                    \n\n.wake \
                    \n\n \
                    \n\n-- User Script -- \
                    \n\n.streamclickscript \
                    \n\n.clickc [X] [Y] [R/M] \
                    \n\n ``` \
                    \n\n ***Further information available for:*** \
                    \n\n ***spotify, twitch, netflix, tab, find, click*** \
                    \n\n ***just use .help spotify/twitch/etc.*** \
                    ``` ", ctx, None, None)
    await Messages(str(ctx.message.author.name) + " used .help", None, None, SerbzChannel, ctx.message)
    return


##########################################################################
##########################################################################
@bot.command(name='jagoodi')
async def jagoodi(ctx):
    await Messages("JAGOOOOOOOOODDIIIIIIII", ctx, None, None, ctx.message)
    chrome.http("http://twitch.tv/jagoodiii")
    return


##########################################################################
##########################################################################
@bot.command(name='oauth')
async def oauth(ctx):
    global optsArray
    sysChannel = optsArray[4]
    SerbzChannel = optsArray[3]
    await Messages(r"Add me to your server!", ctx, None, None, ctx.message)
    await Messages(
        r"<https://discord.com/api/oauth2/authorize?client_id=841794419635781662&permissions=36818497&scope=bot>", ctx,
        sysChannel, None)
    await Messages(str(ctx.message.author.name) + " Used .oauth", None, None, SerbzChannel, ctx.message)
    return

@bot.command(name='pop')
async def populate_lists(ctx):
    if ctx.message.author.id == 246892047284436992:
        outChannel = await bot.fetch_channel(868848148452356138)
        msgStr = "```"
        text_channel_list = []
        msgStr1 = "```"
        guild_list = []
        msgStr2 = "```"
        msgStr3 = ""
        guild_roles_list = []
        voice_channel_List = []
        for guild in bot.guilds:
            guild_list.append([guild,guild.id])
            msgStr1 = msgStr1 + "\n -- ||     " + str(guild) + "  -  " + str(guild.id)
            for role in guild.roles:
                msgStr3 = msgStr3 + "\n -- ||     " + str(guild) + "  -  " + str(guild.id) + "  -  " + str(role) + \
                          "  \n--------- ||  " + str(role.id) + "  -  " + str(role.permissions)
                guild_roles_list.append([guild,guild.id,role,role.id,role.members,role.permissions,role.color,role.colour,role.position,
                    role.tags,role.hoist,role.mentionable,role.name,role.is_default,role.is_integration,role.is_premium_subscriber,
                        role.is_bot_managed])

            for channel in guild.channels:
                if str(channel.type) == 'text':
                    text_channel_list.append([guild,guild.id,channel])
                    msgStr = msgStr + "\n -- ||   " + str(channel.type) + "  -  " + str(guild) + "  -  " + str(guild.id) + "  -  " + str(channel)
                if str(channel.type) == 'voice':
                    voice_channel_List.append([guild,guild.id,channel])
                    msgStr2 = msgStr2 + "\n -- ||   " + str(channel.type) + " -  " + str(guild) + "  -  " + str(guild.id) + "  -  " + str(channel)
        x = 1000
        res = [msgStr1[y - x:y] for y in range(x, len(msgStr1) + x, x)]
        for ult in res:
            await asyncio.sleep(2)
            await outChannel.send("```" + ult + "```")
        res = [msgStr[y - x:y] for y in range(x, len(msgStr) + x, x)]
        for ult in res:
            await asyncio.sleep(2)
            await outChannel.send("```" + ult + "```")
        res = [msgStr2[y - x:y] for y in range(x, len(msgStr2) + x, x)]
        for ult in res:
            await asyncio.sleep(2)
            await outChannel.send("```" + ult + "```")
        res = [msgStr3[y - x:y] for y in range(x, len(msgStr3) + x, x)]
        for ult in res:
            await asyncio.sleep(2)
            await outChannel.send("```" + ult + "```")
        #await outChannel.send(msgStr3 + "```")
    return
##########################################################################
##########################################################################
@bot.command(name='readit')
async def prereadatton(ctx):
    global SerbziText
    await readatton(ctx)
    return


##########################################################################
##########################################################################
async def readatton(ctx):
    global SerbziText
    #####.imgread 440,340,844,859
    ##atten on vo.codes
    sysChannel = optsArray[4]
    x1, y1 = await img2click2(ImgDir + r"\Reddit\redditUPbetween.png", 2)
    if x1 is not None:
        x2, y2 = await img2click2(ImgDir + r"\Reddit\redditPostBar.png", 2)
        attempt = 0
        while y2 < y1 and attempt < 8:
            attempt += 1
            await chrome.scrollDown(amt=60)
            x2, y2 = await img2click2(ImgDir + r"\Reddit\redditPostBar.png", 2)
        x2 = x2 + 400
    else:
        await Messages("Something wasn't found.", ctx, None, None, ctx.message)
        return
    SerbziText = await readImgBin(x1, y1, x2, y2)
    await Messages("``` " + str(SerbziText) + " ```", ctx, None, None, ctx.message)
    SerbziText = SerbziText.replace("\n", " ")
    await sysChannel.send(file=discord.File(HomeDir + r'\ImageSearch\im' + "WM_readImage3" + r'.png'), content="")
    await ctx.send(file=discord.File(HomeDir + r'\ImageSearch\im' + "WM_readImage3" + r'.png'), content="")
    chrome.new_tab()
    loop.create_task(serbzi(ctx))
    return


##########################################################################
##########################################################################
@bot.command(name='quality')
async def quality(ctx):
    global optsArray
    sysChannel = optsArray[4]
    SerbzChannel = optsArray[3]
    if True:
        await Messages("This command is currently under reconstruction. Thank you.", ctx, None, None, ctx.message)
        return
    await focus("d")
    subcmd = str(ctx.message.content).split(" ")
    res = str(subcmd[1])
    fps = str(subcmd[2])
    somevar = 0
    maximizeBTN = pyautogui.locateOnScreen(HomeDir + r"\ImageSearch\discMaximize.PNG")
    video = await colorSearch()
    if video == False:
        pyautogui.locateOnScreen(HomeDir + r"\ImageSearch\discMaximize.PNG")
        x, y = pyautogui.center(maximizeBTN)
        if x < 1500 or y > 20:
            x, y = pyautogui.center(maximizeBTN)
            pyautogui.moveTo(x, y, 0.15)
            pyautogui.click(button='left')
            video = await colorSearch()
            if video == False:
                await Messages("Video is not on.", ctx, sysChannel, SerbzChannel, ctx.message)
                await focus("Chrome")
                return
            else:
                somevar = 1
        if somevar == 0:
            await Messages("Video is not on.", ctx, sysChannel, SerbzChannel, ctx.message)
            await focus("Chrome")
            return
    if ((fps == "15" or fps == "30") and (res == "720" or res == "480")):
        pyautogui.moveTo(248, 1089, 0.15)
        pyautogui.click(button='left')
        pyautogui.moveTo(251, 971, 0.15)
        pyautogui.moveTo(442, 980, 0.15)
        if fps == '30':
            pyautogui.moveTo(439, 920, 0.15)
            pyautogui.click(button='left')
        else:
            pyautogui.moveTo(438, 881, 0.15)
            pyautogui.click(button='left')
        pyautogui.moveTo(1088, 1148, 1)
        pyautogui.click(button='left')
        pyautogui.moveTo(248, 1089, 0.15)
        pyautogui.click(button='left')
        pyautogui.moveTo(251, 971, 0.15)
        pyautogui.moveTo(442, 980, 0.15)
        if res == '720':
            pyautogui.moveTo(432, 1062, 0.15)
            pyautogui.click(button='left')
        else:
            pyautogui.moveTo(443, 1025, 0.15)
            pyautogui.click(button='left')
        pyautogui.moveTo(1088, 1148, 1)
        pyautogui.click(button='left')
    else:
        await Messages("Please use .quality 720/480 30/15", ctx, None, None, ctx.message)
    await focus("Chrome")
    return


##########################################################################
##########################################################################
async def spotifyScroll(scrollLen):
    global SpotifyScrollVar
    global SpotifyScrollDivCounter
    pyautogui.moveTo(846, 479, 0.15)
    file = open(HomeDir + r"\StaticVars\scrollLen.txt", "r")
    scrollSubtr = file.read()
    file.close()
    file = open(HomeDir + r"\StaticVars\scrollAmt.txt", "r")
    scrollAmt = file.read()
    file.close()
    file = open(HomeDir + r"\StaticVars\multAmt.txt", "r")
    multAmt = file.read()
    file.close()
    if SpotifyScrollVar == -1:
        pyautogui.scroll(-75)
        SpotifyScrollVar = 0
        SpotifyScrollDivCounter = 10
    elif SpotifyScrollVar == 0:
        SpotifyScrollVar = 1
    elif SpotifyScrollVar == 1:
        SpotifyScrollVar = 0
        pyautogui.scroll(int(multAmt) * int(scrollAmt))
    SpotifyScrollDivCounter = SpotifyScrollDivCounter + 10
    while scrollLen > 0:
        scrollLen = scrollLen - int(scrollSubtr)
        pyautogui.scroll((int(multAmt) * int(scrollAmt)) + int(SpotifyScrollVar))
        await asyncio.sleep(0.1)
    return


def get_files(root, patterns='*', depth=1, yield_folders=False):
    """
    Return all of the files matching patterns, in pattern.
    Only search to teh specified depth
    Arguments:
        root - Top level directory for search
        patterns - comma separated list of Unix style
                   wildcards to match NOTE: This is not
                   a regular expression.
        depth - level of subdirectory search, default
                1 level down
        yield_folders - True folder names should be returned
                        default False
    Returns:
        generator of files meeting search criteria for all
        patterns in argument patterns
    """
    # Determine the depth of the root directory
    root_depth = len(root.split(os.sep))
    # Figure out what patterns we are matching
    patterns = patterns.split(';')

    for path, subdirs, files in os.walk(root):
        # Are we including directories in search?
        if yield_folders:
            files.extend(subdirs)
        files.sort()

        for name in files:
            for pattern in patterns:
                # Determine if we've exceeded the depth of the
                # search?
                cur_depth = len(path.split(os.sep))
                if (cur_depth - root_depth) > depth:
                    break

                if fnmatch.fnmatch(name, pattern):
                    yield os.path.join(path, name)
                    break


##########################################################################
##########################################################################
async def Messages(msgstr=None, ctx=None, sys=None, SerbzFlag=None, ctx2message=None):
    global myduckingHeadsetJustDied, ready, optsArray
    CurrentChannel, CurrentID, Serbz, SerbzChannel, sysChannel, QuietMode, altSysChanArray, altSysEnable, strict, devVal, supressStart = optsArray
    if ctx2message is not None:
        if ctx2message.author != bot.user:
            something = True
    myduckingHeadsetJustDied = myduckingHeadsetJustDied + 1
    if int(math.floor(float(myduckingHeadsetJustDied / 3))) == int(1) or myduckingHeadsetJustDied == 10:
        myduckingHeadsetJustDied = 0
    try:
        if int(ctx.channel.id) == int(sysChannel.channel.id):
            skip_try = True
        else:
            skip_try = False
    except:
        skip_try = False
    m = msgstr
    if QuietMode < 1 and SerbzFlag != None:
        await SerbzChannel.send(str(m))
    if QuietMode < 2 and ctx != None and skip_try == False:
        await ctx.send(str(m))
    try:
        if ctx.message.channel == sysChannel:
            return
    except:
        pass
    if sys != None and QuietMode < 3:
        await sysChannel.send(str(m))
        if altSysEnable is not True:
            return
    if altSysEnable or altSysEnable == "True":
        for keys in altSysChanArray:
            altSys = await bot.fetch_channel(int(keys))
            await altSys.send(str(m))
    return


bot.run(TOKEN)