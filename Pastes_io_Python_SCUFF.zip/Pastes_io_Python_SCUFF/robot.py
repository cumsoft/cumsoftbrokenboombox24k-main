# Bibliotheques utiles
import time
from time import sleep
from pylgbst.hub import MoveHub
from pylgbst.comms.cgatt import GattConnection

try:
    print("Veuillez appuyer sur le bouton vert du Robot Lego")
    print("En attente...")
    
    # connexion au robot en bluetooth
    conn = GattConnection("hci0")
    conn.connect("00:16:53:BE:9F:A7") # Adresse MAC Robot 2
    #conn.connect("00:16:53:AB:6A:ED") # Adresse MAC Robot 1
    hub = MoveHub(conn)
    print("le robot est connecte  ")
    sleep(1)

    # En avant de 50cm
    hub.motor_AB.angled(1790,0.1,0.1)
    # Rotation droite 45° --> 275°motor = 137.5 ABMotor
    hub.motor_AB.angled(132,0.1,-0.1)
    # Rotation droite 135° --> 825°motor = 412.5 ABMotor 
    hub.motor_AB.angled(405,0.1,-0.1)
    # En avant de 45cm
    hub.motor_AB.angled(1611,0.1,0.1)
    # Rotation de 180° --> 1100° motor = 550 ABMotor
    hub.motor_AB.angled(520,0.1,-0.1)
    # En arrière de 6cm
    hub.motor_AB.angled(215,-0.1,-0.1)

except:
    print('erreur')
    
finally:
    #hub.disconnect()
    #print('hub deconnectee')

    print('Fin ok')