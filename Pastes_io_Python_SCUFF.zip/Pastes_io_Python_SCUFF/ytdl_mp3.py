from pyrogram import Client, filters
import yt_dlp
import shutil
import os


app = Client(
    "sample bot",
    api_id=23951485,
    api_hash="1b0ed878b1df1665f7f370453cd44125",
    bot_token="6332723336:AAG7cT9VHx08bAxI7Xbiwzf28dgrWCsfUks",
)


@app.on_message(filters.command("start"))
async def start(app, message):
    await app.send_message(
        message.chat.id,
        "Ready to groove? Drop your YouTube link, and I'll convert it to MP3 in a snap! 🎵😊",
    )
    print(message.chat.id)


@app.on_message(filters.text)
async def authorised_user(app, message):
    if message.chat.id in [5948556591, 557639247]:
        url = message.text
        if "youtu.be" in url or "youtube.com" in url or "www.youtube.com" in url:
            folder_name = f"{message.chat.id}"
            ydl_opts = {
                "format": "bestaudio/best",
                "outtmpl": os.path.join(folder_name, "%(title)s.%(ext)s"),
                "postprocessors": [
                    {
                        "key": "FFmpegExtractAudio",
                        "preferredcodec": "mp3",
                        "preferredquality": "192",
                    }
                ],
            }
            msg = await message.reply_text("Downloading...")
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                ydl.download([url])
                await msg.edit_text("Uploading...")
                for filename in os.listdir(folder_name):
                    audio_file = os.path.join(folder_name, filename)
                    await message.reply_audio(audio=audio_file)
                shutil.rmtree(folder_name)
                await msg.delete()
        else:
            await app.send_message(message.chat.id, "Not a valid yt link")
    else:
        await app.send_message(message.chat.id, "Not an Authorized User")


print("I am alive")

app.run()