from flask import Flask, request
import requests
import json
import datetime
import ydb

app = Flask(__name__)

# Настройки Contrail
host = 'contrail.host.com'
port = '8082'
auth = ('user', 'password')

# Настройки YDB
endpoint = 'ydb.endpoint.com'
database = 'operations'

# Инициализация соединения с YDB
driver_config = ydb.DriverConfig(endpoint=endpoint, database=database)
driver = ydb.Driver(driver_config)
session = driver.table_client.session()

# Метод для создания виртуальной сети в Contrail
def create_network(name, subnet):
    url = f'http://{host}:{port}/virtual-networks'
    headers = {'Content-Type': 'application/json'}
    data = {
        "virtual-network": {
            "fq_name": ["default-domain", name],
            "parent_type": "project",
            "address_allocation_mode": "user-defined-subnet-only",
            "network_ipam_refs": [
                {
                    "subnet": {
                        "ip_prefix": subnet,
                        "ip_prefix_len": 24
                    },
                    "subnet_uuid": "subnet:uuid-for-subnet",
                    "attr": {
                        "host_routes": [],
                        "allocation_mode": "user-defined-subnet-only"
                    }
                }
            ]
        }
    }
    response = requests.post(url, headers=headers, auth=auth, json=data)
    if response.status_code == 200:
        return True
    else:
        return False

# Метод для сохранения информации о созданной сети в таблицу operations в YDB
def save_operation(name):
    dt = str(datetime.datetime.now())
    query = f'PRAGMA TablePathPrefix("{database}");\n' \
            f'UPSERT INTO operations (name, created_at) VALUES ("{name}", TIMESTAMP("{dt}"));'
    session.transaction().execute(query)

# API-метод для создания виртуальной сети в Contrail и сохранения информации в YDB
@app.route('/create_network', methods=['POST'])
def create_network_api():
    name = request.json['name']
    subnet = request.json['subnet']
    if create_network(name, subnet):
        save_operation(name)
        return json.dumps({'success': True, 'message': f'Network {name} was created.'}), 200
    else:
        return json.dumps({'success': False, 'message': f'Failed to create network {name}.'}), 400

if __name__ == '__main__':
    app.run()