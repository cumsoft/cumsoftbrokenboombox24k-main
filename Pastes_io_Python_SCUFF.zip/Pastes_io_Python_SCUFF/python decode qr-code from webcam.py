# conda/envs/qrcode/bin/python conda/envs/qrcode/~qrcode/decqr.py

import cv2
from pyzbar import pyzbar

def decode_qrcodes(frame):
    return pyzbar.decode(frame)

def format_text(data):
    def format_text_as_raw(data):
        groups = list()
        for index in range(0, len(data), 16):
            groups.append(list(map(lambda x: '{0:2x}'.format(x), data[index:index+16])))
        return '\n'.join(map(lambda group: ' '.join(group), groups))
    def format_text_as_unicode(data):
        return '\n'.join(map(lambda x: repr(x.decode('utf-8'))[1:-1], data.split('\n'.encode('utf-8'))))
    text = {
        'as_raw': format_text_as_raw(data),
        'as_unicode': format_text_as_unicode(data),
    }
    return text


def video_loop():
    video_capture= cv2.VideoCapture(0)
    while True:
        ret, frame = video_capture.read()
        if not ret:
            raise cv2.error('video capture fail')

        cv2.imshow('Scan QR Code', frame)
        key = cv2.waitKey(100)  # msec
        if key == ord('q'):
            break

        try:
            qrcodes = decode_qrcodes(frame)
            assert qrcodes
            for index, qrcode in enumerate(qrcodes):
                text = format_text(qrcode.data)
                print('# {0:d}'.format(index), '## as_raw', text['as_raw'], '## as_unicode', text['as_unicode'], sep='\n')
            break
        except Exception as exc:
            pass
    cv2.destroyAllWindows()
    return

if __name__ == '__main__':
    video_loop()