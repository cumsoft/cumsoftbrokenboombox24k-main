class Register:
	def __init__(self,name,surname,age,email,password,correctpass):
		self.name=name
		self.surname=surname
		self.age=age 
		self.email=email 
		self.password=password 
		self.correctpass=correctpass
reg=Register("Enter name","Enter surname","Enter age","Enter email","Enter password","Correct password")
PersonInfo={
	"name":reg.name,
	"surname":reg.surname,
	"age":reg.age,
	"email":reg.email} 
RegisterPerson=["Salih26","salih**00"]
class Login:
	def __init__(self,nickname,password):
		self.nickname=nickname 
		self.password=password 
	def ForgotPassword():
		newpass=input("Please enter new password")
		correct1=input("Correct password")
		if newpass!=correct1:
			while True:
				newpass=input("Please enter new password")
				correct1=input("Correct password")
		else:
			print("Your password has been successfully reset")
			NewRegisterPerson=[newpass]
			RegisterPerson[1].update(NewRegisterPerson)
	def Verification():
		verify=input("33678\nPlease enter the number on the screen")
		if verify=="33678":
			choices=input("Login or reset password")
			if choices=="login":
				print("You're welcome",log.nickname,"") 
			elif choices=="reset":
				ForgotPassword()
	def loginn():
		log=Login("Enter nickname","Enter password")
		number=1
		n_name=input(log.nickname)
		p_word=input(log._password) 
		if n_name!=RegisterPerson["nickname"] or p_word!=RegisterPerson["password"]: 
			while True:
				print("Wrong nickname or password,please try again.") 
				n_name=input(log.nickname)
				p_word=input(log._password) 
				number +=1
				if number >5:
					print("You have exceeded the maximum number of attempts.\nYou are being redirected...")
					Verification()
		else:
			print("You're welcome",log.nickname,"") 
	def registerr():
		Name=input(reg.name)
		Surname=input(reg.surname) 
		Age=input(reg.age)
		if int(Age)<=18:
			print("You must be over 18 to continue")
			while True:
				Age=input(reg.age)		
		else:
			Email=input(reg.email) 
			Pass=input(reg.password) 
			Pass1=input(reg.correctpass) 
			if Pass!=Pass1:
				while True:
					print("Passwords do not match")
					Pass=input(reg.password) 
					Pass1=input(reg.correctpass) 
			else:
				print("You have successfully registered. You are being redirected to the home page") 
				RegisterPerson.append(reg.password) 
				RegisterPerson.append(reg.nickname) 
	def loginscreen():
		a=input("Welcome.Please register or login [enter r or l]") 
		if a=="l":
			loginn()
		elif a=="r":
			registerr()